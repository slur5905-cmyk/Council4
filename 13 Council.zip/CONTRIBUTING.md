# Contributing

This is an experimental local-first project. Keep changes small, explain the risk boundary they affect, and add a regression test for each confirmed defect.

Before submitting changes, run:

```bash
python -m pytest -q
python -m compileall -q main.py offline_coder tests tools
python tools/check_iphone_js.py
python tools/check_browser_app.py
node tools/check_browser_logic.mjs
python tools/check_mobile_app.py
```

When Docker is available, also run `python tools/docker_fixture_smoke.py`. It is expected to fail closed if Docker or the required images are unavailable. Do not label project-controlled test output as trusted host attestation. Do not weaken workspace write safeguards, self-edit allowlists, research consent, or manual Apply.
