from offline_coder.app import launch_app

if __name__ == "__main__":
    launch_app()
