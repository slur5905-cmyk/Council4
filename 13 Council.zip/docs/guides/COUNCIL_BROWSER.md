# Council Browser (experimental)

Council Browser provides a real Chromium browser through optional Playwright. It runs in a separate browser process/context and does not use the Council coding workspace.

## Install

```bash
pip install -e ".[browser]"
playwright install chromium
```

No paid AI API is used. Playwright controls the browser; the configured local model(s) make decisions.

## Capabilities

- Navigate to public HTTP(S) websites and inspect rendered text and visible links/controls.
- Click controls, fill ordinary text fields, and select dropdown options.
- Create one shared observation packet and four role-specific prompts (Architect, Correctness, Security, Red Team).
- Keep a bounded action history and save declarative workflow descriptions without storing form values or credentials.

Example:

```python
from offline_coder.council_browser import CouncilBrowser, peer_observation_prompts

# Supply a real approval dialog from the host UI.
browser = CouncilBrowser(approval=lambda description: ask_user_to_approve(description))
with browser:
    browser.navigate("https://docs.python.org/3/")
    shared = browser.research_packet()["architect"]
    prompts = peer_observation_prompts(shared)
    # Send each prompt to the matching configured local peer model.
```

`ask_user_to_approve` is a placeholder, not a supplied function.

## Safety boundaries

- Only public HTTP(S) destinations are accepted. Loopback, private, link-local, reserved, localhost, and `.local` destinations are blocked, including DNS resolutions to private addresses.
- Browser downloads are disabled/cancelled; file uploads are not exposed; password, hidden, file, email, phone, and numeric inputs are not fillable.
- Form entry requires approval. Buttons and controls inside forms require approval before clicking.
- No arbitrary JavaScript execution interface is exposed.
- Browser cookies and storage are not persisted between sessions; the browser does not read the Council workspace.
- Website text is untrusted data. All peers are instructed not to follow instructions embedded in pages.
- This is defense-in-depth, not a hardened remote-browser sandbox. Do not use for banking, purchases, account administration, or other high-impact actions.

## Not yet complete

This release adds the browser engine and shared peer-observation interface. A polished in-app browser panel, automatic local-model action loop, persistent documentation capture, and end-to-end browser integration tests remain future work. The host must supply a real approval callback.
