# Optional Advanced Features

The Council's core code-review workflow does not need host telemetry or a persistent expansion database. These features are therefore disabled by default.

Enable **Advanced features** in Local setup only when you want:

- Host CPU/RAM/GPU/network/storage telemetry and adaptive worker limits.
- A local SQLite store with integrity-checked searchable memories.
- Resumable task checkpoints.
- Local tool discovery for reporting available tools.

The database limit defaults to 128 MiB. It is configurable and bounded. Disabling the option uses a no-op store and does not create or change the persistent expansion database. Existing database files are not deleted when the option is turned off.

These are continuity and diagnostics features. They do not upgrade model weights, add new coding knowledge to the underlying model, or prove better reasoning. Evaluate model quality separately with repeatable benchmarks.
