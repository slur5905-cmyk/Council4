# Multi-Model and Role Specialization

## Default truth

The default Council is **one configured model and four role prompts**. The roles are Architect, Correctness, Security, and Red Team. Different prompts can encourage different review lenses, but do not create separate model weights, training histories, or independent model families. The Council UI and reports should disclose this.

## Assigning different local models

The desktop UI accepts per-role assignments. In GGUF mode, each role can use a different local `.gguf` file. In local-server mode, role-specific model IDs can be selected from the configured loopback server. Remote servers are not accepted by the desktop router. No paid provider or hosted model API is required.

## Memory and scheduling

The model manager loads local GGUF models on demand and reuses the same instance when assignments point to the same model. Its resident-model limit defaults to one. Multiple distinct model instances can be scheduled concurrently only when configured and allowed by the resource limit; calls sharing an instance are serialized. More resident models consume more memory and are not automatically more intelligent.

## Measuring diversity and quality

Different model paths/IDs only show that different model instances are configured. They do not prove different training families, non-overlapping training data, independence, or correctness. To measure useful diversity, run the same benchmark tasks across each model and compare factual accuracy, code correctness, defect detection, calibration, and reproducibility. Keep the actual model IDs, versions, settings, and test evidence in the report.

## Browser companion

The browser companion is separate from the desktop GGUF router. It uses a small browser model/runtime, with model weights downloaded on first use. Its four-role interface must not be described as four independent models.
