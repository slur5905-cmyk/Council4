# Adaptive Scaling Implementation Report

**Validation date:** 2026-11-06  
**Cost policy:** No paid inference API, cloud upgrade, or model download was used.

## What is implemented

- **Hardware discovery:** Reports RAM (including container/cgroup limits where available), effective CPU count and architecture, process memory, storage, NVIDIA GPU/VRAM when `nvidia-smi` is available, local network interfaces/default route, configured model, and active/available peer-worker counts. The resource monitor samples every 10 seconds by default (minimum 5 seconds).
- **Resource-aware scheduling:** Concurrency is capped according to available memory; this changes parallelism, not whether a task may be attempted. Identical model assignments reuse one adapter and serialize access to the shared instance; separately configured local models can collaborate concurrently within the worker cap.
- **Evidence-based model ranking:** Candidate ranking separates observed score from a conservative evidence-adjusted score. Missing dimensions receive a neutral prior rather than being omitted from the ranking denominator; task selection requires the relevant coding/reasoning dimension to have an actual measurement. Coverage and provisional-vs-broad evidence notes are exposed. RAM, VRAM, and context fit remain separate from quality; parameter count is not a quality proxy.
- **Memory freshness/conflict handling:** Retrieved memory now carries age and stale flags; competing active entries with the same project, type, and summary are marked as conflicts. Superseded versions are excluded from normal retrieval while remaining in append-only history. Council prompts warn against relying on stale or conflicting memory without re-verification.
- **Model independence transparency:** Every run reports whether peers share one model instance or use multiple instances. The profile explicitly states that separate instances do not establish separate model families or independent correctness.
- **Mobile access hardening:** The local companion caps handler concurrency, applies per-client general/failed-authentication/action rate limits, validates POST content length and JSON content type, and supports TLS. Plaintext access on a non-loopback interface now requires an explicit `--allow-insecure-lan` opt-in.
- **Local fallback:** A role-specific local model gets one attempt; if it fails, the configured primary local model gets one fallback attempt. Both failures are surfaced, and successful fallback events are recorded.
- **Long-task recovery:** Council phase results and context are saved in integrity-checked, redacted SQLite checkpoints. Resume restores completed phases rather than repeating them, and checks a workspace-context fingerprint before reuse; a changed or unverifiable workspace restarts fresh analysis. Resource/model errors are classified and checkpointed. Retries are bounded rather than endless.
- **Cost and network boundaries:** Inference is through a local GGUF model or a verified loopback server. The system does not download models, provision compute, or call a hosted AI API. Network discovery checks local interfaces/routes only; it does not test Internet access.

## Verification results

| Check | Result | What it establishes |
|---|---:|---|
| Python tests | **188 passed, 27 subtests passed** | Deterministic regression coverage, including ranking coverage, task-specific measurement, memory staleness/conflicts, and mobile request limits. |
| Python compile | **Passed** | `offline_coder` and `tools` compile with the active interpreter. |
| Package wheel | **Passed** | Wheel built successfully; packaged Council code includes workspace-fingerprint and phase-resume changes. |
| Adaptive host benchmark | **10/10 checks passed** | Deterministic hardware/resource, evidence-aware model ranking, worker-limit, checkpoint, context, memory-integrity, and safety contracts. |
| Host benchmark runtime | **1.323 seconds** | Time for the deterministic host lane on this machine; not model inference throughput. |
| Host benchmark process peak-RSS delta | **8,470,528 bytes** | The benchmark process measurement; not model memory use. |
| Model-quality benchmark | **NOT_RUN** | No model file or served model was configured; answer quality, switching quality, latency, throughput, and inference memory are unmeasured. |

The host benchmark checks test deterministic software contracts, not the quality of model reasoning.

## Observed validation host

- Linux x86_64; 2 logical CPU cores (1 physical core reported).
- RAM: 7.76 GiB total, 3.23 GiB available at the snapshot.
- Storage: 18.75 GiB free at the snapshot.
- GPU: **unknown**. No supported discovery tool was found; this is not evidence that no GPU exists.
- A default route and local interfaces were visible; Internet connectivity was not tested.
- The detected profile was `constrained`, with an adaptive peer-worker cap of **1** against a configured limit of 4.
- No local model path was configured.

Snapshots are time-specific and will differ on other hosts. GPU discovery currently uses `nvidia-smi`; compatibility estimates based on GGUF file size do not prove a model will load. Actual context usage is not reported by the configured inference backends.

## Limitations and remaining work

- Real model benchmarks are still required to compare coding/reasoning correctness, context behavior, tool-use reliability, speed, and resource use. The six model cases are intentionally left `NOT_RUN` without a supplied local inference model; this environment did not have one configured. Comparisons should use identical tasks and settings and independent scoring.
- Candidate ranking is available as an evidence-based recommendation mechanism; it cannot recommend a best model until a task-specific benchmark score and resource-fit evidence are available. A narrow benchmark can produce only a provisional ranking. Role routing and fallback use configured local models, not automatic model downloads or an unverified model catalog.
- Specialist fallback handles one failed call; it does not automatically retry with multiple strategies, decompose arbitrary tasks, or escalate through an unlimited model ladder.
- A checkpoint restores completed phases, not an interrupted inference request. The SQLite database is local to the application data directory; it survives stopping and restarting the same persistent Codespace, but is not synchronized or guaranteed to survive Codespace deletion or loss of its disk.
- Checkpoint state has a bounded size. Redaction covers common credential patterns but is not a guarantee that arbitrary sensitive text can never be stored.
- RAM-based concurrency is conservative and does not model every backend's KV-cache, driver, or fragmentation requirements. A model can still fail to load or exhaust resources.
- Free compute is not assumed or provisioned. Model files must be supplied by the user after checking storage, licensing, and compatibility.
