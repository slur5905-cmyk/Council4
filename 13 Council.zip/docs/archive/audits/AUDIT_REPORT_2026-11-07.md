# 9 Council v1.5.1 — Security and Reliability Audit

**Audit date:** 2026-11-07  
**Audited source:** Expanded v1.5 package, updated as v1.5.1 after remediation  
**Verdict:** Important verification and filesystem-handling defects were corrected. This remains an experimental local-first project and is **not security-certified or release-certified for unattended operation**.

## Executive summary

The v1.5 codebase had passing unit tests but several test-evidence trust gaps that those tests did not cover. The most important was that project-controlled test code could imitate success output or terminate the Python test-discovery process early. The candidate-comparison path also treated a plain 64-character SHA-256-looking string as a host attestation, although no cryptographic attestation verifier existed.

The v1.5.1 audit patch changes these behaviors conservatively. Python project tests are now reported as diagnostic-only (`UNTRUSTED_TESTS`), malformed/empty Node test evidence cannot be promoted to a pass, candidate selection abstains without independent host evidence, and unattended Apply is unconditionally disabled until a real host-owned attestation channel is implemented. Manual, explicitly user-confirmed Apply remains available behind the existing approval and path-safety gates.

## Findings and remediation

| Severity | Finding | Remediation / current status |
|---|---|---|
| High | Project-owned Python test code could print expected success markers or terminate discovery with a zero exit, causing self-reported output to be mistaken for test evidence. | **Fixed conservatively.** Python project test output is diagnostic-only and is labeled `UNTRUSTED_TESTS`, never host-verified `PASSED`. |
| High | Candidate selection accepted caller-supplied `host-controlled` fields and any 64-character SHA-256-shaped string as an attestation. A digest format check is not authentication. | **Fixed conservatively.** Candidate evidence is always ineligible until a real independent signer/verifier exists; selection abstains. A fake hash regression test was added. |
| High | Unattended Apply relied on the same non-authenticated evidence shape. | **Fixed conservatively.** `can_autonomously_apply` always returns false in this release. Users can still review and manually confirm a proposal. |
| Medium | Node test summaries could be spoofed by project console output, and empty test files could be counted as successful synthetic file records. | **Fixed.** The parser reads the final exact runner summary and requires actual registered test records and at least one non-skipped pass. |
| Medium | Visual output under `.council/visual-runs` could follow a symlinked `.council` directory or unsafe child directory. | **Fixed.** Managed output directories and their parents are checked; symlink and external output paths are rejected. |
| Medium | Visual and simulation manifests could be symlinked or unbounded. | **Fixed.** Both require regular non-symlink files and enforce a 1 MB limit; proposed manifest text is also bounded. |
| Medium | Repository and workspace scanners excluded private/generated directory names case-sensitively, so case variants could be traversed on case-sensitive filesystems. | **Fixed.** Shared directory-exclusion checks are case-insensitive across workspace context, project inventory, repository analysis, supply-chain scanning, and test snapshots. |
| Medium | `tomllib` was imported unconditionally despite the package advertising Python 3.10 support. | **Fixed in package metadata and source.** Python 3.10 uses the conditional `tomli` dependency; CI now has a Python 3.10–3.12 matrix. Python 3.10 itself was not available in this audit container, so that CI leg remains to be observed. |
| Medium | Seven GitHub Actions references use mutable version tags rather than immutable commit SHAs. | **Open advisory.** Pin each action to a reviewed full commit SHA and update deliberately. |

## Verification performed

- `python -m pytest -q`: **227 passed, 44 subtests passed**.
- `python -m compileall -q main.py offline_coder tests tools`: passed.
- `python tools/check_iphone_js.py`: passed.
- `python tools/check_browser_app.py`: passed; JavaScript syntax, 67 unique DOM IDs, labels, preview sandbox, URL-import and runtime-reference guards.
- `python tools/check_mobile_app.py`: passed; JavaScript syntax, 12 unique IDs, labels, auth and localhost-default guards.
- `node tools/check_browser_logic.mjs`: **9 checks passed**.
- Current deterministic host benchmark: **10/10** checks passed. The report is saved at `benchmarks/results/council-v1.5.1-host-2026-11-07.json`.
- Built a Python wheel successfully as `offline_coding_council-1.5.1-py3-none-any.whl`; verified its metadata (`Requires-Python: >=3.10`, conditional `tomli` dependency) and that all **104 knowledge modules** are packaged. The knowledge README is additional documentation, not counted as a module.
- Knowledge inventory: **104 modules, 35,305 words, 277,240 bytes**. The same Markdown source is embedded into the standalone browser app; the sync tool reports 104 modules and 35,305 words.
- Supply-chain inventory completed for the Council source: 2 dependency manifests, 1 lockfile, 7 declared components, and 7 mutable GitHub Actions tag findings.

## Tests that could not be fully executed

- Python in this audit container is 3.13.5; no Python 3.10 interpreter was installed. The compatibility fix is present in source and wheel metadata, and the CI matrix requests 3.10, but the remote CI run was not observed here.
- Docker is not installed. Consequently, this audit did **not** execute arbitrary project code in the configured Docker runner. Tests around the runner use controlled test doubles and validate its reporting and argument construction; they are not a substitute for a real Docker runtime test.
- Playwright and a system Chromium binary are installed. A direct headless Chromium `set_content` smoke test succeeded. The Council's own visual runner attempted three viewport runs (390×844, 768×1024, and 1365×900), but this environment blocked its loopback HTTP navigation with `ERR_BLOCKED_BY_ADMINISTRATOR`; all three were marked `SKIPPED` and no screenshots were produced. This is an environment restriction, not a browser test pass.
- No model weights or local inference server were configured. The 12 model-quality benchmark cases remain `NOT_RUN`. A 10/10 deterministic host score is not an AI reasoning-quality score.
- No physical iPhone, Android device, distinct GPU configuration, Unity/Unreal runtime, or complete native compiler matrix was tested.

## Remaining limitations and risks

1. **No independent host-test attestation exists.** Candidate comparison intentionally abstains and unattended Apply stays disabled. The current evidence envelope contains hashes for traceability; it is not a signature and must not be described as cryptographic proof.
2. **The supply-chain tool is an inventory and workflow heuristic, not a live vulnerability, license, malware, or fully resolved transitive-dependency scan.** The seven mutable-action findings remain open.
3. **Python repository intelligence is a partial AST-based index.** It is not a complete language-server or whole-program semantic graph; dynamic dispatch, generated code, and non-Python languages remain incomplete.
4. **The 27 extension entries are descriptive templates, not executable plugins.** They do not autonomously install tools or grant new permissions.
5. **The self-improvement lab records and compares experiments.** It does not freely rewrite, deploy, or promote its own source.
6. **The offline computing foundation is broad but finite.** 104 modules and 35,305 words cannot contain every programming language, API version, library, hardware manual, standard, research result, proprietary system, or future discovery. It is retrieval context, not model-weight training or a foundation model.
7. **The local mobile companion's plaintext LAN option is intentionally opt-in.** Use HTTPS or a VPN; do not expose it to public Wi-Fi or port-forward it to the internet.
8. **The four Council roles may share one underlying model.** Four role prompts or four votes are not four independent trained intelligences and do not prove correctness.

## Overall assessment

**Suitable for continued private development and careful manual testing; not suitable to describe as fully verified, secure, or autonomously self-improving.** The most important improvement in v1.5.1 is that the Council no longer treats project-controlled test output or a hash-shaped string as independent proof. Keep the repository private while experimental, back up important projects, inspect proposals before Apply, and run the CI matrix plus real Docker/browser/model tests in the target environment before relying on it.
