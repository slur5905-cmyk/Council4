# Offline Coding Council — Expanded v1.5 Upgrade Report

**Build date:** 2026-11-07  
**Source:** `9 Council.zip` supplied for this update  
**Design goals:** stronger reasoning evaluation, better codebase understanding, competing implementations, responsive browser testing, evidence-based self-improvement, broader capability coverage, stronger supply-chain review, and a substantial offline computer-science foundation.

## Summary

The supplied Council source has been extended while preserving its local-first model architecture, four equal peer roles, explicit user approval for file changes, existing workspace boundaries, and no-paid-API approach.

The current build includes **104 curated offline computing modules** with approximately **35,216 words** of foundational engineering material. The desktop/phone-host Council retrieves a bounded, relevant subset for each task. The standalone phone/browser HTML app embeds the same exact 104 modules and performs its own bounded retrieval. The HTML bundle is regenerated from the Markdown source using:

```bash
python tools/sync_universal_knowledge.py
```

The knowledge base is intended to be a useful offline foundation, not a claim that a static archive can contain literally every programming fact, every version of every API, every package, hardware manual, standard, proprietary system, research paper, or future discovery. Retrieval provides context to the configured model; it does not retrain the model's weights or give a small model capabilities it does not possess.

## Implemented changes

### 1. Expanded computing and coding knowledge

- Expanded the offline library from 83 to **104 focused modules** and approximately 35,216 words by adding 21 modules on computation theory, proofs/type theory, statistics, optimization, microarchitecture, virtual memory/NUMA, Linux/Unix, Windows/macOS, IP routing/wireless, web security, cryptographic protocols/PKI, cloud infrastructure, streaming/event systems, static analysis, language-server tooling, frontend frameworks, native mobile engineering, computer vision, audio DSP, real-time safety-critical engineering, and local model inference.
- Expanded content on language implementation, parsing, ASTs, interpreters, bytecode VMs, compiler optimization, JITs, linkers and ABIs, garbage collection, ownership and object lifetimes, operating-system scheduling and IPC, database storage and transaction recovery, distributed consensus and fault tolerance, API contracts and compatibility, defensive security engineering, GPU/HPC, CPU caches and memory ordering, algorithm analysis, architecture, testing, and package ecosystems.
- Improved abbreviation handling and task-aware lexical retrieval, with bounded ranking, title/heading emphasis, excerpts, and content hashes.
- Desktop and standalone browser editions share the same modules. A regression test checks that the embedded browser JSON is identical to the Markdown sources.
- Only a small task-relevant slice enters the active context; the whole corpus is not pasted into every prompt.

### 2. Deeper repository understanding

- Python AST analysis now extracts conservative call and inheritance relationships, source locations, and uniquely resolved local symbol references.
- The project report includes call relationships, unresolved/ambiguous markers, inheritance relationships, and limited call-impact hints.
- The analysis remains incomplete for dynamic dispatch, reflection, monkey-patching, generated code, and languages without equivalent parsing. It is not a full compiler or language-server index.

### 3. Competing implementations

- Eligible build tasks can produce up to three candidate approaches using different proposer roles.
- Candidate files receive host-side path validation and tests against separate disposable project snapshots.
- Candidate drafting can run with limited parallelism only when distinct model instances and the adaptive resource governor permit it; otherwise it is sequential.
- The host compares exact candidate hashes and nested test coverage. Contradictory or incomplete results cannot win. It may abstain when no candidate has usable passing evidence.
- The selected candidate still goes through the normal review and approval path. There is no automatic application, and this is not yet a Git-worktree branch/merge coordinator.

### 4. Responsive browser and visual checks

- The optional Playwright runner supports up to five named viewport profiles, each in its own browser context.
- It records independent screenshots/reports, browser exceptions, console errors, blocked external requests, and horizontal overflow.
- Approved PNG baselines can be compared when Pillow is installed. Pixel thresholds are bounded, path validation is enforced, and baselines are never modified automatically.
- A missing/blocked browser runtime is reported as `SKIPPED`, not as a passing visual test.

### 5. Intelligence benchmark v1.5

- Expanded the model benchmark to **12 coding/reasoning cases**.
- Added 1–10 repeated trials, isolated trial workspaces, repeat identifiers, and per-case median timing.
- Comparison now requires the same benchmark version, case-set hash, runner hash, model configuration, and repeat count. Every trial must be human-scored, and repeated trials are paired by case and repeat index.
- A model is not rated correct merely because it sounds confident or produces a long answer.
- The experiment comparison can record eligible improvements in the existing Self-Improvement Lab. Explicit user approval is required for future evaluation; no code is automatically promoted, deployed, or used to change permissions.

### 6. Test evidence and supply-chain checks

- Host-generated test evidence binds the candidate and changed-file hashes, retains nested check results, and rejects malformed or internally contradictory summaries.
- Compiler/toolchain availability is reported separately from actual compilation/testing; tool detection is not represented as a successful compiler run.
- Exact pinned dependency versions receive package URLs in the CycloneDX inventory. Ranges and floating versions are not falsely represented as resolved pins.
- A read-only GitHub Actions heuristic flags privileged pull-request triggers, overly broad workflow permissions, mutable action references, and persisted checkout credentials.
- These are advisory checks, not a live CVE database scan, complete SBOM resolution, formal attestation, or security certification.

### 7. Benchmark and evidence hardening

- Benchmark version 1.5 now fingerprints every regular file under `offline_coder/`, including nested modules and Markdown knowledge package data. A knowledge-only change can no longer appear to have the same source-tree fingerprint as an unchanged Python package.
- Candidate tournament selection now requires non-empty nested host check evidence. A top-level `PASSED` with no child checks, malformed children, skipped checks, or contradictory child statuses is rejected.
- Evidence normalization now treats malformed child check objects and empty/missing nested checks on a top-level PASS as invalid evidence instead of raising an exception or silently accepting the summary.
- The universal browser checker now distinguishes executable JavaScript from the embedded JSON knowledge data block; it verifies exactly one application script and exactly one knowledge-data block.

### 8. Broader capability templates

- Expanded the extension/capability catalog to **27 domain templates**, including toolchains, databases, distributed systems, networking, mobile/desktop development, data science, AI/ML, formal methods, accessibility, robotics, graphics, media, quantum fundamentals, and hardware.
- These entries are design templates and capability descriptions only. They are not executable plugins and do not grant shell, unrestricted filesystem, network, credential, or host permissions.

## Verification performed

| Check | Result |
|---|---|
| Python automated test suite | **211 passed, 44 subtests passed** |
| Python bytecode compilation (`offline_coder/*.py`, `tools/*.py`) | Passed |
| Browser application and iPhone JavaScript syntax and static checks | Passed |
| Browser logic and knowledge retrieval smoke test | Passed; 9 logic checks; GPU/HPC, GC/JIT, and API-contract queries |
| Browser embedded knowledge consistency test | Passed; exact match to all 104 Markdown source modules |
| v1.5 deterministic host benchmark | **10/10 passed** |
| Python wheel build | Passed; wheel contains all 104 knowledge modules |
| ZIP integrity and contents | Verified during packaging |

### Important unverified items

- The 12 model-quality benchmark cases are `NOT_RUN`: no configured GGUF model weights or local model server were supplied in this environment. The 10/10 host benchmark checks deterministic host-side behavior, not model intelligence.
- The local browser policy blocked Chromium navigation to the temporary loopback test page. The responsive two-viewport smoke test correctly returned `SKIPPED` and produced no screenshots. Run it on the target computer with Playwright/Chromium permitted.
- Physical iPhone/iPad use, real GPU acceleration, inference throughput on the user's hardware, and native Unity/Godot/Unreal testing were not performed.
- Compiler discovery is not a proof that every detected compiler works; native builds were not run here.
- No live dependency vulnerability database scan, independent penetration test, or full resolved-runtime SBOM audit was performed.

## Boundaries intentionally preserved

- The configured local model remains the source of model inference. No paid API or cloud-inference dependency was added.
- The four peer roles may still share one underlying model and therefore share some blind spots. More role prompts do not create independent model families.
- Memory and lessons are retrieval/context aids, not automatic model-weight learning.
- The Council does not grant itself new host permissions, remove its own safety gates, or silently apply self-modifications.
- Human review and confirmation remain required for project writes.
- Hardware limits remain physical: software scheduling can use available CPU/RAM/GPU more intelligently but cannot create additional compute capacity.

## Overall assessment

The updated Council has broader offline technical references, better Python code relationship analysis, an evidence-based candidate tournament, more rigorous repeated model benchmarking, responsive browser-test support, stronger evidence envelopes, and more useful supply-chain review. It is materially more capable and testable than the supplied snapshot, but it should not be described as infallible or as possessing every fact about computing. Its actual coding performance will still depend on the chosen model, context limit, available hardware, current documentation, and tests run against the target environment.
