## 2026-11-07 — v1.6.0 peer communication and model manager

- Implemented persistent peer messages, direct requests, code challenges, investigations, recipient replies, and requester follow-ups.
- Implemented retrieval and bounded continuation of related unresolved discussions across runs.
- Implemented bounded component-level contributions for planned code/build/debug subtasks; proposer integration and normal review gates remain required.
- Implemented provisional disagreement lessons with explicit user verification/rejection. No automatic model-weight training occurs.
- Implemented lazy LRU loading for local GGUF peer models with a configurable 1–4 resident-model cap (default 1). Local-server role-specific routing remains supported.
- Added desktop settings and a Peer communication results tab.
- Verification in this build is limited to local automated tests and deterministic fake-model orchestration; actual model-quality, hardware memory and target-machine inference tests remain separate.

# Coding Council feature status — 2026-11-07

> Current release status is recorded first. Older dated sections below are historical snapshots and may describe earlier implementation states. “Implemented” means code exists; it does not mean every runtime/platform has been independently validated.

## 2026-11-07 — v1.5.1 hostile-audit corrections

- [x] Fixed Python 3.10 metadata/runtime mismatch by using the conditional `tomli` fallback and adding a Python 3.10–3.12 CI matrix. Python 3.10 itself was unavailable in this audit container, so the runtime leg remains awaiting CI execution.
- [x] Visual artifact output now refuses a symlinked `.council` directory and unsafe output subdirectories. Visual and simulation manifests reject symlinks/special files and enforce a 1 MB size limit.
- [x] Workspace indexing, inventory, supply-chain scanning, and disposable snapshots now exclude private/generated directory names case-insensitively (for example `.GIT`, `.COUNCIL`, `Node_Modules`, and `.VENV`).
- [x] Python project-owned test output is now diagnostic-only (`UNTRUSTED_TESTS`), because project tests can print fake success markers or terminate test discovery early. Node test parsing uses the final runner summary and rejects empty/synthetic file-only passes.
- [x] Removed the false attestation acceptance path: a 64-character hash-shaped string plus `host-controlled` fields is not proof. Candidate comparison now abstains, and unattended Apply remains disabled until a real independent host signer/verifier and acceptance-test channel exist. Manual, user-confirmed Apply remains available.
- [x] CI now runs the universal browser logic test script.
- [x] Re-audit verification: **227 pytest tests and 44 subtests passed**; Python compilation, iPhone JavaScript, browser app, mobile companion, and 9 browser-logic checks passed. Current deterministic host benchmark: **10/10**; 12 model-quality cases remain `NOT_RUN`.
- [~] Actual Docker-isolated code execution was unavailable because Docker is not installed in the audit environment. The Playwright runner was exercised, but the host policy blocked its local HTTP navigation, so responsive screenshots remain unverified.
- [~] Supply-chain review reports seven medium findings for mutable GitHub Actions version tags. Pin reviewed actions to full commit SHAs. The inventory is not a live CVE/license scanner and does not resolve every transitive dependency.

---

## 2026-11-07 — v1.5 expanded intelligence and computing foundation

- [x] Expanded the curated offline computer-science foundation to 104 modules (35,305 words at this build) spanning programming languages, algorithms, data structures, systems, compilers, OS, hardware, networking, databases, distributed systems, security, testing, formal methods, AI/ML, graphics, robotics, embedded systems, operations, and more. Retrieval is bounded, task-aware, integrity-hashed, and explicitly non-exhaustive. This is reference context, not model-weight training or a claim to contain literally all computing knowledge.
- [x] Python repository analysis now records conservative call and inheritance relationships, uniquely resolvable local references, source locations, and call-impact clues. Dynamic dispatch, reflection, generated code, and other languages remain incomplete.
- [x] Eligible build tasks can draft up to three alternative implementations with different proposer roles. Candidates receive independent path checks and disposable-copy diagnostics; limited parallel drafting requires distinct model instances and available resources. The current build always abstains from declaring a verified winner because no host attestation verifier exists. This is not a Git-worktree merge system and does not auto-apply changes.
- [x] Desktop visual runner accepts up to five responsive viewport profiles, runs each in a separate browser context, captures separate screenshots, records horizontal overflow, and can compare against approved PNG baselines when Pillow is available. Baselines are never updated automatically.
- [x] Model benchmark v1.5 contains 12 model reasoning/coding cases, supports 1–10 repeats, stores per-trial outcomes, and pairs repeat-indexed human-scored trials for comparisons. Comparisons require matching case/runner/model/repeat configuration and passing host checks.
- [x] A host-generated integrity envelope binds runner output and changed-file hashes for traceability. It is explicitly not a cryptographic attestation and cannot authorize unattended writes or candidate selection.
- [x] Supply-chain inventory adds package URLs for exact pinned dependencies and a read-only heuristic review of GitHub Actions workflow permissions, privileged PR triggers, mutable action refs, and persisted checkout credentials. This is not a live CVE scanner.
- [x] Capability catalog expanded to 27 domain templates. Entries are descriptive capability recipes, not executable plugins and do not grant permissions.
- [x] Validation: `python -m pytest -q` — 227 passed, 44 subtests passed; Python bytecode compilation passed; universal browser app passed its executable-script syntax and runtime-reference checks; browser retrieval smoke checks passed for GPU, GC/JIT, and API topics; wheel includes all 104 Markdown modules; benchmark v1.5 host lane — 10/10 passed.
- [~] All 12 model-quality cases remain `NOT_RUN` in this environment because no configured model weights/model server were supplied. A host benchmark is not an AI reasoning-quality score.
- [~] The Council Playwright runner attempted real phone/tablet/desktop viewport runs but local HTTP navigation was blocked by the audit environment (`ERR_BLOCKED_BY_ADMINISTRATOR`); no screenshots were produced. Physical phone use, Python 3.10 runtime execution, Docker-based project tests, real GPU/inference throughput, native game engines, actual compiler invocations, full dependency/CVE scans, and independent penetration testing remain unverified here.
- [~] The offline knowledge bundle is broad but cannot include every language feature, API version, package, chip, standard, hardware manual, proprietary system, paper, or future discovery. Versioned claims still need current official documentation and toolchain tests.

---

This document distinguishes implemented features from ideas that still need engineering work. “Implemented” means code exists in this repository; it does not mean every runtime/platform has been independently validated.

## 2026-11-05 audit hardening

- [x] Task-aware workspace context ranks candidate files by task terms in paths and a bounded initial-content sample before applying the existing file and context limits. This improves retrieval but is not semantic indexing or a complete dependency graph.
- [x] Verified knowledge records are re-hashed before being marked verified and before retrieval; altered content is rejected or omitted.
- [x] User-confirmed learning records are re-hashed before retrieval and training-data export; altered examples are omitted.
- [x] New knowledge imports can be scoped to a workspace; cross-workspace retrieval is blocked while legacy unscoped records remain shared and visible.
- [x] The tracked `build/lib/offline_coder` package copy and wheel were regenerated and checked against the current source, including the concurrent `expansion.py` module.
- [x] Historical 2026-11-05 benchmark v1.2 snapshot: six model cases, exact case/source hashes, per-member artifacts, and scores that do not treat confidence or verbosity as correctness. Superseded by the v1.4 status above.
- [x] Benchmark v1.2 original `aa81383` host baseline: 4/10; current candidate: 10/10 on matching case-set and runner hashes. Historical v1.0 artifacts remain preserved separately.
- [~] Historical 2026-11-05 state: six model-reasoning cases were `NOT_RUN`; current v1.5 has 12 cases and still requires a configured model. Host checks do not prove improved reasoning quality.
- [~] This Codespaces audit environment has 2 CPU threads, about 7.8 GiB RAM, and no model weights installed. No real-model quality or inference-throughput benchmark was possible; no model was downloaded or selected as currently in use.
- [~] Synthetic 1,200-file scanner comparison (three runs, 90-file context budget): filename-only median 0.1174s and did not include a relevant late file; task-ranked median 0.1974s and did include it. This is a scanner-only microbenchmark, not a general repository or model-performance claim.

## Implemented in the current build

- [x] Phone companion uses the desktop-configured GGUF or loopback local-server backend and role-specific peer model overrides.
- [x] Identical peer model assignments share one in-memory model adapter instead of loading duplicate GGUF weights.
- [x] Review approval requires structured self-reported checks, substantive strengths, valid confidence, and final-vote rationale; this is not a substitute for runtime proof.
- [x] Retrieved learning examples are explicitly treated as untrusted context; local task history and learning-example storage apply central credential redaction checks.
- [x] Unattended Apply is visibly locked because project-controlled test output cannot yet issue host-controlled evidence attestations.

- [x] Four adversarial review roles around the selected local model, with a deterministic host approval gate.
- [x] Whole-site source import through ZIP/folder selection, plus a bounded direct HTTPS same-origin URL crawl when CORS permits.
- [x] Knowledge shelf with explicit user verification; confirmed lessons and training-data export.
- [x] Browser sandboxed preview for generated HTML projects.
- [x] Manual responsive preview widths: 375 px, 768 px, 1280 px, and fit-screen.
- [x] Bounded project inventory: file extensions, likely entry points, dependency manifests, likely test paths, README files, TODO markers, and read-only Git status.
- [x] Heuristic security/accessibility/performance flags. These can miss issues and produce false positives.
- [x] Acceptance checklist draft generator with generic verification checklist.
- [x] Desktop append-only task journal and browser local task history/export.
- [x] Starter templates: website, browser game, web simulation, Python CLI.
- [x] Manifest-backed rollback for new-format desktop backups, including deletion of files created by the applied change.
- [x] Desktop isolated Python compile/unittest checks if Docker and `python:3.12-slim` are already installed locally; otherwise reports SKIPPED.
- [x] Desktop writes require unanimous structured review, host safety checks, a fresh candidate/workspace fingerprint, an automatic backup, and explicit user confirmation. Unattended Apply remains locked until the test harness can issue host-controlled evidence; browser autonomous repair only revises the in-memory candidate.
- [x] Isolated Python runner reports `NO_TESTS` instead of falsely treating an empty unittest suite as a successful test run.


- [x] Structured desktop task plan with ordered subtasks, acceptance criteria, assumptions/open questions, and a verification strategy (model-generated and still needs review).
- [x] Desktop answer-only synthesis across peer analyses/reviews rather than simply returning the rotating proposer answer.
- [x] Bounded iterative web research: up to two targeted follow-up searches based on peer uncertainties (desktop DuckDuckGo snippets; browser Wikipedia snippets only).
- [x] Browser task mode (auto/answer/build), answer-only synthesis/source display, and a working result renderer guarded by a DOM-stub regression harness.
- [x] Research context budget reserved explicitly when the workspace context is large.
- [x] Bounded parallel peer phases when distinct role-specific model instances are configured; shared model objects are serialized with per-instance locks and the run report records the actual model topology.
- [x] Search-query best-effort redaction for common secrets and common OS-specific paths; untrusted snippets and query egress are disclosed.
- [x] Canonical generated-path validation to ensure checked paths match actual write paths across operating systems.

## Partially implemented / advisory only

- [~] Project architecture understanding: Python AST adds conservative call/inheritance links and impact clues, but is not a complete language-server graph; other languages and dynamic behavior remain heuristic.
- [~] Testing: Python/Node checks depend on preinstalled Docker images; optional Playwright provides configured browser interactions, responsive viewport runs, and approved PNG comparisons, but is not a universal acceptance system.
- [~] Self-improvement: retrieval of user-verified lessons and examples, not automatic model-weight learning.
- [~] Competing solutions: up to three alternatives can be tested in disposable copies, with adaptive parallel drafting only for distinct model instances; no Git worktree merge coordinator exists.
- [~] Specialist reviewers: custom role prompts are supported, but reviewers may share one model and its blind spots.

- [x] Optional public web research: desktop DuckDuckGo result snippets, authenticated phone companion search, and browser Wikipedia search with source URLs; snippets are explicitly marked untrusted.

## Not implemented yet

- [~] Selectable local model per peer is implemented; calibrated disagreement metrics and empirical peer-independence scoring are not implemented. Different models can still share blind spots.
- [ ] Verify compatibility of Qwen3-Coder-Next GGUF with the project's current `llama-cpp-python` backend on supported hardware; model recommendation is documented but not runtime-validated.
- [~] Independent Git-worktree code-writing branches and conflict-aware merge coordinator. The current alternative tournament uses disposable snapshots; it is not a full branch/merge workflow.
- [~] General automated browser acceptance coverage remains project-configured and optional; responsive Playwright runs and approved PNG baseline diff are implemented, but require a working local browser runtime.
- [ ] General-purpose browser search backend for the standalone HTML edition; current autonomous browser research uses Wikipedia snippets plus an external full-search tab because browser CORS prevents reliable ingestion from arbitrary search engines. The desktop research follow-up is bounded to two extra searches, not an open-ended agent loop.
- [ ] Native Unity/Godot/Unreal project inspection and engine-specific tests.
- [~] A CycloneDX-style inventory and exact-version PURLs are available; live vulnerability database/CVE matching and a comprehensive resolved-dependency SBOM are not implemented.
- [ ] Voice input/output and microphone workflow.
- [ ] Authenticated cross-device sync service.
- [ ] Continuous background project health monitor.
- [ ] Generic plugin runtime with explicit capability permissions.
- [ ] Visual element-to-source debugging with DOM/source maps.
- [ ] Safe automatic framework migrations with database migration rehearsal.
- [ ] Production deployment and rollback automation.
- [ ] Automatic full performance profiling and accessibility conformance testing.

## Validation caveats

Historical 2026-11-05 verification: `python -m pytest -q` passed 180 tests (including 27 subtests); benchmark v1.2 passed 10/10 deterministic host checks. This historical result is superseded by the 2026-11-07 v1.4 validation at the top of this file.


## Autonomous web research and source ranking — 2026-10-12

- **Implemented:** Desktop, phone-host, and CLI council runs perform bounded pre-task DuckDuckGo research when enabled (default ON), using a sanitized query capped at 180 characters and up to six snippets. Universal browser app has an ON-by-default checkbox and searches Wikipedia before relevant tasks. Simple tasks and explicit no-web/offline-only requests are skipped. Search failures are recorded and the council continues without web evidence.
- **Implemented:** Search results receive transparent source categories. Relevant official/primary docs and standards rank highest for exact technical claims; Wikipedia is an established secondary source ranked above unclassified personal/community content; unknown domains remain unverified. The prompt asks peers to cite URLs, check recency/version fit, corroborate key claims, and ignore instructions in page content.
- **Limitations:** Desktop/CLI/phone host receive search-result snippets, not verified full pages. Browser edition auto-searches Wikipedia only because browser cross-origin rules prevent reliable arbitrary search-engine access. Domain tiering is heuristic and does not prove accuracy. Queries leave the device for the selected external search provider; turn off autonomous research for confidential tasks.


## Recent reliability upgrade

- Added a verified loopback-only OpenAI-compatible local server backend alongside in-process GGUF inference. The adapter checks the model list before use and refuses remote hosts.
- Added isolated JavaScript syntax checks and Node built-in test execution using `node:22-alpine` only when already installed. Existing Python isolated checks remain.
- Added project check aggregation; failed checks can enter the existing bounded repair/re-review loop. Every revised candidate must pass host validation and unanimous peer review again.
- Strict autonomous application requires an actual supported test run to pass. Static-only checks, absent tests, unavailable Docker/images, and unsupported runtimes are not treated as behavioral proof.
- Remaining limitations: no universal Playwright/browser runner, no automatic dependency install, no Unity/Godot/Unreal runtime runner, and no guarantee of correctness.


## Project simulation and end-to-end smoke scenarios (2026-10-13)

- [x] Added opt-in `council.simulations.json` scenarios for Python and Node CLI/service entry scripts. Each scenario can assert exit code and expected output and has a bounded timeout.
- [x] Simulations run on the disposable proposed-code snapshot in preinstalled Docker images only, with networking disabled, read-only container root, CPU/memory/process limits, and no shell command strings.
- [x] Simulation failures are included in the aggregated runtime report and trigger the existing bounded repair loop; missing Docker/images are reported as SKIPPED.
- [x] Added regression tests for path traversal, no-manifest behavior, successful simulated output, and unavailable Docker.
- [ ] Full browser interaction tests (Playwright), real mobile-device tests, database/API integration harnesses, and Unity/Godot/Unreal simulation are not included.
- [ ] Third-party project dependencies are not installed automatically; scenarios must work with the preinstalled image and copied workspace.
- See `SIMULATION_GUIDE.md` for usage and limitations.


## Real-browser visual simulation (2026-10-13)

- [x] Added an optional Playwright/Chromium runner for disposable web-project snapshots.
- [x] Captures screenshots, page exceptions, console errors, basic page metadata, and blocked external requests.
- [x] Supports deterministic UI actions/assertions through root `council.visual.json`.
- [x] Added a desktop **Visual simulate project…** action and automatic visual checks for web-facing candidate changes when applicable.
- [x] Missing/blocked browser runtime reports SKIPPED; no browser or dependency is downloaded automatically.
- [ ] Browser success path not verified in this restricted build environment because Chromium navigation is blocked by local browser policy. Unit tests cover validation and graceful skip behavior; run a real local smoke test on the target computer.
- [ ] This does not provide a universal emulator for native apps, phones, or Unity/Godot/Unreal projects.


## 2026-11-06 — Council v9 repair pass

- [x] Corrected model candidate ranking so incomplete benchmark coverage is discounted and candidates without task-specific coding/reasoning measurements cannot be selected.
- [x] Improved memory retrieval: superseded entries are excluded from active search; stale and exact-summary conflicting entries are flagged; the Council receives explicit verification warnings.
- [x] Exposed whether peer roles share a model instance and clarified that separate instances do not prove independent model families.
- [x] Hardened mobile service with an eight-handler cap, per-client request/auth/action throttles, strict JSON POST body checks, optional TLS 1.2+, and default refusal of unencrypted non-loopback binding unless explicitly opted in.
- [x] Added regression tests and updated mobile, benchmark, start, and audit documentation.
- [x] Historical v1.3 verification: 188 Python tests and 27 subtests passed; browser app, nine browser-logic checks, iPhone JavaScript, mobile app checks, package wheel build, and benchmark v1.3 host lane passed.
- [~] Historical v1.3 note: six model cases were `NOT_RUN` then. The current v1.4 benchmark has 12 model cases, still `NOT_RUN` until a model is configured. Physical iPhone testing, live HTTPS certificate handshake, independent penetration testing, and separate-model-family validation also remain unperformed.
- See `REPAIR_AUDIT_REPORT_2026-11-06.md` and `benchmarks/results/council9-repaired-v1.3.json`.
