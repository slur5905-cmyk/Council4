# Coding Council improvement report — 2026-11-03

## Summary

This release hardens the supplied `5 Council.zip` source tree while keeping its local-first architecture, four-peer review workflow, workspace boundaries, backups, and human-controlled Apply flow.

## Changes made

### Model routing and resource use

- The phone/tablet companion now uses `build_model_router`, matching the desktop configuration for either local GGUF inference or a loopback-only OpenAI-compatible local server.
- Phone mode now honors the desktop's role-specific Architect, Correctness, Security, and Red Team model assignments. It no longer incorrectly requires a `.gguf` file when the configured backend is `local-server`.
- Identical GGUF role paths resolve to one model instance, preventing redundant model-weight loads that can waste substantial RAM/VRAM.
- Identical local-server model IDs share one adapter. Additional role models reuse the model IDs already discovered and validated by the primary adapter, avoiding repeated `/models` requests.

### Review quality and prompt-injection resistance

- An `APPROVE` code review must include at least one concrete self-reported code-path/attack-surface check, a substantive strengths/evidence summary, and a finite confidence value in the range 0–1.
- Final peer votes must include a substantive reason in addition to an explicit, empty `remaining_blockers` list.
- These are completeness gates over model-generated review statements, not cryptographic proof, independent reasoning, or evidence that code was executed.
- System instructions and context labels now explicitly treat retrieved prior learning examples and user-verified imported-source contents as untrusted reference material. A verification label does not make embedded instructions authoritative.

### Local data protection and user approval

- Task journal entries now redact recognizable credential values before local persistence.
- Learning-example storage uses the central host redaction rules in addition to its legacy patterns and rejects examples that contain detected credentials rather than silently exporting them for training.
- Common GitLab personal access tokens and JWT-shaped tokens are added to the central redaction rules.
- The desktop UI now shows unattended Apply as locked. The previous toggle could never safely authorize writes because current test output is controlled by project code and no trusted host-controlled attestation channel exists. Stale persisted opt-in values from older builds are reset. Manual Apply still requires review and explicit confirmation.

## Verification performed

- `python -m pytest -q`: **141 passed, 27 subtests passed**.
- `python -m unittest discover -s tests -q`: **140 tests passed**.
- `python -m compileall -q main.py offline_coder tests tools`: passed.
- `python tools/check_iphone_js.py`: passed.
- `python tools/check_mobile_app.py`: passed, including shared-router and no-GGUF-only guards.
- `python tools/check_browser_app.py`: passed; 66 unique browser-app IDs and the existing safety/runtime guards passed.
- `node tools/check_browser_logic.mjs`: **9 checks passed**.
- `python -m pip wheel . --no-deps --no-build-isolation`: succeeded.
- Installed the built wheel into a clean target directory and imported `offline_coder`, model routing, and the mobile companion: passed.

## Not verified / remaining limitations

- No actual GGUF model weights were present or loaded. No live local-server inference or model-quality benchmark was run.
- No physical iPhone/Safari or desktop Tkinter GUI session was performed.
- The mobile companion still uses plain HTTP when intentionally bound to a LAN interface. Use only a trusted private network; do not use public Wi-Fi or port-forward it.
- Docker isolation/runtime tests were not run as part of this release verification. Passing unit/static checks does not establish that generated code is safe or correct.
- The four Council roles may still share the same underlying foundation model. Different role prompts do not guarantee independent conclusions.
- Credential redaction is heuristic and cannot guarantee that every secret format is detected.
- Filesystem race conditions and best-effort multi-file rollback remain residual risks; serialize writes to a workspace and keep backups.
- This is not a professional penetration test, security certification, or live deployment validation.

## Honest capability boundary

This update improves the software around the model; it does not make model weights intrinsically smarter, create unlimited intelligence, or guarantee correct generated code. Better reasoning quality still depends on the quality, capability, context length, and hardware fit of the models configured by the user. Specialized models can help when they are genuinely different and independently evaluated.
