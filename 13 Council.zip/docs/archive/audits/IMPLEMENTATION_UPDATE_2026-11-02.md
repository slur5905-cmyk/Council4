# 4Council implementation update — code engine + multi-model routing

## Implemented in this update

1. Added role-aware local model routing for Architect, Correctness, Security, and Red Team.
2. Added optional model overrides in the desktop Settings UI. Blank fields fall back to the primary model.
3. Supports exact model IDs exposed by an OpenAI-compatible loopback server, or separate local GGUF file paths.
4. Routed each peer's analysis, cross-review, code review, final vote, and proposal drafting to its assigned model. General planning and final synthesis remain on the primary model.
5. Added safe settings validation for role mappings and normalized `local_server` to `local-server` for compatibility.
6. Added multi-model and specialization documentation. Existing local-only LoRA training workflow is documented, including its limitations and evaluation/merge requirements.
7. Preserved repository intelligence, multi-file candidate generation, unanimous review, path validation, backups, and explicit Apply approval.

## Verification

- `python -m pytest -q`: 130 passed, 24 subtests passed.
- `python -m compileall -q main.py offline_coder tests tools`: passed.
- `python tools/check_iphone_js.py`: passed.
- `python tools/check_mobile_app.py`: passed.
- `python tools/check_browser_app.py`: passed.
- `node tools/check_browser_logic.mjs`: 9 checks passed.

## Not verified

- No local model weights were downloaded or loaded in this environment.
- No live code-generation benchmark against actual model inference was run.
- No LoRA training was run; it requires suitable hardware and training dependencies.
- The desktop GUI was not physically exercised in this environment.

The tests verify software plumbing and deterministic checks, not model intelligence or the correctness of future generated code. Keep auto-apply disabled while evaluating new models.


## Follow-on hardening — 2026-11-03

1. Phone mode now builds the same GGUF or loopback local-server router as desktop, including peer-specific model overrides. Local-server phone mode no longer incorrectly requires a GGUF path.
2. Identical model assignments reuse one loaded instance. Distinct local-server peers share the primary adapter's already-verified model list; duplicate role IDs do not trigger repeated discovery or instantiate redundant adapters.
3. Approval reviews now require a self-reported, concrete check list, strengths/evidence summary, and finite confidence value. Final votes require a substantive reason as well as an explicit empty blocker list. These statements improve audit completeness but are not runtime proof.
4. Retrieved past examples are explicitly untrusted reference material in model instructions and context labels. User-verified imported source content is not treated as trusted instructions.
5. Task journal entries and training examples use the central credential redaction checks. Common GitLab tokens and JWT-shaped values are included in redaction coverage.
6. The desktop UI now visibly locks unattended apply. The current test runner cannot issue independent host-controlled execution attestations, so the previous toggle implied a capability that this build correctly refuses to authorize. Manual Apply still requires explicit user confirmation.

Verification after these changes: see `IMPROVEMENT_REPORT_2026-11-03.md` for full test results and environment limitations.
