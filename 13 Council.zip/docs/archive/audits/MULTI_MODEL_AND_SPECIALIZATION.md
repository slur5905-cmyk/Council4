# Multi-model Council and task-specific specialization

## What is implemented

- Council role routing now supports four independent local model overrides: `architect`, `correctness`, `security`, and `redteam`.
- Blank overrides safely fall back to the primary model. This preserves a one-model setup.
- With a local OpenAI-compatible server, each override is an exact model ID discovered at `/v1/models` on the loopback host. All models must already be installed in that local server.
- With GGUF mode, each override is a local `.gguf` file path. Each additional model consumes additional RAM/VRAM; do not load four large models on a machine that cannot hold them.
- The GUI exposes four override fields. For `local-server`, enter model IDs; for `gguf`, enter local file paths.
- Planner and final synthesis tasks use the primary model; each peer's analysis, cross-review, code review, final vote, and proposer draft route to its assigned model.
- Peer analysis, cross-examination, candidate review, and final-vote phases now use bounded parallel execution when the four roles map to more than one model instance. The default ceiling is two concurrent peer calls; set `max_peer_workers` from 1–4 in desktop settings or use `--peer-workers` in the CLI.
- Calls routed to the same model instance are serialized by a per-instance lock. This protects in-process backends from simultaneous generation calls while still allowing different specialist models to work at the same time. A one-model configuration remains sequential.
- Each saved run report now records the peer-to-model assignment, count of distinct model instances, configured worker ceiling, and whether that run used sequential or bounded-parallel peer execution. The report does not include full GGUF file paths.

## Free model strategy

The software has no model subscription or hosted AI-provider dependency. In direct GGUF mode, the Council loads local weights in-process without a model API. Optional local-server mode uses an OpenAI-compatible HTTP protocol to a server on the same computer (loopback only); it does not contact a remote inference provider. Model weights may be free to download, but hardware, storage, electricity, and download bandwidth are not literally cost-free. Check each model's license and permitted use.

A practical low-memory configuration is one capable code model shared across roles. If the host has enough memory, add smaller specialized models for security/review and architecture. Different role prompts still matter: a model is not independently validated merely because it has a different name.

Start with `max_peer_workers=1` if memory is tight or your local inference server is unstable. Increase to 2 after validating two different role models under a representative workload. Use 3–4 only when the host can sustain the additional simultaneous KV-cache/inference memory and your local server benefits from concurrent requests. Parallel workers improve utilization and latency when models are genuinely distinct; they do not increase a model's underlying intelligence or guarantee better answers.

## Fine-tuning / trained weights

The repository already includes `tools/train_lora.py`. It performs optional local LoRA fine-tuning from a local Hugging Face base-model directory and a reviewed JSONL dataset. It requires at least 20 usable examples, local training dependencies, and suitable hardware. It deliberately does not download model weights or datasets. Training is not run automatically and is not suitable for an iPhone.

The resulting PEFT adapter is a training artifact, not directly a GGUF file. To use it in the current GGUF setup, the adapter must be evaluated, merged with its exact compatible base model, and converted/quantized to GGUF using compatible tooling. Then point one role override at that resulting `.gguf` file. Keep the original base model and adapter as rollback artifacts.

Do not train on raw unreviewed Council output. Build a dataset from examples that have been reviewed, tested, and explicitly marked as good; include counterexamples and a held-out validation set. Evaluate before and after on the same coding, security, and regression benchmark. If the adapter regresses, discard it. Fine-tuning changes model behavior and may make it worse; it does not update the Council's source code or guarantee factual knowledge.

## Example settings

For local-server mode, in the Settings panel:

- Primary Model ID: the general code model.
- Architect: a code-capable reasoning model ID, or blank.
- Correctness: a code model different from the primary, or blank.
- Security: a security-oriented code model, or blank.
- Red team: a second code/reasoning model, or blank.

For GGUF mode, enter absolute paths to local `.gguf` files in those four fields. Leave them blank unless those files exist and fit in memory.

## Safety and verification

- Different models are not proof of independent truth; all still receive the same repository evidence and may share training biases.
- The four unanimous votes and host-side validation gates remain in place.
- Automatic apply remains opt-in and should stay off while testing new models.
- Never give a model an API key or credentials in its prompt. This router only accepts local GGUF paths or loopback model IDs/endpoints.
- Run `python -m pytest -q` after changing routing or model configuration, then run a live inference coding benchmark on the target machine. Unit tests do not prove model quality.


## v1.6.0 — peer communication and bounded model residency

- The four members still complete independent first-pass analyses before seeing each other's work.
- After cross-review, each participating member may initiate one bounded direct question, investigation request, code challenge, or component-collaboration request to another member. The recipient answers using its own role assignment; the initiator then decides whether the exchange is resolved or remains open.
- The communication history is persisted in `~/.offline_coding_council/peer_communication.sqlite3`. Message bodies are size-limited, common credential patterns are redacted, peer identities are validated, and code references cannot use absolute paths or `..` traversal.
- Open threads are retrieved for closely related later tasks. At most one matching open thread is continued per run to keep extra inference bounded. The user can inspect each run's exchanges in the **Peer communication** tab.
- For code-change/build/debug tasks, up to four plan subtasks can be assigned to individual peers. Each returns a bounded component contribution (design, interfaces, tests, and optional file content). These are proposals only: the rotating proposer must reconcile overlaps and integrate them into one candidate; normal safety, test, four-peer review, and manual Apply gates still apply.
- Discussion-derived lessons are saved as `provisional`. They are not used as trusted facts and do not modify model weights. The user can explicitly mark them verified or rejected using **Review peer lessons**. Retrieved lessons remain hypotheses that the peers should re-check against the current project.
- GGUF model assignments now use lazy LRU loading. Only the requested model is loaded when a peer first calls it. `max_loaded_peer_models` (1–4, default 1) limits resident models; idle models are unloaded before another model is loaded, and active models are never evicted. A limit of 1 minimizes memory use but serializes distinct GGUF peers and causes model switching/reload overhead. Larger limits use more RAM/VRAM and may permit parallel model execution.
- Local-server model IDs remain routed independently by role. Their weights are managed by the local model server, not the Council's GGUF LRU manager.
- The model profile reports model assignments and the model-manager snapshot. Distinct model files/IDs do not prove distinct training families; the Council deliberately reports family independence as unverified.

## Practical model setup

1. Set the primary GGUF model (used for planning and final synthesis).
2. Put a different local `.gguf` path in one or more role override fields. For local-server mode, use exact model IDs listed by the loopback server.
3. Start with **Max GGUF models kept in RAM = 1**. This lets all four members use different files without keeping all four loaded simultaneously.
4. Raise the limit to 2, then 3 or 4 only after observing available RAM/VRAM and successful real inference. More resident models are not automatically smarter and may cause memory exhaustion.
5. Compare models with the Council's same-task benchmark. Record model name, quantization, context length, prompt settings, and actual test outcomes. Never treat role names or model labels as proof of independent correctness.

The peer communication and model manager tests use deterministic fake models. They verify routing, persistence, bounded eviction, and orchestration—not the reasoning quality, throughput, memory footprint, or compatibility of a specific downloaded model on the user's hardware.

## Phone/browser edition scope

The v1.6.0 peer communication store, desktop **Peer communication** tab, user lesson-review control, and GGUF LRU model manager are implemented in the Python desktop edition. The separate static `iphone-app/` and `CodingCouncil_Universal.html` browser editions have not yet been upgraded with those systems: they still use one in-browser model for their role prompts, store learning in browser-local storage, and do not share the desktop SQLite discussion database. This release does not provide phone-to-desktop discussion or model-state synchronization.
