# Coding Council — Deep Technical Audit

Audit date: 2026-10-12. **The latest section at the bottom supersedes older test counts and records the current source state.** Earlier sections are chronological audit notes and may describe earlier feature coverage.

## Current audit snapshot

- **59 Python unit tests pass** (`python -m unittest discover -s tests -q`).
- Python compilation passes for the application, tests, and tools.
- The universal app's JavaScript syntax, 66 unique IDs, label references, preview sandbox and import guards pass; its Node-based logic harness passes 9 checks.
- The phone companion check passes (JavaScript syntax, IDs/labels, authentication and localhost-default guards); the iPhone app module syntax check passes.
- Both GitHub Actions workflow files parse as YAML, and current project packaging passes ZIP integrity tests after rebuild.
- The `pip check` command reports a **shared-environment** conflict: installed `moviepy 2.2.1` requires `pillow<12`, while the audit environment has `pillow 12.3.0`. Neither package is a declared dependency of the Coding Council runtime (`pyproject.toml` runtime `dependencies=[]`); this does not establish a defect in the project, but the environment is not dependency-clean.
- No real local model generation, live search provider, real public-site crawl, physical iPhone/Safari test, Docker execution, production deployment, game-engine test, or independent penetration test was completed. The browser harness uses a DOM stub; the URL/ZIP workflow tests use mocked network/decompression pieces.

### Current deep-audit fixes

- Fixed a missing `renderResult(result)` function that was called by the universal browser app but not defined, so completed runs could not reliably display results. Added a Node/DOM-stub integration harness and static guard.
- Separated answer/research tasks from build tasks in the browser app. The browser answer flow now synthesizes the peer analyses, uses source-linked Wikipedia snippets, can generate up to two targeted follow-up Wikipedia searches, and clearly discloses snippet-only research limits.
- Desktop answer-only runs now get a final synthesis across the initial draft, peer analyses and critiques instead of returning the proposer answer without consolidation.
- Added structured task plans with ordered subtasks, acceptance criteria, assumptions/open questions and a verification strategy; context budgeting reserves a section for bounded research rather than allowing large workspace context to silently remove it.
- Tightened search query redaction for common key/token assignments, bearer tokens, common provider tokens and Windows paths. A regression test exposed a desktop regex that had required two literal backslashes; it now redacts ordinary single-backslash paths.
- Found and fixed a path-validation/write-target mismatch: backslash or non-canonical path aliases could be validated as normalized paths but then passed to the writer under their raw key. Proposed writes now reject non-canonical path spellings rather than validating one target and writing another.
- Removed duplicate `queries` output field and an unreachable duplicate error raise found during inspection.


## Scope

- Python desktop/local-model app and mobile companion
- Browser-only iPhone app in `iphone-app/`
- Packaging and documented constraints

## Checks performed

- `pytest -q`: **10 passed**
- `python -m compileall -q main.py offline_coder tests`: passed
- `node --check` on extracted inline JavaScript from the iPhone app: passed
- HTML ID uniqueness check: 34 IDs, no duplicates
- Preview iframe sandbox attribute: `allow-scripts` only; no `allow-same-origin`
- Source scan: no use of `innerHTML` in the iPhone app
- ZIP integrity checks: passed for both distribution archives

## Fix made during audit

The Python council previously treated four `APPROVE` labels as unanimous even if a reviewer still listed items in `remaining_blockers`. The host now requires every vote to be `APPROVE` **and** have an empty blocker list both when enabling Apply and immediately before applying. Added a regression test for this case. Also configured pytest's project import path so plain `pytest -q` works from the project root.

## Important limitations / residual risks

- The four reviewers are role prompts using one selected model, not four separately trained models. Shared model blind spots remain possible.
- No generated project was executed, built, or integration-tested as part of this audit. The static checks are limited and do not prove correctness or security.
- The iPhone-only edition must be hosted at an HTTPS static URL. It initially downloads its JavaScript runtime and model weights from configured hosts; it is not air-gapped. Model size and Safari memory limits may prevent larger options from loading on some iPhones.
- The preview sandbox is a useful containment measure, not a certified security boundary. Preview only generated code you are willing to inspect.
- The desktop mobile companion uses HTTP on the local network with a one-time bearer token. Use a trusted private Wi-Fi network only; do not port-forward it or use it on public Wi-Fi.
- Local model quality depends on the model and device. Unanimous model votes are not proof; users should inspect changes, run real tests, and keep backups.

## Final assessment

The tested application code and packaging checks pass. The approval-gate regression found during audit is fixed and covered by a test. This is a usable experimental local coding-council scaffold, not a guarantee of frontier-level coding quality or production security.


## Deep audit follow-up — 2026-10-12

### Fixes applied
- Desktop approval now fails closed if `remaining_blockers` is missing or is not an empty list. Previously, `get(..., [])` could interpret a missing field as no blockers. Added a regression test for the missing-field case.
- iPhone app now accepts individual source files and ZIP projects, with compressed-size, file-count, per-file, total-context, path-traversal, dependency-folder, sensitive-name and binary-content screening. Files that exceed limits are reported rather than silently truncated. ZIP decompression uses fflate loaded from a CDN on demand; this is not an AI API, but the ZIP-import action needs network access to load the library.
- iPhone app now supports up to three user-defined specialist auditor roles in addition to the four default roles. The additional roles join analysis, adversarial reviews, and final votes; all are role prompts on the same local model.
- Added user-curated local lesson memory and a JSONL starter-dataset export. This is retrieval-based learning, not automatic model-weight training.
- Added a download helper for proposal, report, and lesson exports; added initial rendering of the lesson shelf.

### Checks run after fixes
- Python test suite: 11 passed.
- Python bytecode compilation: passed.
- iPhone app module JavaScript syntax check with Node: passed.
- ZIP archive integrity checks: run after final packaging; both archives passed `unzip -t`.

### Remaining limitations
- ZIP import is bounded by iPhone memory and the app context budget; it cannot audit arbitrarily large repositories at once.
- The app still does not execute uploaded/generated code, run project tests, or perform a full dependency vulnerability scan.
- Browser/CDN/model compatibility and actual inference must be tested on a physical iPhone; no physical-device test was performed in this environment.
- User-saved lessons can be wrong or stale. They are marked as user-verified, not cryptographically verified; review them and clear outdated entries.
- The JSONL export is only a starter format and does not constitute meaningful fine-tuning without curated, representative input/output training pairs.


## GitHub-readiness and ZIP-import follow-up — 2026-10-12

### Changes applied
- Added GitHub Actions CI for Python tests/compilation and the iPhone app's inline JavaScript syntax.
- Added a GitHub Pages workflow that publishes only `iphone-app/` from `main` when Pages is configured to use GitHub Actions.
- Added `.gitignore` entries for environment files, model weights, local databases, caches, and common key files; added `SECURITY.md` and `CONTRIBUTING.md` with human-review requirements for safety-boundary changes.
- Hardened ZIP import by inspecting the ZIP central directory before decompression, rejecting ZIP64/multi-disk archives, limiting entries, rejecting any file above 180 KB, and limiting total declared expanded size to 2 MB. This reduces ZIP-bomb exposure but is not a formal security guarantee.

### Checks run
- `python -m pytest -q`: 11 passed.
- `python -m compileall -q main.py offline_coder tests`: passed.
- `python tools/check_iphone_js.py`: passed.
- ZIP archive integrity checked after repackaging.

### Still not done / not claimed
- No GitHub repository was created or pushed because no GitHub account/repository connector or destination URL is available in this chat. The package is prepared for upload; repository creation and authorization still require the user.
- No physical iPhone test, real local-model inference, generated project execution, full dependency audit, or independent penetration test was performed.
- ZIP metadata can be malformed or misleading; use trusted archives. The importer is defensive input filtering, not a certified hostile-file sandbox.


## Self-improvement and training audit — 2026-10-12

### Implemented
- Added a local SQLite experience store. Only examples explicitly confirmed by the user as successful are recorded; duplicate entries and examples containing patterns resembling common secrets/tokens are rejected. Database connections now commit/rollback and close in `finally` blocks in both knowledge and learning stores.
- Desktop UI now offers **Learn from a successful run** and **Export training data**. Before recording, it asks the user to confirm that they independently tested the result. Saved examples can be retrieved for future tasks as clearly labeled, potentially stale reference data.
- iPhone edition now lets the user explicitly save a tested successful run, uses a few saved examples as context, and exports real task/solution JSONL pairs. It no longer exports generic placeholder assistant responses as if they were meaningful fine-tuning examples. Browser storage is local and can be cleared by Safari.
- Added `tools/train_lora.py` plus optional `requirements-training.txt`. It accepts a local Hugging Face model directory (not GGUF or browser ONNX), reads a reviewed JSONL dataset, requires at least 20 usable examples, makes a deterministic held-out validation split, masks prompt tokens from the training loss where supported, and writes a new LoRA adapter to a new/empty output folder. It does not download model files. CI now compiles the trainer script.
- Training is opt-in and separate from normal inference. The original model is not overwritten; the user must deliberately run the trainer and separately configure/use the adapter.

### Latest checks
- `python -m pytest -q`: **15 passed** (11 previous tests + 4 learning-store tests).
- `python -m compileall -q main.py offline_coder tests tools/train_lora.py`: passed.
- `python tools/check_iphone_js.py`: passed.
- `python -m py_compile tools/train_lora.py`: passed.
- `python tools/train_lora.py --help`: passed without importing optional training dependencies.
- iPhone HTML scan: 43 IDs, no duplicate IDs; no `innerHTML` uses; preview iframe has `sandbox="allow-scripts"`; two dynamic CDN imports found (model runtime and ZIP decompressor).

### Audit limitations / residual risks
- **Actual fine-tuning was not run.** No base model directory, representative training corpus, GPU/VRAM capacity, or optional training packages were supplied. The trainer was syntax-checked and its help path was run, not end-to-end trained. Compatibility of `target_modules='all-linear'`, chat templates, and memory requirements varies by model architecture.
- Twenty examples is only a technical minimum for creating a tiny validation split, not a recommended dataset size. High-quality generalization normally needs many more diverse examples, deduplication, representative hold-out tasks, and careful evaluation. Bad labels can make the model worse. The current starter trainer does not provide a comprehensive benchmark suite or automatic rollback based on evaluation.
- The app uses a GGUF model for inference; the trainer requires a separate Hugging Face model directory. The generated LoRA adapter is not automatically merged into GGUF or loaded by the existing inference UI. Conversion/adapter compatibility must be handled separately for a specific architecture.
- “Self-training” is supervised and user-confirmed, not autonomous unverified self-labeling. This is intentional: a model cannot reliably decide on its own that its code is correct. User confirmation can still be mistaken; test examples before promoting them.
- The iPhone edition cannot update model weights locally; it provides retrieval memory and JSONL export only. Actual weight training needs suitable desktop/workstation hardware.
- Secret scanning is heuristic and can miss credentials or reject harmless strings. Review exported datasets before training; training can memorize secrets and personal data.
- No physical iPhone test, end-to-end training run, model-quality benchmark, generated-code execution, or independent penetration test was performed.
- The desktop workspace write path still has a narrow time-of-check/time-of-use race if another process maliciously swaps directories/symlinks during an apply operation. The app should be used on a trusted local workspace; this is not a hardened multi-user sandbox.

### Current assessment
The app now learns from user-confirmed examples at inference time and includes an optional path to actual local LoRA weight fine-tuning. It is not yet an unattended autonomous trainer, and the trained adapter is not wired into the GGUF runtime. Treat this as an experimental, supervised self-improvement pipeline.


## Reliability hardening follow-up — 2026-10-12

### Issue found and fixed
- **Prior gap:** final unanimous votes were sufficient even if an earlier structured code review had reported a material `HIGH` or `BLOCKER` issue. That allowed a final vote to accidentally or incorrectly erase a finding without changing the candidate.
- **Fix:** the host now independently validates that there is exactly one structured review and final vote for each known peer; all final votes must be `APPROVE` with an explicit empty blocker list; any non-empty `BLOCKER`, `HIGH`, or `MEDIUM` finding blocks approval. The apply function repeats these checks, so a serialized/tampered result cannot rely only on `can_apply=true`. A new regression test covers a material finding that is contradicted by final votes, and another checks that apply revalidates reviews.
- **Result:** 17 automated tests pass; Python compilation and the iPhone JavaScript syntax check pass. This is a conservative gate: false-positive medium/high findings can require another review/revision, which is preferable to silently ignoring them.

### Remaining correctness limits
- The four peers are still role prompts on the same underlying model. They are not statistically independent systems, and consensus is not proof.
- No runtime test suite is executed by default. Python and JSON checks are static; a valid parse does not prove correct behavior. Arbitrary generated code should not be executed without an explicit, isolated test environment.
- The host cannot prove that a review finding is truthful, that a test is comprehensive, or that the requested behavior is fully specified. A model can omit an issue or provide false factual claims.
- There is no universal deterministic validator for all supported programming languages, APIs, user intent, security properties, or natural-language answers.

### Recommended next additions, in priority order
1. **Reproducible test runner:** let the user explicitly select a project-specific test command, run it against a disposable copy in a container/VM with network and secrets disabled, enforce CPU/memory/time limits, and attach raw logs and exit codes. Do not call a plain subprocess/temp folder a security sandbox.
2. **Requirement-to-test matrix:** have the council list each user requirement, the test that demonstrates it, the result, and what remains untested. Block “verified” status if any critical requirement lacks evidence.
3. **Independent evidence lookup:** for library/API questions, inspect the repository's lockfiles and installed versions and cite official documentation or source files; distinguish verified facts, inference, and unknowns. Do not let model confidence substitute for sources.
4. **Regression benchmarks:** maintain held-out tasks for Python, JavaScript, web apps, and simulations; track pass rate, regressions, security findings, and false-positive blockers before changing prompts/models.
5. **Model diversity:** if hardware permits, use different model families for implementation and red-team review. Keep the same deterministic host gates; more models alone do not guarantee correctness.
6. **Safe self-improvement:** only promote lessons after test evidence and human confirmation; deduplicate, scrub secrets, keep a held-out evaluation set, compare before/after, and roll back adapters that regress.
7. **Transactional workspace hardening:** use OS-level isolation and descriptor-based path operations to reduce symlink/time-of-check-time-of-use races; the current application is intended for a trusted local workspace, not hostile multi-user use.

### Updated assessment
The approval path is stronger because material findings cannot be ignored by a later AI vote. This reduces one specific failure mode; it does not make answers infallible. The system should label code as *statically checked*, *tests passed*, or *not verified* based on host-observed evidence, never merely on a peer's claim.


## Deep audit follow-up — 2026-10-12 (portable app, knowledge digestion, isolated tests)

### Implemented
- Added `offline_coder/isolated_tests.py`: optional Python compile + unittest checks inside an already-installed Docker `python:3.12-slim` image. It does not pull images automatically. The test copy omits common generated/dependency directories and secret/binary database suffixes, overlays the proposed patch into a disposable temp directory, disables container networking, uses a read-only container root, drops capabilities, enables no-new-privileges, uses a non-root UID, sets CPU/memory/PID/time limits, and cleans up after completion. A failed run marks the candidate invalid and can trigger a revision. Missing Docker/image is reported as SKIPPED, never PASSED.
- Added unit tests for Docker-unavailable, image-unavailable, and non-Python proposal behavior.
- Added a responsive single-file browser app, `CodingCouncil_Universal.html`, for modern phones and computers. It does not require GitHub specifically; any compatible HTTPS static host can serve it. It uses browser-local inference with runtime/model downloads and no AI API endpoint. Local browser storage is not synced between devices.
- Added a knowledge-digestion workflow to the browser app. Users select bounded text-based documentation/source files, the local model creates a structured digest, the user inspects it, and only after explicit confirmation can it be stored as reviewed knowledge for future tasks. PDF/OCR is not supported by the browser edition.
- Added `START_HERE.md` with standalone, desktop, and phone-to-desktop routes.

### Verification performed in this audit pass
- `python -m unittest discover -s tests -v`: 22 tests passed.
- Python compilation: passed.
- Browser app and standalone universal HTML JavaScript syntax checks: passed with Node.js `--check`.
- ZIP integrity checks: passed for the final portable and GitHub-ready archives.
- No physical phone/desktop browser test, Docker container execution, generated-project runtime test, or independent penetration test was performed.

### Important limits and risks
- Isolated Python execution is only enabled if Docker and the exact image already exist locally. It checks Python compilation and standard-library unittest discovery; it does not install third-party dependencies, run arbitrary shell scripts, or cover JavaScript/browser/backend runtime tests. A skipped check is not evidence of correctness.
- Docker is a defense-in-depth boundary, not a mathematical guarantee that hostile tests are harmless. Do not test untrusted code with valuable host data available.
- The browser digest can summarize incorrect or malicious content. Imported content is untrusted, the user must review it, and the council must still cross-check important claims against authoritative sources.
- The single HTML file still depends on external HTTPS runtime/model downloads on first use. `file://` behavior varies by browser; HTTPS hosting is the recommended path. It is not a fully self-contained, air-gapped model binary.
- Browser localStorage does not sync automatically between phone and computer. Export/transfer is needed to move learned knowledge.


## Website ingestion + autonomous editing audit — 2026-10-12

### Implemented
- Added a website ZIP importer and whole-folder selector to `CodingCouncil_Universal.html`. It ingests supported text/source files and performs a multi-pass architecture digest rather than truncating all website content into one prompt.
- Bounds: 10 MB compressed ZIP, 20 MB expanded ZIP, 1 MB per file, 1,000 ZIP entries inspected, up to 300 supported text files, and 250,000 extracted characters. It skips dependency/build directories, binary files, unsupported extensions, unsafe paths, and secret-like paths. HTML script/style blocks are stripped for text extraction. The digest includes architecture notes and a partial inventory, and must be reviewed before saving to the knowledge shelf.
- Added a browser **Autonomous repair** toggle. ON allows one extra bounded in-memory revision pass without per-edit prompts; the browser app still cannot write directly into local device files.
- Added a desktop **Autonomous edits: ON/OFF** button, default OFF and persisted in settings. After explicit opt-in, future proposals are written automatically only when all known peers unanimously approve, no blockers remain, host safety checks pass, and the core apply function accepts the proposal. The core apply path backs up overwritten files and never executes generated code. Protected app-control files remain separately restricted.
- Updated the setup guide and README with limits and honest capability boundaries.

### Verification performed after these changes
- `python -m compileall -q .`: passed.
- `python -m unittest discover -s tests -v`: **24 tests passed**.
- `node --check` on extracted module scripts from `CodingCouncil_Universal.html` and `iphone-app/index.html`: passed.
- `python tools/check_iphone_js.py`: passed.
- `python -m pip check`: reports an environment-level conflict in a preinstalled unrelated package: `moviepy 2.2.1` requires `pillow<12.0,>=9.2.0`, while this environment has Pillow 12.3.0. The Coding Council's declared runtime requirements do not include MoviePy; this is not evidence of a Coding Council dependency failure, but it is recorded rather than hidden.

### Limits / not claimed
- Website import was syntax-checked but not exercised in a real browser with a representative website ZIP, large archive, iPhone Safari, or desktop folder picker. Model-based digestion was not run end-to-end because that requires downloading and loading a compatible model in a browser.
- The browser digest stores a summary and partial inventory, not the entire site as a live editable workspace. Browser task context remains constrained by the small local model. To edit a site, import the relevant source files separately as project input.
- At the time of this earlier audit pass, automatic URL crawling was not implemented. The later “URL website import follow-up” and “Deep source and integration audit” sections supersede that state; URL crawling is now implemented with explicit limitations.
- The browser autonomous toggle only enables an extra revision pass in memory; it cannot silently modify files on the phone/computer. The desktop auto-apply toggle can write to the selected workspace, but only after unanimous approval and host safety checks. It is still experimental and should be used only with a dedicated workspace and backups.
- No real Docker container execution, full application GUI session, generated project runtime test, physical phone test, or independent penetration test was performed. The full audit remains a source-and-test review, not proof of error-free operation.

### Recommended next additions
1. Add a testable website import preview showing exactly which paths were included/excluded before digesting, plus a downloadable import manifest.
2. Add optional sitemap-aware URL crawling through a separate backend with SSRF protection, redirect revalidation, private-IP blocking, byte/time limits, and domain scope controls; do not use unrestricted browser/server URL fetches.
3. Add workspace change diff, per-file rollback, and an auto-apply activity log visible from the main UI.
4. Add browser/JavaScript runtime tests and a requirement-to-test matrix so approvals are grounded in execution evidence, not only static checks and model votes.
5. Add incremental website digests so later imports can summarize only changed files and preserve source hashes/version metadata.


## URL website import follow-up — 2026-10-12

### Implemented
- Added a public HTTPS URL field and **Fetch and digest website URL** action to the universal browser app. It attempts a bounded same-origin crawl of up to 25 HTML pages and linked same-origin JavaScript/CSS/JSON/text resources, then feeds those resources through the existing multi-pass website digester. Cross-origin links are not crawled.
- Requests omit credentials, do not follow redirects, cap each resource at 1 MB and total extracted content at 250,000 characters, and reject obvious localhost/private/IP-literal host forms. This is defense-in-depth for a browser-only importer, not a formal security guarantee.
- Direct browser fetching avoids sending site URLs/content to a third-party proxy, but it depends on CORS: many websites do not permit cross-origin browser reads. The fallback is to download the source website as a ZIP or select its folder.

### Verification for this follow-up
- `node --check` on the extracted universal HTML module script: passed.
- Confirmed URL-import controls and handler exist, and the document contains no duplicate HTML IDs.
- `python -m unittest discover -s tests -v`: 24 tests passed (these are primarily desktop/core tests and do not validate live browser network behavior).
- Not tested end-to-end against a real public URL or in a physical mobile browser. URL import must therefore be considered implemented but not yet browser-integration-verified.


## Deep source and integration audit — 2026-10-12 (latest)

This section supersedes earlier audit status notes where the current implementation has changed. It records the source review, fixes, and validation actually performed in this pass.

### Scope reviewed

- Python council orchestration, vote/review host gates, path validation, backup/apply implementation, local learning/knowledge stores, workspace scanner, mobile HTTP companion, and optional isolated Python test runner.
- Standalone universal HTML app, website URL crawler, ZIP/source digestion controls, inline preview isolation, local model/runtime loading paths, iPhone app JavaScript, GitHub Actions CI and Pages workflows.
- Project tests, Python/JavaScript syntax, browser import behavior using mocked site responses, archive creation plan, dependency metadata, and documentation consistency.

### Fixes made in this pass

1. **URL-only import now reaches digestion.** Previously, the digestion function returned early if neither a ZIP nor folder was selected, even when a preceding URL crawl had populated URL sources. The check now accepts staged URL sources. A headless Chromium test imported a mocked four-resource website and observed “Completed: 4 text files”, a generated `Website digest: index.html` title, and a source inventory.
2. **Bounded streaming reads and timeouts.** Each fetched URL resource is limited to 1 MiB using a streamed reader; the cap still works when `Content-Length` is absent. Each request/read is aborted after 12 seconds and the full crawl has a 90-second deadline. The crawler is capped at 25 same-origin URLs and 250,000 extracted characters, does not send credentials, rejects redirects and uses HTTPS only.
3. **Secret-aware isolated test snapshots.** The Docker snapshot copy excludes common secret-like directories and file paths (including `.env*`, `secrets/`, credential paths, private key/database suffixes), rather than only skipping a few suffixes. The path validator also rejects `.env`-like parent directories. Regression tests cover these paths.
4. **Mobile companion exposure reduced by default.** The server now binds to `127.0.0.1` by default; LAN service requires explicit `--host 0.0.0.0`. The one-time secret is passed in a URL fragment (not sent in the initial HTTP request), stripped from browser history, and sent to API routes in an `Authorization: Bearer` header instead of query strings. Added no-store, no-referrer, no-sniff, anti-framing and restrictive CSP response headers, plus negative content-length validation. **Explicit LAN mode still uses unencrypted HTTP and is not safe on an untrusted network.**
5. **Workspace scanning is bounded.** The context scanner now caps directory and file traversal (defaults: 8,000 directories and 20,000 files), sorts traversal entries for more repeatable output, and adds an explicit note when a safety cap truncated the scan. This prevents unbounded walk time on pathological repository trees, but large monorepos may need narrower workspace selection. The isolated Docker snapshot copier has corresponding 8,000-directory/20,000-file traversal caps and skips testing if either is exceeded.
6. **Static companion checks added to CI.** `tools/check_mobile_app.py` extracts and syntax-checks the mobile page's inline JavaScript, checks IDs/labels, and guards token handling and the localhost default. CI invokes this checker. The universal app checker now also guards URL-import timeouts and the `fflate@0.8.3` patch version.
7. **Pages publishing corrected.** The Pages workflow now builds `_site/index.html` from `CodingCouncil_Universal.html` and publishes `iphone-app/` below `/iphone-app/`, so the workflow matches both packaged browser choices. This workflow was YAML-parsed locally; it has not been executed by GitHub Actions in this audit.

### Latest verification results

- `python -m unittest discover -s tests -v`: **31 tests passed** (host approval/safety/knowledge/learning, optional isolated-test behavior with Docker mocked, mobile auth shape, secret-path exclusions, and workspace scan bounds).
- `python -m compileall -q main.py offline_coder tests tools`: passed.
- `python tools/check_iphone_js.py`: passed.
- `python tools/check_browser_app.py`: passed — universal inline JavaScript syntax, 52 unique IDs, label references, iframe sandbox, URL-only import guard, stream size cap, time limits, redirect/credential guard, and ZIP parser version guard.
- `python tools/check_mobile_app.py`: passed — mobile embedded JavaScript syntax, 7 unique IDs, label references, bearer-header/fragment behavior, localhost default, and CSP presence.
- `python tools/train_lora.py --help`: passed without importing optional training packages; **actual fine-tuning was not run**.
- GitHub Actions YAML files parse successfully with the available YAML parser.
- Headless Chromium mocked-site integration: four mocked resources (HTML home, HTML about page, CSS, JS) were collected and digested with no browser console/page errors. URL validation rejected tested localhost/private/IP-literal, HTTP, and embedded-credential examples. A streamed response exceeding 1 MiB was rejected even without a declared `Content-Length`.
- Headless Chromium ZIP import integration: a real small ZIP was uploaded and its central directory was checked; a test-only mocked decompressor returned two source entries, and the digestion flow completed with an inventory and no browser console/page errors. This validates the UI/preflight/control flow, not the actual CDN fflate module itself.
- `python -m pip check` still reports the environment-level, unrelated conflict `moviepy 2.2.1` requires `pillow<12`, while this environment has Pillow 12.3.0. The Coding Council's declared normal runtime dependencies do not include MoviePy.

### Findings that remain open (ordered by risk)

**HIGH — Browser runtime supply-chain boundary.** The universal HTML imports the model runtime from jsDelivr and downloads model assets from Hugging Face; ZIP decoding also loads `fflate` from a CDN. Inference is in the browser and there is no AI API endpoint, but third-party JavaScript executes with access to the page's browser context. If the runtime/CDN or selected host is compromised, uploaded project text and browser-local knowledge could be exposed. The app is not air-gapped and lacks a restrictive main-document CSP/SRI-style verification for dynamically imported modules. For sensitive/private source trees, use only reviewed content; the strongest next step is to vendor/self-host exact runtime assets, record hashes, and add a compatible CSP. `fflate` was advanced from 0.8.2 to 0.8.3; the model runtime remains pinned to 3.8.1 to avoid an untested compatibility migration.

**HIGH when enabled — Mobile LAN traffic is unencrypted.** Localhost is now the default and bearer tokens are no longer in API query strings, but `--host 0.0.0.0` enables plain HTTP across the LAN. An observer on an untrusted network can read bearer headers and replay the token. Do not use LAN mode on public Wi-Fi, do not port-forward it, and prefer desktop-only use for sensitive projects until TLS or a VPN-secured route is configured.

**MEDIUM — URL importer is not a server-grade SSRF defense.** It runs in the user's browser, uses CORS, has same-origin scope, rejects obvious private/IP-literal hostname spellings, disables redirects, caps bytes/time, and sends no credentials. It does not independently resolve and vet a DNS hostname's final IP address, so URL validation should not be reused in a server-side crawler. Many normal sites will fail because CORS is not enabled or redirects are used; the source-ZIP/folder workflow is the fallback. No real public website was tested; the browser test used mocked responses.

**MEDIUM — File apply has a time-of-check/time-of-use race.** Safety/path/symlink checks and hash checks occur before staged file replacement, but a hostile concurrent process could theoretically replace a parent path/symlink between validation and write. Multi-file writes are staged and backups are created, but replacements are sequential rather than a single filesystem transaction; rollback failures can be difficult to recover from. Use a trusted workspace, version control, and backups; a future hardened writer should use descriptor-based path operations/locking and test each rollback path.

**MEDIUM — Automated test coverage is incomplete.** The optional Docker runner only handles Python compile/unittest and skips if Docker or the preloaded image is absent; it does not install project dependencies and its Docker execution was mocked in this environment. The browser edition does not run generated backend/unit tests, and the restricted iframe is only a preview. No generated website/game/backend was built or executed end-to-end. A `SKIPPED` status is not a pass even though an otherwise safe candidate may remain eligible for review/apply.

**MEDIUM — Model reviewers are correlated.** The four “peers” are separate role prompts using one selected underlying model, not four independent model families. Shared blind spots, confidently wrong analysis, fabricated API claims, and omitted tests remain possible. Host gates correctly add deterministic guardrails but cannot prove functionality or truth.

**MEDIUM — Dependency reproducibility / continuous vulnerability scans.** Most Python dependencies use lower bounds instead of a lock file; browser runtime/model artifacts are externally hosted. This is not a claim that a current known dependency CVE affects the declared minimums. For context, the official `llama-cpp-python` advisory for CVE-2024-34359 lists affected versions `0.2.30–0.2.71` and fixed version `0.2.72`; this project declares `>=0.3.0`, outside that specific affected range, but that does not replace continuous scanning. Reference: https://github.com/advisories/GHSA-56xg-wfcc-g829. Add automated dependency advisory scanning and review updates instead of treating syntax/tests as dependency security proof. The GitHub Actions workflows also currently reference major-version action tags rather than immutable full commit SHAs; SHA pinning is a further CI supply-chain hardening step.

**LOW/MEDIUM — Heuristic secrets and risk rules are not complete.** Secret-path/pattern screening catches common forms but can miss secrets under generic filenames or produce false positives. Imported docs/website source and saved lessons remain untrusted; manually inspect digests and never treat retrieved text as authoritative without checking it.

**LOW/MEDIUM — Performance and device matrix not validated.** Browser localStorage is device-local, and model weights/runtime require internet on first load. Model memory/speed depends on the selected model, WebGPU/WASM implementation, browser, and device. Large website imports are intentionally incomplete beyond limits and the digest is not a full live editable tree. No physical iPhone/Safari session or desktop GUI session was run.

### Operational recommendations before relying on this for important projects

1. Keep autonomous file writes OFF by default; when using them, use a Git branch or disposable workspace and inspect the patch/backup path after each run.
2. Do not enable mobile LAN mode on untrusted Wi-Fi. Use local-only desktop mode for sensitive repositories.
3. Do not upload projects containing secrets unless you have reviewed the external browser runtime and removed sensitive files. The model inference endpoint is local, but the browser runtime is loaded from third-party hosting.
4. Add real project-specific browser/backend tests in a disposable environment, a requirement-to-test matrix, and CI dependency scanning before calling a result verified.
5. Use website ZIP/folder import when URL fetching fails, and review the inventory/skipped-resource notes before trusting the digest.

### Final assessment

The core code path is a useful experimental scaffold with meaningful host-side approval checks, path restrictions, backups, source ingestion bounds, and regression tests. The latest static checks and mocked browser-import integration pass. It is **not error-proof, not security-certified, not fully runtime-tested, and not ready to expose its LAN interface to untrusted networks**. The highest-value remaining work is supply-chain hardening for the universal browser app, TLS/VPN for remote phone control, and end-to-end tests against real projects on supported devices.


## Feature expansion follow-up — 2026-10-12

### Added in this pass

- Added `offline_coder/project_tools.py` with a bounded read-only project inventory, dependency-manifest listing, likely entry-point/test detection, TODO markers, read-only Git status, and heuristic security/accessibility/performance flags.
- Added a deterministic acceptance-checklist compiler. It preserves distinct lines, deduplicates obvious repeated requirements, and adds a reviewable verification plan. It is a draft generator, not a semantic requirements compiler.
- Added an append-only `.council/task_history.jsonl` journal and desktop task-history viewer. It records task, status, summary, run ID, and report path, not project source contents.
- Added manifest-backed rollback for new-format backups. The manifest tracks both overwritten files and newly created files so rollback can restore originals and remove newly created targets. Old backups without a manifest cannot use automatic rollback.
- Added four non-overwriting starter templates: `website`, `browser-game`, `web-simulation`, and `python-cli`.
- Added browser Project Lab controls for source inventory, acceptance checklist, task-history view/export, and manual responsive preview viewport widths (375, 768, 1280, fit screen).
- Hardened task-history and rollback paths to refuse symlinks in the managed `.council` tree.

### Validation in this pass

- `python -m compileall -q .`: passed.
- `python -m unittest discover -s tests -v`: 39 tests passed after adding project inventory, checklist, task journal, rollback, template safety, and static-flag tests.
- `python tools/check_browser_app.py`: passed; inline JavaScript syntax, unique IDs, labels, sandboxed iframe, and URL import guard checks passed.
- `python tools/check_iphone_js.py`: passed.
- `python tools/check_mobile_app.py`: passed.
- No real local model inference, live public website crawl, physical phone test, actual Docker container execution, production deployment, native game-engine test, or independent penetration test was performed in this pass. A headless Chromium interaction smoke test was attempted, but the execution environment blocked both `http://127.0.0.1` and `file://` navigation with `ERR_BLOCKED_BY_ADMINISTRATOR`; therefore browser interaction remains unverified here.

### Important distinction: requested ideas vs implemented capabilities

The current project still does not implement truly independent model instances per peer, parallel model execution, a full Playwright test lab, Unity/Godot/Unreal integration, CVE database lookups, voice control, cross-device sync, continuous monitoring, a generic plugin runtime, competing Git worktree orchestration, source-mapped visual debugging, or production deployment automation. The Project Lab's security/accessibility/performance findings are simple static heuristics and can produce false positives or miss real issues. The browser viewport buttons only resize the preview manually; they do not automate assertions.

### Remaining safety concern

The rollback workflow validates all target paths and creates a pre-rollback snapshot before applying the selected backup, but restoration across multiple files is not a single filesystem-wide atomic transaction. If the operating system fails mid-restore, inspect the pre-rollback snapshot under `.council/backups/rollback_*` and recover manually. Use Git commits for important projects.


See `FEATURE_STATUS.md` for the current implemented / partial / not-yet-implemented feature matrix.


## Web research feature — 2026-10-12

Implemented optional source-linked public web search. The desktop app uses a bounded standard-library HTTP request to a fixed DuckDuckGo HTML endpoint (no API key), limits query length/results/timeout/response size, accepts only HTTP(S) result links, and places snippets into task context only after explicit user action. The phone companion uses an authenticated `/search` route on the desktop host. The universal browser edition uses Wikipedia's public CORS-enabled API for automatically ingestible snippets and can open a broader search in a separate tab; it does not proxy or automatically scrape arbitrary search engines.

Search results are untrusted, potentially stale snippets—not verified evidence. The tool does not execute page content or automatically fetch result URLs. Network integration tests mock provider responses; a live external search request was not performed in this build environment. Provider markup, connectivity, rate limiting, or policy may cause search failures.

### Latest verification after web-search integration

- `python -m unittest discover -s tests -v`: **46 tests passed**.
- `python -m compileall -q offline_coder tests`: passed.
- Node `--check` on extracted universal-app module script and phone-companion inline script: passed.
- Web-search unit tests cover result parsing, query bounds, response-size cap, content type, URL scheme/credential filtering, and untrusted-context labeling.
- No live search request was made; mocked provider HTML was used. Real provider markup and network availability remain unverified here.


## Deep audit follow-up — autonomous research and source hierarchy (2026-10-12)

### Changes implemented

- Added autonomous pre-task web research to the desktop `CouncilRunner`; it runs before the four peers analyze a relevant task and attaches source-linked results to the read-only context. Research is enabled by default and can be switched off with the saved **Autonomous web research** setting. The CLI and authenticated phone-host route respect the same setting.
- The universal browser app now has a checked **Automatically research relevant tasks** toggle and searches Wikipedia before peer analysis. It still supports manual Wikipedia search and opening a broader search in a new tab.
- Search queries are bounded to 180 characters; code fences and URLs are stripped and common credential-like key/value patterns are redacted. The external provider receives the short query, not project source files or the local model prompt as a whole. This is best-effort redaction, not a guarantee that all sensitive information is removed; disable web research for confidential tasks.
- Search result domains are labeled and ranked using a transparent heuristic: relevant primary/official documentation and standards first for exact technical behavior, Wikipedia as an established secondary encyclopedia above unclassified personal/community sources, and unclassified sources as unverified leads. Prompts tell peers to cite URLs, check recency and version fit, corroborate material claims, and treat webpage text as untrusted data rather than instructions.
- Search failures are recorded and do not abort the coding task. Trivial tasks and explicit no-web/offline-only requests are skipped by a heuristic.

### Verification performed

- Python compilation passed.
- Full unit test suite: **53 tests passed**. This includes automatic research injection before peer analysis, graceful handling of provider failure, source-tier ranking, query sanitization, and default settings.
- Universal browser JavaScript syntax, duplicate-ID/label checks, preview sandbox checks, and URL-import guards passed using `tools/check_browser_app.py`.
- Phone companion JavaScript syntax, IDs/labels, authentication, and localhost-default checks passed using `tools/check_mobile_app.py`.
- The search-provider HTTP request was mocked in tests. A live external search was not executed in this audit; provider availability, page markup changes, and real device behavior remain unverified.

### Remaining limitations / risk

- Desktop/CLI/phone-host research uses DuckDuckGo HTML result snippets, not full-page retrieval or fact verification. Browser autonomous research uses the Wikipedia API only; broader search engines are opened manually because arbitrary cross-origin search access is not reliable from a standalone browser page.
- Domain reputation is a heuristic, not a truth score. Official sites can be outdated or wrong; Wikipedia can be incomplete or stale; an unknown source may still be correct. For technical claims, prefer the specific official documentation for the project's installed version.
- Query redaction handles common obvious patterns but cannot identify every private detail. The short query is sent to an external provider. Disable autonomous research before working on sensitive/private task descriptions.
- Autonomous research occurs before peer analysis, not as an unrestricted iterative agent tool-call loop. The council does not fetch arbitrary result URLs or execute instructions from retrieved pages.


## Deep quality and full-project audit — final pass (2026-10-12)

### Reasoning and research workflow

- Desktop workflow: bounded autonomous pre-task web search; four role-based first-pass analyses; optional up-to-two model-suggested follow-up queries based on gaps/uncertainties; peer cross-examination; structured task/acceptance plan; draft; host validation; adversarial reviews; final votes; revision if configured; and final report. Answer-only outcomes now receive a final synthesis.
- Browser workflow: explicit/automatic answer-versus-build mode; local model analysis and cross-review; answer synthesis, source-link display, bounded Wikipedia follow-up searches, and output rendering. Build mode has its own manifest/acceptance-contract flow.
- Source ranking is heuristic. Primary/official documentation is preferred for exact versioned behavior; Wikipedia ranks above unclassified blogs/community sources but below suitable primary sources. Source tiers are not truth scores. Desktop search supplies snippets and does not fetch each full result page; the browser edition searches Wikipedia snippets only.
- Complex-task performance still depends heavily on the chosen local model, its supported context length, available RAM/VRAM, and model instructions/training. The four peers are **role prompts around one model**, not four independent model families. Consensus can still be confidently wrong. Larger capable models improve the odds but do not guarantee correctness.

### Additional source-level findings

- Path canonicalization: generated file paths now need to be clean relative forward-slash paths. This keeps the paths checked for secret names, symlinks, hashes and containment aligned with the paths the writer will use on Windows/macOS/Linux. Added regression tests for backslashes, repeated separators, dot segments and surrounding whitespace.
- Search privacy: code fences, URLs, common credential key/value patterns, bearer tokens, some common provider tokens, emails, phone-like numbers, JWT-like strings, local path prefixes and IPv4-like strings are redacted or removed before research queries leave the device. This is **best-effort** and cannot identify all project names, unique identifiers, secrets, or personal details. Disable autonomous research for sensitive tasks.
- Context and workspace bounds: the workspace scanner, project inventory, and optional Docker snapshot have traversal/size limits. Scans can be incomplete when limits are reached; the status note should be read rather than treating the inventory as exhaustive.
- The optional test runner never pulls a Docker image, and reports `SKIPPED` if Docker or the expected image is absent. The container runtime configuration was checked in code, but Docker itself was not run in this environment. It only covers Python compile/unittest discovery and does not install project dependencies; successful results do not prove security.
- Host write checks revalidate safe paths and expected content hashes, back up files, and block common protected paths/file types. Backups and multiple-file replacement are not a single filesystem transaction. A narrow race with a hostile concurrent filesystem process remains possible. Continue using a trusted workspace and version control.

### Current verification record

- `python -m unittest discover -s tests -q`: **59 passed**.
- `python -m compileall -q main.py offline_coder tests tools`: passed.
- `python tools/check_browser_app.py`: passed; Node syntax, HTML ID/label and preview checks, plus **9 browser logic/rendering checks** passed.
- `python tools/check_mobile_app.py`: passed; JS syntax, IDs/labels, auth/local-only defaults passed.
- `python tools/check_iphone_js.py`: passed.
- `.github/workflows/ci.yml` and `pages.yml`: parsed successfully as YAML.
- `unzip -t` on rebuilt portable and GitHub-ready archives: passed after packaging.
- `python -m pip check`: reports the unrelated shared-environment `moviepy`/`pillow` version conflict noted at the top. No full vulnerability database scan ran because `pip-audit` was not installed; no claim is made that all transitive dependencies are secure.

### Remaining high-value engineering work (not claimed implemented)

1. Test with one or more real local models on supported desktop hardware, including complex multi-file tasks and context-window overflow. Add a benchmark set with expected answers and acceptance checks to measure quality instead of assuming it.
2. Add a token-aware prompt budget. Character-count budgeting is approximate and large candidates/analyses may exceed the active model's context window.
3. Run true browser E2E tests (e.g. Playwright), real URL imports from several permissive and CORS-blocked sites, and a physical iPhone Safari compatibility matrix.
4. Add a real, versioned dependency lock/upgrade policy and continuous advisory scanning. Pin GitHub Actions to immutable SHAs before use in a security-sensitive public repository.
5. Harden the workspace write/rollback transaction against hostile concurrent modification; add Windows/macOS/Linux-specific regression tests.
6. For the browser version, consider self-hosted/version-pinned runtime assets and verify third-party artifacts. The universal page downloads its JS runtime/model artifacts on first use and is not fully air-gapped.

### Final judgment

This pass improves the answer/research pipeline, fixes one major browser runtime-reference defect, hardens cross-platform path handling, expands regression coverage, and verifies the current project’s syntax/checks/package. It remains an experimental local coding scaffold. **The audit does not prove complex-task correctness, production security, full runtime compatibility, or frontier-level intelligence.** Real-model benchmarks, live web integration, true browser E2E, and a penetration review remain necessary before trusting it with important or sensitive work.

## Follow-up reliability pass — 2026-10-13

### Implemented

- Added a fail-closed autonomous-write gate: unanimous council/host approval is still required, and unattended writes now additionally require an actual isolated runtime test report marked `PASSED`. A missing report, `SKIPPED`, `NO_TESTS`, `NOT_APPLICABLE`, or other status blocks unattended writes. Manual Apply remains available for a user to review and explicitly approve.
- Added a second check at the final GUI apply boundary so an automatic write cannot proceed just because the result-rendering flow was passed earlier.
- Fixed a false-positive in the optional Docker Python test runner: an empty unittest suite previously returned exit code zero and could be mislabeled `PASSED`. It now reports `NO_TESTS` when compilation succeeds but no tests are discovered.
- Added regression tests for the unattended-apply gate and empty test suites.
- Added `models/RECOMMENDED_MODEL.md` with a model-selection recommendation and hardware/compatibility caveats. Recommendation is to use an established open-weight coding model now, collect verified examples, and consider fine-tuning later rather than training a foundation model from scratch.

### Verification in this follow-up

- `python -m unittest discover -s tests -v`: **62 tests passed**.
- `python -m compileall -q main.py offline_coder tests`: passed.
- `python tools/check_iphone_js.py`: passed.
- `python tools/check_mobile_app.py`: passed.
- `python tools/check_browser_app.py`: passed.
- `node tools/check_browser_logic.mjs`: 9 checks passed.
- These checks do not include a real model generation, verified Qwen3-Coder-Next runtime compatibility, a real Docker container execution, live internet research, physical phone/Safari testing, or a production end-to-end coding task. The Docker behavior tests are mocked. The system is more conservative, not infallible.

### Residual limits

- Autonomous writes for non-Python changes are blocked by the strict runtime-test gate until a relevant real test runner is implemented and reports `PASSED`; use manual review/approval for those tasks in this build.
- Four peer roles still share one underlying model. This is structured review, not four independent models.
- The Qwen3-Coder-Next recommendation is not a universal ranking and its compatibility with the current `llama-cpp-python` backend has not been validated here.


## Follow-up upgrade: local backend verification, cross-language checks, repair feedback (2026-10-13)

### Implemented
- Added `LocalServerModel`, an OpenAI-compatible adapter for a model server running on the same computer. It checks `/v1/models` before use, selects or validates an exact model ID, refuses non-loopback hosts, rejects embedded credentials/query/fragment, disables proxy use, and does not follow redirects. It never calls a remote endpoint by configuration.
- Added desktop UI and CLI selection between in-process GGUF inference and a verified loopback local server. The app does not download models or start servers automatically.
- Added isolated Node.js syntax checks and built-in `node:test` execution with a preinstalled `node:22-alpine` Docker image, in addition to Python compile/unittest checks. Docker images and dependencies are never pulled/installed automatically; tests run without network access and with resource limits.
- Aggregated supported project checks. A failed test run passes its bounded diagnostic output to the existing revision loop. A revised candidate must be validated and reviewed/voted on again; previous reviews do not authorize the new patch.
- Added tests for local-server verification, refusal of remote hosts, model ID validation, Node runtime skip behavior, status aggregation, and failed-check blocking.

### Verification performed in this environment
- `python -m unittest discover -s tests -q`: 68 tests passed.
- `python -m compileall -q .`: passed.
- `python tools/check_iphone_js.py`: passed.
- `python tools/check_mobile_app.py`: passed.
- `python tools/check_browser_app.py`: passed.
- `node tools/check_browser_logic.mjs`: 9 checks passed.
- No real local LLM server was started; model discovery and completion requests were tested with mocked responses. No real GGUF model was loaded. No Docker runtime or real project code execution is claimed; isolated Docker behavior is unit-tested with mocks only.

### Limitations
- Local server compatibility depends on the server implementing OpenAI-compatible `/v1/models` and `/v1/chat/completions`; specific Qwen3-Coder-Next runtime compatibility is not asserted.
- Python tests use `unittest` discovery; Node runtime tests use Node's built-in `node:test`. Projects relying on external JS test frameworks, missing dependencies, browsers, mobile devices, or game engines need additional runners.
- This is a bounded repair loop, not an unlimited autonomous process. `review_rounds` controls how many revisions are allowed. Missing tests or unavailable Docker/images are reported as unverified and block unattended application.
- Docker isolation reduces risk but is not a formal sandbox. Passing tests and unanimous model votes do not prove correctness or security.


## Follow-up upgrade: explicit project simulations (2026-10-13)

### Implemented
- Added optional root-level `council.simulations.json` with bounded Python/Node script scenarios, argv-based execution (no shell), expected exit code/output assertions, and per-scenario timeout caps.
- Simulations run against the disposable workspace snapshot in already-installed Docker images only; the runner disables networking and applies read-only container root, memory/CPU/process limits, and unprivileged execution. Writes by a scenario are confined to the temporary snapshot.
- Aggregated simulation failures become test failures and are fed to the existing bounded repair loop. Missing Docker/images are reported as SKIPPED; no images or dependencies are downloaded.
- Added `SIMULATION_GUIDE.md` and documented the manifest format and caveats.

### Scope limits
- This adds project-specific command-line smoke/integration simulations, not universal browser interaction or game-engine simulation. Playwright/browser, mobile-device, database/API integration, and Unity/Godot/Unreal tests still require their respective runners and dependencies.
- A scenario can still contain buggy or malicious code. Docker limits reduce risk but do not formally prove safety. Only use trusted workspaces and review scenarios.
- Simulation support is opt-in through a manifest; it does not guess how to safely launch every project.

### Verification for this upgrade
- `python -m unittest discover -s tests -q`: **72 passed** (including four new simulation-runner tests).
- `python -m compileall -q .`: passed.
- `python tools/check_iphone_js.py`: passed.
- `python tools/check_mobile_app.py`: passed.
- `python tools/check_browser_app.py`: passed.
- `node tools/check_browser_logic.mjs`: 9 checks passed.
- The Docker execution paths are tested with mocks; no real Docker image or real project simulation was executed in this build environment. No live model inference or browser/game-engine E2E run is claimed.

## Follow-up upgrade: real-browser visual simulation (2026-10-13)

### Implemented
- Added optional `offline_coder.visual_simulation` runner using Playwright + local Chromium to render a disposable snapshot of a web project, capture a PNG screenshot, record page exceptions and console errors, and capture basic DOM/page metadata.
- Added root-level `council.visual.json` for reproducible viewport settings and bounded CSS-selector actions/assertions (`click`, `fill`, `select`, `press`, `wait`, `assert_text`, `assert_visible`, `assert_count`).
- Browser requests outside the local snapshot origin are blocked. Screenshot and JSON report artifacts are saved under `.council/visual-runs/`.
- Web-facing proposed changes can trigger visual smoke checks during the council's verification/repair process. The desktop UI also has **Visual simulate project…** to render the current workspace and open the saved screenshot.
- Added an optional `visual` dependency extra. The application does not install Playwright, browser binaries, Docker images, or project dependencies automatically.

### Verification and limitations
- `python -m unittest discover -s tests -q`: **78 passed** after this change.
- Python compilation, iPhone JS check, mobile companion check, universal browser app check, and Node browser-logic harness passed.
- Attempted a real Playwright/Chromium smoke run in this build environment; Chromium navigation was blocked by the environment's browser policy (`ERR_BLOCKED_BY_ADMINISTRATOR`), so no real screenshot was generated here. The runner correctly reports a blocked/unavailable browser as SKIPPED. Test coverage here validates manifest/path/action checks and graceful missing-runtime behavior, not a successful real browser render.
- The visual runner is not a vision model: it captures a screenshot and inspects DOM state, configured assertions, and browser errors. It does not semantically understand pixels or simulate native apps / Unity / Unreal / Godot. Those need a compatible vision backend or project-specific engine runner.
- Docker execution remains mock-tested only in this environment. No real local model inference, complete autonomous task, or live Docker simulation is claimed.

## Focused remediation applied — 2026-10-23

This update hardens `offline_coder/safety.py`'s approved file-application path:

- Requires the reviewed-hash mapping to contain exactly the same path keys as the proposal. Missing hash entries can no longer silently act like a reviewed new file.
- Rechecks symlink components, target type, and the current file hash immediately before staging and again before each replacement.
- Uses a unique temporary file in the destination directory, flushes it, and calls `fsync` before `os.replace` for each staged file.
- Records the reviewed pre-change hash in the backup manifest.
- Reports incomplete rollback explicitly and preserves the backup rather than silently swallowing restore errors.
- Adds regression tests for missing hash entries, incorrect new-file hashes, symlink targets, and manifest hash recording.

Verification performed in this environment on 2026-10-23:

- `python -m pytest -q`: **82 passed, 4 subtests passed**.
- `python -m compileall -q offline_coder tests tools`: passed.
- `python tools/check_iphone_js.py`: passed.
- `python tools/check_mobile_app.py`: passed.
- `python tools/check_browser_app.py`: passed.
- `node tools/check_browser_logic.mjs`: 9 checks passed.

Limitations: this is a focused hardening change, not a complete security certification. Filesystem races involving a separate concurrent process cannot be eliminated by these portable path checks alone. Rollback is best-effort; if the operating system refuses restoration, the raised error names the retained backup directory. No real Docker container execution, live model inference, physical iPhone/Safari test, or penetration test was performed as part of this update.

## Security and verification remediation — 2026-10-24

### Findings addressed in this revision

- **Multi-file rollback could overwrite a concurrent edit.** The previous rollback loop attempted to restore every planned target after any apply failure, including targets this invocation had not replaced. Rollback now acts only on files successfully replaced by this invocation. Before restoring/deleting, it checks that the current target still matches the candidate this invocation wrote; unexpected concurrent changes are preserved and reported as incomplete rollback, with the backup retained.
- **Snapshot runners had weaker path validation than the write gate.** Python, Node, and configured simulation runners now share a defense-in-depth overlay helper that rejects non-canonical aliases, absolute/traversal/Windows-drive paths, protected/generated directories, sensitive paths, symlink parents/targets, non-text proposal values, oversized files, and oversized proposal sets before staging into disposable snapshots. The visual browser runner reuses this helper and no longer normalizes ambiguous manifest aliases.
- **Python Docker image inspection could throw before returning a test status.** Image-inspection failures/timeouts now return `SKIPPED` with a reason instead of escaping the runner.
- **A suite containing only skipped tests could be reported as `PASSED`.** Python runtime output now includes explicit counts for run, skipped, executed, failures, and errors; no non-skipped test executions produce `NO_TESTS`. Node's built-in runner also returns `NO_TESTS` when all discovered tests are skipped. The unattended-apply gate independently rejects these zero-execution reports even if a caller supplies a misleading `PASSED` status.

### Regression coverage added

- Concurrent change to an unapplied second file survives rollback when the first file replacement fails.
- Snapshot overlays reject backslash and repeated-separator aliases, traversal, Windows drive paths, `.env`, `.council`, and oversized content.
- Python image-inspection timeout is handled as `SKIPPED`.
- Python and Node test suites where every discovered case is skipped are not marked as behavioral passes.
- Unattended application rejects a Python report indicating zero executed tests.
- Visual relative-path validation rejects non-canonical and Windows-drive aliases.

### Verification performed in this environment on 2026-10-24

- `python -m pytest -q`: **90 passed, 14 subtests passed**.
- `python -m unittest discover -s tests -q`: **90 tests passed**.
- `python -m compileall -q main.py offline_coder tests tools`: passed.
- `python tools/check_iphone_js.py`: passed.
- `python tools/check_mobile_app.py`: passed (12 unique IDs, labels resolve, auth and localhost-default guards pass).
- `python tools/check_browser_app.py`: passed (66 unique IDs, labels resolve, preview sandbox and import/runtime guards pass).
- `node tools/check_browser_logic.mjs`: **9 checks passed**.

### Remaining limitations / not claimed

- The tests above validate local Python logic, mocks, static checks, and browser logic harnesses; they do not demonstrate a real Docker execution, live local-model inference, a real hostile-workspace penetration test, or physical iPhone/Safari behavior.
- Portable path checks cannot fully eliminate filesystem TOCTOU races with a separate concurrent process. Multi-file writes are not a single atomic transaction; rollback remains best-effort and deliberately reports incomplete recovery instead of overwriting an unexpected concurrent edit.
- Docker isolation is a risk reduction, not a formally verified sandbox. A test suite that executes successfully can still be incomplete or maliciously misleading.

## Follow-up remediation — fail-closed test evidence and cross-platform protected paths (2026-10-24)

### Findings addressed

- **A `PASSED` label without structured test evidence could authorize unattended application.** `can_autonomously_apply` now requires the host-generated `checks` structure, requires every reported check to be `PASSED`, and requires positive evidence of executed Python unit tests, passing Node tests, or configured simulation scenarios. A summary label, empty report, or visual-only check is insufficient.
- **Node test runner output was insufficiently validated.** A zero exit code no longer implies `PASSED`: the runner requires a complete parseable test-count summary, rejects reported failures, rejects zero tests, and rejects results where no non-skipped test passed.
- **Protected directory checks were case-sensitive.** Proposal validation and disposable-snapshot overlays now reject case variants of protected directories (for example `.GIT` and `.COUNCIL`) to reduce cross-platform path alias risks on case-insensitive filesystems.

### New regression coverage

- A bare `PASSED` test-report label without structured evidence cannot authorize unattended apply.
- Valid host runner evidence with actual non-skipped Python tests remains eligible for the existing gate.
- Node runner output missing its test summary fails closed even when the process exit code is zero.
- Node runner output reporting failures is rejected even if the process exit code is zero.
- Case variants of `.git` and `.council` are rejected by both proposal validation and snapshot overlay checks.

### Verification performed in this environment on 2026-10-24

- `python -m pytest -q`: **94 passed, 17 subtests passed**.
- `python -m unittest discover -s tests -v`: **94 tests passed**.
- `python -m compileall -q offline_coder tests main.py`: passed.
- `python tools/check_iphone_js.py`: passed.
- `python tools/check_mobile_app.py`: passed (12 unique IDs, labels resolve, auth and localhost-default guards).
- `python tools/check_browser_app.py`: passed (66 unique IDs, labels resolve, preview sandbox and import/runtime guards).
- `node tools/check_browser_logic.mjs`: **9 checks passed**.

### Remaining limitations

The updated gate deliberately fails closed when it cannot identify structured test evidence. Docker runtime execution remains mock-tested only in this environment. No live model inference, physical iPhone/Safari run, independent penetration test, or production deployment was performed. Filesystem TOCTOU races and best-effort multi-file rollback remain known limitations.

## Adversarial remediation — bind approval to exact candidate (2026-10-24)

### Confirmed findings fixed

- **Review-to-apply gap:** an approved `RunResult` could have its `proposed_files` mapping changed after unanimous reviews and still pass the vote/review checks. The apply boundary now requires a SHA-256 fingerprint recorded only after the final unanimous review, recomputes it at apply time, and refuses missing or mismatched fingerprints. This is an integrity check against stale/accidentally modified candidates, not a defense against a fully compromised host process that can rewrite all in-memory state.
- **Stale hash checks normalized invalid UTF-8:** existing files were decoded with replacement characters before hashing, so different invalid byte sequences could normalize to identical text and evade the stale-state check. Existing file hashes now use exact raw bytes at validation and immediately before replacement/rollback; proposed text is still hashed from its exact UTF-8 output bytes.
- **Unsafe optional gate bypass:** `can_autonomously_apply(..., require_runtime_tests=False)` could bypass the runtime-evidence requirement. The argument remains for API compatibility but no longer disables runtime evidence for unattended application.

### Adversarial regression tests

- Mutate a proposed file after unanimous approval and verify apply is blocked with no file written.
- Remove the reviewed-candidate fingerprint and verify apply fails closed.
- Attempt to disable runtime evidence and verify unattended apply remains blocked.
- Change a file between two invalid UTF-8 byte sequences that decode to the same replacement text and verify the raw-byte hash detects the change.

### Verification performed in this environment

- `python -m pytest -q`: **98 passed, 17 subtests passed**.
- `python -m unittest discover -s tests -q`: **98 tests passed**.
- `python -m compileall -q main.py offline_coder tests tools`: passed.
- `python tools/check_iphone_js.py`: passed.
- `python tools/check_mobile_app.py`: passed (12 unique IDs; labels, auth and localhost-default guards checked).
- `python tools/check_browser_app.py`: passed (66 unique IDs; labels, preview sandbox and import/runtime-reference guards checked).
- `node tools/check_browser_logic.mjs`: **9 checks passed**.
- Docker executable was not available, so no real container execution was possible in this environment.

### Remaining risk

- Filesystem TOCTOU races with a separate process cannot be completely eliminated by these portable checks; multi-file rollback remains best-effort.
- Four peer roles use the same configured underlying model, so their votes are not independent model implementations or proof of correctness.
- No live model inference, physical iPhone/Safari run, independent penetration test, or production deployment was performed.

## Deep adversarial remediation — reviewer dissent and rollback symlinks (2026-10-24)

### Confirmed findings fixed

- **Review dissent could be overwritten by later votes.** The deterministic review gate accepted `REQUEST_CHANGES` or `REJECT` from a code reviewer as long as no structured HIGH/MEDIUM/BLOCKER finding survived. The gate now requires every review record itself to vote `APPROVE`; final votes cannot erase a reviewer's explicit dissent.
- **Backup restoration validated resolved paths but wrote through original paths.** A pre-existing symlink target could redirect restoration to another in-workspace file. Restore now rejects symlink components in target paths and backup payload paths, rejects duplicate/non-canonical paths and case-insensitive `.council` aliases, rechecks immediately before mutation, and stages restored files before replacement.
- **Selected backup-directory symlinks were hidden by early path resolution.** Restore now checks the selected path lexically under the managed backup directory before resolving it and rejects symlink path components.
- **Partial rollback snapshots lacked a manifest until success.** The current-state snapshot manifest is now persisted before any restore mutation, so an interrupted restore leaves a discoverable recovery snapshot. A failed multi-file restore can still be partial; the snapshot is retained for recovery and the error states this explicitly.

### New regression coverage

- A reviewer `REQUEST_CHANGES` vote blocks apply even if every final vote says `APPROVE`.
- Restore refuses an in-workspace symlink target, a symlink-selected backup directory, duplicate target entries, and case variants of `.council`.
- Simulated failure during a multi-file restore leaves a manifest and copies of the pre-restore state.

### Verification performed in this environment

- `python -m pytest -q`: **103 passed, 17 subtests passed**.
- `python -m compileall -q main.py offline_coder tests tools`: passed.
- `python tools/check_iphone_js.py`: passed.
- `python tools/check_mobile_app.py`: passed (12 unique IDs; labels, auth and localhost-default guards checked).
- `python tools/check_browser_app.py`: passed (66 unique IDs; labels, preview sandbox and import/runtime-reference guards checked).
- `node tools/check_browser_logic.mjs`: **9 checks passed**.

### Remaining limitations

The restore routine now leaves a recovery snapshot, but multi-file rollback is still not an atomic transaction and can stop partway through. Filesystem races with a separate concurrent process remain possible. The audit still has not performed real Docker execution, live local-model inference, physical iPhone/Safari testing, a production deployment, or an independent penetration test. Four peer roles share the same configured underlying model, so agreement is not independent verification.


## Hostile end-to-end audit follow-up — 2026-10-24

### Additional defects found and remediated
- Search-result ranking previously stopped collecting results at the requested output limit before sorting by source tier. Low-quality results appearing first could crowd out official documentation. The bounded parsed result set is now ranked first, then limited. Official-source classification now requires an exact configured hostname rather than automatically trusting arbitrary subdomains of a documentation host.
- Approval integrity was bound to proposed code but not to the target workspace or reviewed preconditions. A mutated `RunResult.workspace` or `hashes_before` could redirect an otherwise reviewed candidate. Added an apply-context fingerprint binding candidate, resolved workspace, pre-change hashes, and run ID; apply fails closed if that context changes.
- The post-apply report path was mutable and previously written with ordinary `Path.write_text`, which follows symlinks. Apply now checks the report path against the expected `.council/runs/<run-id>.json` location before touching project files, and managed reports use atomic replacement.
- The append-only task journal could follow a pre-planted symlink and append outside the workspace. Journal appends now reject symlinked parent/leaf paths and use `O_NOFOLLOW` where the platform supports it; journal reads refuse a symlinked file.
- Added hostile end-to-end regressions for repository prompt injection attempting to write `.env`, contradictory reviewer votes, failing runtime checks, corrupted backups, misleading research snippets, source-ranking crowd-out, source-host lookalikes, mutated apply workspace, arbitrary report-path redirection, and task-journal symlinks.

### Verification after these fixes
- `pytest -q`: **114 passed, 17 subtests passed**.
- Python compilation, iPhone JavaScript checks, mobile companion checks, browser app checks, and browser logic checks must be rerun against this exact final build before distribution.

### Limits
- Hostile model behavior is simulated with deterministic model doubles in tests; live model robustness against prompt injection has not been proven. Research tests mock search results and do not verify external claims. No Docker execution, live inference, physical iPhone/Safari run, or independent penetration test was performed. Filesystem TOCTOU races remain possible despite symlink checks and atomic report writes.

## Follow-up hostile audit — backup and report-path boundaries (2026-10-24)

A further review found two issues beyond the previous v5 audit:

- `restore_backup` trusted path policy implied by a backup's origin. A crafted manifest under the managed backup directory could target secret paths (for example `.env`, private-key names, or `secrets.json`) or ignored repository metadata such as `.git/config`, even though ordinary proposal writes reject those targets. Restore now rejects ignored directories, secret paths, and unsupported file types before snapshotting or mutating anything. Regression coverage verifies secret and `.git` targets are refused.
- Apply preflight checked whether the final run-report path was a symlink, but not whether `.council` or `.council/runs` had become symlinks. This could let project files be applied before the later report update failed. Apply now checks all managed report path components and refuses before applying any candidate if a symlink or missing report directory is detected. A regression test confirms no candidate file is written in this scenario.

Validation of the final source archive in this environment:

- `pytest -q`: **116 passed, 17 subtests passed**.
- `python -m unittest discover -s tests -q`: **116 tests passed**.
- `python -m compileall -q main.py offline_coder tests tools`: passed.
- `python tools/check_iphone_js.py`: passed.
- `python tools/check_mobile_app.py`: passed.
- `python tools/check_browser_app.py`: passed.
- `node tools/check_browser_logic.mjs`: **9 checks passed**.

Limitations remain: Docker is unavailable here; no live local model is bundled in the archive; live model inference, the user's actual Codespace, and a physical iPhone/Safari run are not verified. These must not be represented as passed tests.

## Hostile audit follow-up — 2026-10-26 (v7)

The full report is in `HOSTILE_AUDIT_REPORT_2026-10-26.md`. This pass reproduced and fixed a settings temporary-file symlink overwrite, added bounded settings validation, added heuristic secret redaction before workspace/knowledge context reaches the model, expanded proposed-code credential detection, and hardened mobile request-body validation and idle socket handling. It also identified that project-controlled test output cannot safely authorize unattended apply; unattended apply now fails closed until a host-controlled evidence attestation exists. This mitigates unsafe automatic writes but does not make malicious test output itself trustworthy. Verification: 127 pytest tests passed, 24 subtests passed; unittest discovery passed; compile, iPhone, mobile, browser, and browser-logic checks passed. Docker was unavailable, so real container isolation remains unverified. See the report for reproducible details and residual risks.


## 2026-11-06 repair addendum

The 2026-11-06 repair pass supersedes the older mobile-network note above: mobile mode now supports TLS certificate/key configuration, refuses plaintext non-loopback binding by default, caps concurrent handler threads at eight, rate-limits requests and failed authentication, and validates POST content length and media type. Plaintext LAN mode is available only with explicit `--allow-insecure-lan` opt-in and remains unsafe on untrusted networks. Model ranking now accounts for missing benchmark coverage and requires task-specific measurements; memory retrieval omits superseded versions and labels stale/conflicting entries. See `REPAIR_AUDIT_REPORT_2026-11-06.md` and `benchmarks/results/council9-repaired-v1.3.json` for current evidence.
