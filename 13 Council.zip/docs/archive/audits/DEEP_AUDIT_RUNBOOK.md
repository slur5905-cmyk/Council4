# Deep audit runbook for the user's Codespace

This archive was tested in a separate local extraction. It has **not** been tested inside the user's live GitHub Codespace. Use this checklist there before replacing any existing files.

## 1. Back up first

- Keep the existing Codespace/repository unchanged until the checks finish.
- Download the ZIP to the Codespace or upload/extract it into a separate folder.
- Do not overwrite the current project folder during the first test.

## 2. Run static and unit checks

From the extracted project root:

```bash
python -m pip install -r requirements.txt
python -m pytest -q
python -m unittest discover -s tests -q
python -m compileall -q main.py offline_coder tests tools
python tools/check_iphone_js.py
python tools/check_mobile_app.py
python tools/check_browser_app.py
node tools/check_browser_logic.mjs
```

If an optional tool is missing, record that check as **not run**, not passed.

## 3. Check Docker availability before trusting runtime evidence

```bash
docker version
docker image inspect python:3.12-slim
```

If either command fails, the Council should report isolated Python execution as skipped. Do not configure unattended apply on the assumption that code was executed.

The runner deliberately does not download container images automatically. If you intentionally choose to fetch the image in a trusted environment, review the image provenance and policy first, then rerun the tests. Generated code should run only in the disposable no-network container, never directly on the Codespace host.

## 4. Real task smoke test

Use a disposable empty test workspace, not the repository containing secrets or valuable work. Ask the Council for a tiny project change with an explicit acceptance test, such as a pure function and unit tests. Confirm all of the following:

- each peer's analysis, cross-review, structured code review, and final vote are visible;
- a single `REQUEST_CHANGES` review blocks approval;
- intentionally failing tests block apply;
- Docker being unavailable is reported as skipped rather than passed;
- modifying the candidate or workspace after review blocks apply;
- the generated diff and backup are inspectable before accepting changes;
- no changes reach the workspace before explicit approval;
- rollback restores the prior state in the disposable workspace.

Do not use a real credential, `.env` file, private key, or production project as the adversarial fixture. Use fake marker strings and disposable files.

## 5. Local model inference

The archive does not include model weights. To test a real model, configure a compatible local GGUF model or a verified loopback-only local server in the Codespace environment. Record the model name/version, quantization, context size, and whether inference ran locally. Do not paste API keys or private model URLs into prompts or public issues. If no compatible model is available, mark live inference as not run.

## 6. iPhone check

Open the forwarded app URL on the iPhone and test the main flow, settings, code preview, reports, and backup controls. Confirm that the app is reachable only through the intended authenticated/forwarded path. Do not enable unencrypted LAN access on an untrusted network.

## 7. Record evidence honestly

For every check, save the exact command, exit code, and summary. Distinguish unit tests and static checks from Docker execution, live model inference, browser/device testing, and independent penetration testing. Passing the first group does not prove the latter groups.
