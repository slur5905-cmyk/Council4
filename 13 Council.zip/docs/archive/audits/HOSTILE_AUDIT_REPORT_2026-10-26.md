# Coding Council hostile audit report — 2026-10-26

## Scope and method

Audited the v6 source archive supplied in this conversation. Extracted it into a disposable working directory, ran the existing suite before changes (116 tests passed, 17 subtests passed), reproduced two data-flow/security defects with small local scripts, changed the source, added regression tests, and reran tests and static/mobile/browser checks. This is not a live GitHub pull or an independent professional penetration test.

## Confirmed findings and remediation

### High — settings writer followed a predictable temporary-file symlink (fixed)

**Affected file:** `offline_coder/config.py`

**Reproducer:** create `settings.tmp` as a symlink to an unrelated file, then call `save_settings`. The original implementation wrote through the symlink before `os.replace` replaced the symlink itself. The unrelated file's contents were overwritten.

**Fix:** settings persistence now uses the existing same-directory atomic writer, which creates a randomized temporary file and refuses a symlink target. Settings values are type-checked and bounded before use; oversized, malformed, symlinked, or incorrectly typed settings fall back safely. New tests cover temporary-link attacks, settings-file links, malformed values, extreme numeric values, and normal persistence.

### High — project-controlled test output could be mistaken for trusted unattended-apply evidence (mitigated fail-closed)

**Affected file:** `offline_coder/council.py` and desktop messaging in `offline_coder/app.py`

**Attack path:** Python/Node test files execute project-controlled code and their stdout is included in the test report. A malicious test can print summary-looking markers or exit early. Parsing output strings is not a reliable trust boundary for unattended writes.

**Fix:** `can_autonomously_apply` now requires an explicit host-controlled evidence attestation. The current runners do not issue that attestation, so unattended apply is blocked in this build. Manual Apply remains available after unanimous reviews, host path/hash checks, and explicit user confirmation. The UI explains why automatic apply is blocked.

**Limitation:** the test report itself may still mislabel a maliciously forged summary as passed in an adversarial project. The mitigation prevents that string alone from authorizing unattended writes; a future trusted test-harness design is needed to make test evidence itself robust against test code that deliberately attacks its own runner. Treat test output as untrusted, not as a proof of safety.

### High — secret scanning missed common API tokens and generic credential assignments (fixed)

**Affected file:** `offline_coder/safety.py`

**Attack path:** the automatic-write safety check only recognized a short list of credential formats. It missed common `sk-...` API tokens and credential assignments such as `password="..."` or `TOKEN="..."`, allowing code that hard-coded these values to pass this particular secret check.

**Fix:** added detection for common API-token formats and credential-like assignments, while allowing explicit placeholders such as `YOUR_API_KEY_HERE`. Added regression tests for API tokens, JSON password values, generic token assignments, and placeholders. This is pattern-based detection and can still miss unknown token formats.

### Medium — ordinary project config files could expose credential-like values to model context (partially fixed)

**Affected files:** `offline_coder/safety.py`, `offline_coder/workspace.py`, `offline_coder/knowledge.py`, `offline_coder/project_tools.py`

**Reproducer:** put an `api_key` and `password` in an ordinary `config.json`. The workspace context collector included both raw values because it only excluded sensitive file paths, not secret-looking values in ordinary source/config files.

**Fix:** added heuristic redaction for common credential assignments, private-key blocks, and common AWS/GitHub/Slack/API/Bearer token formats before workspace context and imported/retrieved knowledge are provided to the model. TODO excerpts in project reports are redacted too.

**Limitation:** this is heuristic redaction, not complete data-loss prevention. Novel token formats, secrets under unusual key names, encoded secrets, and values split across files may evade it. Review sensitive projects before analysis; do not assume the scanner guarantees that every secret is removed.

### Medium — malformed JSON request bodies could trigger uncaught handler errors (fixed)

**Affected file:** `offline_coder/mobile.py`

**Attack path:** valid JSON arrays, strings, or `null` were accepted as request bodies, then endpoint code called `.get`, which only exists on objects. This could produce an unhandled exception and noisy server-side failure.

**Fix:** request parsing now rejects non-object JSON with HTTP 400. The mobile handler also sets a 15-second socket timeout to limit idle/slow-client connection retention when LAN mode is deliberately enabled.

## Other attack surfaces reviewed

- Candidate paths, protected paths, symlink checks, stale hashes, approval fingerprints, reviewer votes, backup manifests, and task journal protections were inspected; the existing tests continue to pass.
- Search result URLs are classified by exact official hostnames rather than lookalike subdomains; snippets remain untrusted prompt context.
- Generated-code test execution uses preinstalled Docker images only, disables network, drops capabilities, sets resource limits, uses an unprivileged user, and mounts a disposable snapshot. This was inspected but **not run in a real Docker daemon in this environment**.
- Mobile mode binds to localhost by default. Explicit LAN mode still uses plain HTTP and should only be used on a trusted private network; do not port-forward it or use it on public Wi-Fi.
- The four peer roles share the configured underlying model. Agreement is not independent verification and does not prove correctness.

## Verification on the modified source tree

- `pytest -q`: **127 passed, 24 subtests passed**.
- `python -m unittest discover -s tests -q`: **127 tests passed**.
- `python -m compileall -q main.py offline_coder tests tools`: passed.
- `python tools/check_iphone_js.py`: passed.
- `python tools/check_mobile_app.py`: passed (12 unique IDs, label checks, auth/default guards).
- `python tools/check_browser_app.py`: passed (66 unique IDs, label checks, preview sandbox and URL-import/runtime-reference guards).
- `node tools/check_browser_logic.mjs`: 9 checks passed.
- Docker: unavailable; no real container test, live model inference, or physical iPhone/Safari test was performed.

## Residual risk / next work

1. Implement a separate, host-controlled test-evidence channel before enabling unattended apply. Project test stdout must never itself authorize writes.
2. Run the Docker isolation suite in the user's actual Codespace with the intended images already present; then attempt filesystem, network, process, and resource-exhaustion attacks from inside the disposable container.
3. Perform live-model prompt-injection tests against uploaded files and retrieved research, keeping those results distinct from deterministic mock tests.
4. Exercise mobile mode on an actual iPhone/Safari session and, if LAN access is needed, add TLS or a secure tunnel rather than relying on plaintext HTTP.
5. Treat credential redaction as a useful guardrail, not a guarantee.

## Integrity note

This archive is based on the v6 source archive available in the conversation, not a fresh checkout from GitHub. Compare with the current repository before replacing any existing Codespace files.
