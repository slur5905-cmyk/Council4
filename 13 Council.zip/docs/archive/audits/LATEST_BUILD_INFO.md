# Latest Coding Council Source Bundle — v7 hostile audit

Date: 2026-10-26. Based on the `CodingCouncil_Deep_Audit_2026-10-24_v6.zip` archive supplied in this conversation. This is not a live pull from GitHub; compare against current repository commits before replacing an existing Codespace.

## Additional fixes in v7

- Fixed settings persistence's predictable temporary-file symlink vulnerability by using randomized atomic writes and rejecting a symlink settings target.
- Sanitized settings types/ranges and rejected oversized, malformed, symlinked, or invalid settings data so corrupted settings cannot feed arbitrary types into startup/model constructors.
- Added heuristic credential redaction for common secret assignments, token formats, private-key blocks, workspace context, imported/retrieved knowledge, and TODO excerpts.
- Expanded proposed-code secret checks to block common `sk-...` and Google-style API token formats and hard-coded credential assignments while allowing explicit placeholders.
- Mobile API request bodies must be JSON objects; malformed JSON arrays/scalars now return HTTP 400 rather than causing uncaught `.get` errors.
- Mobile request sockets now have a 15-second timeout to reduce idle/slow-client resource retention in explicitly enabled LAN mode.
- Unattended apply now fails closed unless an explicit host-controlled test-evidence attestation exists. The current project-controlled test runners do not issue one, so automatic apply is blocked; manual apply remains available after user confirmation.
- Added regression tests for settings symlink attacks, settings corruption, secret redaction, mobile request body validation, and forged test-summary output not authorizing unattended apply.

## Verification performed on the modified source tree

- `pytest -q`: **127 passed, 24 subtests passed**.
- `python -m unittest discover -s tests -q`: **127 tests passed**.
- `python -m compileall -q main.py offline_coder tests tools`: passed.
- `python tools/check_iphone_js.py`: passed.
- `python tools/check_mobile_app.py`: passed (12 unique IDs, labels resolve, auth and localhost-default guards).
- `python tools/check_browser_app.py`: passed (66 unique IDs, labels resolve, preview sandbox and URL-import/runtime-reference guards).
- `node tools/check_browser_logic.mjs`: 9 checks passed.
- ZIP integrity and extraction are checked after packaging.

## Not verified

Docker was unavailable in this environment, so no real container execution or isolation escape attempt was performed. No live local-model inference, production deployment, physical iPhone/Safari test, or independent penetration test was performed. Credential redaction is heuristic and can miss secrets. The project-controlled test output is not a trustworthy basis for unattended writes, which is why automatic apply remains blocked until a host-controlled evidence mechanism is implemented. Four peer roles share the configured underlying model; consensus is not independent verification. Filesystem TOCTOU races and best-effort multi-file rollback remain residual risks.

## Latest follow-on hardening — 2026-11-03

The current source tree includes the phone/backend parity, duplicate model-instance reuse, stricter structured review requirements, explicit untrusted-learning-context handling, credential redaction for task history/training examples, and a visibly locked unattended-Apply control described in `IMPLEMENTATION_UPDATE_2026-11-02.md` and `IMPROVEMENT_REPORT_2026-11-03.md`.

Latest local verification: 141 pytest tests passed with 27 subtests; 140 unittest-discovery tests passed; compileall, iPhone JavaScript syntax, mobile companion static/syntax/security checks, universal browser checks, 9 browser-logic checks, wheel build, and clean wheel import passed. No live model inference, live local-server, Docker runtime, physical device, desktop GUI, or independent security test was performed.

## Bounded specialist parallelism — 2026-11-05

- Independent peer analysis, cross-examination, candidate review, and final voting now use a bounded worker pool when peer roles are assigned to more than one model instance.
- The default concurrency ceiling is two workers and is configurable from 1–4 in desktop settings, local settings JSON, and the CLI (`--peer-workers`). Mobile-host mode uses the same saved setting.
- `RoleModelRouter` adds a per-model-instance reentrant lock. Multiple peer roles sharing the same in-process model are serialized; genuinely distinct model instances can run concurrently. Single-model configurations remain sequential.
- Every run report records a sanitized peer-to-model assignment, number of distinct model instances, worker limit, and the execution mode. Full local GGUF paths are not copied into the model profile.
- Added regression tests for shared-instance serialization, distinct-instance concurrency, stable peer ordering, model-profile reporting, and bounded settings validation.

Verification performed on this update: `python -m pytest -q` — **148 passed, 27 subtests passed**; `python -m unittest discover -s tests -q` — **147 tests passed**; bytecode compilation, iPhone JavaScript syntax, phone companion checks, universal browser checks, 9 browser-logic assertions, wheel build, clean wheel installation, and import smoke checks passed. Live inference with multiple actual GGUFs or a multi-model local server was not possible in this environment, so speedups, memory behavior, and backend-specific concurrent serving remain unverified. Start at one worker on memory-constrained hardware and increase only after live validation.


## Council intelligence / review-quality update — 2026-11-05

- Refined the four permanent reviewer lenses and strengthened the system protocol with requirements-to-evidence mapping, complete execution-path tracing, explicit fact/assumption/unknown separation, concrete test design, and context-limit uncertainty handling.
- Strengthened peer cross-examination to challenge unsupported claims and test adequacy.
- Increased output budgets for independent analysis, cross-examination, exact-candidate review, and final votes. This may increase run time and local resource use.
- Four permanent desktop/Python peers remain unchanged. The iPhone/browser app supports up to three additional user-defined specialist roles (up to seven total role-based reviewers in that edition).
- No paid API, remote inference provider, or API key was added. Local model quality remains dependent on the chosen GGUF/local-server model and available hardware.

Verification: `python -m pytest -q` — 148 passed, 27 subtests passed. No live model inference or benchmark was performed; no measured quality improvement is claimed.
