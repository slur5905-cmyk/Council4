# Council maximum-capability upgrade report

Date: 2026-11-05  
Source: `6 Council(1).zip` supplied in this conversation

## Executive summary

The supplied source already had a substantial local-first architecture and passed its existing regression suite before changes: **141 pytest tests passed, with 27 subtests**. The most actionable performance gap was that peer-specific models were configurable, but the Council still called every peer serially. This update activates bounded multi-model execution while retaining safe behavior for single-model configurations.

## Changes implemented

### 1. Bounded parallel peer execution

The Council can run independent peer calls concurrently during:

- Initial task analysis
- Peer-to-peer cross-examination
- Candidate code review
- Final peer voting

The default maximum is two parallel workers. The setting can be configured from 1 to 4 in the desktop settings UI, saved settings, or CLI `--peer-workers`. The phone-host companion reads the same setting.

Agents are grouped by their assigned model instance before dispatch. This prevents two peers using the same in-process model from occupying separate worker slots while one waits on the other. Results are reassembled in the original peer order, preserving stable report ordering and vote identity.

### 2. Per-model concurrency protection

`RoleModelRouter` now creates one reentrant lock per distinct model instance. Calls assigned to the same model instance are serialized. Distinct instances can run concurrently. This is important for in-process inference backends that should not receive simultaneous calls through one model object.

### 3. Model topology transparency

Each run report now records:

- The model label assigned to each of the four peers
- The count of distinct peer model instances
- The configured maximum peer-worker count
- Whether that run used sequential or bounded-parallel peer execution

GGUF model labels use the file basename rather than copying the full local model path into the run's model profile. The desktop audit view and phone audit view expose this profile.

### 4. Configuration and documentation

- Added bounded `max_peer_workers` settings validation (1–4).
- Added a desktop setting and CLI option.
- Passed the setting through phone-host execution.
- Updated the multi-model guide, feature status, README, and build notes.
- Added tests for shared-instance serialization, distinct-instance concurrency, peer-order stability, model profile reporting, and settings validation.

## Verification results

| Check | Result |
|---|---:|
| `python -m pytest -q` | **148 passed, 27 subtests passed** |
| `python -m unittest discover -s tests -q` | **147 passed** |
| `python -m compileall -q main.py offline_coder tests tools` | Passed |
| `python tools/check_iphone_js.py` | Passed |
| `python tools/check_mobile_app.py` | Passed; 12 unique IDs, labels, auth and localhost-default guards |
| `python tools/check_browser_app.py` | Passed; 66 unique IDs, labels, preview sandbox and import/runtime guards |
| `node tools/check_browser_logic.mjs` | 9 assertions passed |
| Python wheel build | Passed |
| Clean wheel installation/import smoke test | Passed |

## How to use the new capability

1. Assign different local model files or different model IDs to the peer roles in desktop settings. Blank role assignments still use the primary model.
2. Keep **Parallel peer workers** at `2` initially. This is the default.
3. Start with `1` if RAM/VRAM is tight or the local inference server is unstable. Increase to `3` or `4` only after observing memory use and stability with the actual models on the target computer.
4. Run a representative coding task, then open the **Safety & audit** view (desktop or phone). Check `model_profile` to confirm the peers really used different models and whether the run was parallel.

CLI equivalent: `python -m offline_coder.cli --help` shows the `--peer-workers` option; the value must be from 1 through 4.

## What this does not magically solve

- This does not increase the intelligence or training quality of any model. Better models and well-matched role assignments still matter.
- Four roles using one underlying model are still four prompted perspectives, not four independent foundation models.
- Different models can share training data, blind spots, or incorrect assumptions. Model diversity is not proof of truth.
- Parallelism can increase peak inference/KV-cache memory. The default is deliberately capped at two, and the best value depends on hardware and the local inference server.
- This update parallelizes peer analysis and review work, not simultaneous code-writing agents in separate worktrees. Conflict-aware multi-branch implementation remains unimplemented.
- No live multi-GGUF or multi-model local-server inference was available in this environment. Therefore actual speedup, memory impact, and the target computer's concurrent inference behavior remain unverified.
- No Docker runtime isolation test, production deployment test, physical iPhone/Safari test, GUI interaction test, or independent penetration test was performed during this pass.

## Engineering recommendation

Use different models where their strengths genuinely differ, not simply four copies of the same model under different labels. A strong general coding model can draft; a separate code-reasoning model can audit correctness; and a security-focused model can challenge trust boundaries. Compare their real outputs on your own representative tasks before trusting a model assignment. Keep human review and manual Apply enabled.
