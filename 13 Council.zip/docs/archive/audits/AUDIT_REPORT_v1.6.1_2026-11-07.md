# Offline Coding Council 1.6.1 — Change & Verification Report

Date: 2026-11-07. This report describes the source snapshot packaged with v1.6.1.

## Main changes

- Peer messaging, investigations, code-specific challenges, component contributions, continuing discussion threads, and provisional peer lessons are integrated into the Council workflow.
- Local role model routing is retained; GGUF loading is demand-based with a configurable resident-model limit. Same model instances are reused and serialized.
- The interface now discloses that four role prompts may share one underlying model.
- Self-edit protection is default-deny and allowlist-based for documentation and curated knowledge only.
- Python/Node project-controlled test output is not trusted host attestation. Node discovered file paths are passed after `--`; flag-like paths are rejected.
- Automatic public web research is forced off. Manual search displays the exact query and requires confirmation.
- Host policy is separated into `host_policy.py`; model votes and objections are advisory, not file-write authorization. Manual Apply remains required.
- Mobile Apply requires typing `APPLY` and a single-use code displayed in the computer terminal.
- Browser companion no longer embeds the desktop's 104-module knowledge pack. The browser model requires initial runtime/weight downloads.
- Advanced telemetry, SQLite memory, and resumable checkpoints are opt-in; the default DB budget when enabled is 128 MiB.
- GitHub Pages deployment is gated on unit tests, model-runtime import, Docker fixture execution, and a static publish scan. Workflow actions are pinned to commit SHAs.
- Historical audit files are moved to `docs/archive/audits/`; root status is consolidated into `STATUS.md`.

## Local verification

- `python -m pytest -q`: 247 passed, 65 subtests passed.
- `python -m compileall -q main.py offline_coder tests tools`: passed.
- `python tools/check_browser_app.py`: passed.
- `node tools/check_browser_logic.mjs`: 8 checks passed.
- `python tools/check_iphone_js.py`: passed.
- `python tools/check_mobile_app.py`: passed.

## Not verified locally

- No real model weights, model-quality benchmark, or complete inference request was run.
- Docker daemon is not available in this container. The CI Docker fixture deliberately fails closed if Docker is unavailable; actual Docker execution must be confirmed by the remote CI job.
- Python versions 3.10–3.12 were not locally tested; CI matrix now includes 3.10–3.13.
- GitHub Actions and Pages have not yet executed against the repository.
- Not verified for Windows/macOS or shared-LAN exposure.

## Release posture

Private experimental use only, manual Apply only. Not security-certified, not ready for shared LAN, and not suitable for unattended use. A public release still needs an owner-selected LICENSE and a monitored private vulnerability-reporting contact.
