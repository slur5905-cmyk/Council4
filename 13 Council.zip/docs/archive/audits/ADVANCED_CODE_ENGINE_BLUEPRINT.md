# 4Council — Advanced Autonomous Software Engineering Blueprint

**Status:** Design specification only. This document does not claim that the proposed modules have been implemented.

## 1. Mission

Turn 4Council from a task-to-patch coding assistant into a disciplined software engineering system that can understand unfamiliar repositories, plan multi-stage changes, generate coherent multi-file implementations, test them in appropriate environments, repair failures, and produce an auditable release candidate.

The Council must optimize for correctness, traceability, reversibility, and user control—not maximum autonomy. Model agreement is never treated as proof.

## 2. Target architecture

```text
User / iOS dashboard / CLI
          |
          v
  API + Session Gateway ---- Authentication / quotas / audit log
          |
          v
     Task Orchestrator
          |
   +------+-------+----------------+
   |              |                |
   v              v                v
Repository     Research         Memory &
Intelligence   Coordinator      Provenance Store
   |              |                |
   +--------------+----------------+
                  |
                  v
            Planning Engine
                  |
       Dependency & Change Graph
                  |
                  v
       Candidate Generation Engine
                  |
       +----------+-----------+
       |          |           |
    Architect  Implementer  Test Designer
       |          |           |
       +----------+-----------+
                  |
                  v
       Patch / File Manifest Builder
                  |
                  v
      Static + Policy + Secret Checks
                  |
                  v
       Isolated Test Environment
                  |
                  v
       Four-Peer Adversarial Review
                  |
                  v
        Bounded Repair Controller
                  |
                  v
       Human Approval / Release Gate
                  |
                  v
       Atomic Apply + Backup + Audit
```

## 3. Core subsystems

### 3.1 Repository intelligence

Build a bounded repository index containing:
- File inventory, language, size, hash, and ownership hints.
- Entry points, package manifests, build scripts, configuration, routes, schemas, and test locations.
- Import/reference relationships and likely module boundaries.
- Public interfaces: exported functions/classes, HTTP routes, CLI commands, database schemas, event names, and serialized formats.
- Existing conventions: naming, formatting, error handling, logging, and test patterns.
- Explicit uncertainty markers for binary files, generated code, ignored directories, oversized files, and unparsed languages.

Use language-aware parsers where available. Heuristic scans must be labelled as heuristic and must never silently become authoritative.

### 3.2 Task compiler

Convert the user's request into a versioned `TaskSpec`:

```json
{
  "goal": "string",
  "non_goals": [],
  "acceptance_criteria": [],
  "constraints": [],
  "target_files": [],
  "risk_level": "low|medium|high|critical",
  "required_test_profiles": [],
  "open_questions": [],
  "assumptions": []
}
```

The compiler must distinguish explicit requirements from inferred assumptions. Missing critical requirements pause for clarification; noncritical uncertainty is recorded.

### 3.3 Change-graph planner

Represent the planned change as a directed graph. Nodes include files, interfaces, dependencies, tests, migrations, and deployment artifacts. Edges represent imports, calls, schema dependencies, route-to-client links, and build/test dependencies.

Each proposed change must declare:
- Why the file changes.
- Which acceptance criteria it satisfies.
- Which interfaces it affects.
- Which dependent files may need coordinated updates.
- Which tests prove the intended behavior.
- Rollback implications.

Reject orphaned changes and flag interface changes without corresponding caller/test analysis.

### 3.4 Candidate generation

Generate a complete patch set, not disconnected snippets. Every candidate has an immutable ID and manifest with path, operation, before-hash, after-hash, byte count, language, and rationale.

Generation rules:
- Preserve unrelated behavior and minimize patch surface.
- Never invent dependency versions or APIs; consult pinned manifests and official documentation when research is enabled.
- Add or update tests alongside behavior changes.
- Keep secrets, credentials, environment files, and protected policy files out of candidate output.
- Produce explicit migration and compatibility notes for persisted formats and public APIs.
- Split oversized tasks into independently reviewable milestones.

### 3.5 Four-peer review protocol

Keep the existing four equal roles, but make review evidence structured and file-specific:
1. Architect / integration breaker — architecture, boundaries, backward compatibility.
2. Correctness auditor — invariants, types, edge cases, concurrency, failure paths.
3. Security and reliability auditor — trust boundaries, injection, secrets, permissions, resource exhaustion.
4. Red-team verifier — adversarial inputs, regression scenarios, hidden assumptions, test gaps.

Each reviewer receives the exact same immutable candidate hash. Reviews must reference file paths, line ranges or symbols, severity, reproduction steps, and a proposed regression test. A reviewer may abstain when context is insufficient. Abstentions and unresolved high-severity findings block approval.

Future multi-model routing may add genuinely different model providers, but provider identity, model ID, and failures must be visible. Four prompts to one model must never be described as independent model consensus.

### 3.6 Test orchestration matrix

Select checks based on changed files and detected project stack:
- Syntax / parse checks.
- Type checking and linting.
- Unit tests and regression tests.
- Integration tests with disposable services or fixtures.
- API contract and schema compatibility tests.
- Browser end-to-end tests for web interfaces.
- Accessibility checks for user-facing UI.
- Dependency and license policy checks.
- Performance smoke tests for explicitly defined budgets.
- Migration dry-runs and rollback tests.

Every check result has one of: `PASSED`, `FAILED`, `SKIPPED`, `UNAVAILABLE`, or `NOT_APPLICABLE`, plus command identity, environment fingerprint, duration, exit code, bounded logs, and evidence provenance. Missing tests are never reported as passing. Test output produced by project code is untrusted and cannot alone authorize unattended writes.

### 3.7 Bounded repair controller

On a failed check or blocking review:
1. Normalize the failure into a typed issue.
2. Map the issue to affected graph nodes.
3. Ask the generator for a minimal repair to the current candidate.
4. Create a new candidate ID and hashes.
5. Re-run all checks affected by the patch plus mandatory regression checks.
6. Re-run all four reviews against the new exact candidate.
7. Stop after a configurable maximum number of rounds or when progress stalls.

Never carry approvals from an older candidate to a revised candidate.

### 3.8 Apply and rollback transaction

Apply is a separate host-controlled transaction:
- Verify workspace root and path containment.
- Recheck before-hashes to detect concurrent edits.
- Reject symlinks, traversal, secret paths, protected controller files, and unexpected binary writes.
- Create a manifest-backed backup before mutation.
- Stage writes to temporary files and atomically replace targets where supported.
- Verify after-hashes and write an append-only audit record.
- On partial failure, restore from the exact backup manifest.
- Require explicit human confirmation by default. Unattended mode remains disabled unless a future host-controlled test attestation and policy gate are independently validated.

## 4. Data contracts

### Candidate manifest

```json
{
  "candidate_id": "uuid",
  "task_id": "uuid",
  "base_revision": "git-commit-or-workspace-hash",
  "files": [
    {
      "path": "src/example.py",
      "operation": "create|modify|delete",
      "before_sha256": null,
      "after_sha256": "sha256",
      "acceptance_criteria": ["AC-1"],
      "tests": ["tests/test_example.py::test_behavior"]
    }
  ],
  "review_state": "pending",
  "test_state": "pending"
}
```

Deletion should remain disabled in the first implementation milestone. The schema includes it only for future explicit, separately gated support.

### Evidence record

Every factual claim used to justify a change should point to one or more evidence records: repository file/hash, test result, official documentation URL and retrieval time, or user-provided requirement. Search snippets are leads, not proof of API behavior.

### Learning record

Store lessons as candidate knowledge with provenance, confidence, affected stack/version, and expiry/revalidation policy. Promote a lesson to verified only after independent evidence or explicit user confirmation. Learning must never rewrite system policy or grant new permissions.

## 5. Security model

Assume model output, repository content, dependency metadata, test fixtures, web pages, and test logs can be malicious. Enforce permissions in host code, not prompts. Keep network access disabled during test execution by default. Use pinned dependencies and preinstalled images; do not let generated code install packages or execute arbitrary shell commands. Separate research credentials from build/test workers. Redact secrets before logs and memory storage.

## 6. iOS and cloud deployment boundary

The iOS PWA is a control plane: task submission, status, review display, approvals, and backup export. It is not a persistent compute host. A scheduled free worker may collect and queue bounded research, but it cannot run a full Python Council or local LLM within tiny serverless CPU quotas. The local model remains on a user-controlled capable device, or a separately hosted inference service is required. No architecture should claim continuous reasoning while the PWA is suspended.

## 7. Implementation milestones

**M0 — Verify current coding path:** run a live model on a disposable project; create a multi-file feature plus tests; inspect candidate, reviews, and report; manually apply only after inspection.

**M1 — Typed task and candidate contracts:** formalize TaskSpec, candidate manifest, immutable candidate IDs, and per-file rationale.

**M2 — Repository graph:** add language-aware indexing and dependency/interface edges with confidence labels.

**M3 — Test profiles:** add adapters selected by project manifests; distinguish skipped/unavailable from pass; preserve bounded logs.

**M4 — Repair loop:** map test/review findings to graph nodes; bounded patch-retest-rereview cycle; never reuse prior approvals.

**M5 — Multi-model reviewer routing:** optional provider adapters, independent model identity, timeout/fallback policy, per-peer evidence.

**M6 — Transactional apply:** exact-hash checks, manifest backups, atomic writes, rollback verification, append-only audit trail.

**M7 — Dashboard observability:** live task graph, file diffs, peer findings, test matrix, provenance links, queue, memory versions, backup status, and approval controls.

**M8 — Deployment hardening:** authentication, rate limits, quotas, secret isolation, backup restore drills, monitoring, and disaster recovery.

## 8. Acceptance benchmark

Before calling the system a reliable software engineer, run live-model tasks in disposable repositories:
- Build a small full-stack app from a written spec.
- Add a database migration and backward-compatible API endpoint.
- Fix a race condition with a deterministic regression test.
- Refactor a multi-module project without changing public behavior.
- Identify and repair a security flaw with an exploit regression test.
- Build an accessible responsive interface and verify it in a real browser.
- Recover from a deliberately failing test and show a bounded repair cycle.
- Detect prompt injection hidden in README, source comments, test output, and web content.

Score each task on acceptance criteria, test evidence, regression count, security findings, patch size, and human review. Deterministic orchestration tests are not model-quality scores. Publish failures and skipped checks alongside successes.

## 9. Definition of done

A release is ready only when the exact candidate has complete provenance, required tests have actually run in a suitable environment, all mandatory reviews have examined the exact same hash, no blocking findings remain, backup restoration has been tested, and the user has approved the change. The Council must say what it could not verify.
