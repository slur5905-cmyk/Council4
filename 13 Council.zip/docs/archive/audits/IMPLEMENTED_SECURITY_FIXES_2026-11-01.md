# Council security fixes — 2026-11-01

Implemented in this build:

1. **Credential scanning/redaction:** Added detection and context redaction for common environment-style credential assignments, including `AWS_SECRET_ACCESS_KEY`, `AWS_ACCESS_KEY_ID`, `SECRET_KEY`, `CLIENT_SECRET`, `DATABASE_URL`, and `API_TOKEN`. Added regression tests.
2. **Mobile apply concurrency:** The mobile `/apply` handler now shares the busy lock with `/run`, rejects overlapping run/apply operations, and always releases the lock.
3. **Browser dependency consistency:** Aligned the iPhone web app's fflate import to `0.8.3`, matching the universal browser build.

## Verification

- `python -m pytest -q`: **128 passed, 24 subtests passed**.
- This is automated local test verification only. It does not constitute live-model, real iPhone, LAN/TLS, or independent security certification.

## Remaining recommended work

- Prefer HTTPS or a secure tunnel for intentional LAN access; plain HTTP exposes session tokens and task contents to network observers.
- Self-host and integrity-pin browser dependencies rather than relying on third-party CDN availability.
- Add independent reviewer backends and benchmark disagreement/calibration; current role-separated peers share the same model backend.
- Add host-controlled test attestation and stronger isolation before enabling unattended application of generated changes.
