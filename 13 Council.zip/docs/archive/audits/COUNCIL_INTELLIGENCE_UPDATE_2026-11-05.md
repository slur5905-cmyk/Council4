# Council intelligence and review-quality update

Date: 2026-11-05

## Changes in this build
- Sharpened the four permanent reviewer lenses so architecture, correctness/testing, security/reliability, and independent red-team review have clearer responsibilities.
- Added an engineering-quality protocol requiring requirement-to-evidence mapping, end-to-end execution-path tracing, separation of observed facts from assumptions, concrete test setup/action/expected results, and explicit uncertainty when context is incomplete.
- Strengthened independent analysis and cross-examination prompts so reviewers challenge unsupported claims and check whether proposed tests actually establish acceptance criteria.
- Increased local inference output budgets for independent analysis, cross-examination, candidate review, and final voting. This can make runs slower and use more local resources.
- Kept the four-peer approval gate, exact-candidate review, manual user approval, and host safety checks unchanged.
- Synchronized the packaged build/lib copy with the canonical Council source.

## Member count
- Four permanent Python/desktop peers.
- The browser/iPhone edition supports up to three additional user-defined specialist auditors, for up to seven role-based reviewers in that edition.
- These are roles, not necessarily independent models. Unless separately configured with different local model files/model IDs, they share the same underlying model and its blind spots.

## Model and cost policy
- No paid API, cloud inference account, or API key was added.
- The application remains local-first: GGUF model files run locally, or a compatible server may run on the same computer's loopback interface.
- A stronger model can improve results, but it must be downloaded and run on hardware with enough memory. The app does not silently download models or use paid services.
- More reviewers do not automatically mean more intelligence; distinct model families, good evidence, real tests, and hardware capacity matter more than adding duplicate roles.

## Verification
- `python -m pytest -q`: 148 passed, 27 subtests passed.
- No live model inference or benchmark was run here, so the prompt changes are verified structurally and by the test suite, not by a measured coding-quality score.
