# Council v9 Repair and Verification Report

**Source:** uploaded `9? Council.zip`  
**Repair date:** 2026-11-06  
**Cost policy:** no paid services, hosted inference APIs, or model downloads were used.

## Repairs applied

### Model selection
- Replaced ranking based only on the normalized measured dimensions with an evidence-adjusted score.
- Missing benchmark dimensions receive a neutral prior and reduce evidence coverage rather than silently disappearing from the ranking denominator.
- A candidate cannot be selected for a coding task without a measured coding score, or for a reasoning task without a measured reasoning score.
- The result reports measurement coverage and labels a narrow-coverage recommendation as provisional.

### Memory quality
- Memory search now omits entries superseded by a newer version; older records remain available in append-only history.
- Search results include age, a kind-specific staleness flag, and exact-summary conflict flags for competing active entries in the same project namespace.
- The Council's retrieved-memory context warns the model to re-check stale information and resolve flagged conflicts instead of treating either as established fact.
- Existing database rows and integrity digests remain readable; no user memory was deleted or rewritten.

### Council model transparency
- Each run's profile now states whether peer roles share one model instance or route to multiple instances.
- The profile explicitly says that multiple instances do not prove different training families or independent correctness. Four role prompts over one model are not represented as four separate foundation models.

### Mobile security and reliability
- Added a bounded HTTP server with at most eight concurrent handler threads and a bounded request queue.
- Added per-client request limits, failed-authentication limits, and separate action limits for search, run, and apply. Action limits are only charged after bearer authentication succeeds.
- POST endpoints now require a valid `Content-Length`, a body no larger than 1 MB, an exact `application/json` media type, and a complete body matching the declared length.
- Added optional TLS 1.2+ certificate/key support.
- Non-loopback plaintext binding is refused by default. The explicit `--allow-insecure-lan` option remains available only as a conscious opt-in for trusted private networks; it is not safe for public Wi-Fi or internet exposure.

### Regression protection and documentation
- Added regressions for narrow-vs-broad model benchmark coverage, task-specific measurement, stale/conflicting memory, bounded mobile requests, and plaintext LAN opt-in.
- Updated the mobile safety checker, benchmark v1.3, README, start guide, and audit addendum.

## Verification performed

| Check | Result |
|---|---:|
| Python unit tests | **188 passed** |
| Additional Python subtests | **27 passed** |
| Python bytecode compilation | Passed |
| Universal browser app checks | Passed; 66 unique IDs |
| Universal browser logic checks | **9 passed** |
| iPhone JavaScript syntax/export checks | Passed |
| Mobile companion checks | Passed; 12 unique IDs |
| Wheel build | Passed |
| Deterministic host benchmark v1.3 | **10/10 passed** |
| Model reasoning benchmark | **6/6 NOT_RUN** |

The current benchmark result is `benchmarks/results/council9-repaired-v1.3.json`. The model cases remain `NOT_RUN` because no local inference model was supplied/configured in this environment. This is not a model intelligence score.

## Remaining limits

- A real local-model run and independent human or executable-oracle scoring are still required to measure reasoning quality, coding ability, tool use, speed, and model-specific memory use.
- The phone UI was statically validated but not exercised on a physical iPhone in this environment.
- TLS support was implemented, but no user certificate was available for a live HTTPS handshake test. Use a trusted certificate and verify the connection on the actual devices.
- Explicit `--allow-insecure-lan` mode still uses plaintext HTTP and exposes bearer credentials to anyone able to observe that network traffic.
- Multiple configured model instances are not evidence of independent model families. The Council still cannot create physical RAM, CPU, GPU, or storage; it can only measure and allocate resources the host already provides.
- The memory conflict detector covers competing active entries with the same project, kind, and exact summary. It cannot discover every semantic contradiction between differently worded memories; source-aware semantic fact checking remains future work.
- No independent penetration test, public-internet exposure test, real Docker workload, or native game-engine test is claimed.
