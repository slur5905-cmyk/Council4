# Offline Coding Council v1.6.0 — Peer Collaboration and Model Management

**Build date:** 2026-11-07  
**Source:** `10 Council.zip` uploaded for the v1.6.0 update.

## Implemented

1. **Persistent peer communication** — bounded direct questions, investigation requests, code challenges, component-collaboration requests, recipient responses, initiator follow-ups, and discussion status. Messages are stored in a dedicated SQLite database, with peer validation, size limits, credential redaction, code-reference traversal checks, and content hashes.
2. **Continuing discussions** — open discussions are retrieved for related future tasks. One relevant open discussion may be continued per run, and it remains open until the exchange records a resolution.
3. **Component-level collaboration** — for code-change, project-build, and debugging task plans, up to four subtasks are assigned to individual peers. Peers return bounded component designs, interfaces, tests, and optional file contributions. Contributions are not applied independently; the rotating proposer integrates them into the single reviewed candidate. Every candidate reviewer and final voter also receives the exchange history and component handoffs so they can check whether challenges were actually addressed.
4. **Collective lessons** — disagreement-derived lessons are stored as provisional. They can be retrieved as hypotheses and explicitly reviewed by the user. Only user-confirmed verified lessons receive the `verified` status. The system does not silently fine-tune model weights.
5. **Lazy GGUF model manager** — separate role models are loaded only when used, with a bounded LRU resident-model limit (`max_loaded_peer_models`, default 1, range 1–4). Active models are not evicted. Model usage, loads, and evictions are reported.
6. **Desktop controls and visibility** — settings for resident GGUF models, peer dialogue, and component collaboration; new Peer communication tab; manual Review peer lessons control.

## Model assignment

The four existing role override fields remain supported. GGUF mode accepts local file paths; local-server mode accepts model IDs advertised by the loopback server. Empty overrides use the primary model. The planner and final synthesis continue using the primary model. A failed specialist may fall back to the primary, and the fallback is recorded. Distinct model assignments do not prove distinct training families.

## Verification

- Python syntax compilation: passed.
- Python wheel: built and installed into an isolated target directory; import checks for the package, peer store, and model manager passed.
- Full automated suite: **238 passed, 44 subtests passed**.
- Model behavior / model-quality benchmarks with actual GGUF weights: not run in this environment.
- Real RAM/VRAM measurements, llama.cpp unload behavior under the user's GPU drivers, and multi-model performance: require testing on the target computer.
- Component contributions remain proposals until integrated, path-validated, tested, reviewed by all four peers, and manually applied by the user.
- This v1.6.0 upgrade applies to the Python desktop edition. The separate static iPhone/browser edition has not yet gained the persisted peer discussion store, component collaboration, user-reviewed peer lessons, or separate per-role model configuration; it still uses one local in-browser model and browser-local learning storage.

## Important limitations

- Peer messages are one bounded request/response/follow-up exchange per participating member per run; at most one prior open thread is continued per new run. This prevents unbounded debate loops.
- Component contributions are handed to the proposer as work products; the current application is not a simultaneous shared editor and does not perform automatic branch merging.
- Provisional lessons may be wrong. They remain visibly unverified until the user reviews them.
- The model manager is an LRU memory bound, not a hardware memory predictor. A single GGUF model may still exceed available memory; increasing the resident limit can increase RAM/VRAM pressure.
