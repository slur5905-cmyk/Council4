# Coding Council v7 re-audit and packaging repair — 2026-11-01

## Scope

Source supplied by the user as `Useless.zip` (258,392 bytes). The archive is a valid ZIP and its `LATEST_BUILD_INFO.md` identifies it as the 2026-10-26 v7 hostile-audit source bundle based on v6. The archive contains the source tree, tests, mobile/browser apps, build metadata, and the October 26 hostile-audit report.

This was a local re-audit of the supplied archive, not a live GitHub checkout, live-model evaluation, professional penetration test, or physical-device test.

## Newly reproduced finding

### Medium — Python wheel build fails due to ambiguous setuptools package discovery (fixed)

**Affected file:** `pyproject.toml`

**Reproducer:** `python -m pip wheel . --no-deps --no-build-isolation`

**Observed failure:** setuptools refused to build metadata because it discovered multiple top-level directories in the flat layout (`models` and `offline_coder`) and had no explicit package discovery configuration.

**Fix:** added explicit setuptools discovery to include `offline_coder*` and exclude `models*`, `tests*`, and `tools*`. Added `tests/test_packaging_config.py` to guard this configuration.

**Verification:** wheel build succeeded. The resulting wheel installed into a clean target directory and `import offline_coder` succeeded.

## Verification on supplied v7 source, before packaging repair

- `python -m pytest -q`: **127 passed, 24 subtests passed**.
- `python -m unittest discover -s tests -q`: **127 tests passed**.
- `python -m compileall -q main.py offline_coder tests tools`: passed.
- `python tools/check_iphone_js.py`: passed.
- `python tools/check_mobile_app.py`: passed (12 unique IDs; labels and guards checked).
- `python tools/check_browser_app.py`: passed (66 unique IDs; labels and sandbox/import/runtime guards checked; includes 9 browser logic checks).
- `node tools/check_browser_logic.mjs`: 9 checks passed.
- ZIP integrity check: passed.

## Verification after repair

- `python -m pytest -q`: **128 passed, 24 subtests passed**.
- `pip wheel`: succeeded; produced `offline_coding_council-0.1.0-py3-none-any.whl`.
- Clean target install of wheel: succeeded.
- Import from installed wheel: succeeded (`offline_coder` imported from the install target).

## Previously reported v7 security changes inspected

The supplied v7 build notes and source include the October 26 fixes for atomic settings persistence and settings validation, heuristic secret detection/redaction, mobile JSON-object validation and socket timeout, and fail-closed unattended apply requiring host-controlled evidence. These were not represented as newly discovered by this re-audit. The earlier October 26 report's limitations remain applicable: heuristic secret scanning is incomplete; test output itself is not trusted evidence; automatic apply remains blocked without host attestation.

## Remaining limitations / not tested

- Docker is unavailable in this execution environment; no real container isolation or escape testing was performed.
- No live model inference or adversarial prompt-injection session against a running model was performed.
- No physical iPhone/Safari or desktop end-to-end session was performed.
- No current GitHub repository checkout or comparison was performed. Compare this bundle with the live Codespace before replacing repository files.
- Four peer roles sharing one configured model are role-diverse prompts, not independent foundation models.
- Passing tests and static checks do not prove security or correctness.
- The Python environment emitted an unrelated spreadsheet-runtime warmup traceback during startup; the commands listed above still returned success and their project checks passed.

## Deliverables

- `Councilv1-v7-Reaudited-Fixed-2026-11-01.zip`: supplied v7 source with the packaging fix and regression test, plus this report.
- `offline_coding_council-0.1.0-py3-none-any.whl`: successfully built installable wheel.
