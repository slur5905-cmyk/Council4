# Start Here

## What this is

Offline Coding Council is a local-first coding assistant with four role prompts. By default it is **one underlying model used in four roles**. You can assign separate local GGUF files or separate model IDs from a loopback-only model server, but you must configure and verify those models yourself.

## Desktop setup

1. Use Python 3.10–3.13 and install this project with its test/runtime dependencies as needed.
2. Choose a local `.gguf` model in the desktop app, or configure a model server bound to `127.0.0.1` / `localhost`.
3. Choose a dedicated project workspace. Do not point the Council at your home directory or a folder containing unrelated/private files.
4. Run a task. Review each analysis, peer discussion, candidate file, warning, and test report.
5. Apply only after you have inspected the exact proposal and the host UI enables the manual Apply control.

The base runtime does not require a paid AI API or cloud model. Model files and Python dependencies must already be present locally.

## Peer communication

Members first analyze independently. They then see peer analyses, ask direct questions, request investigations, challenge specific code, collaborate on components, continue unresolved discussions in later related tasks, and record lesson candidates. Lesson candidates remain provisional until you review them.

## Distinct local models

Set per-role model paths/IDs in **Local setup**. The default maximum resident GGUF count is one; increase it only when your computer has enough memory. The model manager loads local models on demand and evicts idle ones under its configured resident-model limit. Different model instances do not prove different model families or independent correctness.

## Optional advanced features

The checkbox in Local setup enables host resource telemetry, a local SQLite memory database, and resumable task checkpoints. It is off by default. Enabling it uses a 128 MiB database limit by default. These features improve observability and continuity; they do not make the model smarter.

## Web research

Automatic research is disabled. When you choose Search web, the full query is shown for confirmation before it is sent to an external public search provider. Do not include secrets or private project data in a query.

## Browser / phone companion

The browser companion is not the full desktop product. It uses a small local browser model and a much smaller context. The initial Transformers.js runtime and model weights are downloaded from configured hosting/CDN services, so first use requires internet access. Its Apply action is manual and requires typing `APPLY` plus a one-time code printed in the computer terminal. Keep the terminal private.

## Autonomous operation

The Council can carry a bounded coding task through planning, peer discussion, implementation, testing, and revisions inside its configured workspace without requiring you to approve every intermediate thought. It should not run endless self-directed changes or treat model agreement as proof that something is safe.

After this workflow is pushed to the repository default branch with GitHub Actions enabled, a weekly scheduled CI run performs deterministic tests, imports the optional local-model backend, and exercises Docker fixtures. This is automated verification, not an AI agent repairing the repository: GitHub-hosted CI does not have your private local model weights. Model-driven unattended maintenance would require an always-on trusted runner with a configured local model and a bounded task queue.

## Important safety boundary

Automatic Apply is disabled. AI votes are advisory. The host checks paths, candidate integrity, and other deterministic conditions; only then can you manually authorize a write. Project-controlled test output is not treated as trusted host attestation.

See [STATUS.md](STATUS.md) and [SECURITY.md](SECURITY.md) before use.
\n\n## Optional Council Browser\n\nSee [Council Browser guide](docs/guides/COUNCIL_BROWSER.md) for Playwright installation, usage, and security limits.\n