# Security Policy

Offline Coding Council is experimental software for private, local use. It has not been security-certified. Do not expose its desktop/mobile server to a shared or untrusted LAN, host it publicly, or use it for unattended operation.

## Current safeguards

- Workspace path validation, symlink refusal, candidate hash checks, and atomic writes.
- Self-editing is default-deny; only documentation and curated knowledge paths are eligible. Application code and authority-bearing modules are blocked.
- Project-controlled Python/Node test output is explicitly untrusted and cannot serve as host attestation for Apply.
- Automatic Apply is disabled. Model votes are advisory; deterministic host checks and a manual user action control file writes.
- Web research is disabled by default and requires explicit confirmation of each exact query.
- The phone companion uses a session token, typed `APPLY` phrase, and a single-use code printed in the computer terminal. This is defense in depth, not a guarantee against a compromised device, browser, or network.

## Reporting a vulnerability

This private experimental package does not yet publish a dedicated security contact. Until the repository owner adds a real private reporting channel, do not submit sensitive vulnerability details in a public issue. Before any public release, the owner must publish a monitored private reporting contact and an explicit support policy.

## License and release status

No LICENSE file is included because the owner has not selected a license. Treat this as private-use source; do not assume permission to redistribute it. A public release requires the owner to choose and add a license.
