Put a downloaded GGUF model file here, or select it anywhere on your computer in the app. Do not commit or share model weights unless their license permits it.

Recommended evaluation candidate: Qwen3-Coder-Next GGUF Q4_K_M. Official page: https://huggingface.co/Qwen/Qwen3-Coder-Next-GGUF. The Q4_K_M file is approximately 48.4 GB; runtime memory needs are higher. Compatibility with this project's current llama-cpp-python backend has not yet been verified, so test it before relying on it.

Smaller alternative: Qwen3-Coder-30B-A3B-Instruct GGUF or a 7B–14B coder model, depending on your computer's RAM/VRAM. Model quality and performance depend on quantization, hardware, prompt format, and task.

We recommend using an existing open-weight model now, improving the developer system around it, collecting verified examples, and considering fine-tuning later. Training a foundation model from scratch is not a practical starting point for this project. See RECOMMENDED_MODEL.md for the full rationale.


Local model server backend
--------------------------
The desktop app can also use an OpenAI-compatible server already running on this computer. Choose backend `local-server` and use a loopback URL such as http://127.0.0.1:8080/v1. The app verifies /v1/models and rejects non-loopback hosts. Start the server yourself and ensure the model and runtime are compatible; no server or model is downloaded or launched automatically.
