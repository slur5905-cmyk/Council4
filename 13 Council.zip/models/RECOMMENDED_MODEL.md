# Recommended coding model for Coding Council

## Recommendation: use an open-weight model first; do not train a foundation model from scratch

The best fit is an existing coding-specialized model paired with the Council's planning, review, retrieval, test, and rollback workflow. Training a foundation model from zero requires very large curated datasets, substantial accelerator compute, training infrastructure, and expensive evaluations. It is not a realistic first step for this project and would likely perform worse than established models for a long time.

### Main candidate: Qwen3-Coder-Next GGUF

- Official model: https://huggingface.co/Qwen/Qwen3-Coder-Next-GGUF
- License listed on the official model page: Apache-2.0 (check the current card and any applicable terms before redistribution).
- Model card describes an 80B-total-parameter mixture-of-experts model with about 3B parameters activated per token and 262,144-token native context.
- The Q4_K_M GGUF is listed at approximately 48.4 GB. That is just the model file, not the total runtime memory requirement. A machine with 64 GB RAM/unified memory may still be tight; more memory is safer. GPU/accelerator support and speed vary by machine.
- The official page documents llama.cpp support. Use a recent compatible llama.cpp build and verify the architecture before committing to it. This app currently loads GGUF through `llama-cpp-python`; direct compatibility of the current installed Python backend with this specific model has **not** been verified by this project. Do not assume every GGUF model works with every backend version.

### Smaller fallback

If your computer cannot handle the 48.4 GB model, evaluate a quantized Qwen3-Coder-30B-A3B-Instruct model or a smaller 7B–14B coder model. These are easier to run but can be less capable on long, complex, multi-file tasks. Choose a quantization that fits in memory with room left for context and the operating system. Official model card: https://huggingface.co/Qwen/Qwen3-Coder-30B-A3B-Instruct

### Why this beats training from scratch right now

1. You get a capable pretrained coding foundation immediately.
2. Engineering time goes into the differentiating part of this project: task planning, bounded tool use, adversarial reviews, source-backed research, actual tests, safe writes, backups, and rollback.
3. You can collect high-quality examples of tasks, fixes, failures, and verified outcomes before deciding whether fine-tuning is worthwhile.
4. Later, you can fine-tune an eligible open-weight base model on a curated dataset. That is a more realistic way to make a model specifically yours than training every weight from zero.

### Important reality check

There is no universally best free model for every computer and coding task. This is a candidate based on its coding-agent specialization and official published specifications, not a claim that it wins every benchmark. “Open-weight” does not mean small, easy to run, or automatically compatible with this app. Model inference quality, tool reliability, tests, and hardware all matter.
