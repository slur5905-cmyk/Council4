# Local Coding Council — iPhone-only edition

> **Version scope:** The v1.6.0 peer-to-peer communication store, cross-run discussions, component collaboration, reviewable peer lessons, and per-role GGUF model manager are currently implemented in the Python desktop edition. This separate browser edition has not yet received those upgrades. It still runs one in-browser model across its role prompts, keeps learning data in this browser's local storage, and does not sync discussions or model assignments with the desktop edition.

A browser-first local coding assistant for iPhone/iPad. It needs **no AI API key, no paid AI API, no cloud inference endpoint, and no computer to run after setup**. The model is loaded in Safari and generates/reviews code locally in the page.

## What it can build

The task form accepts plain-English requests and offers project profiles for websites/web apps, browser games, simulations/visualizers, mobile app source, backend APIs, libraries/tools, and debugging. Choose a build depth:

- **Working prototype:** smallest useful complete vertical slice.
- **Polished MVP:** adds responsive UX, core flows, error/empty states, docs and targeted tests/test instructions.
- **Thorough project:** uses more file slots and asks for architecture, edge cases, security/reliability, tests and documentation.

The builder creates a manifest, then generates each file separately to reduce the chance that a whole project is truncated by one response. It tracks shared paths/contracts, runs four independent adversarial review passes, attempts targeted repairs for severe or multiple medium findings, and then asks each equal peer to challenge the repaired candidate and vote. Reviewers must explicitly mark each initial critical/high issue as fixed and cite evidence before final approval can be displayed. A conservative gate blocks approval if reviews are malformed, planned files are missing, a severe static check remains, a final reviewer finds a severe issue, or initial severe findings are not explicitly resolved.

## Quality checks

Browser-side checks inspect JSON syntax, CSS brace balance, duplicate HTML IDs, in-page anchors, local HTML asset references, empty files, and common TODO/placeholder markers. They do **not** execute generated JavaScript, start a server, install dependencies, run tests, prove security, or establish that the project works in every browser. The AIs can miss bugs and invent findings. A green/unanimous status means only that the AI and static checks did not detect blocking problems; run the project and tests yourself before depending on it.

Generated files can be saved/shared individually, bundled into a ZIP with the original folder structure plus an audit report, or exported as proposal JSON. On iPhone, exports use Safari's native share sheet when available; choose **Save to Files** to store the file. If file sharing is unavailable, the app falls back to a Safari download; check the Downloads button or Files → Downloads. If an HTML entry point exists, you can request a sandboxed browser preview. The preview iframe limits many kinds of network access but is not a certified security sandbox: only preview code you trust.

## Models

- `onnx-community/Qwen2.5-Coder-0.5B-Instruct`: recommended first attempt for compatibility; weakest of the included choices.
- `onnx-community/Qwen2.5-Coder-1.5B-Instruct`: larger and potentially better at reasoning/code, but significantly more memory/storage.
- `onnx-community/Qwen2.5-Coder-3B-Instruct`: experimental, strongest included option; quantized weights alone are about 1.1 GB. Safari may run out of memory or terminate the tab, depending on the device.

Even the 3B model is small compared with frontier-scale assistants, so quality will vary. You can add up to three extra specialist auditor roles for a run (for example, accessibility, game physics, performance, or database migrations); they use the same local model and have equal review standing. Four agents are four different role prompts to one local model, not four independent trained models. More review rounds use more local compute; allow the phone to stay awake during longer tasks.

The runtime uses the pinned Transformers.js 3.8.1 package. WebGPU is attempted when selected/supported; CPU/WebAssembly is the compatibility option. WebGPU support varies by device and Safari version. If the model fails, try Auto or CPU and the smallest model.

## Use from only an iPhone

1. Download and unzip the project in the iPhone **Files** app.
2. You need to publish the contents of this `iphone-app` folder at an HTTPS URL. For a repository created from this full project, the included `.github/workflows/pages.yml` workflow publishes the contents of `iphone-app/` automatically when you push to `main` and enable GitHub Pages with GitHub Actions as the source. If Pages is not available for your repository/plan, publish only the three app files (`index.html`, `manifest.webmanifest`, `icon.svg`) to another static HTTPS host you trust. You can also use another static HTTPS host you trust. The optional `README.md` can be uploaded too.
3. Open the published HTTPS page in Safari. Keep internet available for the initial download of the Transformers.js runtime and the selected model. The model downloads may be hundreds of MB or more; 1.5B/3B options are much larger.
4. Tap **Load model on this iPhone**. Start with 0.5B. If loading fails, close other tabs, restart Safari, choose CPU/WebAssembly, or switch to a smaller model.
5. Choose a project type and build depth, write what you want in plain English, and optionally add individual source files or a ZIP of an existing project from Files, plus requirements or error details. ZIP imports are capped at 100 entries, 10 MB compressed, 180 KB per file, 2 MB total expanded size, and the phone context budget; the archive central directory is checked before decompression to reduce ZIP-bomb risk. Oversized or unsupported files are reported rather than silently included. ZIP decoding loads a small open-source decompression library from its CDN, so keep internet available for that import step.
6. Tap **Generate code + attack it**. Read the findings, inspect each peer's report and final vote, then download the complete project ZIP and audit report.
7. For a web project, tap **Preview website / game safely** to try it in the restricted iframe. Then extract the downloaded ZIP in Files. To install a web app on the Home Screen, use Safari's Share menu → **Add to Home Screen**.

This iPhone-only route is a static HTTPS site that runs inference in the browser. It does **not** send your prompt/source code to an AI API or remote inference server. It does contact the static host, JavaScript CDN, and model asset host to load the application/runtime/model. Do not call this fully air-gapped, and do not assume every browser cache will persist forever after initial download.

## Privacy and permissions

The page has no direct filesystem write, shell, package install, automatic code execution, API key field, or repository-write permission. Uploaded ZIP entries are treated as untrusted data; absolute paths, parent traversal, dependency folders, sensitive filenames, binary data, and over-budget files are skipped. It reads source files only when you explicitly select them. Generated files are downloaded to Files when you choose. The only code execution feature is your manual request to preview generated HTML inside the sandboxed iframe; treat that as untrusted code and review before running it elsewhere.

## Verified references

- Transformers.js official documentation: https://huggingface.co/docs/transformers.js/en/index
- WebGPU support notes: https://huggingface.co/docs/transformers.js/guides/webgpu
- Qwen2.5-Coder 0.5B model: https://huggingface.co/onnx-community/Qwen2.5-Coder-0.5B-Instruct
- Qwen2.5-Coder 1.5B model: https://huggingface.co/onnx-community/Qwen2.5-Coder-1.5B-Instruct
- Qwen2.5-Coder 3B model: https://huggingface.co/onnx-community/Qwen2.5-Coder-3B-Instruct


## Learning from successful work

The learning panel lets you save a run only after you confirm that you independently tested it and it worked. Saved task/solution pairs are stored in this browser's local storage and may be included as context in future tasks. You can export the real task/assistant-solution pairs as JSONL, or clear them. Manually entered lessons are retrieval notes, not fine-tuning pairs. Browser memory may be cleared by Safari and does not sync to another device.

This browser edition does **not** train or change model weights on the iPhone. For optional actual LoRA fine-tuning, transfer the exported JSONL to a compatible computer, use the full project's `tools/train_lora.py` with a local Hugging Face model directory (not the browser ONNX model or a GGUF file), and follow the root README. Training needs at least 20 usable examples as a minimal gate; useful generalization usually requires many more high-quality, diverse examples and held-out evaluation.
