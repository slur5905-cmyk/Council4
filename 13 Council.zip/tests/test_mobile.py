import unittest
from unittest.mock import patch
import sys

from offline_coder.mobile import (PAGE, _valid_bearer, _valid_apply_confirmation, _read_json_object, _load_mobile_model,
                                  SlidingWindowRateLimiter, BoundedThreadingHTTPServer, main)


class MobileSecurityTests(unittest.TestCase):
    def test_bearer_validation_is_scheme_and_secret_specific(self):
        self.assertTrue(_valid_bearer("Bearer secret-token", "secret-token"))
        self.assertFalse(_valid_bearer("bearer secret-token", "secret-token-x"))
        self.assertFalse(_valid_bearer("Basic secret-token", "secret-token"))
        self.assertFalse(_valid_bearer("Bearer ", "secret-token"))

    def test_mobile_apply_requires_typed_phrase_and_terminal_one_time_code(self):
        self.assertTrue(_valid_apply_confirmation("APPLY", "123456789", "123456789"))
        self.assertFalse(_valid_apply_confirmation("apply", "123456789", "123456789"))
        self.assertFalse(_valid_apply_confirmation("APPLY", "123456788", "123456789"))
        self.assertFalse(_valid_apply_confirmation("APPLY", "1234", "123456789"))

    def test_mobile_shell_uses_nonce_script_policy_and_discloses_one_model_four_prompts(self):
        self.assertIn('<script nonce="__COUNCIL_CSP_NONCE__">', PAGE)
        self.assertNotIn("script-src 'unsafe-inline'", PAGE)
        self.assertIn("one model + four role prompts", PAGE.lower())
        self.assertIn("apply_code:applyCode", PAGE)

    def test_mobile_web_search_requires_exact_query_confirmation(self):
        self.assertIn("This exact query will be sent to an external public search provider", PAGE)

    def test_failed_authentication_is_rate_limited_per_client(self):
        limiter = SlidingWindowRateLimiter()
        self.assertTrue(all(limiter.allow("192.0.2.1", 3, 60) for _ in range(3)))
        self.assertFalse(limiter.allow("192.0.2.1", 3, 60))
        self.assertTrue(limiter.allow("192.0.2.2", 3, 60))

    def test_mobile_server_caps_concurrent_handler_threads(self):
        server = BoundedThreadingHTTPServer(("127.0.0.1", 0), __import__("http.server").server.BaseHTTPRequestHandler, max_workers=3)
        try:
            self.assertEqual(server.max_workers, 3)
            self.assertTrue(server.daemon_threads)
            self.assertEqual(server.request_queue_size, 16)
        finally:
            server.server_close()

    def test_request_body_must_be_a_json_object(self):
        self.assertEqual(_read_json_object(b'{"task":"hello"}'), {"task": "hello"})
        for raw in (b'[]', b'null', b'"string"', b'not-json'):
            with self.subTest(raw=raw):
                with self.assertRaises(ValueError):
                    _read_json_object(raw)

    def test_mobile_handler_has_idle_socket_timeout(self):
        import inspect
        import offline_coder.mobile as mobile
        source = inspect.getsource(mobile.serve)
        self.assertIn('self.request.settimeout(15)', source)

    def test_page_uses_fragment_then_authorization_header_not_query_token(self):
        self.assertIn("new URLSearchParams(location.hash.slice(1))", PAGE)
        self.assertIn("history.replaceState(null,'',location.pathname+location.search)", PAGE)
        self.assertIn("headers={'Authorization':'Bearer '+token}", PAGE)
        self.assertNotIn("fetch(path+'?token=", PAGE)

    def test_mobile_page_includes_authenticated_web_search(self):
        self.assertIn("api('/search',{query})", PAGE)
        self.assertIn("Search the public web", PAGE)

    def test_mobile_audit_view_displays_model_execution_profile(self):
        self.assertIn("model_profile:result.model_profile", PAGE)

    def test_mobile_server_defaults_to_localhost(self):
        with patch.object(sys, "argv", ["offline-council-mobile"]), patch("offline_coder.mobile.serve") as serve:
            main()
        serve.assert_called_once_with("127.0.0.1", 8765, None, None, False)

    def test_mobile_model_loader_uses_desktop_router_settings(self):
        settings = {
            "model_backend": "local-server",
            "local_server_url": "http://127.0.0.1:8080/v1",
            "local_server_model": "primary",
            "local_server_role_models": {"redteam": "specialist"},
        }
        with patch("offline_coder.mobile.build_model_router", return_value="router") as factory:
            self.assertEqual(_load_mobile_model(settings), "router")
        factory.assert_called_once_with(settings)

    def test_mobile_server_boots_with_local_server_backend_without_gguf_path(self):
        import tempfile
        from pathlib import Path
        from types import SimpleNamespace
        from offline_coder.mobile import serve

        class FakeServer:
            def __init__(self, address, handler):
                self.address = address
                self.handler = handler
                self.closed = False
            def serve_forever(self):
                raise KeyboardInterrupt()
            def server_close(self):
                self.closed = True

        with tempfile.TemporaryDirectory() as temp:
            settings = {
                "model_backend": "local-server", "model_path": "",
                "local_server_url": "http://127.0.0.1:8080/v1",
                "local_server_model": "primary", "workspace_path": temp,
            }
            router = SimpleNamespace(
                primary=SimpleNamespace(model="primary"),
                configured_roles=lambda: {"redteam": "local-server:specialist"},
            )
            server_holder = {}
            def server_factory(address, handler, **_kwargs):
                server = FakeServer(address, handler)
                server_holder["server"] = server
                return server
            with patch("offline_coder.mobile.load_settings", return_value=settings), \
                 patch("offline_coder.mobile._load_mobile_model", return_value=router) as load_model, \
                 patch("offline_coder.mobile.KnowledgeStore"), \
                 patch("offline_coder.mobile.BoundedThreadingHTTPServer", side_effect=server_factory), \
                 patch("offline_coder.mobile.lan_ip", return_value="127.0.0.1"):
                serve()
            load_model.assert_called_once_with(settings)
            self.assertTrue(server_holder["server"].closed)

    def test_mobile_page_explains_that_configured_local_models_are_used(self):
        self.assertIn("local model", PAGE)
        self.assertIn("Run four role reviewers", PAGE)

    def test_mobile_server_hardening_is_wired_into_request_handlers(self):
        import inspect
        import offline_coder.mobile as mobile
        source = inspect.getsource(mobile.serve)
        self.assertIn("request_limiter.allow", source)
        self.assertIn("auth_failure_limiter.allow", source)
        self.assertIn("endpoint_limiter.allow", source)
        self.assertIn("Content-Length is required", source)
        self.assertIn("Content-Type must be application/json", source)
        self.assertIn("if not self.endpoint_allowed(path): return", source)
        self.assertLess(source.index("if not self.authorized():return"), source.index("if not self.endpoint_allowed(path): return"))

    def test_plaintext_lan_binding_requires_explicit_opt_in(self):
        from offline_coder.mobile import serve
        with patch("offline_coder.mobile.load_settings") as load_settings:
            with self.assertRaisesRegex(SystemExit, "Refusing unencrypted mobile access"):
                serve(host="0.0.0.0")
        load_settings.assert_not_called()


if __name__ == "__main__":
    unittest.main()
