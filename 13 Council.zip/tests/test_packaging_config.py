from pathlib import Path
try:
    import tomllib
except ImportError:
    import tomli as tomllib


def test_setuptools_package_discovery_is_explicit():
    config = tomllib.loads((Path(__file__).resolve().parents[1] / "pyproject.toml").read_text())
    discovery = config["tool"]["setuptools"]["packages"]["find"]
    assert "offline_coder*" in discovery["include"]
    assert "models*" in discovery["exclude"]
    assert "tests*" in discovery["exclude"]
