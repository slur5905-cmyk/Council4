import json
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

from offline_coder.visual_simulation import run_visual_browser_checks, _safe_relative, _read_manifest, _prepare_visual_output_dir


class VisualSimulationTests(unittest.TestCase):
    def test_no_web_entry_or_manifest_is_not_applicable(self):
        with tempfile.TemporaryDirectory() as temp:
            report = run_visual_browser_checks(Path(temp), {})
        self.assertEqual(report["status"], "NOT_APPLICABLE")

    def test_rejects_manifest_path_traversal(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            (root / "index.html").write_text("<h1>hi</h1>", encoding="utf-8")
            (root / "council.visual.json").write_text(json.dumps({"entry": "../outside.html"}), encoding="utf-8")
            report = run_visual_browser_checks(root, {})
        self.assertEqual(report["status"], "FAILED")
        self.assertIn("safe relative", report["summary"])

    def test_rejects_unknown_action_before_launch(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            (root / "index.html").write_text("<h1>hi</h1>", encoding="utf-8")
            manifest = {"entry": "index.html", "steps": [{"action": "execute_shell", "selector": "body"}]}
            report = run_visual_browser_checks(root, {"council.visual.json": json.dumps(manifest)})
        self.assertEqual(report["status"], "FAILED")
        self.assertIn("unsupported action", report["summary"])

    def test_safe_relative_rejects_parent_paths_and_absolute_paths(self):
        self.assertIsNone(_safe_relative("../secret.html"))
        self.assertIsNone(_safe_relative("/tmp/secret.html"))
        self.assertEqual(_safe_relative("src/index.html"), Path("src/index.html"))

    def test_safe_relative_rejects_noncanonical_and_windows_paths(self):
        for path in (r"src\index.html", "src//index.html", "C:/outside.html", " index.html"):
            with self.subTest(path=path):
                self.assertIsNone(_safe_relative(path))

    def test_visual_manifest_refuses_symlink(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp) / "workspace"
            root.mkdir()
            outside = Path(temp) / "outside.json"
            outside.write_text('{"entry":"index.html"}', encoding="utf-8")
            (root / "council.visual.json").symlink_to(outside)
            manifest, error = _read_manifest(root, {})
        self.assertIsNone(manifest)
        self.assertIn("symlink", error)

    def test_visual_manifest_has_size_limit(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            manifest, error = _read_manifest(root, {"council.visual.json": " " * 1_000_001})
        self.assertIsNone(manifest)
        self.assertIn("1 MB", error)

    def test_visual_output_refuses_council_symlink(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp) / "workspace"
            root.mkdir()
            outside = Path(temp) / "outside"
            outside.mkdir()
            (root / ".council").symlink_to(outside, target_is_directory=True)
            with self.assertRaisesRegex(ValueError, "symlink"):
                _prepare_visual_output_dir(root)
            self.assertEqual(list(outside.iterdir()), [])

    def test_visual_output_rejects_external_output_directory(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp) / "workspace"
            root.mkdir()
            outside = Path(temp) / "outside"
            outside.mkdir()
            with self.assertRaisesRegex(ValueError, "inside"):
                _prepare_visual_output_dir(root, outside)
            self.assertEqual(list(outside.iterdir()), [])

    def test_multiple_viewports_are_run_independently_and_aggregated(self):
        import builtins
        real_import = builtins.__import__
        def guarded_import(name, *args, **kwargs):
            if name == "playwright.sync_api":
                raise ImportError("simulated missing Playwright")
            return real_import(name, *args, **kwargs)
        manifest = {"entry": "index.html", "viewports": [
            {"name": "phone", "width": 375, "height": 812},
            {"name": "tablet", "width": 768, "height": 1024},
            {"name": "desktop", "width": 1280, "height": 800},
        ]}
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            (root / "index.html").write_text("<h1>hi</h1>", encoding="utf-8")
            with patch("builtins.__import__", side_effect=guarded_import):
                report = run_visual_browser_checks(root, {"council.visual.json": json.dumps(manifest)})
        self.assertEqual(report["status"], "SKIPPED")
        self.assertEqual([item["name"] for item in report["viewports"]], ["phone", "tablet", "desktop"])
        self.assertTrue(all(item["status"] == "SKIPPED" for item in report["viewports"]))

    def test_rejects_duplicate_or_invalid_viewports(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            (root / "index.html").write_text("<h1>hi</h1>", encoding="utf-8")
            manifest = {"viewports": [{"name": "phone", "width": 375, "height": 800},
                                     {"name": "phone", "width": 800, "height": 1000}]}
            report = run_visual_browser_checks(root, {"council.visual.json": json.dumps(manifest)})
        self.assertEqual(report["status"], "FAILED")
        self.assertIn("duplicate", report["summary"])

    def test_rejects_visual_baseline_path_traversal(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            (root / "index.html").write_text("<h1>hi</h1>", encoding="utf-8")
            manifest = {"baselines": {"desktop": "../outside.png"}}
            report = run_visual_browser_checks(root, {"council.visual.json": json.dumps(manifest)})
        self.assertEqual(report["status"], "FAILED")
        self.assertIn("safe relative PNG", report["summary"])

    def test_missing_playwright_reports_skipped(self):
        import builtins
        real_import = builtins.__import__
        def guarded_import(name, *args, **kwargs):
            if name == "playwright.sync_api":
                raise ImportError("simulated missing Playwright")
            return real_import(name, *args, **kwargs)
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            (root / "index.html").write_text("<h1>hi</h1>", encoding="utf-8")
            with patch("builtins.__import__", side_effect=guarded_import):
                report = run_visual_browser_checks(root, {})
        self.assertEqual(report["status"], "SKIPPED")
        self.assertIn("Playwright", report["summary"])


if __name__ == "__main__":
    unittest.main()
