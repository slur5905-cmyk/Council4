import tempfile
import unittest
from pathlib import Path
from offline_coder.workspace import collect_workspace_context


class WorkspaceScanTests(unittest.TestCase):
    def test_task_query_ranks_relevant_source_ahead_of_generic_priority_files(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            (root / "README.md").write_text("General project overview.", encoding="utf-8")
            (root / "src").mkdir()
            (root / "src" / "processing.py").write_text(
                "def retry_payment():\n    # exponential backoff policy\n    return 'retry'\n",
                encoding="utf-8",
            )
            (root / "src" / "unrelated.py").write_text("def render_dashboard():\n    return True\n", encoding="utf-8")
            context = collect_workspace_context(
                root, max_chars=6000, max_files=1, query="exponential backoff retry policy"
            )
        self.assertIn("FILE: src/processing.py", context)
        self.assertNotIn("FILE: README.md", context)

    def test_context_without_query_keeps_existing_filename_priority(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            (root / "README.md").write_text("Project overview.", encoding="utf-8")
            (root / "main.py").write_text("print('main')", encoding="utf-8")
            context = collect_workspace_context(root, max_chars=6000, max_files=1)
        self.assertIn("FILE: README.md", context)

    def test_scan_limits_are_reported_in_context(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            for i in range(8):
                (root / f"file_{i}.py").write_text(f"value = {i}\n", encoding="utf-8")
            context = collect_workspace_context(root, max_chars=10000, max_files=90, max_scan_files=2, max_scan_dirs=20)
        self.assertIn("safety limit", context)
        self.assertLessEqual(context.count("===== FILE:"), 2)

    def test_redacts_credentials_in_ordinary_source_files(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            (root / "config.json").write_text(
                '{"api_key":"sk-live-EXAMPLE-DO-NOT-USE-123456789", "password":"hunter2-example"}',
                encoding="utf-8",
            )
            context = collect_workspace_context(root)
        self.assertIn("[REDACTED]", context)
        self.assertNotIn("sk-live-EXAMPLE-DO-NOT-USE-123456789", context)
        self.assertNotIn("hunter2-example", context)

    def test_skips_secret_paths(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            (root / "app.py").write_text("print('ok')", encoding="utf-8")
            (root / ".env").mkdir()
            (root / ".env" / "local.py").write_text("token='do-not-read'", encoding="utf-8")
            context = collect_workspace_context(root)
        self.assertIn("app.py", context)
        self.assertNotIn("do-not-read", context)

    def test_skips_case_variant_private_and_generated_directories(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            (root / "app.py").write_text("def visible(): return True\n", encoding="utf-8")
            for directory, filename, content in [
                (".GIT", "history.py", "SECRET_IN_GIT_HISTORY = True\n"),
                (".COUNCIL", "backup.py", "PRIVATE_COUNCIL_BACKUP = True\n"),
                ("Node_Modules", "package.js", "PRIVATE_DEPENDENCY = true;\n"),
                (".VENV", "site.py", "PRIVATE_ENVIRONMENT = True\n"),
            ]:
                folder = root / directory
                folder.mkdir()
                (folder / filename).write_text(content, encoding="utf-8")
            context = collect_workspace_context(root, max_chars=12000, max_files=100)
        self.assertIn("visible", context)
        self.assertNotIn("SECRET_IN_GIT_HISTORY", context)
        self.assertNotIn("PRIVATE_COUNCIL_BACKUP", context)
        self.assertNotIn("PRIVATE_DEPENDENCY", context)
        self.assertNotIn("PRIVATE_ENVIRONMENT", context)


if __name__ == "__main__":
    unittest.main()

    def test_redacts_environment_style_aws_secret(self):
        from offline_coder.safety import redact_sensitive_text
        text = 'AWS_SECRET_ACCESS_KEY=super-secret-value-123'
        self.assertNotIn('super-secret-value-123', redact_sensitive_text(text))
