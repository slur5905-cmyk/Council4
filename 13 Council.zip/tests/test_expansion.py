import json
import sqlite3
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

from offline_coder.expansion import (
    ExpansionStore,
    NullExpansionStore,
    ResourceMonitor,
    adaptive_worker_limit,
    discover_local_tools,
    inspect_resources,
    rank_model_candidates,
)


class ResourceAssessmentTests(unittest.TestCase):
    def test_null_expansion_store_does_not_persist_memory_or_checkpoints(self):
        store = NullExpansionStore()
        self.assertEqual(store.start_checkpoint("task"), "")
        self.assertIsNone(store.get_checkpoint("not-created"))
        self.assertEqual(store.list_checkpoints(), [])
        self.assertEqual(store.search("anything"), [])
        self.assertIsNone(store.add_memory("experience", "summary", "content"))
        self.assertEqual(store.memory_status()["search_index"], "disabled")

    def test_worker_limit_never_exceeds_configuration_and_scales_down_with_low_ram(self):
        self.assertEqual(adaptive_worker_limit(4, 2 * 1024**3), 1)
        self.assertEqual(adaptive_worker_limit(4, 6 * 1024**3), 2)
        self.assertEqual(adaptive_worker_limit(3, 16 * 1024**3), 3)
        self.assertEqual(adaptive_worker_limit(4, None), 1)

    def test_resource_snapshot_separates_measured_values_from_unknown_context_usage(self):
        with tempfile.TemporaryDirectory() as temp:
            report = inspect_resources(
                {"n_ctx": 4096, "max_context_chars": 9000, "max_peer_workers": 3},
                app_dir=Path(temp),
                active_tasks=1,
            )
        self.assertEqual(report["context"]["configured_tokens"], 4096)
        self.assertEqual(report["context"]["current_usage"], "Not reported by the configured model backend")
        self.assertEqual(report["workers"]["active_tasks"], 1)
        self.assertLessEqual(report["workers"]["adaptive_peer_limit"], 3)
        self.assertGreater(report["storage"]["total_bytes"] or 0, 0)
        self.assertIn("architecture", report["cpu"])
        self.assertIn("gpu", report)
        self.assertIn("network", report)
        self.assertFalse(report["network"]["external_connectivity_tested"])

    def test_resource_monitor_reports_active_workers_and_available_slots(self):
        baseline = {"workers": {"adaptive_peer_limit": 2, "active_workers": 0, "available_peer_slots": 2}}
        with patch("offline_coder.expansion.inspect_resources", return_value=baseline):
            monitor = ResourceMonitor(interval_seconds=30, active_tasks=1)
            monitor.start()
            monitor.set_active_workers(2)
            snapshot = monitor.snapshot()
            monitor.stop()
        self.assertEqual(snapshot["workers"]["active_workers"], 2)
        self.assertEqual(snapshot["workers"]["available_peer_slots"], 0)
        self.assertEqual(snapshot["workers"]["peak_active_workers"], 2)

    def test_candidate_ranking_uses_measured_task_quality_and_current_memory_fit(self):
        candidates = [
            {
                "id": "large-but-unmeasured",
                "estimated_memory_bytes": 6 * 1024**3,
                "parameter_count": 700_000_000_000,
            },
            {
                "id": "small-measured",
                "estimated_memory_bytes": 2 * 1024**3,
                "context_tokens": 8192,
                "quantization": "Q4_K_M",
                "benchmarks": {"coding": 0.8, "tool_use": 0.7, "reliability": 0.9, "speed": 0.8},
            },
            {
                "id": "stronger-but-does-not-fit",
                "estimated_memory_bytes": 12 * 1024**3,
                "benchmarks": {"coding": 1.0, "tool_use": 1.0, "reliability": 1.0, "speed": 1.0},
            },
        ]
        result = rank_model_candidates(candidates, available_memory_bytes=8 * 1024**3, task_type="coding")
        self.assertEqual(result["selected"]["id"], "small-measured")
        self.assertEqual(result["status"], "measured recommendation")
        self.assertEqual(result["rejected"][0]["id"], "stronger-but-does-not-fit")
        no_evidence = rank_model_candidates(candidates[:1], 8 * 1024**3)
        self.assertIsNone(no_evidence["selected"])
        self.assertEqual(no_evidence["status"], "insufficient task-specific benchmark evidence")

    def test_model_without_task_specific_measurement_is_not_selected(self):
        result = rank_model_candidates(
            [{"id": "tool-only", "benchmarks": {"tool_use": 1.0, "reliability": 1.0}}],
            available_memory_bytes=8 * 1024**3,
            task_type="coding",
        )
        self.assertIsNone(result["selected"])
        self.assertEqual(result["status"], "insufficient task-specific benchmark evidence")

    def test_model_ranking_penalizes_incomplete_benchmark_evidence(self):
        result = rank_model_candidates(
            [
                {"id": "narrow-perfect", "benchmarks": {"coding": 0.95}},
                {"id": "broad-strong", "benchmarks": {
                    "coding": 0.85, "tool_use": 0.85, "reliability": 0.85,
                    "context": 0.85, "speed": 0.85,
                }},
            ],
            available_memory_bytes=8 * 1024**3,
            task_type="coding",
        )
        self.assertEqual(result["selected"]["id"], "broad-strong")
        narrow = next(item for item in result["ranked"] if item["id"] == "narrow-perfect")
        broad = next(item for item in result["ranked"] if item["id"] == "broad-strong")
        self.assertGreater(narrow["score"], broad["score"])
        self.assertLess(narrow["evidence_adjusted_score"], broad["evidence_adjusted_score"])
        self.assertEqual(narrow["measurement_coverage"], 0.4)

    @patch("offline_coder.expansion.shutil.which", side_effect=lambda name: f"/usr/bin/{name}" if name == "git" else None)
    def test_local_tool_discovery_never_claims_unreviewed_tools_are_integrated(self, which):
        tools = discover_local_tools()
        git = next(item for item in tools if item["name"] == "git")
        self.assertTrue(git["path"])
        self.assertIn("not integrated", git["status"])
        self.assertEqual(next(item for item in tools if item["name"] == "docker")["path"], "")
        self.assertEqual(which.call_count, len(tools))


class PersistentMemoryTests(unittest.TestCase):
    def test_memory_expands_without_changing_existing_entries_and_versions_are_integrity_checked(self):
        with tempfile.TemporaryDirectory() as temp:
            store = ExpansionStore(Path(temp) / "expansion.sqlite3")
            first = store.add_memory("fact", "Python ordering", "Dictionaries preserve insertion order.", tags=["python"])
            duplicate = store.add_memory("fact", "Python ordering", "Dictionaries preserve insertion order.", tags=["python"])
            second = store.add_memory(
                "fact", "Python ordering update", "Dictionary insertion order is guaranteed.", supersedes=first
            )
            extra = store.add_memory("project", "Project choice", "Use local SQLite for small indexed memory.")
            self.assertEqual(first, duplicate)
            self.assertEqual([item["id"] for item in store.search("dictionary insertion order")], [second])
            self.assertEqual(store.get_checkpoint("missing"), None)
            records = {item["id"]: item for item in store.list_memories()}
            self.assertEqual(records[first]["content"], "Dictionaries preserve insertion order.")
            self.assertEqual(records[second]["version"], 2)
            self.assertEqual(records[second]["supersedes"], first)
            self.assertIn(extra, records)

    def test_search_marks_old_memory_stale_and_flags_unresolved_conflicts(self):
        with tempfile.TemporaryDirectory() as temp:
            store = ExpansionStore(Path(temp) / "expansion.sqlite3")
            from datetime import datetime, timedelta, timezone
            first = store.add_memory("fact", "Retry policy", "Use fixed one-second retries.")
            second = store.add_memory("fact", "Retry policy", "Use bounded exponential backoff.")

            class FutureDateTime(datetime):
                @classmethod
                def now(cls, tz=None):
                    return datetime.now(timezone.utc) + timedelta(days=2)

            with patch("offline_coder.expansion.datetime", FutureDateTime):
                matches = store.search("retry policy", max_age_days=1)
        self.assertEqual({item["id"] for item in matches}, {first, second})
        self.assertTrue(all(item["is_stale"] for item in matches))
        self.assertTrue(all(item["conflict"] for item in matches))
        self.assertTrue(all(set(item["conflicting_memory_ids"]) == {first, second} for item in matches))

    def test_superseded_memory_versions_are_not_reported_as_conflicts(self):
        with tempfile.TemporaryDirectory() as temp:
            store = ExpansionStore(Path(temp) / "expansion.sqlite3")
            first = store.add_memory("fact", "Dictionary ordering", "Old statement.")
            second = store.add_memory("fact", "Dictionary ordering", "Corrected statement.", supersedes=first)
            matches = store.search("dictionary ordering")
        latest = next(item for item in matches if item["id"] == second)
        self.assertFalse(latest["conflict"])
        self.assertFalse(latest["is_stale"])

    def test_tampered_memory_is_excluded_and_existing_entries_remain_searchable(self):
        with tempfile.TemporaryDirectory() as temp:
            db_path = Path(temp) / "expansion.sqlite3"
            store = ExpansionStore(db_path)
            intact_id = store.add_memory("fact", "SQLite fact", "SQLite commits are transactional.")
            tampered_id = store.add_memory("fact", "Tampered fact", "Original entry.")
            with sqlite3.connect(db_path) as db:
                db.execute("UPDATE memories SET content=? WHERE id=?", ("Modified content.", tampered_id))
            found = store.search("SQLite transactional")
            self.assertEqual([item["id"] for item in found], [intact_id])
            self.assertEqual(store.memory_status()["integrity_failures"], 1)

    def test_memory_integrity_covers_version_links_and_timestamps(self):
        with tempfile.TemporaryDirectory() as temp:
            db_path = Path(temp) / "expansion.sqlite3"
            store = ExpansionStore(db_path)
            original = store.add_memory("fact", "Versioned fact", "Original memory.")
            version = store.add_memory(
                "fact", "Versioned fact update", "Updated memory.", supersedes=original
            )
            timestamped = store.add_memory("fact", "Timestamped fact", "Created at is integrity-bound.")
            with sqlite3.connect(db_path) as db:
                db.execute("UPDATE memories SET supersedes=? WHERE id=?", (None, version))
                db.execute("UPDATE memories SET created_at=? WHERE id=?", ("2000-01-01T00:00:00+00:00", timestamped))
            found = {item["id"] for item in store.list_memories()}
            self.assertNotIn(version, found)
            self.assertNotIn(timestamped, found)
            self.assertEqual(store.memory_status()["integrity_failures"], 2)

    def test_checkpoint_survives_reopen_and_returns_only_unfinished_subtasks(self):
        with tempfile.TemporaryDirectory() as temp:
            db_path = Path(temp) / "expansion.sqlite3"
            first = ExpansionStore(db_path)
            task_id = first.start_checkpoint("Build and verify a local feature", "recoverable-task")
            first.update_checkpoint(
                task_id,
                "implementation",
                subtasks=["Implement behavior", "Run regression tests", "Record outcome"],
                completed=["Implement behavior"],
                notes="Implementation findings are saved.",
                state={"result": {"analyses": {"peer-a": "saved analysis"}}, "context": "saved context"},
            )
            resumed = ExpansionStore(db_path).get_checkpoint(task_id)
        self.assertEqual(resumed["stage"], "implementation")
        self.assertEqual(resumed["completed"], ["Implement behavior"])
        self.assertEqual(resumed["remaining"], ["Run regression tests", "Record outcome"])
        self.assertEqual(resumed["notes"], "Implementation findings are saved.")
        self.assertEqual(resumed["state"]["context"], "saved context")

    def test_checkpoint_integrity_failure_is_reported(self):
        with tempfile.TemporaryDirectory() as temp:
            db_path = Path(temp) / "expansion.sqlite3"
            store = ExpansionStore(db_path)
            task_id = store.start_checkpoint("Recover interrupted work", "tampered-task")
            with sqlite3.connect(db_path) as db:
                db.execute("UPDATE checkpoints SET notes=? WHERE task_id=?", ("unverified edit", task_id))
            with self.assertRaisesRegex(ValueError, "integrity check failed"):
                store.get_checkpoint(task_id)

    def test_checkpoint_state_redacts_common_credentials_before_persisting(self):
        with tempfile.TemporaryDirectory() as temp:
            store = ExpansionStore(Path(temp) / "expansion.sqlite3")
            task_id = store.start_checkpoint("Save sanitized work", "redacted-state")
            store.update_checkpoint(
                task_id, "analysis",
                state={"analysis": 'api_key = "sk-12345678901234567890"'},
            )
            recovered = store.get_checkpoint(task_id)
        serialized = json.dumps(recovered["state"])
        self.assertNotIn("sk-12345678901234567890", serialized)

    def test_database_limit_refuses_growth_without_deleting_existing_memory(self):
        with tempfile.TemporaryDirectory() as temp:
            store = ExpansionStore(Path(temp) / "expansion.sqlite3", max_db_bytes=1_048_576)
            saved = store.add_memory("fact", "Retained fact", "Keep this existing information.")
            store.max_db_bytes = store.db_path.stat().st_size
            with self.assertRaisesRegex(OSError, "limit reached"):
                store.add_memory("fact", "New fact", "This addition exceeds the configured limit.")
            self.assertEqual(store.search("existing information")[0]["id"], saved)

    def test_benchmark_measures_retrieval_and_only_adopts_measured_nonregressions(self):
        with tempfile.TemporaryDirectory() as temp:
            store = ExpansionStore(Path(temp) / "expansion.sqlite3")
            store.add_memory("fact", "Benchmark target", "Indexed memory retrieves this exact benchmark phrase.")
            measured = store.benchmark_search("benchmark phrase", rounds=3)
        self.assertEqual(measured["status"], "verified")
        self.assertEqual(measured["hits"], 1)
        self.assertEqual(measured["integrity_failures"], 0)
        baseline = {**measured, "hits": 0, "mean_query_ms": measured["mean_query_ms"] * 2}
        decision = store.compare_benchmarks(baseline, measured)
        self.assertTrue(decision["accepted"])
        self.assertEqual(decision["status"], "verified")
        self.assertIn("does not measure model intelligence", decision["scope"])
        regressed = store.compare_benchmarks(measured, {**measured, "hits": 0})
        self.assertFalse(regressed["accepted"])
        self.assertFalse(regressed["checks"]["retrieval_not_regressed"])


if __name__ == "__main__":
    unittest.main()
