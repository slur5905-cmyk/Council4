import re
import unittest
from tools.check_publish import PATTERNS


class PublishGuardTests(unittest.TestCase):
    def test_common_windows_user_profile_path_is_detected(self):
        pattern = dict(PATTERNS)["Windows user profile"]
        self.assertIsNotNone(pattern.search(r"C:\Users\Antton\private\file.txt"))

    def test_windows_path_pattern_does_not_match_public_relative_path(self):
        pattern = dict(PATTERNS)["Windows user profile"]
        self.assertIsNone(pattern.search("docs\guide.md"))


if __name__ == "__main__":
    unittest.main()
