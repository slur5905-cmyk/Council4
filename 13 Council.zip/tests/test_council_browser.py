import json
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

from offline_coder.council_browser import (
    BrowserPolicyError, action_requires_approval, save_workflow,
    validate_public_http_url,
)


class CouncilBrowserPolicyTests(unittest.TestCase):
    def test_allows_public_http_and_https(self):
        self.assertEqual(validate_public_http_url("https://example.com/a#fragment", resolve_dns=False),
                         "https://example.com/a")
        self.assertEqual(validate_public_http_url("http://example.com", resolve_dns=False),
                         "http://example.com/")

    def test_rejects_non_web_schemes_and_credentials(self):
        for url in ("file:///etc/passwd", "javascript:alert(1)",
                    "https://user:pass@example.com", "ftp://example.com"):
            with self.subTest(url=url), self.assertRaises(BrowserPolicyError):
                validate_public_http_url(url, resolve_dns=False)

    def test_rejects_local_private_and_reserved_ip_addresses(self):
        for url in ("http://127.0.0.1", "http://10.0.0.1", "http://192.168.1.1",
                    "http://169.254.169.254", "http://[::1]", "http://localhost",
                    "http://printer.local"):
            with self.subTest(url=url), self.assertRaises(BrowserPolicyError):
                validate_public_http_url(url, resolve_dns=False)

    def test_dns_resolution_blocks_private_addresses(self):
        with patch("offline_coder.council_browser.socket.getaddrinfo",
                   return_value=[(2, 1, 6, "", ("192.168.1.9", 0))]):
            with self.assertRaises(BrowserPolicyError):
                validate_public_http_url("https://example.com")

    def test_consequential_actions_need_approval(self):
        self.assertTrue(action_requires_approval("submit"))
        self.assertTrue(action_requires_approval("click", "Delete account"))
        self.assertTrue(action_requires_approval("click", "Continue", inside_form=True))
        self.assertFalse(action_requires_approval("click", "Read documentation"))

    def test_saved_workflows_do_not_store_values_or_credentials(self):
        with tempfile.TemporaryDirectory() as td:
            path = Path(td) / "workflows.json"
            save_workflow(path, "Docs lookup", [
                {"action": "navigate", "target": "https://example.com"},
                {"action": "fill_prompt", "target": "Search box"}
            ])
            data = json.loads(path.read_text())
            self.assertEqual(data[0]["name"], "Docs lookup")
            self.assertNotIn("password", path.read_text().lower())
            self.assertNotIn("value", data[0]["steps"][1])

    def test_rejects_unknown_workflow_actions(self):
        with tempfile.TemporaryDirectory() as td:
            with self.assertRaises(ValueError):
                save_workflow(Path(td) / "w.json", "bad", [{"action": "execute_python"}])


if __name__ == "__main__":
    unittest.main()
