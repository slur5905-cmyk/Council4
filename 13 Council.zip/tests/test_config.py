import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

from offline_coder import config


class ConfigTests(unittest.TestCase):
    def test_web_research_defaults_off_and_ignores_stale_opt_in(self):
        from offline_coder.config import _validated_settings
        self.assertFalse(config.DEFAULT_SETTINGS["autonomous_web_research"])
        self.assertFalse(_validated_settings({"autonomous_web_research": True})["autonomous_web_research"])

    def test_autonomous_apply_defaults_off(self):
        self.assertFalse(config.DEFAULT_SETTINGS["auto_apply_approved"])

    def test_expansion_and_host_telemetry_are_opt_in_with_a_smaller_database_budget(self):
        from offline_coder.config import _validated_settings
        self.assertFalse(config.DEFAULT_SETTINGS["advanced_features_enabled"])
        self.assertFalse(_validated_settings({"advanced_features_enabled": "yes"})["advanced_features_enabled"])
        self.assertEqual(config.DEFAULT_SETTINGS["memory_max_bytes"], 134217728)

    def test_legacy_unattended_apply_opt_in_is_forced_off_on_load_and_save(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            target = root / "settings.json"
            with patch.object(config, "APP_DIR", root), patch.object(config, "SETTINGS_PATH", target):
                config.save_settings({**config.DEFAULT_SETTINGS, "auto_apply_approved": True})
                self.assertFalse(config.load_settings()["auto_apply_approved"])
                self.assertFalse(__import__("json").loads(target.read_text(encoding="utf-8"))["auto_apply_approved"])

    def test_save_settings_does_not_follow_predictable_temp_symlink(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            app = root / "app"
            app.mkdir()
            outside = root / "unrelated.txt"
            outside.write_text("do not overwrite", encoding="utf-8")
            temp_link = app / "settings.tmp"
            try:
                temp_link.symlink_to(outside)
            except (OSError, NotImplementedError):
                self.skipTest("Symlinks are not available on this platform")
            with patch.object(config, "APP_DIR", app), patch.object(config, "SETTINGS_PATH", app / "settings.json"):
                config.save_settings(config.DEFAULT_SETTINGS.copy())
            self.assertEqual(outside.read_text(encoding="utf-8"), "do not overwrite")
            self.assertTrue((app / "settings.json").is_file())

    def test_save_settings_refuses_settings_file_symlink(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            app = root / "app"
            app.mkdir()
            outside = root / "unrelated.json"
            outside.write_text('{"safe": true}', encoding="utf-8")
            target = app / "settings.json"
            try:
                target.symlink_to(outside)
            except (OSError, NotImplementedError):
                self.skipTest("Symlinks are not available on this platform")
            with patch.object(config, "APP_DIR", app), patch.object(config, "SETTINGS_PATH", target):
                with self.assertRaisesRegex(ValueError, "symlink"):
                    config.save_settings(config.DEFAULT_SETTINGS.copy())
            self.assertEqual(outside.read_text(encoding="utf-8"), '{"safe": true}')

    def test_extreme_or_wrong_type_settings_do_not_crash_startup(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            target = root / "settings.json"
            target.write_text('{"temperature": 1e10000, "model_backend": "remote", "n_ctx": true}', encoding="utf-8")
            with patch.object(config, "APP_DIR", root), patch.object(config, "SETTINGS_PATH", target):
                loaded = config.load_settings()
            self.assertEqual(loaded["temperature"], config.DEFAULT_SETTINGS["temperature"])
            self.assertEqual(loaded["model_backend"], "gguf")
            self.assertEqual(loaded["n_ctx"], config.DEFAULT_SETTINGS["n_ctx"])

    def test_malformed_settings_are_sanitized_to_bounded_defaults(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            target = root / "settings.json"
            target.write_text('{"workspace_path": null, "n_threads": "many", "max_tokens": -999, "temperature": 999, "auto_apply_approved": "yes"}', encoding="utf-8")
            with patch.object(config, "APP_DIR", root), patch.object(config, "SETTINGS_PATH", target):
                loaded = config.load_settings()
            self.assertEqual(loaded["workspace_path"], config.DEFAULT_SETTINGS["workspace_path"])
            self.assertEqual(loaded["n_threads"], config.DEFAULT_SETTINGS["n_threads"])
            self.assertEqual(loaded["max_tokens"], 64)
            self.assertEqual(loaded["temperature"], 2.0)
            self.assertFalse(loaded["auto_apply_approved"])

    def test_parallel_peer_worker_setting_is_bounded(self):
        from offline_coder.config import _validated_settings
        self.assertEqual(_validated_settings({"max_peer_workers": 99})["max_peer_workers"], 4)
        self.assertEqual(_validated_settings({"max_peer_workers": 0})["max_peer_workers"], 1)
        self.assertEqual(_validated_settings({"max_peer_workers": True})["max_peer_workers"], 2)

    def test_local_model_timeout_is_bounded_for_slow_inference(self):
        from offline_coder.config import _validated_settings
        self.assertEqual(_validated_settings({"model_timeout_seconds": 3600})["model_timeout_seconds"], 600)
        self.assertEqual(_validated_settings({"model_timeout_seconds": 1})["model_timeout_seconds"], 30)

    def test_persistent_memory_limit_is_bounded(self):
        from offline_coder.config import _validated_settings
        self.assertEqual(_validated_settings({"memory_max_bytes": 1})["memory_max_bytes"], 1_048_576)
        self.assertEqual(_validated_settings({"memory_max_bytes": 9_000_000_000})["memory_max_bytes"], 4_294_967_296)
        self.assertEqual(_validated_settings({"memory_max_bytes": True})["memory_max_bytes"], 134217728)
