import json
import tempfile
import unittest
from unittest import mock
from pathlib import Path

from offline_coder.safety import validate_proposed_files, apply_files, sha256_text
from offline_coder.council import _json_object


class SafetyTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.root = Path(self.tmp.name)

    def tearDown(self):
        self.tmp.cleanup()

    def test_accepts_safe_python_and_json(self):
        files = {"src/hello.py": "def hello():\n    return 'hello'\n", "settings.json": json.dumps({"enabled": True})}
        result = validate_proposed_files(self.root, files)
        self.assertTrue(result.ok, result.errors)
        self.assertEqual(set(result.hashes_before), set(files))

    def test_blocks_path_traversal(self):
        result = validate_proposed_files(self.root, {"../outside.py": "print('no')"})
        self.assertFalse(result.ok)
        self.assertTrue(any("unsafe path" in e.lower() for e in result.errors))

    def test_blocks_noncanonical_path_aliases(self):
        for name in (r"src\nested.py", "src//nested.py", "./nested.py", " nested.py"):
            with self.subTest(name=name):
                result = validate_proposed_files(self.root, {name: "value = 1\n"})
                self.assertFalse(result.ok, f"non-canonical path should be rejected: {name!r}")
                self.assertTrue(any("non-canonical path" in e.lower() for e in result.errors))

    def test_path_validation_writer_targets_are_identical(self):
        result = validate_proposed_files(self.root, {"src/nested.py": "value = 1\n"})
        self.assertTrue(result.ok, result.errors)
        self.assertIn("src/nested.py", result.hashes_before)

    def test_blocks_case_variants_of_protected_directories(self):
        for name in (".GIT/config.py", ".Git/hooks/pre-commit.py", ".COUNCIL/backup.py"):
            with self.subTest(name=name):
                result = validate_proposed_files(self.root, {name: "value = 1\n"})
                self.assertFalse(result.ok, f"protected path case variant should be rejected: {name}")

    def test_blocks_common_api_tokens_and_hardcoded_credentials(self):
        samples = [
            {"settings.py": 'API_KEY = "sk-live-EXAMPLE-DO-NOT-USE-123456789"\n'},
            {"config.json": '{"password":"a-real-looking-password-value"}'},
            {"client.py": 'TOKEN = "a-long-sensitive-token-value"\n'},
        ]
        for files in samples:
            with self.subTest(files=list(files)):
                result = validate_proposed_files(self.root, files)
                self.assertFalse(result.ok, "credential-like content must be blocked")
                self.assertTrue(any("credential/private-key" in e.lower() for e in result.errors))

    def test_allows_explicit_secret_placeholders(self):
        result = validate_proposed_files(self.root, {"settings.py": 'API_KEY = "YOUR_API_KEY_HERE"\n'})
        self.assertTrue(result.ok, result.errors)

    def test_blocks_env_files_and_private_key_material(self):
        env = validate_proposed_files(self.root, {".env": "TOKEN=not-real"})
        self.assertFalse(env.ok)
        env_child = validate_proposed_files(self.root, {".env/generated.py": "TOKEN = 'placeholder'"})
        self.assertFalse(env_child.ok, "secret-like .env directories must not be writable either")
        key = validate_proposed_files(self.root, {"keys.txt": "-----BEGIN PRIVATE KEY-----\nsecret\n-----END PRIVATE KEY-----"})
        self.assertFalse(key.ok)

    def test_blocks_invalid_python_and_json(self):
        py = validate_proposed_files(self.root, {"bad.py": "def broken(:\n    pass"})
        js = validate_proposed_files(self.root, {"bad.json": "{broken"})
        self.assertFalse(py.ok)
        self.assertFalse(js.ok)

    def test_apply_checks_stale_hashes_and_backs_up(self):
        path = self.root / "hello.py"
        path.write_text("old = True\n", encoding="utf-8")
        expected = {"hello.py": sha256_text("old = True\n")}
        backup = apply_files(self.root, {"hello.py": "new = True\n"}, expected)
        self.assertEqual(path.read_text(encoding="utf-8"), "new = True\n")
        self.assertEqual((backup / "hello.py").read_text(encoding="utf-8"), "old = True\n")
        stale = {"hello.py": sha256_text("some other content")}
        with self.assertRaises(ValueError):
            apply_files(self.root, {"hello.py": "another = True\n"}, stale)

    def test_apply_rejects_missing_expected_hash_entry(self):
        with self.assertRaisesRegex(ValueError, "exactly one reviewed entry"):
            apply_files(self.root, {"new.py": "value = 1\n"}, {})

    def test_apply_rejects_unreviewed_new_file_hash_value(self):
        with self.assertRaisesRegex(ValueError, "changed after review"):
            apply_files(self.root, {"new.py": "value = 1\n"}, {"new.py": "not-none"})

    def test_stale_hash_check_uses_exact_bytes_for_invalid_utf8(self):
        path = self.root / "broken.py"
        path.write_bytes(b"value = \xff\n")
        # Different invalid UTF-8 bytes can decode to the same replacement text;
        # exact-byte hashing must still detect that the file changed after review.
        reviewed = validate_proposed_files(self.root, {"broken.py": "value = 2\n"})
        self.assertTrue(reviewed.ok, reviewed.errors)
        path.write_bytes(b"value = \xfe\n")
        with self.assertRaisesRegex(ValueError, "changed after review"):
            apply_files(self.root, {"broken.py": "value = 2\n"}, reviewed.hashes_before)

    def test_apply_rejects_symlink_created_before_apply(self):
        outside = self.root.parent / (self.root.name + "_outside.py")
        outside.write_text("safe = True\n", encoding="utf-8")
        try:
            (self.root / "linked.py").symlink_to(outside)
            with self.assertRaises(ValueError):
                apply_files(self.root, {"linked.py": "unsafe = True\n"}, {"linked.py": sha256_text("safe = True\n")})
            self.assertEqual(outside.read_text(encoding="utf-8"), "safe = True\n")
        finally:
            outside.unlink(missing_ok=True)

    def test_failed_multi_file_apply_does_not_overwrite_concurrent_unapplied_change(self):
        first = self.root / "first.py"
        second = self.root / "second.py"
        first.write_text("first_old = 1\n", encoding="utf-8")
        second.write_text("second_old = 1\n", encoding="utf-8")
        files = {"first.py": "first_new = 1\n", "second.py": "second_new = 1\n"}
        expected = {
            "first.py": sha256_text("first_old = 1\n"),
            "second.py": sha256_text("second_old = 1\n"),
        }
        import offline_coder.safety as safety
        original_replace = safety.os.replace
        replace_calls = 0

        def concurrent_replace(src, dst):
            nonlocal replace_calls
            replace_calls += 1
            result = original_replace(src, dst)
            # Simulate an unrelated process editing the second file after the first
            # replacement. The second write should fail its hash recheck, and rollback
            # must not restore over that concurrent edit because this run never replaced it.
            if replace_calls == 1:
                second.write_text("concurrent_edit = True\n", encoding="utf-8")
            return result

        with mock.patch("offline_coder.safety.os.replace", side_effect=concurrent_replace):
            with self.assertRaisesRegex(ValueError, "changed during apply"):
                apply_files(self.root, files, expected)

        self.assertEqual(first.read_text(encoding="utf-8"), "first_old = 1\n")
        self.assertEqual(second.read_text(encoding="utf-8"), "concurrent_edit = True\n")

    def test_apply_records_original_hash_in_manifest(self):
        path = self.root / "existing.py"
        path.write_text("old = 1\n", encoding="utf-8")
        before = sha256_text("old = 1\n")
        backup = apply_files(self.root, {"existing.py": "new = 2\n"}, {"existing.py": before})
        manifest = json.loads((backup / "manifest.json").read_text(encoding="utf-8"))
        self.assertEqual(manifest["targets"][0]["sha256_before"], before)

    def test_json_parser_accepts_fenced_and_embedded_json(self):
        self.assertEqual(_json_object('```json\n{"vote":"APPROVE"}\n```'), {"vote": "APPROVE"})
        self.assertEqual(_json_object('Here: {"files": {"x.py": "print(1)"}} end'), {"files": {"x.py": "print(1)"}})
        self.assertIsNone(_json_object("not json"))


    def test_self_edit_allowlist_blocks_all_application_and_authority_modules(self):
        from offline_coder.safety import validate_proposed_files, PROJECT_ROOT
        blocked = {
            "offline_coder/mobile.py": "# change phone permissions\n",
            "offline_coder/isolated_tests.py": "# change test runner\n",
            "offline_coder/web_search.py": "# change network behavior\n",
            "offline_coder/cli.py": "# change command entrypoint\n",
            "offline_coder/expansion.py": "# change host tooling\n",
            "offline_coder/safety.py": "# change write policy\n",
            "offline_coder/council.py": "# change orchestration and votes\n",
            "offline_coder/model_backend.py": "# change model loading\n",
            "offline_coder/workspace.py": "# change workspace access\n",
            "offline_coder/config.py": "# change authority settings\n",
            "offline_coder/app.py": "# change desktop controls\n",
            "main.py": "# change program entrypoint\n",
        }
        for path, content in blocked.items():
            with self.subTest(path=path):
                result = validate_proposed_files(PROJECT_ROOT, {path: content}, allow_self_edit=True)
                self.assertFalse(result.ok)
                self.assertTrue(any("Self-edit allowlist blocked" in item for item in result.errors))

    def test_self_edit_allowlist_allows_only_documentation_and_curated_knowledge(self):
        from offline_coder.safety import validate_proposed_files, PROJECT_ROOT
        for path in ("STATUS.md", "docs/security-notes.md", "offline_coder/base_knowledge/python_basics.md"):
            with self.subTest(path=path):
                result = validate_proposed_files(PROJECT_ROOT, {path: "# reviewed notes\n"}, allow_self_edit=True)
                self.assertTrue(result.ok, result.errors)



if __name__ == "__main__":
    unittest.main()

    def test_blocks_environment_style_aws_secret_assignment(self):
        result = validate_proposed_files(self.root, {"settings.py": 'AWS_SECRET_ACCESS_KEY="super-secret-value-123"\n'})
        self.assertFalse(result.ok)
        self.assertTrue(any("credential" in error.lower() for error in result.errors))
