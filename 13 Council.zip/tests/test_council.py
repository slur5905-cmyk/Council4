import json
import tempfile
import unittest
from pathlib import Path

from offline_coder.council import CouncilRunner, apply_approved_result


class StubModel:
    """Deterministic fake used to test the orchestration without an AI model or network."""
    def generate(self, system, user, max_tokens=None, temperature=None):
        if "Work independently before being shown" in user:
            return "Requirements: implement a tiny function. Use one file and test syntax."
        if "Return ONLY a JSON object with this schema" in user:
            return json.dumps({
                "summary": "Add a hello function.",
                "user_facing_answer": "I propose adding a small Python hello function.",
                "notes": ["No code has been executed."],
                "files": {"hello.py": "def hello():\n    return 'hello'\n"},
            })
        if "ALL FOUR INDEPENDENT ANALYSES" in user:
            return "Peer critique: the approach is consistent; ensure valid syntax."
        if '"findings"' in user and "CANDIDATE SUMMARY" in user:
            return json.dumps({"vote": "APPROVE", "findings": [], "checks_performed": ["Traced normal and malformed input paths."], "strengths": ["Small and clear."], "confidence": 0.9})
        if "ALL FOUR REVIEW REPORTS" in user:
            return json.dumps({"vote": "APPROVE", "remaining_blockers": [], "reason": "Reviewed the other peer reports; no blockers remain."})
        return "Generic peer note."


class CouncilTests(unittest.TestCase):
    def test_autonomous_apply_requires_actual_runtime_test_pass(self):
        from offline_coder.council import RunResult, can_autonomously_apply
        base = dict(run_id="x", task="t", workspace=".", can_apply=True, proposed_files={"a.py": "pass"})
        result = RunResult(**base, test_report={"status": "SKIPPED", "summary": "Docker unavailable"})
        self.assertFalse(can_autonomously_apply(result))
        result.test_report = {"status": "NO_TESTS", "summary": "No tests discovered"}
        self.assertFalse(can_autonomously_apply(result))
        result.test_report = {"status": "PASSED", "summary": "Tests passed", "output": "UNITTEST_DISCOVERY: tests found"}
        self.assertFalse(can_autonomously_apply(result), "a PASSED label without structured host evidence must fail closed")
        result.test_report = {"status": "PASSED", "checks": {"python": {"status": "PASSED", "output": "UNITTEST_DISCOVERY: tests found\nUNITTEST_RESULTS: run=2 skipped=0 executed=2 failures=0 errors=0"}}}
        self.assertFalse(can_autonomously_apply(result), "project-controlled output must not authorize unattended writes")

    def test_sha256_shaped_string_cannot_forge_host_attestation_for_auto_apply(self):
        from offline_coder.council import RunResult, can_autonomously_apply
        result = RunResult(
            run_id="x", task="t", workspace=".", can_apply=True,
            proposed_files={"a.py": "pass"},
            test_report={
                "status": "PASSED", "checks": {"python": {"status": "PASSED"}},
                "evidence_source": "host-controlled", "host_evidence_verified": True,
                "host_attestation_sha256": "a" * 64,
            },
        )
        self.assertFalse(can_autonomously_apply(result))

    def test_forged_test_summary_cannot_authorize_unattended_apply(self):
        from offline_coder.council import RunResult, can_autonomously_apply
        forged = "UNITTEST_DISCOVERY: tests found\nUNITTEST_RESULTS: run=1 skipped=0 executed=1 failures=0 errors=0"
        result = RunResult(run_id="x", task="t", workspace=".", can_apply=True,
                           proposed_files={"evil.py": "import os; os._exit(0)"},
                           test_report={"status": "PASSED", "checks": {"python": {"status": "PASSED", "output": forged}}})
        self.assertFalse(can_autonomously_apply(result))

    def test_autonomous_apply_rejects_report_where_all_python_tests_were_skipped(self):
        from offline_coder.council import RunResult, can_autonomously_apply
        result = RunResult(run_id="x", task="t", workspace=".", can_apply=True,
                           proposed_files={"a.py": "pass"},
                           test_report={"status": "PASSED", "checks": {"python": {"status": "PASSED", "output": "UNITTEST_DISCOVERY: tests found\nUNITTEST_RESULTS: run=3 skipped=3 executed=0 failures=0 errors=0"}}})
        self.assertFalse(can_autonomously_apply(result))

    def test_autonomous_apply_rejects_empty_candidate(self):
        from offline_coder.council import RunResult, can_autonomously_apply
        result = RunResult(run_id="x", task="t", workspace=".", can_apply=True, proposed_files={}, test_report={"status": "PASSED", "output": "UNITTEST_DISCOVERY: tests found"})
        self.assertFalse(can_autonomously_apply(result))
    def test_answer_only_task_gets_final_synthesis_not_only_proposer_draft(self):
        class AnswerOnlyModel(StubModel):
            def generate(self, system, user, max_tokens=None, temperature=None):
                if "Write the final answer to the user." in user:
                    return "Final synthesized answer: compare the evidence, state limits, and give the direct conclusion."
                if "Return ONLY a JSON object with this schema" in user:
                    return json.dumps({"summary": "Initial answer draft", "user_facing_answer": "First-draft answer", "notes": [], "files": {}})
                return super().generate(system, user, max_tokens, temperature)

        with tempfile.TemporaryDirectory() as temp:
            result = CouncilRunner(AnswerOnlyModel(), Path(temp), review_rounds=0, web_research_enabled=False, logger=lambda _: None).run_task("Explain why testing matters for complex software systems.")
        self.assertEqual(result.answer, "Final synthesized answer: compare the evidence, state limits, and give the direct conclusion.")
        self.assertEqual(result.final_status, "Advice completed — no file changes proposed.")
        self.assertIn("acceptance_criteria", result.task_plan)

    def test_followup_research_is_never_started_without_manual_query_confirmation(self):
        from unittest.mock import patch
        with tempfile.TemporaryDirectory() as temp, patch("offline_coder.council.search_web") as search:
            result = CouncilRunner(StubModel(), Path(temp), review_rounds=0, logger=lambda _: None, web_research_enabled=True).run_task("Build a website with the latest React APIs and verify version-specific behavior.")
        search.assert_not_called()
        self.assertEqual(result.web_research.get("status"), "skipped")
        self.assertFalse(result.web_research.get("enabled", True))

    def test_research_context_is_not_dropped_when_workspace_context_is_large(self):
        with tempfile.TemporaryDirectory() as temp:
            runner = CouncilRunner(StubModel(), Path(temp), max_context_chars=6000, web_research_enabled=False)
            context = runner._compose_context("WORKSPACE_CONTEXT\n" + ("x" * 20000), "IMPORTANT_WEB_SOURCE https://docs.python.org/3/", "")
        self.assertIn("IMPORTANT_WEB_SOURCE", context)
        self.assertLessEqual(len(context), 6200)

    def test_model_profile_reports_peer_assignments_and_sequential_single_model_mode(self):
        with tempfile.TemporaryDirectory() as temp:
            runner = CouncilRunner(StubModel(), Path(temp), web_research_enabled=False)
            from unittest.mock import patch
            with patch("offline_coder.council.adaptive_worker_limit", return_value=1):
                profile = runner._model_profile()
        self.assertEqual(profile["unique_peer_models"], 1)
        self.assertEqual(profile["peer_model_diversity"], "one shared model instance")
        self.assertFalse(profile["independent_model_families_verified"])
        self.assertIn("share one underlying model", profile["independence_note"])
        self.assertEqual(profile["peer_execution"], "sequential")
        self.assertEqual(len(profile["peer_models"]), 4)
        self.assertEqual(profile["adaptive_peer_workers"], 1)

    def test_completed_run_persists_a_recoverable_checkpoint_and_searchable_experience(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            runner = CouncilRunner(StubModel(), root, review_rounds=0, web_research_enabled=False, logger=lambda _: None, advanced_features_enabled=True)
            result = runner.run_task("Add a hello function.")
            checkpoint = runner.expansion.get_checkpoint(result.checkpoint_id)
            memories = runner.expansion.search("hello function", project=str(root))
        self.assertEqual(checkpoint["status"], "completed")
        self.assertEqual(checkpoint["remaining"], [])
        self.assertTrue(memories)
        self.assertIn("Add a hello function.", memories[0]["content"])

    def test_resume_restores_completed_phases_after_a_model_failure(self):
        from offline_coder.expansion import ExpansionStore
        from unittest.mock import patch

        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            database = root / "state.sqlite3"

            class InterruptedModel(StubModel):
                def __init__(self):
                    self.analysis_calls = 0

                def generate(self, system, user, max_tokens=None, temperature=None):
                    if "Work independently before being shown" in user:
                        self.analysis_calls += 1
                    if "ALL FOUR INDEPENDENT ANALYSES" in user:
                        raise RuntimeError("simulated model interruption")
                    return super().generate(system, user, max_tokens, temperature)

            factory = lambda max_db_bytes=536870912: ExpansionStore(database, max_db_bytes)
            with patch("offline_coder.council.ExpansionStore", side_effect=factory):
                interrupted_model = InterruptedModel()
                interrupted_runner = CouncilRunner(
                    interrupted_model, root, review_rounds=0, web_research_enabled=False,
                    logger=lambda _: None, advanced_features_enabled=True,
                )
                with self.assertRaisesRegex(RuntimeError, "simulated model interruption"):
                    interrupted_runner.run_task("Add a hello function.")
                checkpoint = interrupted_runner.expansion.list_checkpoints(limit=1)[0]
                self.assertEqual(checkpoint["status"], "failed")
                self.assertEqual(checkpoint["stage"], "research_complete")
                self.assertEqual(len(checkpoint["state"]["result"]["analyses"]), 4)

                class CountingModel(StubModel):
                    def __init__(self):
                        self.analysis_calls = 0

                    def generate(self, system, user, max_tokens=None, temperature=None):
                        if "Work independently before being shown" in user:
                            self.analysis_calls += 1
                        return super().generate(system, user, max_tokens, temperature)

                resumed_model = CountingModel()
                resumed_runner = CouncilRunner(
                    resumed_model, root, review_rounds=0, web_research_enabled=False,
                    logger=lambda _: None, advanced_features_enabled=True,
                )
                result = resumed_runner.run_task(
                    "Add a hello function.", resume_checkpoint_id=checkpoint["task_id"]
                )
                self.assertEqual(resumed_model.analysis_calls, 0)
                self.assertEqual(len(result.analyses), 4)
                self.assertEqual(
                    resumed_runner.expansion.get_checkpoint(checkpoint["task_id"])["status"],
                    "completed",
                )

    def test_interrupted_run_restores_completed_analysis_without_repeating_model_calls(self):
        class FailOnceModel(StubModel):
            def __init__(self):
                self.failed_cross_review = False
                self.analysis_calls = 0

            def generate(self, system, user, max_tokens=None, temperature=None):
                if "Work independently before being shown" in user:
                    self.analysis_calls += 1
                if "ALL FOUR INDEPENDENT ANALYSES (including yours)" in user and not self.failed_cross_review:
                    self.failed_cross_review = True
                    raise RuntimeError("simulated interruption after analysis checkpoint")
                return super().generate(system, user, max_tokens, temperature)

        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            model = FailOnceModel()
            runner = CouncilRunner(model, root, review_rounds=0, web_research_enabled=False, logger=lambda _: None, advanced_features_enabled=True)
            task = "Add a hello function."
            with self.assertRaisesRegex(RuntimeError, "simulated interruption"):
                runner.run_task(task)
            checkpoint = runner.expansion.list_checkpoints(include_completed=False)[0]
            self.assertEqual(checkpoint["stage"], "research_complete")
            resumed = runner.run_task(task, resume_checkpoint_id=checkpoint["task_id"])
        self.assertEqual(model.analysis_calls, 4)
        self.assertEqual(resumed.checkpoint_id, checkpoint["task_id"])
        self.assertEqual(runner.expansion.get_checkpoint(checkpoint["task_id"])["status"], "completed")

    def test_resume_restarts_analysis_when_workspace_snapshot_changed(self):
        class FailOnceModel(StubModel):
            def __init__(self):
                self.failed_cross_review = False
                self.analysis_calls = 0

            def generate(self, system, user, max_tokens=None, temperature=None):
                if "Work independently before being shown" in user:
                    self.analysis_calls += 1
                if "ALL FOUR INDEPENDENT ANALYSES (including yours)" in user and not self.failed_cross_review:
                    self.failed_cross_review = True
                    raise RuntimeError("simulated interruption after analysis checkpoint")
                return super().generate(system, user, max_tokens, temperature)

        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            messages = []
            model = FailOnceModel()
            runner = CouncilRunner(model, root, review_rounds=0, web_research_enabled=False, logger=messages.append, advanced_features_enabled=True)
            task = "Add a hello function."
            with self.assertRaisesRegex(RuntimeError, "simulated interruption"):
                runner.run_task(task)
            checkpoint = runner.expansion.list_checkpoints(include_completed=False)[0]
            (root / "README.md").write_text("The workspace changed after analysis.", encoding="utf-8")

            resumed = runner.run_task(task, resume_checkpoint_id=checkpoint["task_id"])

        self.assertEqual(model.analysis_calls, 8)
        self.assertEqual(len(resumed.analyses), 4)
        self.assertTrue(any("Workspace context changed" in message for message in messages))
        self.assertEqual(runner.expansion.get_checkpoint(checkpoint["task_id"])["status"], "completed")

    def test_distinct_role_models_enable_bounded_parallel_peer_work(self):
        import threading
        from offline_coder.model_backend import RoleModelRouter

        rendezvous = threading.Barrier(2)
        class BarrierModel:
            def __init__(self, label):
                self.label = label
                self._first_call = True
                self._guard = threading.Lock()
            def generate(self, system, user, max_tokens=None, temperature=None):
                with self._guard:
                    wait_for_peer = self._first_call
                    self._first_call = False
                if wait_for_peer:
                    rendezvous.wait(timeout=1.0)
                return self.label

        primary, specialist = BarrierModel("primary"), BarrierModel("specialist")
        router = RoleModelRouter(primary, {"correctness": specialist})
        with tempfile.TemporaryDirectory() as temp:
            runner = CouncilRunner(router, Path(temp), web_research_enabled=False, max_peer_workers=2)
            from unittest.mock import patch
            with patch("offline_coder.council.adaptive_worker_limit", return_value=2):
                profile = runner._model_profile()
                results = runner._peer_phase(lambda agent: runner._generate("s", "u", role=agent.name))
        self.assertEqual(profile["peer_execution"], "bounded_parallel")
        self.assertEqual(results[0], "primary")
        self.assertEqual(results[1], "specialist")
        self.assertEqual(len(results), 4)

    def test_single_model_peer_phase_keeps_stable_order_without_parallel_mode(self):
        with tempfile.TemporaryDirectory() as temp:
            runner = CouncilRunner(StubModel(), Path(temp), web_research_enabled=False, max_peer_workers=4)
            results = runner._peer_phase(lambda agent: agent.name)
        self.assertEqual(results, [agent.name for agent in __import__("offline_coder.council", fromlist=["AGENTS"]).AGENTS])

    def test_host_checked_proposal_can_be_manually_applied_with_four_peer_reviews_recorded(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            result = CouncilRunner(StubModel(), root, review_rounds=0, logger=lambda _: None).run_task("Add a hello function.")
            self.assertTrue(result.can_apply, result.final_status)
            self.assertEqual(len(result.votes), 4)
            self.assertTrue(all(v["vote"] == "APPROVE" for v in result.votes))
            self.assertFalse((root / "hello.py").exists(), "council must not write files before explicit apply")
            backup = apply_approved_result(result)
            self.assertTrue((root / "hello.py").exists())
            self.assertIn("hello", (root / "hello.py").read_text(encoding="utf-8"))
            self.assertTrue(Path(backup).exists())

    def test_legacy_autonomous_web_research_flag_never_sends_a_query(self):
        from unittest.mock import patch
        sources = [{"title":"React official docs", "url":"https://react.dev/learn", "host":"react.dev", "snippet":"Official React docs", "credibility_tier":1, "credibility_label":"Primary/official documentation", "credibility_reason":"Official docs"}]
        with tempfile.TemporaryDirectory() as temp, patch("offline_coder.council.search_web", return_value=sources) as search:
            result = CouncilRunner(StubModel(), Path(temp), review_rounds=0, logger=lambda _: None, web_research_enabled=True).run_task("Build a website using the latest React APIs and document setup.")
        search.assert_not_called()
        self.assertEqual(result.web_research.get("status"), "skipped")
        self.assertFalse(result.web_research.get("enabled", True))

    def test_non_unanimous_vote_is_advisory_and_host_gate_controls_apply(self):
        class DissentingStub(StubModel):
            def generate(self, system, user, max_tokens=None, temperature=None):
                if "ALL FOUR REVIEW REPORTS" in user and "Peer D" in user:
                    return json.dumps({"vote": "REJECT", "remaining_blockers": ["test blocker"], "reason": "Need more evidence."})
                return super().generate(system, user, max_tokens, temperature)
        with tempfile.TemporaryDirectory() as temp:
            result = CouncilRunner(DissentingStub(), Path(temp), review_rounds=0, logger=lambda _: None).run_task("Add a hello function.")
            self.assertTrue(result.can_apply)
            self.assertTrue(result.ai_review_warnings)
            self.assertFalse((Path(temp) / "hello.py").exists())

    def test_approve_vote_with_remaining_blocker_is_advisory(self):
        class BlockerStub(StubModel):
            def generate(self, system, user, max_tokens=None, temperature=None):
                if "ALL FOUR REVIEW REPORTS" in user:
                    return json.dumps({"vote": "APPROVE", "remaining_blockers": ["Still needs a test"], "reason": "Concern remains."})
                return super().generate(system, user, max_tokens, temperature)
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            result = CouncilRunner(BlockerStub(), root, review_rounds=0, logger=lambda _: None).run_task("Add a hello function.")
            self.assertTrue(result.can_apply, "peer-reported blockers are advisory and remain visible to the human approver")
            self.assertTrue(result.ai_review_warnings)
            self.assertFalse((root / "hello.py").exists())
            apply_approved_result(result)
            self.assertTrue((root / "hello.py").exists())


    def test_review_request_changes_blocks_even_when_final_votes_approve(self):
        class RequestChangesStub(StubModel):
            def generate(self, system, user, max_tokens=None, temperature=None):
                if '"findings"' in user and "CANDIDATE SUMMARY" in user:
                    return json.dumps({"vote": "REQUEST_CHANGES", "findings": [], "strengths": [], "confidence": 0.9})
                return super().generate(system, user, max_tokens, temperature)
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            result = CouncilRunner(RequestChangesStub(), root, review_rounds=0, logger=lambda _: None).run_task("Add a hello function.")
            self.assertTrue(result.can_apply, "review votes are advisory; host checks control Apply eligibility")
            self.assertTrue(any("code review vote is REQUEST_CHANGES" in e for e in result.ai_review_warnings))
            self.assertFalse((root / "hello.py").exists())

    def test_high_severity_review_finding_blocks_even_if_all_final_votes_approve(self):
        class FindingStub(StubModel):
            def generate(self, system, user, max_tokens=None, temperature=None):
                if '"findings"' in user and "CANDIDATE SUMMARY" in user:
                    return json.dumps({
                        "vote": "APPROVE",
                        "findings": [{"severity": "HIGH", "file": "hello.py", "detail": "The implementation lacks required error handling.", "suggested_fix": "Handle the error case."}],
                        "strengths": [], "confidence": 0.99,
                    })
                return super().generate(system, user, max_tokens, temperature)
        with tempfile.TemporaryDirectory() as temp:
            result = CouncilRunner(FindingStub(), Path(temp), review_rounds=0, logger=lambda _: None).run_task("Add a hello function.")
            self.assertTrue(result.can_apply, "model findings must not replace host-side evidence or manual review")
            self.assertTrue(any("unresolved HIGH finding" in e for e in result.ai_review_warnings))

    def test_approval_requires_specific_review_checks_strengths_and_confidence(self):
        from offline_coder.council import AGENTS, _review_gate_errors
        reviews = [
            {"agent": agent.name, "vote": "APPROVE", "findings": [],
             "checks_performed": ["Traced invalid input and error-handling branches."],
             "strengths": ["The patch is scoped and preserves the public contract."], "confidence": 0.9}
            for agent in AGENTS
        ]
        self.assertEqual(_review_gate_errors(reviews), [])
        reviews[0].pop("checks_performed")
        errors = _review_gate_errors(reviews)
        self.assertTrue(any("lacks a concrete" in error for error in errors))

    def test_approval_rejects_invalid_confidence_and_empty_evidence(self):
        from offline_coder.council import AGENTS, _review_gate_errors
        reviews = [
            {"agent": agent.name, "vote": "APPROVE", "findings": [],
             "checks_performed": ["Inspected the boundary conditions and failure paths."],
             "strengths": ["The patch is narrowly scoped."], "confidence": 0.9}
            for agent in AGENTS
        ]
        reviews[1]["confidence"] = float("nan")
        reviews[2]["strengths"] = []
        errors = _review_gate_errors(reviews)
        self.assertTrue(any("confidence must be a finite" in error for error in errors))
        self.assertTrue(any("lacks a substantive" in error for error in errors))

    def test_final_vote_requires_a_substantive_reason(self):
        from offline_coder.council import AGENTS, _vote_gate_errors
        votes = [
            {"agent": agent.name, "vote": "APPROVE", "remaining_blockers": [],
             "reason": "Reviewed concerns and found no unresolved material blocker."}
            for agent in AGENTS
        ]
        self.assertEqual(_vote_gate_errors(votes), [])
        votes[0]["reason"] = "ok"
        self.assertTrue(any("missing a substantive reason" in error for error in _vote_gate_errors(votes)))

    def test_apply_rejects_candidate_mutated_after_review(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            result = CouncilRunner(StubModel(), root, review_rounds=0, logger=lambda _: None).run_task("Add a hello function.")
            self.assertTrue(result.can_apply)
            self.assertTrue(result.reviewed_candidate_sha256)
            result.proposed_files["hello.py"] = "from pathlib import Path\nPath('/tmp/council-pwned').write_text('changed')\n"
            with self.assertRaisesRegex(ValueError, "changed after review"):
                apply_approved_result(result)
            self.assertFalse((root / "hello.py").exists())

    def test_apply_rejects_legacy_or_missing_review_fingerprint(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            result = CouncilRunner(StubModel(), root, review_rounds=0, logger=lambda _: None).run_task("Add a hello function.")
            self.assertTrue(result.can_apply)
            result.reviewed_candidate_sha256 = ""
            with self.assertRaisesRegex(ValueError, "no recorded review fingerprint"):
                apply_approved_result(result)
            self.assertFalse((root / "hello.py").exists())

    def test_autonomous_apply_cannot_disable_runtime_evidence_requirement(self):
        from offline_coder.council import RunResult, can_autonomously_apply
        result = RunResult(run_id="x", task="t", workspace=".", can_apply=True,
                           proposed_files={"a.py": "pass"}, test_report={"status": "SKIPPED"})
        self.assertFalse(can_autonomously_apply(result, require_runtime_tests=False))

    def test_apply_rechecks_reviews_and_known_peer_identities(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            result = CouncilRunner(StubModel(), root, review_rounds=0, logger=lambda _: None).run_task("Add a hello function.")
            self.assertTrue(result.can_apply)
            result.reviews = []
            apply_approved_result(result)
            self.assertTrue((root / "hello.py").exists())

    def test_failed_isolated_python_checks_block_approval(self):
        from unittest.mock import patch
        with tempfile.TemporaryDirectory() as temp:
            with patch("offline_coder.council.run_project_checks", return_value={"status": "FAILED", "summary": "Unit test failed", "output": "AssertionError"}):
                result = CouncilRunner(StubModel(), Path(temp), review_rounds=0, logger=lambda _: None).run_task("Add a hello function.")
        self.assertFalse(result.can_apply)
        self.assertEqual(result.test_report["status"], "FAILED")
        self.assertTrue(any("Isolated project checks failed" in x for x in result.safety_errors))

    def test_missing_remaining_blockers_field_fails_closed(self):
        class MissingBlockersStub(StubModel):
            def generate(self, system, user, max_tokens=None, temperature=None):
                if "ALL FOUR REVIEW REPORTS" in user:
                    return json.dumps({"vote": "APPROVE", "reason": "I forgot to report blocker status."})
                return super().generate(system, user, max_tokens, temperature)
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            result = CouncilRunner(MissingBlockersStub(), root, review_rounds=0, logger=lambda _: None).run_task("Add a hello function.")
            self.assertTrue(result.can_apply, "malformed AI vote data must remain advisory, not a host authority gate")
            self.assertTrue(result.ai_review_warnings)



    def test_apply_rejects_workspace_changed_after_review(self):
        with tempfile.TemporaryDirectory() as first, tempfile.TemporaryDirectory() as second:
            result = CouncilRunner(StubModel(), Path(first), review_rounds=0, logger=lambda _: None).run_task("Add a hello function.")
            self.assertTrue(result.can_apply)
            result.workspace = second
            with self.assertRaisesRegex(ValueError, "workspace or reviewed file preconditions changed"):
                apply_approved_result(result)
            self.assertFalse((Path(first) / "hello.py").exists())
            self.assertFalse((Path(second) / "hello.py").exists())

    def test_apply_rejects_report_path_redirect_before_writing_code(self):
        with tempfile.TemporaryDirectory() as temp, tempfile.TemporaryDirectory() as outside:
            root = Path(temp)
            result = CouncilRunner(StubModel(), root, review_rounds=0, logger=lambda _: None).run_task("Add a hello function.")
            self.assertTrue(result.can_apply)
            external_report = Path(outside) / "victim.txt"
            result.report_path = str(external_report)
            with self.assertRaisesRegex(ValueError, "Report path is not the expected safe Council run report"):
                apply_approved_result(result)
            self.assertFalse((root / "hello.py").exists())
            self.assertFalse(external_report.exists())

    def test_apply_rejects_symlinked_report_parent_before_writing_code(self):
        with tempfile.TemporaryDirectory() as temp, tempfile.TemporaryDirectory() as outside:
            root = Path(temp)
            result = CouncilRunner(StubModel(), root, review_rounds=0, logger=lambda _: None).run_task("Add a hello function.")
            self.assertTrue(result.can_apply)
            runs_dir = root / ".council" / "runs"
            moved_runs = Path(outside) / "runs-original"
            runs_dir.rename(moved_runs)
            try:
                runs_dir.symlink_to(Path(outside), target_is_directory=True)
            except (OSError, NotImplementedError):
                moved_runs.rename(runs_dir)
                self.skipTest("Directory symlinks are unavailable on this platform")
            with self.assertRaisesRegex(ValueError, "report path contains a symlink"):
                apply_approved_result(result)
            self.assertFalse((root / "hello.py").exists())


    def test_peer_dialogue_runs_direct_question_response_and_keeps_lessons_provisional(self):
        from unittest.mock import patch
        from offline_coder.peer_communication import PeerCommunicationStore, PEER_NAMES
        from offline_coder.council import RunResult

        class DialogueModel(StubModel):
            action_calls = 0
            def generate(self, system, user, max_tokens=None, temperature=None):
                if "Choose at most ONE useful action" in user:
                    self.action_calls += 1
                    if self.action_calls == 1:
                        return json.dumps({"kind":"question", "recipient":"correctness", "subject":"Cache invariant", "body":"Can you show why the version counter cannot skip an invalidation?"})
                    return json.dumps({"kind":"none"})
                if "A colleague has sent you a direct" in user:
                    return json.dumps({"reply":"The write path increments the version while holding the same lock; concurrent readers observe the updated generation.", "status":"resolved", "lesson_candidate":"Mutations and version increments must share an atomic synchronization boundary.", "lesson_evidence":"The inspected write path performs both operations under the same lock; the claim still needs a concurrency test."})
                if "You initiated this peer exchange" in user:
                    return json.dumps({"status":"open", "reply":"Please add a concurrent reader/writer regression test before considering this fully resolved.", "lesson_candidate":"Validate cache invalidation with a concurrent read/write regression test.", "lesson_evidence":"The current reasoning identifies a lock invariant but no executed concurrency test is available."})
                return super().generate(system, user, max_tokens, temperature)

        with tempfile.TemporaryDirectory() as tmp:
            store_path = Path(tmp) / "peer.sqlite3"
            with patch("offline_coder.council.PeerCommunicationStore", side_effect=lambda: PeerCommunicationStore(store_path)):
                runner = CouncilRunner(DialogueModel(), Path(tmp), web_research_enabled=False, logger=lambda _: None)
                result = RunResult(run_id="20261107_000000_000001", task="Improve cache invalidation", workspace=tmp)
                result.discussion_id = runner.communication.begin_discussion(result.run_id, result.task)
                result.analyses = {name: "Analysis" for name in PEER_NAMES}
                result.cross_reviews = {name: "Review" for name in PEER_NAMES}
                runner._run_peer_dialogue(result.task, "current context", result)
                self.assertEqual(len(result.peer_dialogue), 1)
                self.assertEqual(result.peer_dialogue[0]["kind"], "question")
                self.assertEqual(result.peer_dialogue[0]["recipient"], PEER_NAMES[1])
                self.assertEqual(result.peer_dialogue[0]["status"], "open")
                self.assertEqual(len(result.peer_lessons), 1)
                self.assertEqual(result.peer_lessons[0]["status"], "provisional")
                self.assertEqual(store_path.exists(), True)

    def test_component_collaboration_creates_bounded_peer_handoffs_without_applying_files(self):
        from unittest.mock import patch
        from offline_coder.peer_communication import PeerCommunicationStore, PEER_NAMES
        from offline_coder.council import RunResult

        class ComponentModel(StubModel):
            def generate(self, system, user, max_tokens=None, temperature=None):
                if "ASSIGNED COMPONENT / SUBTASK" in user:
                    return json.dumps({"component":"component", "design":"small isolated change", "interfaces":["input/output contract"], "files":{"src/component.py":"def value():\n    return 1\n"}, "tests":["assert value() == 1"], "handoff_notes":"No files are written during peer collaboration."})
                return super().generate(system, user, max_tokens, temperature)

        with tempfile.TemporaryDirectory() as tmp:
            store_path = Path(tmp) / "peer.sqlite3"
            with patch("offline_coder.council.PeerCommunicationStore", side_effect=lambda: PeerCommunicationStore(store_path)):
                runner = CouncilRunner(ComponentModel(), Path(tmp), web_research_enabled=False, logger=lambda _: None)
                result = RunResult(run_id="20261107_000000_000002", task="Build a small component", workspace=tmp)
                result.discussion_id = runner.communication.begin_discussion(result.run_id, result.task)
                result.task_plan = {"task_type":"project_build", "subtasks":["Build the data layer", "Build the API layer"]}
                runner._collaborate_components(result.task, "Read-only project context", result)
                self.assertEqual(len(result.component_contributions), 2)
                self.assertEqual(result.component_contributions[0]["peer"], PEER_NAMES[0])
                self.assertTrue(result.component_contributions[0]["files"])
                self.assertTrue(all(item["status"] == "proposed_not_applied" for item in runner.communication.list_messages(result.discussion_id)))



    def test_prior_open_peer_discussion_continues_in_later_run_and_can_remain_open(self):
        from unittest.mock import patch
        from offline_coder.peer_communication import PeerCommunicationStore, PEER_NAMES
        from offline_coder.council import RunResult

        class ContinuationModel(StubModel):
            def generate(self, system, user, max_tokens=None, temperature=None):
                if "You are continuing an OPEN discussion" in user:
                    return json.dumps({"reply":"The current project snapshot still does not show a concurrent stress test; please add one.", "status":"open"})
                if "A colleague has continued an unresolved discussion" in user:
                    return json.dumps({"reply":"Agreed. The race remains unverified until a concurrent test is run.", "status":"open"})
                return super().generate(system, user, max_tokens, temperature)

        with tempfile.TemporaryDirectory() as tmp:
            store_path = Path(tmp) / "peer.sqlite3"
            with patch("offline_coder.council.PeerCommunicationStore", side_effect=lambda: PeerCommunicationStore(store_path)):
                store = PeerCommunicationStore(store_path)
                old_id = store.begin_discussion("old-run", "Investigate cache invalidation concurrency")
                request_id = store.add_message(old_id, PEER_NAMES[0], PEER_NAMES[1], "investigation",
                                               "Concurrent invalidation", "Investigate writer-reader races.")
                store.add_message(old_id, PEER_NAMES[1], PEER_NAMES[0], "response", "Initial response",
                                  "The lock appears correct, but no race test was run.", related_message_id=request_id)
                store.set_discussion_status(old_id, "open")

                runner = CouncilRunner(ContinuationModel(), Path(tmp), web_research_enabled=False, logger=lambda _: None)
                result = RunResult(run_id="new-run", task="Investigate cache invalidation concurrency", workspace=tmp)
                result.discussion_id = runner.communication.begin_discussion(result.run_id, result.task)
                result.discussion_context = "Current snapshot still lacks a concurrency test."
                runner._continue_prior_discussions(result.task, result.discussion_context, result)
                self.assertEqual(len(result.peer_dialogue), 1)
                self.assertEqual(result.peer_dialogue[0]["kind"], "continued_thread")
                self.assertEqual(result.peer_dialogue[0]["status"], "open")
                self.assertEqual(len(runner.communication.list_messages(old_id)), 4)
                self.assertEqual(runner.communication.list_open_discussions("cache invalidation concurrency")[0]["id"], old_id)



if __name__ == "__main__":
    unittest.main()
