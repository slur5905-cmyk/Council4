import hashlib
import json
import tempfile
import unittest
from pathlib import Path

from offline_coder.base_knowledge import BaseKnowledgeLibrary, format_base_knowledge
from offline_coder.extensions import ExtensionRegistry
from offline_coder.repository_intelligence import analyze_repository, format_repository_digest
from offline_coder.self_improvement import ImprovementLab
from offline_coder.solution_lab import CandidateEvidence, compare_candidate_evidence
from offline_coder.supply_chain import analyze_supply_chain, make_cyclonedx_sbom
from offline_coder.test_matrix import build_test_matrix, normalize_test_evidence


class BaseKnowledgeTests(unittest.TestCase):
    def test_retrieval_finds_computing_domains_and_reports_limitations(self):
        library = BaseKnowledgeLibrary()
        results = library.search("CPU memory cache GPU architecture", limit=4)
        self.assertTrue(results)
        formatted = format_base_knowledge(results)
        self.assertIn("not exhaustive", formatted)
        self.assertTrue(any("computer_architecture" in item["file"] or "computer_fundamentals" in item["file"] for item in results))

    def test_inventory_has_multiple_domains(self):
        inventory = BaseKnowledgeLibrary().inventory()
        self.assertEqual(inventory["status"], "available")
        self.assertGreaterEqual(inventory["file_count"], 80)
        self.assertGreaterEqual(inventory["word_count"], 27000)
        self.assertGreater(inventory["bytes"], 100000)
        self.assertNotIn("README.md", {item["name"] for item in inventory["files"]})

    def test_deep_domain_queries_retrieve_specialized_offline_material(self):
        library = BaseKnowledgeLibrary()
        cases = {
            "Rust ownership lifetime borrow checker": "c_cpp_rust_systems_programming.md",
            "SQL isolation transaction query plan index": "sql_relational_model_transactions.md",
            "assembly ABI linker symbol relocation": "assembly_abi_linking.md",
            "responsive browser accessibility focus": "frontend_accessibility_user_experience.md",
            "robotics sensor actuator control loop": "robotics_control_systems.md",
            "theory computation automata decidability halting problem": "computation_theory_automata_decidability.md",
            "Linux Unix file descriptor process signal": "linux_unix_internals.md",
            "TLS certificate PKI key rotation nonce": "cryptographic_protocols_pki_key_management.md",
            "real time scheduling deadline watchdog safety case": "realtime_safety_critical_software.md",
            "audio DSP sampling Nyquist filtering convolution": "digital_signal_processing_audio.md",
            "local model inference KV cache quantization throughput": "local_model_inference_serving_optimization.md",
        }
        for query, filename in cases.items():
            with self.subTest(query=query):
                self.assertIn(filename, {item["file"] for item in library.search(query, limit=8)})

    def test_deep_runtime_systems_api_and_gpu_topics_are_retrievable(self):
        library = BaseKnowledgeLibrary()
        cases = {
            "GC pause and JIT deoptimization": "memory_management_gc_lifetimes.md",
            "IPC process scheduling and shared memory": "os_kernel_scheduling_ipc.md",
            "GPU warp occupancy and host device transfer": "gpu_parallel_computing_hpc.md",
            "API compatibility idempotency and schema versioning": "api_design_contracts_compatibility.md",
            "database transaction MVCC WAL": "database_transactions_storage_engines.md",
            "CPU cache false sharing memory ordering": "computer_architecture_cpu_cache_memory.md",
        }
        for query, filename in cases.items():
            with self.subTest(query=query):
                self.assertIn(filename, {item["file"] for item in library.search(query, limit=10)})


class RepositoryIntelligenceTests(unittest.TestCase):
    def test_python_ast_and_local_import_edges_are_indexed(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            (root / "main.py").write_text("import helper\nclass Base:\n    pass\nclass App(Base):\n    def start(self):\n        return helper.run()\n", encoding="utf-8")
            (root / "helper.py").write_text("def run():\n    return 3\n", encoding="utf-8")
            report = analyze_repository(root, query="app startup")
        self.assertEqual(report["status"], "completed")
        self.assertIn("python", report["languages"])
        self.assertTrue(any(item["name"] == "App" for item in report["symbols"]))
        self.assertTrue(any(item["from"] == "main.py" and item["to"] == "helper.py" for item in report["dependency_edges"]))
        self.assertIn("not a complete semantic compiler", format_repository_digest(report))
        self.assertTrue(any(edge["callee"] == "helper.run" and edge["resolution"] == "unique-local-name-match" for edge in report["call_edges"]))
        self.assertTrue(any(edge["base"] == "Base" and edge["resolution"] == "unique-local-name-match" for edge in report["inheritance_edges"]))
        self.assertIn("call", format_repository_digest(report).lower())


    def test_repository_index_skips_case_variant_private_directories(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            (root / "main.py").write_text("def visible(): return True\n", encoding="utf-8")
            private = root / ".GIT"
            private.mkdir()
            (private / "history.py").write_text("def secret_from_history(): pass\n", encoding="utf-8")
            report = analyze_repository(root)
        paths = {item["path"] for item in report["files"]}
        self.assertIn("main.py", paths)
        self.assertNotIn(".GIT/history.py", paths)

    def test_secret_paths_and_symlink_targets_are_not_indexed(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            (root / "app.py").write_text("def ok(): return True\n", encoding="utf-8")
            secret = root / ".env"
            secret.write_text("TOKEN=supersecretvalue\n", encoding="utf-8")
            target = root / "outside.py"
            target.write_text("def hidden(): pass\n", encoding="utf-8")
            link = root / "linked.py"
            try:
                link.symlink_to(target)
            except OSError:
                pass
            report = analyze_repository(root)
        paths = {item["path"] for item in report["files"]}
        self.assertIn("app.py", paths)
        self.assertNotIn(".env", paths)
        self.assertNotIn("linked.py", paths)


class SelfImprovementTests(unittest.TestCase):
    def test_only_improved_benchmarked_candidate_with_passed_tests_is_eligible(self):
        with tempfile.TemporaryDirectory() as temp:
            lab = ImprovementLab(Path(temp) / "lab.sqlite3")
            baseline = hashlib.sha256(b"baseline").hexdigest()
            candidate = hashlib.sha256(b"candidate").hexdigest()
            not_qualified = lab.record_experiment(
                title="bad experiment", hypothesis="A faster planner", baseline_score=0.7,
                candidate_score=0.9, benchmark_suite="planner-v1", baseline_hash=baseline,
                candidate_hash=candidate, test_status="SKIPPED", evidence={"runs": 10},
            )
            qualified = lab.record_experiment(
                title="good experiment", hypothesis="A more accurate planner", baseline_score=0.7,
                candidate_score=0.8, benchmark_suite="planner-v1", baseline_hash=baseline,
                candidate_hash=candidate, test_status="PASSED", evidence={"runs": 10, "seed": 1},
            )
            with self.assertRaises(ValueError):
                lab.approve_for_future_evaluation(not_qualified, user_confirmed=True)
            with self.assertRaises(PermissionError):
                lab.approve_for_future_evaluation(qualified, user_confirmed=False)
            approved = lab.approve_for_future_evaluation(qualified, user_confirmed=True)
            records = lab.list_experiments()
        self.assertEqual(approved["status"], "approved_for_future_evaluation")
        self.assertEqual(len(records), 2)


class ExtensionRegistryTests(unittest.TestCase):
    def test_builtin_capability_templates_and_manifest_validation(self):
        with tempfile.TemporaryDirectory() as temp:
            registry = ExtensionRegistry(Path(temp) / "extensions")
            builtins = registry.list_extensions()
            self.assertGreaterEqual(len(builtins), 24)
            self.assertIn("compiler-toolchains", {item.get("extension_id", item.get("id")) for item in builtins})
            self.assertIn("distributed-systems", {item.get("extension_id", item.get("id")) for item in builtins})
            saved = registry.add_manifest({
                "id": "custom-renderer", "name": "Custom renderer", "category": "graphics",
                "description": "Builds render pipeline candidates.",
                "permissions": ["read_project", "write_candidate", "run_isolated_tests"],
            })
            self.assertTrue(saved.is_file())
            with self.assertRaises(PermissionError):
                registry.validate_manifest({
                    "id": "bad-extension", "name": "Bad", "category": "system",
                    "description": "Not allowed", "permissions": ["host_shell"],
                })


class CandidateCompetitionTests(unittest.TestCase):
    def test_fake_sha256_host_attestation_cannot_select_candidate(self):
        items = [
            CandidateEvidence("a", {"a.py": "x"}, True, [], {"status": "SKIPPED", "summary": "not run"}),
            CandidateEvidence("spoofed-host", {"b.py": "x"}, True, [], {
                "status": "PASSED", "summary": "claims host tests passed",
                "checks": {"python": {"status": "PASSED"}},
                "evidence_source": "host-controlled", "host_evidence_verified": True,
                "host_attestation_sha256": "a" * 64,
            }),
        ]
        result = compare_candidate_evidence(items)
        self.assertEqual(result["status"], "abstained_no_verified_winner")
        self.assertEqual(result["selected_candidate_id"], "")
        self.assertFalse(result["candidates"][1]["eligible_by_host_evidence"])

    def test_project_controlled_pass_cannot_win_even_with_all_nested_checks_passed(self):
        items = [CandidateEvidence("project-claimed", {"a.py": "x"}, True, [], {
            "status": "PASSED", "summary": "project tests claim success",
            "checks": {"python": {"status": "PASSED"}},
            "evidence_source": "project-controlled-sandbox", "host_evidence_verified": False,
        })]
        result = compare_candidate_evidence(items)
        self.assertEqual(result["status"], "abstained_no_verified_winner")
        self.assertFalse(result["candidates"][0]["checks_consistent"])

    def test_nested_failed_check_overrides_forged_top_level_pass(self):
        items = [CandidateEvidence("forged", {"a.py": "x"}, True, [], {
            "status": "PASSED", "summary": "claim", "checks": {"browser": {"status": "SKIPPED"}}
        })]
        result = compare_candidate_evidence(items)
        self.assertEqual(result["status"], "abstained_no_verified_winner")
        self.assertFalse(result["candidates"][0]["checks_consistent"])

    def test_no_verified_candidate_causes_abstention(self):
        items = [CandidateEvidence("a", {"a.py": "x"}, True, [], {"status": "NO_TESTS"})]
        result = compare_candidate_evidence(items)
        self.assertEqual(result["status"], "abstained_no_verified_winner")
        self.assertEqual(result["selected_candidate_id"], "")

    def test_top_level_pass_without_nested_evidence_cannot_win(self):
        items = [CandidateEvidence("forged-empty", {"a.py": "x"}, True, [], {"status": "PASSED"})]
        result = compare_candidate_evidence(items)
        self.assertEqual(result["status"], "abstained_no_verified_winner")

    def test_malformed_nested_evidence_is_rejected_without_crashing(self):
        digest = hashlib.sha256(b"candidate").hexdigest()
        envelope = normalize_test_evidence(
            {"status": "PASSED", "checks": {"browser": "PASSED", "unit": {"status": "PASSED"}}},
            digest,
        )
        self.assertEqual(envelope["status"], "INVALID_EVIDENCE")
        self.assertIn("INVALID", envelope["nested_check_statuses"])


class SupplyChainAndTestMatrixTests(unittest.TestCase):
    def test_supply_chain_inventory_tracks_exact_purls_and_unresolved_specs(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            (root / "package.json").write_text(json.dumps({"dependencies": {"react": "^18.0.0", "demo": "*", "pinned": "1.2.3"}, "scripts": {"postinstall": "node setup.js"}}), encoding="utf-8")
            (root / "package-lock.json").write_text("{}", encoding="utf-8")
            report = analyze_supply_chain(root)
            sbom = make_cyclonedx_sbom(report)
        self.assertIn("package-lock.json", report["lockfiles"])
        self.assertTrue(report["declared_install_scripts"])
        self.assertTrue(report["broad_or_unusual_specs"])
        self.assertFalse(any(x.get("purl") for x in report["components"] if x["name"] in {"react", "demo"}))
        pinned = next(x for x in report["components"] if x["name"] == "pinned")
        self.assertEqual(pinned["purl"], "pkg:npm/pinned@1.2.3")
        self.assertEqual(sbom["specVersion"], "1.5")
        self.assertEqual(sbom["metadata"]["properties"][1]["value"], "false")

    def test_workflow_security_review_flags_mutable_actions_and_privileged_pr_flows(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            workflow = root / ".github" / "workflows" / "build.yml"
            workflow.parent.mkdir(parents=True)
            workflow.write_text("on: [pull_request_target]\npermissions: write-all\njobs:\n  build:\n    steps:\n      - uses: actions/checkout@main\n      - run: echo ${{ secrets.DEPLOY_TOKEN }}\n", encoding="utf-8")
            report = analyze_supply_chain(root)
        rules = {item["rule"] for item in report["workflow_security_findings"]}
        self.assertIn("untrusted-pull-request-trigger", rules)
        self.assertIn("broad-workflow-permissions", rules)
        self.assertIn("mutable-action-reference", rules)
        self.assertIn("secrets-in-privileged-pr-workflow", rules)

    def test_matrix_and_evidence_envelope_separate_plan_from_results(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            (root / "package.json").write_text("{}", encoding="utf-8")
            matrix = build_test_matrix(root, {"src/app.js": "console.log('hi')"})
        self.assertTrue(any(item["id"] == "javascript-syntax" for item in matrix["checks"]))
        self.assertIn("not test evidence", matrix["warning"])
        digest = hashlib.sha256(b"candidate").hexdigest()
        envelope = normalize_test_evidence({"status": "SKIPPED", "summary": "not installed"}, digest)
        self.assertEqual(envelope["status"], "SKIPPED")
        self.assertIn("not a cryptographic attestation", envelope["scope"])
        invalid = normalize_test_evidence({"status": "PASSED", "checks": {"browser": {"status": "SKIPPED"}}}, digest,
                                          changed_files={"app.js": "console.log(1)"})
        self.assertEqual(invalid["status"], "INVALID_EVIDENCE")
        self.assertTrue(invalid["inconsistent_top_level_pass"])
        self.assertIn("app.js", invalid["changed_file_sha256"])


if __name__ == "__main__":
    unittest.main()
