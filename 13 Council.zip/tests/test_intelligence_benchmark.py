import json
import tempfile
import unittest
from pathlib import Path
from argparse import Namespace

from tools.run_intelligence_benchmark import PROJECT_ROOT, _run_host_checks, _run_model_cases, _tree_digest
from tools.compare_benchmark_reports import compare


class IntelligenceBenchmarkTests(unittest.TestCase):
    def test_cases_are_unique_and_do_not_score_confidence_or_verbosity_as_correctness(self):
        cases = json.loads((PROJECT_ROOT / "benchmarks" / "cases.json").read_text(encoding="utf-8"))
        model_cases = cases["model_cases"]
        identifiers = [case["id"] for case in model_cases]
        self.assertEqual(len(identifiers), len(set(identifiers)))
        self.assertGreaterEqual(len(identifiers), 12)
        self.assertTrue({"ENG-001", "ARCH-001", "FACT-001", "CORR-001", "MEM-001", "SEC-001",
                         "ALGO-001", "API-001", "PERF-001", "FORMAL-001", "SUPPLY-001", "ARCH-002"}.issubset(identifiers))
        self.assertIn("confidence", cases["scoring"]["confidence"].lower())
        self.assertIn("diagnostic only", cases["scoring"]["verbosity"].lower())

    def test_host_suite_passes_current_deterministic_contracts(self):
        results = _run_host_checks(PROJECT_ROOT)
        self.assertEqual(len(results), 10)
        self.assertTrue(all(result["status"] == "PASS" for result in results), results)

    def test_benchmark_comparison_pairs_independently_scored_repeated_trials(self):
        common = {
            "benchmark_version": "1.5", "cases_sha256": "a" * 64,
            "benchmark_runner_sha256": "b" * 64, "repeat_count": 2,
            "model_config": {"backend": "gguf", "model_filename": "same.gguf"},
            "host_checks": [{"status": "PASS"}],
        }
        baseline = dict(common, source_tree_sha256="c" * 64, source_revision="base", model_cases=[
            {"id": "ENG-001", "repeat_index": 1, "correct": False},
            {"id": "ENG-001", "repeat_index": 2, "correct": True},
        ])
        candidate = dict(common, source_tree_sha256="d" * 64, source_revision="candidate", model_cases=[
            {"id": "ENG-001", "repeat_index": 1, "correct": True},
            {"id": "ENG-001", "repeat_index": 2, "correct": True},
        ])
        result = compare(baseline, candidate)
        self.assertEqual(result["baseline_trials"], 2)
        self.assertEqual(result["candidate_trials"], 2)
        self.assertAlmostEqual(result["delta"], 0.5)
        candidate["model_cases"].pop()
        with self.assertRaises(ValueError):
            compare(baseline, candidate)

    def test_source_fingerprint_includes_nested_markdown_knowledge(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            package = root / "offline_coder"
            knowledge = package / "base_knowledge"
            knowledge.mkdir(parents=True)
            (package / "example.py").write_text("VALUE = 1\n", encoding="utf-8")
            source_before = _tree_digest(root)
            (knowledge / "topic.md").write_text("Original knowledge.\n", encoding="utf-8")
            source_after = _tree_digest(root)
            self.assertNotEqual(source_before, source_after)
            (knowledge / "topic.md").write_text("Updated knowledge.\n", encoding="utf-8")
            self.assertNotEqual(source_after, _tree_digest(root))

    def test_model_cases_are_not_scored_without_a_model(self):
        cases = json.loads((PROJECT_ROOT / "benchmarks" / "cases.json").read_text(encoding="utf-8"))
        results = _run_model_cases(Namespace(model="", backend="gguf"), PROJECT_ROOT, cases)
        self.assertEqual(len(results), len(cases["model_cases"]))
        self.assertTrue(all(result["status"] == "NOT_RUN" and result["correct"] is None for result in results))


if __name__ == "__main__":
    unittest.main()