import tempfile
import unittest
import sqlite3
from pathlib import Path
from offline_coder.knowledge import KnowledgeStore


class KnowledgeTests(unittest.TestCase):
    def test_credentials_are_redacted_before_imported_knowledge_is_retrieved(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            doc = root / "notes.md"
            doc.write_text('api_key = "sk-live-EXAMPLE-DO-NOT-USE-123456789"\nUseful notes about Python APIs.', encoding="utf-8")
            store = KnowledgeStore(root / "knowledge.sqlite3")
            source_id = store.add_file(doc, "Notes", verified=True)
            results = store.relevant_sources("Python APIs")
            self.assertTrue(results)
            self.assertNotIn("sk-live-EXAMPLE-DO-NOT-USE-123456789", results[0]["snippet"])
            self.assertIn("[REDACTED]", results[0]["snippet"])

    def test_only_user_verified_sources_are_retrieved(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            db = root / "knowledge.sqlite3"
            doc = root / "python_notes.md"
            doc.write_text("Python dictionaries preserve insertion order in supported versions. Use dict.get for optional keys.", encoding="utf-8")
            store = KnowledgeStore(db)
            source_id = store.add_file(doc, "Python dictionary notes", "Hand-checked local documentation", verified=False)
            self.assertEqual(store.relevant_sources("Python dictionary insertion order"), [])
            store.verify_source(source_id)
            results = store.relevant_sources("Python dictionary insertion order")
            self.assertEqual(len(results), 1)
            self.assertEqual(results[0]["title"], "Python dictionary notes")
            self.assertTrue(results[0]["sha256"])

    def test_tampered_verified_source_is_not_retrieved(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            db = root / "knowledge.sqlite3"
            doc = root / "notes.md"
            doc.write_text("Verified notes about Python dictionaries.", encoding="utf-8")
            store = KnowledgeStore(db)
            source_id = store.add_file(doc, "Python notes", verified=True)
            with sqlite3.connect(db) as connection:
                connection.execute("UPDATE sources SET body=? WHERE id=?", ("Tampered instructions about Python dictionaries.", source_id))
            self.assertEqual(store.relevant_sources("Python dictionaries"), [])

    def test_tampered_source_cannot_be_marked_verified(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            db = root / "knowledge.sqlite3"
            doc = root / "notes.md"
            doc.write_text("Original Python notes.", encoding="utf-8")
            store = KnowledgeStore(db)
            source_id = store.add_file(doc, "Python notes")
            with sqlite3.connect(db) as connection:
                connection.execute("UPDATE sources SET body=? WHERE id=?", ("Altered Python notes.", source_id))
            with self.assertRaisesRegex(ValueError, "integrity check failed"):
                store.verify_source(source_id)

    def test_project_scoped_sources_are_not_retrieved_by_other_workspaces(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            doc = root / "project_a.md"
            doc.write_text("Project A uses the custom red delivery protocol.", encoding="utf-8")
            store = KnowledgeStore(root / "knowledge.sqlite3")
            store.add_file(doc, "Project A protocol", verified=True, project_scope=root / "project-a")
            self.assertTrue(store.relevant_sources("red delivery protocol", project_scope=root / "project-a"))
            self.assertEqual(store.relevant_sources("red delivery protocol", project_scope=root / "project-b"), [])
            self.assertEqual(store.relevant_sources("red delivery protocol"), [])

    def test_legacy_and_explicitly_shared_sources_remain_available(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            doc = root / "shared.md"
            doc.write_text("Shared retry guidance uses bounded exponential backoff.", encoding="utf-8")
            store = KnowledgeStore(root / "knowledge.sqlite3")
            store.add_file(doc, "Shared retry guidance", verified=True)
            self.assertTrue(store.relevant_sources("retry guidance", project_scope=root / "project-a"))
            self.assertTrue(store.relevant_sources("retry guidance", project_scope=root / "project-b"))

    def test_existing_database_is_migrated_without_dropping_records(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            db = root / "knowledge.sqlite3"
            with sqlite3.connect(db) as connection:
                connection.execute("""CREATE TABLE sources (
                    id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT NOT NULL, origin TEXT NOT NULL,
                    file_path TEXT NOT NULL, sha256 TEXT NOT NULL, verified INTEGER NOT NULL DEFAULT 0,
                    body TEXT NOT NULL, added_at TEXT NOT NULL)""")
                body = "Legacy shared retry guidance."
                import hashlib
                connection.execute(
                    "INSERT INTO sources(title,origin,file_path,sha256,verified,body,added_at) VALUES (?,?,?,?,?,?,?)",
                    ("Legacy", "Old notebook", "legacy.md", hashlib.sha256(body.encode()).hexdigest(), 1, body, "2026-01-01T00:00:00+00:00"),
                )
            store = KnowledgeStore(db)
            results = store.relevant_sources("legacy retry guidance", project_scope=root / "new-project")
            self.assertEqual(len(results), 1)
            self.assertEqual(store.list_sources()[0]["project_scope"], "")


if __name__ == "__main__":
    unittest.main()
