from pathlib import Path
import re
import unittest

ROOT = Path(__file__).resolve().parents[1]


class CIWorkflowTests(unittest.TestCase):
    def test_every_github_action_is_pinned_to_a_full_commit_sha(self):
        workflow = (ROOT / ".github/workflows/ci.yml").read_text(encoding="utf-8")
        uses = re.findall(r"^\s*-?\s*uses:\s*([^\s]+)", workflow, re.M)
        self.assertGreaterEqual(len(uses), 6)
        for reference in uses:
            with self.subTest(reference=reference):
                self.assertRegex(reference, r"^[^@]+@[0-9a-f]{40}$")

    def test_pages_waits_for_test_model_runtime_and_docker_jobs(self):
        workflow = (ROOT / ".github/workflows/ci.yml").read_text(encoding="utf-8")
        self.assertIn("needs: [test, model-runtime, docker-fixture]", workflow)
        self.assertIn("run: docker info", workflow)
        self.assertIn("python tools/docker_fixture_smoke.py", workflow)
        self.assertIn("python -m pip install -e '.[test,model]'", workflow)
        self.assertIn("'3.10', '3.11', '3.12', '3.13'", workflow)

    def test_static_publish_guard_is_part_of_pages_job(self):
        workflow = (ROOT / ".github/workflows/ci.yml").read_text(encoding="utf-8")
        self.assertIn("python tools/check_publish.py _site", workflow)


    def test_weekly_self_check_is_scheduled_without_enabling_scheduled_deployment(self):
        workflow = (ROOT / ".github/workflows/ci.yml").read_text(encoding="utf-8")
        self.assertIn('cron: "0 18 * * 0"', workflow)
        deploy_condition = next(line for line in workflow.splitlines() if line.strip().startswith("if: github.event_name"))
        self.assertIn("github.event_name == 'push'", deploy_condition)
        self.assertIn("github.ref == 'refs/heads/main'", deploy_condition)


if __name__ == "__main__":
    unittest.main()

