import io
import unittest
from unittest.mock import patch
from email.message import Message

from offline_coder.web_search import search_web, format_search_context, _clean_result_url, classify_source, should_auto_research, make_safe_search_query


class FakeResponse(io.BytesIO):
    def __init__(self, body, content_type="text/html; charset=utf-8"):
        super().__init__(body)
        self.headers = Message()
        self.headers["Content-Type"] = content_type
    def __enter__(self): return self
    def __exit__(self, *args): self.close()


class WebSearchTests(unittest.TestCase):
    def test_parses_titles_urls_and_snippets(self):
        html = b'''<div class="result"><a class="result__a" href="https://example.org/docs">Example Docs</a><a class="result__snippet">Official docs and examples.</a></div><div class="result"><a class="result__a" href="https://example.net/guide">Guide</a><a class="result__snippet">Helpful guide.</a></div>'''
        with patch("offline_coder.web_search.urlopen", return_value=FakeResponse(html)):
            results = search_web("example docs")
        self.assertEqual(len(results), 2)
        self.assertEqual(results[0]["title"], "Example Docs")
        self.assertEqual(results[0]["url"], "https://example.org/docs")
        self.assertIn("Official docs", results[0]["snippet"])

    def test_rejects_empty_or_oversized_queries(self):
        with self.assertRaises(ValueError): search_web(" ")
        with self.assertRaises(ValueError): search_web("x" * 301)

    def test_rejects_unexpected_content_type(self):
        with patch("offline_coder.web_search.urlopen", return_value=FakeResponse(b"ok", "application/json")):
            with self.assertRaises(RuntimeError): search_web("test")

    def test_rejects_oversized_response(self):
        with patch("offline_coder.web_search.urlopen", return_value=FakeResponse(b"x" * 1_500_001)):
            with self.assertRaises(RuntimeError): search_web("test")

    def test_only_http_links_and_no_credentials(self):
        self.assertIsNone(_clean_result_url("javascript:alert(1)"))
        self.assertIsNone(_clean_result_url("https://user:pass@example.com"))
        self.assertEqual(_clean_result_url("https://example.com/path"), "https://example.com/path")
        # Absolute and relative search-engine redirect wrappers must resolve to the actual source.
        self.assertEqual(_clean_result_url("https://duckduckgo.com/l/?uddg=https%3A%2F%2Fdocs.python.org%2F3%2F&rut=abc"), "https://docs.python.org/3/")
        self.assertEqual(_clean_result_url("/l/?uddg=https%3A%2F%2Fen.wikipedia.org%2Fwiki%2FPython"), "https://en.wikipedia.org/wiki/Python")
        self.assertEqual(_clean_result_url("https://duckduckgo.com/l/?uddg=https%3A%2F%2Fexample.org%2Fpath%2Fa%2520b"), "https://example.org/path/a%20b")

    def test_source_ranking_prefers_primary_docs_then_wikipedia_then_unclassified(self):
        self.assertEqual(classify_source("https://docs.python.org/3/library/json.html")["credibility_tier"], 1)
        self.assertEqual(classify_source("https://en.wikipedia.org/wiki/Python_(programming_language)")["credibility_tier"], 2)
        self.assertEqual(classify_source("https://random-blog.example/post")["credibility_tier"], 4)
        self.assertIn("Established encyclopedia", classify_source("https://en.wikipedia.org/wiki/Example")["credibility_label"])

    def test_autonomous_research_heuristic_respects_explicit_no_web(self):
        self.assertTrue(should_auto_research("Please build a website using the latest React APIs and document the setup."))
        self.assertFalse(should_auto_research("Just say hello"))
        self.assertFalse(should_auto_research("Build a website using React, offline only; do not search the internet."))
        self.assertTrue(should_auto_research("Explain the scientific evidence and history of dark matter in detail."))
        self.assertTrue(should_auto_research("What is the difference between two major cryptographic approaches?"))
        self.assertFalse(should_auto_research("Please explain this concept offline only and never use the web for this answer."))

    def test_safe_query_strips_code_urls_and_secrets(self):
        query = make_safe_search_query("Find docs for this API key=abc123 https://example.com ```password=foo``` latest Python API")
        self.assertNotIn("abc123", query)
        self.assertNotIn("https://example.com", query)
        self.assertNotIn("password=foo", query)
        self.assertLessEqual(len(query), 180)
        windows = make_safe_search_query(r"Debug C:\Users\alice\work\app.py with Bearer abcdefghijklmnop and ghp_ABCDEFGHIJKLMNOPQRSTUVWXYZ012345")
        self.assertNotIn(r"C:\Users\alice", windows)
        self.assertNotIn("abcdefghijklmnop", windows)
        self.assertNotIn("ghp_ABCDEFGHIJKLMNOPQRSTUVWXYZ012345", windows)

    def test_safe_query_redacts_common_personal_data_paths_and_phone_numbers(self):
        query = make_safe_search_query("Research this error for me john.doe@example.com call 415-555-0199 path /Users/alex/private/project and key=secretvalue")
        for sensitive in ("john.doe@example.com", "415-555-0199", "/Users/alex/private/project", "secretvalue"):
            self.assertNotIn(sensitive, query)

    def test_search_results_include_source_classification(self):
        html = b"<div class='result'><a class='result__a' href='https://docs.python.org/3/'>Python docs</a><a class='result__snippet'>Official docs.</a></div><div class='result'><a class='result__a' href='https://random-blog.example/post'>Random blog</a><a class='result__snippet'>Blog post.</a></div>"
        with patch("offline_coder.web_search.urlopen", return_value=FakeResponse(html)):
            results = search_web("python docs")
        self.assertEqual(results[0]["credibility_tier"], 1)
        self.assertEqual(results[1]["credibility_tier"], 4)

    def test_context_warns_results_are_untrusted_and_keeps_urls(self):
        text = format_search_context("topic", [{"title":"Docs", "url":"https://example.com", "host":"example.com", "snippet":"snippet"}])
        self.assertIn("untrusted data", text)
        self.assertIn("Wikipedia", text)
        self.assertIn("Source category", text)
        self.assertIn("https://example.com", text)


    def test_source_ranking_happens_before_requested_result_limit(self):
        html = b"""<div class='result'><a class='result__a' href='https://random-blog.example/post'>Blog first</a><a class='result__snippet'>A confident but unverified claim.</a></div><div class='result'><a class='result__a' href='https://en.wikipedia.org/wiki/Python'>Wikipedia second</a><a class='result__snippet'>Secondary overview.</a></div><div class='result'><a class='result__a' href='https://docs.python.org/3/'>Official docs third</a><a class='result__snippet'>Versioned official documentation.</a></div>"""
        with patch("offline_coder.web_search.urlopen", return_value=FakeResponse(html)):
            results = search_web("python details", limit=2)
        self.assertEqual([item["title"] for item in results], ["Official docs third", "Wikipedia second"])

    def test_lookalike_subdomain_is_not_automatically_official(self):
        result = classify_source("https://attacker.docs.python.org/phishing")
        self.assertEqual(result["credibility_tier"], 4)
        self.assertEqual(result["credibility_label"], "Unclassified source")


if __name__ == "__main__": unittest.main()
