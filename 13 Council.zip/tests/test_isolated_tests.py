import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

from offline_coder.isolated_tests import run_isolated_python_checks, run_isolated_node_checks, run_project_checks, run_project_simulations, _copy_workspace, _overlay_proposed_files, _node_tap_has_real_test_records, _last_node_tap_summary_value, _validated_node_script_args


class IsolatedTestRunnerTests(unittest.TestCase):
    def test_non_python_proposal_is_not_applicable(self):
        with tempfile.TemporaryDirectory() as temp:
            result = run_isolated_python_checks(Path(temp), {"index.html": "<h1>Hello</h1>"})
        self.assertEqual(result["status"], "NOT_APPLICABLE")

    def test_node_empty_test_file_is_not_counted_as_a_real_test(self):
        empty_output = """TAP version 13
# Subtest: src/empty.test.js
ok 1 - src/empty.test.js
1..1
# tests 1
# pass 1
# fail 0
# skipped 0
"""
        self.assertFalse(_node_tap_has_real_test_records(empty_output, ["src/empty.test.js"]))

    def test_node_summary_uses_final_runner_values_not_test_console_output(self):
        output = """# tests 1
# pass 1
# fail 0
# skipped 0
ok 1 - intentional skip # SKIP
1..1
# tests 1
# pass 0
# fail 0
# skipped 1
"""
        self.assertEqual(_last_node_tap_summary_value(output, "pass"), 0)
        self.assertEqual(_last_node_tap_summary_value(output, "skipped"), 1)

    def test_node_script_paths_are_option_terminated_and_flag_names_rejected(self):
        self.assertEqual(_validated_node_script_args(["src/app.js", "tests/sample.test.js"]), ["--", "src/app.js", "tests/sample.test.js"])
        for path in ("--eval", "-e", "../outside.js", "folder/../outside.js", "/absolute.js", "bad\\path.js"):
            with self.subTest(path=path):
                with self.assertRaises(ValueError):
                    _validated_node_script_args([path])

    def test_node_registered_test_case_is_counted(self):
        test_output = """TAP version 13
# Subtest: computes output
ok 1 - computes output
1..1
# tests 1
# pass 1
# fail 0
# skipped 0
"""
        self.assertTrue(_node_tap_has_real_test_records(test_output, ["src/math.test.js"]))

    def test_node_test_console_output_cannot_create_tap_record(self):
        test_output = """TAP version 13
# ok 1 - fake test from console output
# tests 1
# pass 1
# fail 0
# skipped 0
"""
        self.assertFalse(_node_tap_has_real_test_records(test_output, ["src/empty.test.js"]))

    @patch("offline_coder.isolated_tests.shutil.which", return_value=None)
    def test_missing_docker_skips_without_running_code(self, _which):
        with tempfile.TemporaryDirectory() as temp:
            result = run_isolated_python_checks(Path(temp), {"hello.py": "print('hello')"})
        self.assertEqual(result["status"], "SKIPPED")
        self.assertIn("not executed", result["summary"])


    def test_proposal_overlay_rejects_noncanonical_and_sensitive_paths(self):
        with tempfile.TemporaryDirectory() as temp:
            snapshot = Path(temp)
            for path in (r"src\app.py", "src//app.py", "../outside.py", ".env", ".council/run.json", "C:/outside.py"):
                with self.subTest(path=path):
                    error = _overlay_proposed_files(snapshot, {path: "value = 1"}, "test runner")
                    self.assertIsNotNone(error, path)
            self.assertFalse((snapshot / "src" / "app.py").exists())

    def test_proposal_overlay_rejects_oversized_content(self):
        with tempfile.TemporaryDirectory() as temp:
            error = _overlay_proposed_files(Path(temp), {"app.py": "x" * 1_000_001}, "test runner")
        self.assertIn("1 MB limit", error)

    def test_workspace_snapshot_excludes_secret_paths(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp) / "source"
            dest = Path(temp) / "snapshot"
            root.mkdir(); dest.mkdir()
            (root / ".env").write_text("API_TOKEN=example-secret", encoding="utf-8")
            (root / "credentials.json").write_text('{"password":"example"}', encoding="utf-8")
            (root / "secrets").mkdir()
            (root / "secrets" / "prod.py").write_text("token='example'", encoding="utf-8")
            (root / "app.py").write_text("def main(): return True", encoding="utf-8")
            _copy_workspace(root, dest)
            self.assertTrue((dest / "app.py").exists())
            self.assertFalse((dest / ".env").exists())
            self.assertFalse((dest / "credentials.json").exists())
            self.assertFalse((dest / "secrets" / "prod.py").exists())


    def test_snapshot_overlay_blocks_case_variants_of_protected_directories(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            for name in (".GIT/config.py", ".COUNCIL/backup.py"):
                result = _overlay_proposed_files(root, {name: "value = 1\n"}, "test runner")
                self.assertIsNotNone(result, f"protected path case variant should be rejected: {name}")

    def test_workspace_snapshot_bounds_entry_traversal(self):
        import offline_coder.isolated_tests as isolated
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp) / "source"
            dest = Path(temp) / "snapshot"
            root.mkdir(); dest.mkdir()
            (root / "a.txt").write_text("a", encoding="utf-8")
            (root / "b.txt").write_text("b", encoding="utf-8")
            with patch.object(isolated, "MAX_COPY_FILES", 1):
                with self.assertRaisesRegex(ValueError, "automatic tests were skipped"):
                    _copy_workspace(root, dest)

    @patch("offline_coder.isolated_tests.subprocess.run")
    @patch("offline_coder.isolated_tests.shutil.which", return_value="/usr/bin/docker")
    def test_missing_local_image_does_not_pull_or_execute(self, _which, run):
        run.return_value.returncode = 1
        with tempfile.TemporaryDirectory() as temp:
            result = run_isolated_python_checks(Path(temp), {"hello.py": "print('hello')"})
        self.assertEqual(result["status"], "SKIPPED")
        self.assertEqual(run.call_count, 1)
        self.assertEqual(run.call_args.args[0][1:3], ["image", "inspect"])

    @patch("offline_coder.isolated_tests.subprocess.run", side_effect=__import__("subprocess").TimeoutExpired("docker", 8))
    @patch("offline_coder.isolated_tests.shutil.which", return_value="/usr/bin/docker")
    def test_python_image_inspection_timeout_is_reported_as_skipped(self, _which, _run):
        with tempfile.TemporaryDirectory() as temp:
            result = run_isolated_python_checks(Path(temp), {"hello.py": "print('hello')"})
        self.assertEqual(result["status"], "SKIPPED")
        self.assertIn("Could not inspect", result["summary"])

    @patch("offline_coder.isolated_tests.subprocess.run")
    @patch("offline_coder.isolated_tests.shutil.which", return_value="/usr/bin/docker")
    def test_available_image_runs_with_network_disabled_and_limits(self, _which, run):
        inspect = type("Result", (), {"returncode": 0, "stdout": "[]", "stderr": ""})()
        executed = type("Result", (), {"returncode": 0, "stdout": "PYTHON_COMPILE: PASS\nUNITTEST_DISCOVERY: tests found\nRan 1 test", "stderr": ""})()
        run.side_effect = [inspect, executed]
        with tempfile.TemporaryDirectory() as temp:
            result = run_isolated_python_checks(Path(temp), {"hello.py": "def hello(): return 'hi'"})
        self.assertEqual(result["status"], "UNTRUSTED_TESTS")
        self.assertIn("not proof of correctness", result["summary"])
        args = run.call_args.args[0]
        self.assertIn("--network", args)
        self.assertEqual(args[args.index("--network") + 1], "none")
        self.assertIn("--read-only", args)
        self.assertIn("--memory", args)
        self.assertIn("--pids-limit", args)

    @patch("offline_coder.isolated_tests.subprocess.run")
    @patch("offline_coder.isolated_tests.shutil.which", return_value="/usr/bin/docker")
    def test_forged_python_success_marker_never_becomes_verified_pass(self, _which, run):
        inspect = type("Result", (), {"returncode": 0, "stdout": "[]", "stderr": ""})()
        # A malicious tests/__init__.py can print this marker and call os._exit(0)
        # before unittest discovery reaches any real test. Never trust this output.
        executed = type("Result", (), {
            "returncode": 0,
            "stdout": "PYTHON_COMPILE: PASS\nUNITTEST_DISCOVERY: tests found\nUNITTEST_RESULTS: run=1 skipped=0 executed=1 failures=0 errors=0",
            "stderr": "",
        })()
        run.side_effect = [inspect, executed]
        with tempfile.TemporaryDirectory() as temp:
            result = run_isolated_python_checks(Path(temp), {"hello.py": "def hello(): return 'hi'"})
        self.assertEqual(result["status"], "UNTRUSTED_TESTS")
        self.assertFalse(result.get("host_evidence_verified", False))

    @patch("offline_coder.isolated_tests.subprocess.run")
    @patch("offline_coder.isolated_tests.shutil.which", return_value="/usr/bin/docker")
    def test_empty_unittest_suite_is_not_reported_as_passed(self, _which, run):
        inspect = type("Result", (), {"returncode": 0, "stdout": "[]", "stderr": ""})()
        executed = type("Result", (), {"returncode": 0, "stdout": "PYTHON_COMPILE: PASS\nUNITTEST_DISCOVERY: no unittest tests discovered", "stderr": ""})()
        run.side_effect = [inspect, executed]
        with tempfile.TemporaryDirectory() as temp:
            result = run_isolated_python_checks(Path(temp), {"hello.py": "def hello(): return 'hi'"})
        self.assertEqual(result["status"], "NO_TESTS")
        self.assertIn("no unittest tests were discovered", result["summary"])


    @patch("offline_coder.isolated_tests.subprocess.run")
    @patch("offline_coder.isolated_tests.shutil.which", return_value="/usr/bin/docker")
    def test_all_skipped_python_tests_are_not_reported_as_passed(self, _which, run):
        inspect = type("Result", (), {"returncode": 0, "stdout": "[]", "stderr": ""})()
        executed = type("Result", (), {"returncode": 0, "stdout": "PYTHON_COMPILE: PASS\nUNITTEST_DISCOVERY: tests found\nUNITTEST_RESULTS: run=2 skipped=2 executed=0 failures=0 errors=0", "stderr": ""})()
        run.side_effect = [inspect, executed]
        with tempfile.TemporaryDirectory() as temp:
            result = run_isolated_python_checks(Path(temp), {"hello.py": "def hello(): return 'hi'"})
        self.assertEqual(result["status"], "NO_TESTS")


    def test_simulation_manifest_symlink_is_rejected(self):
        with tempfile.TemporaryDirectory() as temp, tempfile.TemporaryDirectory() as outside:
            root = Path(temp)
            external = Path(outside) / "manifest.json"
            external.write_text('{"scenarios":[]}', encoding="utf-8")
            try:
                (root / "council.simulations.json").symlink_to(external)
            except OSError:
                self.skipTest("Symlinks are unavailable on this platform")
            result = run_project_simulations(root, {})
        self.assertEqual(result["status"], "FAILED")
        self.assertIn("not a symlink", result["summary"])

    def test_simulation_manifest_size_is_bounded(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            (root / "council.simulations.json").write_text(" " * 1_000_001, encoding="utf-8")
            result = run_project_simulations(root, {})
        self.assertEqual(result["status"], "FAILED")
        self.assertIn("1 MB limit", result["summary"])

    @patch("offline_coder.isolated_tests.shutil.which", return_value=None)
    def test_node_check_skips_without_docker(self, _which):
        with tempfile.TemporaryDirectory() as temp:
            result = run_isolated_node_checks(Path(temp), {"app.js": "console.log('hi')"})
        self.assertEqual(result["status"], "SKIPPED")
        self.assertIn("not executed", result["summary"])

    @patch("offline_coder.isolated_tests.subprocess.run")
    @patch("offline_coder.isolated_tests.shutil.which", return_value="/usr/bin/docker")
    def test_successful_project_controlled_node_output_is_untrusted_not_passed(self, _which, run):
        inspect = type("Result", (), {"returncode": 0, "stdout": "[]", "stderr": ""})()
        syntax = type("Result", (), {"returncode": 0, "stdout": "", "stderr": ""})()
        tests = type("Result", (), {"returncode": 0, "stdout": "TAP version 13\n# Subtest: computes output\nok 1 - computes output\n1..1\n# tests 1\n# pass 1\n# fail 0\n# skipped 0", "stderr": ""})()
        run.side_effect = [inspect, syntax, tests]
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            (root / "tests").mkdir()
            (root / "tests" / "sample.test.js").write_text("// test", encoding="utf-8")
            result = run_isolated_node_checks(root, {"app.js": "console.log('hi')"})
        self.assertEqual(result["status"], "UNTRUSTED_TESTS")
        self.assertFalse(result.get("host_evidence_verified", False))

    @patch("offline_coder.isolated_tests.subprocess.run")
    @patch("offline_coder.isolated_tests.shutil.which", return_value="/usr/bin/docker")
    def test_all_skipped_node_tests_are_not_reported_as_passed(self, _which, run):
        inspect = type("Result", (), {"returncode": 0, "stdout": "[]", "stderr": ""})()
        syntax = type("Result", (), {"returncode": 0, "stdout": "", "stderr": ""})()
        tests = type("Result", (), {"returncode": 0, "stdout": "ℹ tests 2\nℹ pass 0\nℹ fail 0\nℹ skipped 2", "stderr": ""})()
        run.side_effect = [inspect, syntax, tests]
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            (root / "tests").mkdir()
            (root / "tests" / "sample.test.js").write_text("// test", encoding="utf-8")
            result = run_isolated_node_checks(root, {"app.js": "console.log('hi')"})
        self.assertEqual(result["status"], "NO_TESTS")

    @patch("offline_coder.isolated_tests.subprocess.run")
    @patch("offline_coder.isolated_tests.shutil.which", return_value="/usr/bin/docker")
    def test_node_runner_does_not_pass_when_test_summary_is_missing(self, _which, run):
        inspect = type("Result", (), {"returncode": 0, "stdout": "[]", "stderr": ""})()
        syntax = type("Result", (), {"returncode": 0, "stdout": "", "stderr": ""})()
        tests = type("Result", (), {"returncode": 0, "stdout": "unexpected empty output", "stderr": ""})()
        run.side_effect = [inspect, syntax, tests]
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            (root / "tests").mkdir()
            (root / "tests" / "sample.test.js").write_text("// test", encoding="utf-8")
            result = run_isolated_node_checks(root, {"app.js": "console.log('hi')"})
        self.assertEqual(result["status"], "FAILED")
        self.assertIn("parseable final TAP summary", result["summary"])

    @patch("offline_coder.isolated_tests.subprocess.run")
    @patch("offline_coder.isolated_tests.shutil.which", return_value="/usr/bin/docker")
    def test_node_runner_rejects_reported_failure_even_if_exit_code_is_zero(self, _which, run):
        inspect = type("Result", (), {"returncode": 0, "stdout": "[]", "stderr": ""})()
        syntax = type("Result", (), {"returncode": 0, "stdout": "", "stderr": ""})()
        tests = type("Result", (), {"returncode": 0, "stdout": "ℹ tests 2\nℹ pass 1\nℹ fail 1\nℹ skipped 0", "stderr": ""})()
        run.side_effect = [inspect, syntax, tests]
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            (root / "tests").mkdir()
            (root / "tests" / "sample.test.js").write_text("// test", encoding="utf-8")
            result = run_isolated_node_checks(root, {"app.js": "console.log('hi')"})
        self.assertEqual(result["status"], "FAILED")
        self.assertIn("reports 1 failed", result["summary"])

    def test_simulation_runner_is_not_applicable_without_manifest(self):
        with tempfile.TemporaryDirectory() as temp:
            result = run_project_simulations(Path(temp), {})
        self.assertEqual(result["status"], "NOT_APPLICABLE")

    def test_simulation_manifest_rejects_path_traversal(self):
        import json
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            (root / "council.simulations.json").write_text(json.dumps({"scenarios": [{"name": "bad", "runtime": "python", "script": "../outside.py"}]}), encoding="utf-8")
            result = run_project_simulations(root, {})
        self.assertEqual(result["status"], "FAILED")
        self.assertIn("unsafe", result["summary"].lower())

    @patch("offline_coder.isolated_tests.subprocess.run")
    @patch("offline_coder.isolated_tests.shutil.which", return_value="/usr/bin/docker")
    def test_simulation_runs_script_in_offline_container_and_checks_output(self, _which, run):
        import json
        inspect = type("Result", (), {"returncode": 0, "stdout": "[]", "stderr": ""})()
        executed = type("Result", (), {"returncode": 0, "stdout": "SIMULATION_OK", "stderr": ""})()
        run.side_effect = [inspect, executed]
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            (root / "main.py").write_text("print('SIMULATION_OK')", encoding="utf-8")
            (root / "council.simulations.json").write_text(json.dumps({"scenarios": [{"name": "smoke", "runtime": "python", "script": "main.py", "expect_output_contains": "SIMULATION_OK"}]}), encoding="utf-8")
            result = run_project_simulations(root, {})
        self.assertEqual(result["status"], "PASSED")
        self.assertEqual(result["scenarios"][0]["status"], "PASSED")
        args = run.call_args.args[0]
        self.assertIn("--network", args)
        self.assertEqual(args[args.index("--network") + 1], "none")
        self.assertIn("--read-only", args)

    @patch("offline_coder.isolated_tests.shutil.which", return_value=None)
    def test_simulation_skips_without_docker(self, _which):
        import json
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            (root / "main.py").write_text("print('ok')", encoding="utf-8")
            (root / "council.simulations.json").write_text(json.dumps({"scenarios": [{"runtime": "python", "script": "main.py"}]}), encoding="utf-8")
            result = run_project_simulations(root, {})
        self.assertEqual(result["status"], "SKIPPED")
        self.assertIn("not executed", result["summary"])

    def test_project_checks_run_visual_browser_check_for_html_changes(self):
        with tempfile.TemporaryDirectory() as temp:
            with patch("offline_coder.isolated_tests.run_project_simulations", return_value={"status": "NOT_APPLICABLE", "summary": "none", "output": ""}), \
                 patch("offline_coder.visual_simulation.run_visual_browser_checks", return_value={"status": "PASSED", "summary": "rendered", "output": "", "screenshot": "shot.png"}) as visual:
                result = run_project_checks(Path(temp), {"index.html": "<h1>hi</h1>"})
        self.assertEqual(result["status"], "PASSED")
        self.assertIn("visual", result["checks"])
        visual.assert_called_once()

    def test_project_check_aggregates_runtime_statuses(self):
        with tempfile.TemporaryDirectory() as temp:
            with patch("offline_coder.isolated_tests.run_isolated_python_checks", return_value={"status": "PASSED", "summary": "python passed", "output": ""}), \
                 patch("offline_coder.isolated_tests.run_isolated_node_checks", return_value={"status": "FAILED", "summary": "node failed", "output": "failure"}):
                result = run_project_checks(Path(temp), {"app.py": "", "app.js": ""})
        self.assertEqual(result["status"], "FAILED")
        self.assertIn("python", result["checks"])
        self.assertIn("node", result["checks"])


if __name__ == "__main__":
    unittest.main()
