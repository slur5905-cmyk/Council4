import json
import re
import unittest

from tools.sync_universal_knowledge import HTML_PATH, OPEN_TAG, CLOSE_TAG
from offline_coder.base_knowledge import BASE_KNOWLEDGE_DIR


class UniversalEmbeddedKnowledgeTests(unittest.TestCase):
    def test_browser_bundle_does_not_embed_the_full_desktop_knowledge_corpus(self):
        html = HTML_PATH.read_text(encoding="utf-8")
        match = re.search(re.escape(OPEN_TAG) + r"(.*?)" + re.escape(CLOSE_TAG), html, re.S)
        self.assertIsNotNone(match, "browser app retains a valid knowledge data slot")
        self.assertEqual(json.loads(match.group(1)), [])
        self.assertLess(len(html.encode("utf-8")), 200_000)

    def test_desktop_knowledge_corpus_remains_packaged_separately(self):
        knowledge_dir = BASE_KNOWLEDGE_DIR
        modules = [p for p in knowledge_dir.glob("*.md") if p.name.lower() != "readme.md"]
        self.assertGreaterEqual(len(modules), 80)

    def test_browser_context_retrieval_is_bounded_and_empty_without_local_pack(self):
        html = HTML_PATH.read_text(encoding="utf-8")
        self.assertIn("function retrieveOfflineKnowledge(", html)
        self.assertIn("composeBrowserContext(ctx,researchContext,offlineBaseContext)", html)
        self.assertIn("!OFFLINE_COMPUTING_LIBRARY.length", html)


if __name__ == "__main__":
    unittest.main()
