import json
import tempfile
import unittest
from pathlib import Path
from offline_coder.project_tools import analyze_project, format_project_report, compile_acceptance_checklist, TaskJournal, restore_backup, create_starter_template
from offline_coder.safety import apply_files, sha256_text


class ProjectToolsTests(unittest.TestCase):
    def test_project_inventory_detects_manifests_entries_tests_and_todos(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            (root / "README.md").write_text("Project", encoding="utf-8")
            (root / "package.json").write_text('{"name":"demo"}', encoding="utf-8")
            (root / "index.js").write_text("// TODO: handle failures\n", encoding="utf-8")
            (root / "tests").mkdir(); (root / "tests" / "test_app.py").write_text("assert True", encoding="utf-8")
            (root / ".env").write_text("SECRET=do-not-show", encoding="utf-8")
            report = analyze_project(root)
            markdown = format_project_report(report)
        self.assertIn("package.json", report["manifests"])
        self.assertIn("index.js", report["entry_points"])
        self.assertTrue(report["test_paths"])
        self.assertTrue(report["todos"])
        self.assertNotIn("do-not-show", markdown)


    def test_project_inventory_skips_case_variant_generated_directories(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            (root / "main.py").write_text("def visible(): return True\n", encoding="utf-8")
            hidden = root / ".COUNCIL"
            hidden.mkdir()
            (hidden / "backup.py").write_text("def hidden_backup(): pass\n", encoding="utf-8")
            report = analyze_project(root)
        self.assertEqual(report["file_count"], 1)
        self.assertEqual(report["semantic_index"]["indexed_files"], 1)

    def test_checklist_handles_empty_and_deduplicates(self):
        with self.assertRaises(ValueError):
            compile_acceptance_checklist("  ")
        checklist = compile_acceptance_checklist("Build a website.\n- Build a website.\n- Add a login form.")
        self.assertEqual(checklist.count("Build a website."), 1)
        self.assertIn("Add a login form", checklist)
        self.assertIn("Verification plan", checklist)

    def test_task_journal_round_trip(self):
        with tempfile.TemporaryDirectory() as temp:
            journal = TaskJournal(Path(temp))
            journal.record("Add a button", "Passed review", "Small patch", "run-1", "report.json")
            items = journal.list_recent()
        self.assertEqual(len(items), 1)
        self.assertEqual(items[0]["run_id"], "run-1")
        self.assertEqual(items[0]["task"], "Add a button")

    def test_task_journal_redacts_credentials_from_task_and_summary(self):
        with tempfile.TemporaryDirectory() as temp:
            journal = TaskJournal(Path(temp))
            secret = "ghp_ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789"
            journal.record(f"Debug API_TOKEN={secret}", "Failed", f"Observed token {secret}")
            raw = journal.path.read_text(encoding="utf-8")
            entries = journal.list_recent()
        self.assertNotIn(secret, raw)
        self.assertIn("[REDACTED]", entries[0]["task"])
        self.assertIn("[REDACTED GIT TOKEN]", entries[0]["summary"])

    def test_rollback_restores_overwritten_and_removes_created_files(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            old = root / "existing.txt"; old.write_text("old", encoding="utf-8")
            proposed = {"existing.txt": "new", "created.txt": "created"}
            hashes = {"existing.txt": sha256_text("old"), "created.txt": None}
            backup = apply_files(root, proposed, hashes)
            self.assertEqual(old.read_text(encoding="utf-8"), "new")
            self.assertTrue((root / "created.txt").exists())
            restored = restore_backup(root, backup)
            self.assertEqual(old.read_text(encoding="utf-8"), "old")
            self.assertFalse((root / "created.txt").exists())
            self.assertEqual(set(restored), {"existing.txt", "created.txt"})
            self.assertTrue((root / ".council" / "backups").is_dir())

    def test_static_report_adds_advisory_security_and_accessibility_flags(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            (root / "index.html").write_text('<img src="x.png"><input><script>el.innerHTML = input</script>', encoding="utf-8")
            report = analyze_project(root)
            markdown = format_project_report(report)
        self.assertTrue(report["accessibility_flags"])
        self.assertTrue(report["security_flags"])
        self.assertIn("not vulnerability-checked", markdown)

    def test_starter_templates_create_files_without_overwriting(self):
        with tempfile.TemporaryDirectory() as temp:
            dest = Path(temp) / "new-site"
            created = create_starter_template(dest, "website")
            self.assertIn("index.html", created)
            self.assertTrue((dest / "index.html").is_file())
            with self.assertRaises(ValueError):
                create_starter_template(dest, "python-cli")

    def test_template_rejects_unknown_kind(self):
        with tempfile.TemporaryDirectory() as temp:
            with self.assertRaises(ValueError):
                create_starter_template(Path(temp) / "site", "unknown")

    def test_rollback_refuses_backup_file_whose_contents_no_longer_match_manifest_hash(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            original = root / "existing.txt"
            original.write_text("original", encoding="utf-8")
            backup = apply_files(root, {"existing.txt": "changed"}, {"existing.txt": sha256_text("original")})
            backup_file = backup / "existing.txt"
            backup_file.write_text("tampered backup", encoding="utf-8")
            with self.assertRaisesRegex(ValueError, "integrity check failed"):
                restore_backup(root, backup)
            self.assertEqual(original.read_text(encoding="utf-8"), "changed")

    def test_rollback_rejects_outside_backup(self):
        with tempfile.TemporaryDirectory() as temp, tempfile.TemporaryDirectory() as outside:
            root = Path(temp); invalid = Path(outside)
            with self.assertRaises(ValueError):
                restore_backup(root, invalid)

    def test_rollback_refuses_symlink_target_even_when_link_points_inside_workspace(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            protected = root / "protected.txt"
            protected.write_text("must remain untouched", encoding="utf-8")
            backup = root / ".council" / "backups" / "crafted"
            backup.mkdir(parents=True)
            (backup / "link.txt").write_text("attacker-controlled backup", encoding="utf-8")
            (backup / "manifest.json").write_text(json.dumps({"targets": [
                {"path": "link.txt", "existed": True}
            ]}), encoding="utf-8")
            link = root / "link.txt"
            try:
                link.symlink_to(protected)
            except (OSError, NotImplementedError):
                self.skipTest("Symlinks are unavailable on this platform")
            with self.assertRaisesRegex(ValueError, "symlink"):
                restore_backup(root, backup)
            self.assertEqual(protected.read_text(encoding="utf-8"), "must remain untouched")

    def test_rollback_keeps_recovery_manifest_if_restore_stops_partway(self):
        from unittest.mock import patch
        import offline_coder.project_tools as project_tools
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            (root / "one.txt").write_text("old one", encoding="utf-8")
            (root / "two.txt").write_text("old two", encoding="utf-8")
            backup = apply_files(root, {"one.txt": "new one", "two.txt": "new two"},
                                 {"one.txt": sha256_text("old one"), "two.txt": sha256_text("old two")})
            real_replace = project_tools.os.replace
            calls = {"count": 0}
            def fail_on_second_replace(src, dst):
                calls["count"] += 1
                if calls["count"] == 2:
                    raise OSError("simulated disk failure")
                return real_replace(src, dst)
            with patch("offline_coder.project_tools.os.replace", side_effect=fail_on_second_replace):
                with self.assertRaisesRegex(RuntimeError, "snapshot retained"):
                    restore_backup(root, backup)
            snapshots = list((root / ".council" / "backups").glob("rollback_*/manifest.json"))
            self.assertTrue(snapshots, "partial restore must leave a machine-readable recovery manifest")
            snapshot_dir = snapshots[-1].parent
            manifest = json.loads(snapshots[-1].read_text(encoding="utf-8"))
            self.assertEqual({x["path"] for x in manifest["targets"]}, {"one.txt", "two.txt"})
            self.assertEqual((snapshot_dir / "one.txt").read_text(encoding="utf-8"), "new one")
            self.assertEqual((snapshot_dir / "two.txt").read_text(encoding="utf-8"), "new two")

    def test_rollback_rejects_symlink_selected_backup_directory(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            backups = root / ".council" / "backups"
            real = backups / "real"
            real.mkdir(parents=True)
            (real / "manifest.json").write_text(json.dumps({"targets": []}), encoding="utf-8")
            link = backups / "alias"
            try:
                link.symlink_to(real, target_is_directory=True)
            except (OSError, NotImplementedError):
                self.skipTest("Directory symlinks are unavailable on this platform")
            with self.assertRaisesRegex(ValueError, "symlink"):
                restore_backup(root, link)

    def test_rollback_rejects_duplicate_and_managed_directory_paths(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            backup = root / ".council" / "backups" / "crafted"
            backup.mkdir(parents=True)
            manifest = backup / "manifest.json"
            manifest.write_text(json.dumps({"targets": [
                {"path": "same.txt", "existed": False},
                {"path": "same.txt", "existed": False},
            ]}), encoding="utf-8")
            with self.assertRaisesRegex(ValueError, "Duplicate"):
                restore_backup(root, backup)
            manifest.write_text(json.dumps({"targets": [
                {"path": ".COUNCIL/runs/report.json", "existed": False},
            ]}), encoding="utf-8")
            with self.assertRaisesRegex(ValueError, "Unsafe.*rollback path"):
                restore_backup(root, backup)



    def test_rollback_refuses_crafted_manifest_targeting_secrets_and_git_metadata(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            secret = root / ".env"
            secret.write_text("KEEP=original\n", encoding="utf-8")
            backup = root / ".council" / "backups" / "crafted"
            backup.mkdir(parents=True)
            manifest = backup / "manifest.json"
            for unsafe in (".env", ".git/config", "id_rsa", "secrets.json"):
                manifest.write_text(json.dumps({"targets": [{"path": unsafe, "existed": False}]}), encoding="utf-8")
                with self.assertRaisesRegex(ValueError, "Unsafe or protected rollback path"):
                    restore_backup(root, backup)
            self.assertEqual(secret.read_text(encoding="utf-8"), "KEEP=original\n")

    def test_task_journal_refuses_symlink_target(self):
        with tempfile.TemporaryDirectory() as temp, tempfile.TemporaryDirectory() as outside:
            root = Path(temp)
            victim = Path(outside) / "victim.jsonl"
            victim.write_text("do not modify\n", encoding="utf-8")
            journal = TaskJournal(root)
            try:
                journal.path.symlink_to(victim)
            except (OSError, NotImplementedError):
                self.skipTest("Symlinks are unavailable on this platform")
            with self.assertRaises((ValueError, OSError)):
                journal.record("attacker", "failed")
            self.assertEqual(victim.read_text(encoding="utf-8"), "do not modify\n")
            self.assertEqual(journal.list_recent(), [])


if __name__ == "__main__":
    unittest.main()
