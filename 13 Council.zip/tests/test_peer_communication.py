import tempfile
import unittest
from pathlib import Path

from offline_coder.peer_communication import PeerCommunicationStore, PEER_NAMES


class PeerCommunicationStoreTests(unittest.TestCase):
    def test_persists_direct_questions_and_replies_with_integrity_hashes(self):
        with tempfile.TemporaryDirectory() as tmp:
            store = PeerCommunicationStore(Path(tmp) / "peer.sqlite3")
            discussion = store.begin_discussion("run-1", "Improve the caching layer")
            request_id = store.add_message(
                discussion, PEER_NAMES[0], PEER_NAMES[1], "question",
                "Cache invalidation", "How is stale data invalidated?", "cache/store.py:Cache.get",
                "awaiting_response",
            )
            store.add_message(
                discussion, PEER_NAMES[1], PEER_NAMES[0], "response",
                "Re: Cache invalidation", "The version counter invalidates stale entries.",
                "cache/store.py:Cache.get", "resolved", request_id,
            )
            messages = store.list_messages(discussion)
            self.assertEqual(len(messages), 2)
            self.assertTrue(all(item["integrity_valid"] for item in messages))
            self.assertEqual(messages[0]["kind"], "question")
            self.assertEqual(messages[1]["recipient"], PEER_NAMES[0])

    def test_rejects_unknown_peers_self_messages_and_path_traversal(self):
        with tempfile.TemporaryDirectory() as tmp:
            store = PeerCommunicationStore(Path(tmp) / "peer.sqlite3")
            discussion = store.begin_discussion("run-1", "Task")
            with self.assertRaises(ValueError):
                store.add_message(discussion, "Unknown", PEER_NAMES[1], "question", "x", "y")
            with self.assertRaises(ValueError):
                store.add_message(discussion, PEER_NAMES[0], PEER_NAMES[0], "question", "x", "y")
            with self.assertRaises(ValueError):
                store.add_message(discussion, PEER_NAMES[0], PEER_NAMES[1], "code_challenge", "x", "y", "../../secret.txt")

    def test_lessons_start_provisional_and_only_explicit_review_promotes_them(self):
        with tempfile.TemporaryDirectory() as tmp:
            store = PeerCommunicationStore(Path(tmp) / "peer.sqlite3")
            discussion = store.begin_discussion("run-1", "Improve retry logic")
            lesson_id = store.add_lesson(
                discussion, "Retry loops", "Always bound retries and include jitter.",
                "A prior stress test showed synchronized retries caused a load spike.",
            )
            self.assertEqual(store.list_lessons("provisional")[0]["id"], lesson_id)
            self.assertTrue(store.relevant_lessons("retry jitter"))
            store.review_lesson(lesson_id, "verified")
            self.assertEqual(store.list_lessons("verified")[0]["id"], lesson_id)
            with self.assertRaises(ValueError):
                store.review_lesson(lesson_id, "rejected")

    def test_discussion_can_remain_open_and_be_retrieved_for_related_future_tasks(self):
        with tempfile.TemporaryDirectory() as tmp:
            store = PeerCommunicationStore(Path(tmp) / "peer.sqlite3")
            discussion = store.begin_discussion("run-1", "Database cache invalidation")
            store.add_message(discussion, PEER_NAMES[2], PEER_NAMES[1], "investigation",
                              "Cache invalidation risk", "Investigate stale entries after concurrent writes.")
            store.set_discussion_status(discussion, "open")
            matches = store.list_open_discussions("cache invalidation concurrent writes")
            self.assertEqual(matches[0]["id"], discussion)

    def test_supports_all_dialogue_outcome_statuses(self):
        with tempfile.TemporaryDirectory() as tmp:
            store = PeerCommunicationStore(Path(tmp) / "peer.sqlite3")
            discussion = store.begin_discussion("run-statuses", "Test peer outcomes")
            statuses = ("needs_follow_up", "disagree", "cannot_verify", "resolved")
            for index, status in enumerate(statuses):
                store.add_message(
                    discussion, PEER_NAMES[index], "", "response", f"Outcome {status}",
                    "This message records a supported dialogue outcome.", status=status,
                )
            saved = store.list_messages(discussion)
            self.assertEqual([item["status"] for item in saved], list(statuses))
            with self.assertRaises(ValueError):
                store.add_message(
                    discussion, PEER_NAMES[0], "", "response", "Invalid", "Unknown status.",
                    status="arbitrary_status",
                )

    def test_sensitive_text_is_redacted_before_persistence(self):
        with tempfile.TemporaryDirectory() as tmp:
            store = PeerCommunicationStore(Path(tmp) / "peer.sqlite3")
            discussion = store.begin_discussion("run-1", "Task")
            store.add_message(discussion, PEER_NAMES[0], PEER_NAMES[1], "question",
                              "Credential safety", "Do not log api_key=abcdefghijklmnop during tests.")
            message = store.list_messages(discussion)[0]
            self.assertNotIn("abcdefghijklmnop", message["body"])
            self.assertIn("REDACTED", message["body"])


    def test_rejects_cross_discussion_links_and_caps_message_history(self):
        with tempfile.TemporaryDirectory() as tmp:
            store = PeerCommunicationStore(Path(tmp) / "peer.sqlite3")
            first = store.begin_discussion("run-1", "First task")
            second = store.begin_discussion("run-2", "Second task")
            source_id = store.add_message(
                first, PEER_NAMES[0], PEER_NAMES[1], "question", "Question", "Investigate this result."
            )
            with self.assertRaises(ValueError):
                store.add_message(
                    second, PEER_NAMES[1], PEER_NAMES[0], "response", "Cross-thread", "That is the answer.",
                    related_message_id=source_id,
                )
            for index in range(250):
                store.add_message(
                    second, PEER_NAMES[index % 4], "", "follow_up", f"Message {index}",
                    "Bounded discussion history test message.",
                )
            with self.assertRaisesRegex(ValueError, "250-message"):
                store.add_message(
                    second, PEER_NAMES[0], "", "follow_up", "Overflow", "This message should be rejected."
                )


if __name__ == "__main__":
    unittest.main()
