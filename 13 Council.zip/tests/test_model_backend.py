import unittest
from unittest.mock import patch

from offline_coder.model_backend import LocalModelError, LocalServerModel


class LocalServerModelTests(unittest.TestCase):
    @patch.object(LocalServerModel, "_request", return_value={"data": [{"id": "qwen-local"}]})
    def test_verifies_server_and_discovers_model_id(self, request):
        model = LocalServerModel("http://127.0.0.1:8080/v1")
        self.assertEqual(model.model, "qwen-local")
        self.assertEqual(model.model_path, "local-server:http://127.0.0.1:8080/v1/qwen-local")
        request.assert_called_once_with("/models", method="GET")

    def test_refuses_non_loopback_server(self):
        with self.assertRaisesRegex(LocalModelError, "loopback"):
            LocalServerModel("http://example.com:8080/v1")

    def test_refuses_unknown_requested_model(self):
        with patch.object(LocalServerModel, "_request", return_value={"data": [{"id": "available"}]}):
            with self.assertRaisesRegex(LocalModelError, "was not listed"):
                LocalServerModel("http://localhost:8080/v1", model="missing")

    @patch.object(LocalServerModel, "_request", return_value={"choices": [{"message": {"content": "fixed code"}}]})
    def test_generate_uses_chat_completions_and_returns_content(self, request):
        with patch.object(LocalServerModel, "_request", return_value={"data": [{"id": "qwen-local"}]}) as verify:
            model = LocalServerModel("http://127.0.0.1:8080/v1")
        self.assertEqual(model.generate("system", "user"), "fixed code")
        args, kwargs = request.call_args
        self.assertEqual(args[0], "/chat/completions")
        self.assertEqual(kwargs["body"]["model"], "qwen-local")
        self.assertEqual(kwargs["body"]["messages"][0]["role"], "system")

    def test_build_router_reuses_identical_gguf_models(self):
        import tempfile
        from pathlib import Path
        from unittest.mock import patch
        from offline_coder.model_backend import build_model_router

        class FakeModel:
            def __init__(self, model_path, **kwargs):
                self.model_path = str(model_path)
                self.kwargs = kwargs

            def generate(self, *args, **kwargs):
                return self.model_path

        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            primary = root / "primary.gguf"
            specialist = root / "specialist.gguf"
            primary.touch(); specialist.touch()
            settings = {
                "model_backend": "gguf", "model_path": str(primary),
                "role_model_paths": {
                    "architect": str(specialist),
                    "correctness": str(specialist),
                    "security": str(primary),
                    "redteam": str(specialist),
                },
            }
            from unittest.mock import Mock
            factory = Mock(side_effect=FakeModel)
            with patch("offline_coder.model_backend.LocalModel", factory):
                router = build_model_router(settings)
                self.assertEqual(factory.call_count, 0, "GGUF files should not load until a role first calls them")
                self.assertIs(router.role_models["architect"], router.role_models["correctness"])
                self.assertIs(router.role_models["architect"], router.role_models["redteam"])
                self.assertNotIn("security", router.role_models)
                specialist_answer = router.generate("system", "task", role="architect")
                self.assertEqual(specialist_answer, str(specialist.resolve()))
                self.assertEqual(factory.call_count, 1)
                primary_answer = router.generate("system", "task", role="security")
                self.assertEqual(primary_answer, str(primary.resolve()))
                self.assertEqual(factory.call_count, 2)
                status = router.model_manager.snapshot()
                self.assertEqual(status["currently_loaded"], 1)
                self.assertEqual(status["eviction_count"], 1)

    def test_build_router_discovers_local_server_models_once_and_reuses_duplicates(self):
        from unittest.mock import patch
        from offline_coder.model_backend import build_model_router
        with patch.object(LocalServerModel, "_request", return_value={"data": [{"id": "primary"}, {"id": "specialist"}]}) as request:
            router = build_model_router({
                "model_backend": "local-server",
                "local_server_url": "http://127.0.0.1:8080/v1",
                "local_server_model": "primary",
                "local_server_role_models": {
                    "architect": "specialist", "correctness": "specialist",
                    "security": "primary", "redteam": "specialist",
                },
            })
        request.assert_called_once_with("/models", method="GET")
        self.assertIs(router.role_models["architect"], router.role_models["correctness"])
        self.assertIs(router.role_models["architect"], router.role_models["redteam"])
        self.assertNotIn("security", router.role_models)

    def test_build_router_rejects_unlisted_specialist_model(self):
        from unittest.mock import patch
        from offline_coder.model_backend import build_model_router
        with patch.object(LocalServerModel, "_request", return_value={"data": [{"id": "primary"}]}):
            with self.assertRaisesRegex(LocalModelError, "was not listed"):
                build_model_router({
                    "model_backend": "local-server", "local_server_model": "primary",
                    "local_server_role_models": {"security": "not-installed"},
                })


class RoleModelRouterTests(unittest.TestCase):
    def test_dispatches_role_to_override_and_falls_back_to_primary(self):
        from offline_coder.model_backend import RoleModelRouter
        class Fake:
            def __init__(self, value): self.value = value; self.calls = 0
            def generate(self, system, user, max_tokens=None, temperature=None):
                self.calls += 1
                return self.value
        primary, security = Fake("primary"), Fake("security")
        router = RoleModelRouter(primary, {"security": security})
        self.assertEqual(router.generate("s", "u", role="security"), "security")
        self.assertEqual(router.generate("s", "u", role="architect"), "primary")
        self.assertEqual((primary.calls, security.calls), (1, 1))

    def test_role_assignments_are_reported_without_exposing_credentials(self):
        from offline_coder.model_backend import RoleModelRouter
        class Fake:
            model_path = "local-model:test"
            def generate(self, *args, **kwargs): return "ok"
        router = RoleModelRouter(Fake(), {"redteam": Fake()})
        self.assertEqual(router.configured_roles(), {"redteam": "local-model:test"})

    def test_shared_model_instance_is_serialized_across_peer_calls(self):
        import threading
        import time
        from concurrent.futures import ThreadPoolExecutor
        from offline_coder.model_backend import RoleModelRouter

        class TrackingModel:
            def __init__(self):
                self.active = 0
                self.max_active = 0
                self.guard = threading.Lock()
            def generate(self, *args, **kwargs):
                with self.guard:
                    self.active += 1
                    self.max_active = max(self.max_active, self.active)
                time.sleep(0.02)
                with self.guard:
                    self.active -= 1
                return "ok"

        shared = TrackingModel()
        router = RoleModelRouter(shared, {"architect": shared, "security": shared})
        with ThreadPoolExecutor(max_workers=3) as pool:
            results = list(pool.map(lambda role: router.generate("s", "u", role=role), ["architect", "security", "redteam"]))
        self.assertEqual(results, ["ok", "ok", "ok"])
        self.assertEqual(shared.max_active, 1)

    def test_distinct_model_instances_can_run_concurrently(self):
        import threading
        from concurrent.futures import ThreadPoolExecutor
        from offline_coder.model_backend import RoleModelRouter

        rendezvous = threading.Barrier(2)
        class BarrierModel:
            def __init__(self, label): self.label = label
            def generate(self, *args, **kwargs):
                rendezvous.wait(timeout=1.0)
                return self.label

        primary, security = BarrierModel("primary"), BarrierModel("security")
        router = RoleModelRouter(primary, {"security": security})
        with ThreadPoolExecutor(max_workers=2) as pool:
            first = pool.submit(router.generate, "s", "u")
            second = pool.submit(router.generate, "s", "u", role="security")
            self.assertEqual({first.result(timeout=2), second.result(timeout=2)}, {"primary", "security"})

    def test_failed_specialist_falls_back_once_to_primary_and_records_the_reason(self):
        from offline_coder.model_backend import RoleModelRouter

        class Fake:
            def __init__(self, path, fail=False):
                self.model_path = path
                self.fail = fail
                self.calls = 0

            def generate(self, *args, **kwargs):
                self.calls += 1
                if self.fail:
                    raise RuntimeError("local context allocation failed")
                return "primary answer"

        primary = Fake("primary.gguf")
        specialist = Fake("security.gguf", fail=True)
        router = RoleModelRouter(primary, {"security": specialist})
        self.assertEqual(router.generate("system", "task", role="security"), "primary answer")
        self.assertEqual(specialist.calls, 1)
        self.assertEqual(primary.calls, 1)
        self.assertEqual(router.fallback_events[0]["failed_model"], "security.gguf")
        self.assertEqual(router.fallback_events[0]["fallback_model"], "primary.gguf")

    def test_failed_specialist_and_primary_fallback_are_both_reported(self):
        from offline_coder.model_backend import LocalModelError, RoleModelRouter

        class Broken:
            def __init__(self, model_path):
                self.model_path = model_path

            def generate(self, *args, **kwargs):
                raise RuntimeError(self.model_path + " failed")

        router = RoleModelRouter(Broken("primary.gguf"), {"security": Broken("security.gguf")})
        with self.assertRaisesRegex(LocalModelError, "primary fallback.*also failed"):
            router.generate("system", "task", role="security")

    def test_lazy_manager_never_exceeds_resident_model_limit_and_reloads_evicted_model(self):
        import tempfile
        from pathlib import Path
        from unittest.mock import patch
        from offline_coder.model_backend import LocalModelManager

        class FakeModel:
            def __init__(self, model_path, **kwargs):
                self.model_path = str(model_path)
            def generate(self, system, user, max_tokens=None, temperature=None):
                return Path(self.model_path).name

        with tempfile.TemporaryDirectory() as temp:
            paths = [str(Path(temp) / f"m{i}.gguf") for i in range(3)]
            for path in paths:
                Path(path).touch()
            manager = LocalModelManager(max_loaded_models=2)
            with patch("offline_coder.model_backend.LocalModel", FakeModel):
                self.assertEqual(manager.generate(paths[0], "s", "u"), "m0.gguf")
                self.assertEqual(manager.generate(paths[1], "s", "u"), "m1.gguf")
                self.assertEqual(manager.snapshot()["currently_loaded"], 2)
                self.assertEqual(manager.generate(paths[2], "s", "u"), "m2.gguf")
                self.assertEqual(manager.snapshot()["currently_loaded"], 2)
                self.assertEqual(manager.snapshot()["eviction_count"], 1)
                self.assertEqual(manager.generate(paths[0], "s", "u"), "m0.gguf")
                self.assertLessEqual(manager.snapshot()["currently_loaded"], 2)


if __name__ == "__main__":
    unittest.main()
