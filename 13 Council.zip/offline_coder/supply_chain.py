"""Read-only dependency and software-supply-chain inventory.

No package manager is invoked, no dependency is installed, and no network request is made.
This is inventory/hardening guidance, not a vulnerability scan or license verdict.
"""
from __future__ import annotations

import json
import re
import shutil
try:
    import tomllib
except ImportError:  # Python 3.10 compatibility
    import tomli as tomllib
from pathlib import Path
from urllib.parse import quote
from typing import Any

from .safety import IGNORED_DIRS, is_secret_path, is_within, is_ignored_directory_name

MAX_MANIFEST_BYTES = 2_000_000
LOCK_FILES = {
    "package-lock.json", "npm-shrinkwrap.json", "pnpm-lock.yaml", "yarn.lock",
    "poetry.lock", "Pipfile.lock", "uv.lock", "requirements.txt", "Cargo.lock",
    "go.sum", "Gemfile.lock", "composer.lock", "gradle.lockfile", "packages.lock.json",
}
SCANNERS = {
    "osv-scanner": "OSV vulnerability scanner (not invoked automatically)",
    "pip-audit": "Python dependency vulnerability scanner (not invoked automatically)",
    "npm": "npm CLI (audit can use network; not invoked automatically)",
    "cargo-audit": "Rust advisory scanner (not invoked automatically)",
    "govulncheck": "Go vulnerability scanner (not invoked automatically)",
    "trivy": "Filesystem/container/dependency scanner (not invoked automatically)",
    "syft": "SBOM generator (not invoked automatically)",
}


def _read(path: Path) -> str:
    if path.is_symlink() or not path.is_file() or path.stat().st_size > MAX_MANIFEST_BYTES:
        return ""
    try:
        return path.read_text(encoding="utf-8", errors="replace")
    except OSError:
        return ""


def _component(name: str, version: str, ecosystem: str, direct: bool = True) -> dict[str, Any]:
    name_text = str(name)[:250]
    version_text = str(version)[:250].strip()
    package_type = {"npm": "npm", "pypi": "pypi", "crates.io": "cargo", "Go modules": "golang",
                    "RubyGems": "gem", "Composer": "composer"}.get(ecosystem)
    # Only emit a PURL if the manifest contains an exact version, not a range or wildcard.
    exact_version = bool(re.fullmatch(r"v?\d+(?:\.\d+){1,3}(?:[-+][A-Za-z0-9.-]+)?", version_text))
    purl = f"pkg:{package_type}/{quote(name_text, safe='.@_-')}@{quote(version_text.lstrip('v'), safe='.+-_')}" if package_type and exact_version else ""
    return {"type": "library", "name": name_text, "version": version_text,
            "purl": purl, "ecosystem": ecosystem, "scope": "required" if direct else "optional"}


def _workflow_security_review(root: Path, *, max_workflows: int = 200) -> list[dict[str, Any]]:
    """Conservative, read-only GitHub Actions workflow review; findings need human verification."""
    github_root = root / ".github"
    workflow_root = github_root / "workflows"
    findings: list[dict[str, Any]] = []
    if github_root.is_symlink() or workflow_root.is_symlink() or not is_within(workflow_root, root) or not workflow_root.is_dir():
        return findings
    candidates = sorted([*workflow_root.glob("*.yml"), *workflow_root.glob("*.yaml")])[:max_workflows]
    for path in candidates:
        if path.is_symlink() or not path.is_file() or path.stat().st_size > MAX_MANIFEST_BYTES:
            continue
        body = _read(path)
        relative = path.relative_to(root).as_posix()
        lines = body.splitlines()
        text = body.casefold()
        def add(code: str, severity: str, reason: str, line: int = 0):
            findings.append({"file": relative, "rule": code, "severity": severity, "line": line,
                             "reason": reason, "status": "REVIEW_REQUIRED"})
        for number, line in enumerate(lines, 1):
            value = line.strip().casefold()
            if re.search(r"\bpull_request_target\b", value):
                add("untrusted-pull-request-trigger", "HIGH", "pull_request_target can expose privileged workflow context to untrusted contributions; audit checkout, secrets, and write permissions.", number)
            if re.match(r"permissions\s*:\s*write-all\b", value):
                add("broad-workflow-permissions", "HIGH", "Workflow grants write-all permissions; apply least privilege at workflow and job scope.", number)
            if re.search(r"\buses\s*:\s*[^\s#]+@(main|master|latest|v\d+(?:\.\d+)?)(?:\s|$)", value):
                add("mutable-action-reference", "MEDIUM", "Action reference is a mutable branch or version tag; pin to a reviewed full commit SHA and update deliberately.", number)
            if re.search(r"\bpersist-credentials\s*:\s*true\b", value):
                add("persisted-checkout-credentials", "MEDIUM", "Checkout credentials persist in the workspace; disable unless a later step explicitly requires them.", number)
        if "pull_request_target" in text and re.search(r"\bsecrets\.[a-z0-9_]+", text):
            add("secrets-in-privileged-pr-workflow", "HIGH", "Workflow combines pull_request_target with secret references; verify that untrusted code cannot access privileged secrets.")
    return findings


def analyze_supply_chain(root: Path, *, max_files: int = 4000) -> dict[str, Any]:
    """Inventory dependency declarations and controls without running package managers."""
    root = Path(root).expanduser().resolve()
    if not root.is_dir():
        return {"status": "unavailable", "error": "Workspace does not exist."}
    manifests: list[str] = []
    lockfiles: list[str] = []
    components: list[dict[str, Any]] = []
    install_scripts: list[str] = []
    unpinned: list[str] = []
    symlink_skips = 0
    visited = 0
    for base, dirs, names in __import__("os").walk(root, followlinks=False):
        bp = Path(base)
        dirs[:] = [d for d in dirs if not is_ignored_directory_name(d) and not (bp / d).is_symlink()]
        for name in names:
            visited += 1
            if visited > max_files:
                break
            path = bp / name
            if path.is_symlink():
                symlink_skips += 1
                continue
            try:
                relative = path.relative_to(root).as_posix()
            except ValueError:
                continue
            if is_secret_path(relative):
                continue
            if name in LOCK_FILES:
                lockfiles.append(relative)
            if name not in {"package.json", "requirements.txt", "requirements-dev.txt", "pyproject.toml", "Cargo.toml", "go.mod", "Gemfile", "composer.json"}:
                continue
            body = _read(path)
            if not body:
                continue
            manifests.append(relative)
            ecosystem = "unknown"
            if name == "package.json":
                ecosystem = "npm"
                try:
                    data = json.loads(body)
                    for section in ("dependencies", "devDependencies", "optionalDependencies", "peerDependencies"):
                        for dep, version in (data.get(section, {}) or {}).items():
                            components.append(_component(dep, version, ecosystem, section != "optionalDependencies"))
                            if isinstance(version, str) and (version in {"*", "latest"} or version.startswith(("http:", "https:", "git+", "github:", "file:"))):
                                unpinned.append(f"{relative}: {dep} uses broad or non-registry specifier {version!r}")
                    scripts = data.get("scripts", {})
                    if isinstance(scripts, dict):
                        for script in ("preinstall", "install", "postinstall", "prepare"):
                            if scripts.get(script):
                                install_scripts.append(f"{relative}: {script} script is declared; inspect before installing")
                except (json.JSONDecodeError, AttributeError):
                    unpinned.append(f"{relative}: invalid or unexpected package manifest")
            elif name == "pyproject.toml":
                ecosystem = "pypi"
                try:
                    data = tomllib.loads(body)
                    deps = data.get("project", {}).get("dependencies", [])
                    optional = data.get("project", {}).get("optional-dependencies", {})
                    for item in deps if isinstance(deps, list) else []:
                        match = re.match(r"\s*([A-Za-z0-9_.-]+)\s*(.*)", str(item))
                        if match:
                            components.append(_component(match.group(1), match.group(2) or "unspecified", ecosystem))
                    for group in optional.values() if isinstance(optional, dict) else []:
                        for item in group if isinstance(group, list) else []:
                            match = re.match(r"\s*([A-Za-z0-9_.-]+)\s*(.*)", str(item))
                            if match:
                                components.append(_component(match.group(1), match.group(2) or "unspecified", ecosystem, False))
                except (tomllib.TOMLDecodeError, AttributeError):
                    unpinned.append(f"{relative}: pyproject.toml could not be parsed")
            elif name.startswith("requirements"):
                ecosystem = "pypi"
                for line in body.splitlines():
                    line = line.split("#", 1)[0].strip()
                    if not line or line.startswith(("-r ", "--")):
                        continue
                    match = re.match(r"([A-Za-z0-9_.-]+)(.*)", line)
                    if match:
                        spec = match.group(2).strip() or "unspecified"
                        components.append(_component(match.group(1), spec, ecosystem))
                        if spec in {"", "*"} or " @ " in spec or spec.startswith(("git+", "http:", "https:")):
                            unpinned.append(f"{relative}: {line[:180]}")
            elif name == "Cargo.toml":
                ecosystem = "crates.io"
                # Lightweight TOML parsing records declared names/specs, not full feature resolution.
                try:
                    data = tomllib.loads(body)
                    for section in ("dependencies", "dev-dependencies", "build-dependencies"):
                        for dep, spec in data.get(section, {}).items():
                            version = spec.get("version", "unspecified") if isinstance(spec, dict) else spec
                            components.append(_component(dep, version, ecosystem, section != "dev-dependencies"))
                            if version in (None, "*", "latest"):
                                unpinned.append(f"{relative}: {dep} has no precise declared version")
                except (tomllib.TOMLDecodeError, AttributeError):
                    unpinned.append(f"{relative}: Cargo.toml could not be parsed")
            elif name == "go.mod":
                ecosystem = "Go modules"
                for match in re.finditer(r"(?m)^\s*([^\s()]+)\s+(v\S+)", body):
                    components.append(_component(match.group(1), match.group(2), ecosystem))
            elif name == "Gemfile":
                ecosystem = "RubyGems"
                for match in re.finditer(r"(?m)^\s*gem\s+['\"]([^'\"]+)['\"](?:\s*,\s*['\"]([^'\"]+)['\"])?", body):
                    components.append(_component(match.group(1), match.group(2) or "unspecified", ecosystem))
            elif name == "composer.json":
                ecosystem = "Composer"
                try:
                    data = json.loads(body)
                    for section in ("require", "require-dev"):
                        for dep, version in (data.get(section, {}) or {}).items():
                            if dep != "php":
                                components.append(_component(dep, version, ecosystem, section == "require"))
                except (json.JSONDecodeError, AttributeError):
                    unpinned.append(f"{relative}: invalid Composer manifest")
        if visited > max_files:
            break

    available_tools = [{"name": name, "description": desc, "path": shutil.which(name) or ""} for name, desc in SCANNERS.items()]
    workflow_findings = _workflow_security_review(root)
    return {
        "status": "completed", "root": str(root), "manifests": sorted(set(manifests)),
        "lockfiles": sorted(set(lockfiles)), "lockfile_coverage": bool(lockfiles),
        "components": components[:10_000], "component_count": len(components),
        "declared_install_scripts": install_scripts[:200], "broad_or_unusual_specs": unpinned[:200],
        "security_tools": available_tools, "workflow_security_findings": workflow_findings,
        "workflow_findings_are_advisory": True, "symlinks_skipped": symlink_skips,
        "files_scanned": min(visited, max_files), "truncated": visited > max_files,
        "limitations": [
            "No package manager or scanner was executed; no network access or dependency installation occurred.",
            "This inventory is not a vulnerability audit, license analysis, malware scan, or proof that dependencies are safe.",
            "Manifest parsing is partial and may omit workspace, platform, optional, generated, or transitive dependency resolution.",
        ],
    }


def format_supply_chain_report(report: dict[str, Any], *, max_components: int = 120) -> str:
    if report.get("status") != "completed":
        return "SUPPLY-CHAIN INVENTORY UNAVAILABLE: " + str(report.get("error", "unknown"))
    lines = ["READ-ONLY SUPPLY-CHAIN INVENTORY (no scanner/package manager executed):",
             f"Manifests: {', '.join(report['manifests']) or 'none detected'}",
             f"Lockfiles: {', '.join(report['lockfiles']) or 'none detected'}",
             f"Declared dependency entries: {report['component_count']}",
             "Components (partial manifest declarations):"]
    lines.extend(f"- {x['ecosystem']}: {x['name']} {x['version']}" for x in report["components"][:max_components])
    lines.append("Available local scanners (not run): " + ", ".join(f"{x['name']}={'available' if x['path'] else 'not found'}" for x in report["security_tools"]))
    lines.extend(f"Workflow review [{x['severity']}] {x['file']}:{x['line'] or '?'} {x['rule']}: {x['reason']}" for x in report.get("workflow_security_findings", [])[:60])
    lines.append("Workflow findings are heuristic review flags, not confirmed vulnerabilities.")
    lines.extend("Warning: " + str(x) for x in report["broad_or_unusual_specs"][:30])
    lines.extend("Install script: " + str(x) for x in report["declared_install_scripts"][:20])
    lines.extend("Limitation: " + str(x) for x in report["limitations"])
    return "\n".join(lines)


def make_cyclonedx_sbom(report: dict[str, Any]) -> dict[str, Any]:
    """Produce a conservative CycloneDX 1.5 JSON inventory; it is not a resolved SBOM."""
    components = []
    for index, item in enumerate(report.get("components", [])[:10_000], 1):
        component = {"type": "library", "bom-ref": f"declared-{index}", "name": item["name"],
                     "version": item["version"], "scope": item["scope"],
                     "properties": [{"name": "offline-council:ecosystem", "value": item["ecosystem"]}]}
        if item.get("purl"):
            component["purl"] = item["purl"]
        components.append(component)
    return {
        "bomFormat": "CycloneDX", "specVersion": "1.5", "version": 1,
        "metadata": {"properties": [{"name": "offline-council:inventory-only", "value": "true"},
                                       {"name": "offline-council:resolved", "value": "false"}]},
        "components": components,
    }
