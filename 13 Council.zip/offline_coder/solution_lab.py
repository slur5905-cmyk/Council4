"""Safe comparison helpers for independently generated candidate patches.

Candidate code is never executed here. The caller supplies host-side validation and test
results from the Council's existing isolated runners. Selection is conservative and evidence
based; no candidate is applied or automatically trusted.
"""
from __future__ import annotations
import hashlib

from dataclasses import dataclass, field
from typing import Any, Callable


@dataclass
class CandidateEvidence:
    candidate_id: str
    files: dict[str, str]
    validation_ok: bool
    validation_errors: list[str] = field(default_factory=list)
    test_report: dict[str, Any] = field(default_factory=dict)

    @property
    def test_status(self) -> str:
        return str(self.test_report.get("status", "NOT_RUN")).upper()

    @property
    def patch_bytes(self) -> int:
        return sum(len(str(name).encode("utf-8")) + len(str(body).encode("utf-8")) for name, body in self.files.items())

    @property
    def candidate_sha256(self) -> str:
        import json
        payload = json.dumps(self.files, sort_keys=True, ensure_ascii=False, separators=(",", ":"))
        return hashlib.sha256(payload.encode("utf-8")).hexdigest()

    def check_coverage(self) -> tuple[int, int, bool]:
        checks = self.test_report.get("checks")
        total = len(checks) if isinstance(checks, dict) else 0
        # A string that looks like a SHA-256 digest is not an attestation. This build
        # has no independent host signer/verifier, so no report field supplied to this
        # function can make a candidate eligible. Keep the visible count for diagnostics
        # but always report zero trusted passes and an ineligible result.
        return 0, total, False


def compare_candidate_evidence(candidates: list[CandidateEvidence]) -> dict[str, Any]:
    """Choose only among candidates with an explicit host attestation; otherwise abstain.

    The current project-controlled runners cannot issue this attestation. This function
    therefore abstains until a separate host-owned acceptance-test channel is implemented.
    Among equally passing candidates, prefer fewer changed bytes and fewer files as a
    conservative tie-breaker, not as a claim of superior design quality.
    """
    if not candidates:
        return {"status": "no_candidates", "selected_candidate_id": "", "candidates": []}
    rows = []
    eligible = []
    for item in candidates:
        passed_checks, total_checks, checks_consistent = item.check_coverage()
        passed = item.validation_ok and item.test_status == "PASSED" and checks_consistent
        row = {
            "candidate_id": item.candidate_id,
            "validation_ok": bool(item.validation_ok),
            "validation_errors": [str(x)[:500] for x in item.validation_errors[:20]],
            "test_status": item.test_status,
            "test_summary": str(item.test_report.get("summary", ""))[:1000],
            "changed_files": len(item.files),
            "patch_bytes": item.patch_bytes,
            "candidate_sha256": item.candidate_sha256,
            "passed_checks": passed_checks,
            "total_checks": total_checks,
            "checks_consistent": checks_consistent,
            "eligible_by_host_evidence": passed,
        }
        rows.append(row)
        if passed:
            eligible.append(item)
    if not eligible:
        return {
            "status": "abstained_no_verified_winner", "selected_candidate_id": "",
            "reason": "No candidate has an independently issued host-controlled acceptance-test attestation. Project-owned test output, configured simulations, visual manifests, SKIPPED, NO_TESTS, UNTRUSTED_TESTS, NOT_RUN, and NOT_APPLICABLE are not proof.",
            "candidates": rows,
        }
    selected = min(eligible, key=lambda x: (
        -(x.check_coverage()[0] / max(1, x.check_coverage()[1])),
        -x.check_coverage()[0], x.patch_bytes, len(x.files), x.candidate_id,
    ))
    return {
        "status": "selected_by_host_test_coverage_and_minimal_patch_tiebreak",
        "selected_candidate_id": selected.candidate_id,
        "selected_candidate_sha256": selected.candidate_sha256,
        "reason": "The selected candidate passed all reported host checks and had the strongest reported check coverage. Patch size is only a final tie-breaker; this does not establish design superiority, untested requirements, or absence of defects.",
        "candidates": rows,
    }
