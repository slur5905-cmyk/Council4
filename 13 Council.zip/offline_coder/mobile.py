"""Responsive phone/tablet web companion for the local-only coding council."""
from __future__ import annotations
import argparse, json, secrets, socket, ssl, threading, time, urllib.parse
from collections import deque
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from .config import load_settings
from .model_backend import build_model_router
from .knowledge import KnowledgeStore
from .council import CouncilRunner, apply_approved_result
from .web_search import search_web, format_search_context

PAGE = r"""<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover"><meta name="color-scheme" content="dark"><title>Offline Coding Council</title><style>
:root{color-scheme:dark;--bg:#0b1020;--panel:#151d30;--line:#2b3852;--text:#edf2ff;--muted:#a8b5ce;--accent:#8bb5ff}*{box-sizing:border-box}body{margin:0;background:var(--bg);color:var(--text);font:16px/1.5 system-ui,-apple-system,sans-serif}header{position:sticky;top:0;background:#0b1020ed;border-bottom:1px solid var(--line);padding:14px;z-index:2}h1{font-size:1.2rem;margin:0}header p,.muted{color:var(--muted);font-size:.9rem}header p{margin:3px 0 0}main{max-width:900px;margin:auto;padding:14px 14px 30px;display:grid;gap:12px}.card{background:var(--panel);border:1px solid var(--line);border-radius:15px;padding:15px;min-width:0}h2{font-size:1rem;margin:0 0 10px}label{display:block;font-size:.9rem;color:var(--muted);margin:10px 0 5px}textarea,input,button{font:inherit;border-radius:10px;width:100%;padding:12px;border:1px solid var(--line);background:#0c1426;color:var(--text)}textarea{min-height:140px;resize:vertical}button{background:var(--accent);color:#081020;font-weight:700;border:0;cursor:pointer;margin-top:10px;min-height:46px}button.secondary{background:#263651;color:var(--text)}button.danger{background:#6a282b;color:white}button:disabled{opacity:.45}.tabs{display:flex;gap:6px;overflow:auto;padding-bottom:8px}.tabs button{width:auto;white-space:nowrap;margin:0;padding:9px 12px;min-height:40px}pre{white-space:pre-wrap;overflow-wrap:anywhere;background:#0a1120;border:1px solid var(--line);padding:12px;border-radius:10px;max-height:55vh;overflow:auto;font:13px/1.5 ui-monospace,monospace}@media(min-width:760px){main{grid-template-columns:1fr 1fr}.wide{grid-column:1/-1}}
</style></head><body><header><h1>OFFLINE CODING COUNCIL</h1><p>One model + four role prompts unless distinct models are configured · manual Apply only</p></header><main><section class="card wide"><h2>Task</h2><p class="muted">The model runs on your computer. This phone page is a local-network remote control. One model with four role prompts is not four independent models.</p><label for="task">What should the council build, debug, or explain?</label><textarea id="task" placeholder="Describe the goal, constraints, expected behavior, and how to test it."></textarea><label for="webQuery">Search the public web (optional)</label><input id="webQuery" maxlength="300" placeholder="Research a library, API, error, or technique"><button id="searchWeb" class="secondary">Search web and attach sources</button><div id="webResults" class="muted" aria-live="polite"></div><button id="run">Run four role reviewers</button><div id="status" class="muted" aria-live="polite">Ready.</div></section><section class="card wide"><h2>Result</h2><div class="tabs" id="tabs"></div><div id="result"><p class="muted">Run a task to see analyses, code, attack findings, votes, and safety checks.</p></div><button id="apply" class="danger" disabled>Apply host-checked proposal</button><p class="muted">Host-side checks decide whether Apply is available. AI reviews and votes are advice only. Type APPLY and enter the one-time code printed in the computer terminal.</p></section><section class="card"><h2>Shared workspace</h2><div id="setup" class="muted">Loading local configuration…</div><button id="refreshFiles" class="secondary">Refresh project files</button><div id="files" class="muted" aria-live="polite">Loading files…</div><p class="muted">This is the same configured workspace used by the desktop app when both are running on the same computer.</p></section><section class="card"><h2>Safety rules</h2><ul class="muted"><li>No automatic code execution or shell commands.</li><li>Writes stay inside the selected workspace.</li><li>No secrets, protected controller files, or permission changes.</li><li>Model consensus never replaces your review.</li></ul></section></main><script nonce="__COUNCIL_CSP_NONCE__">
const token=new URLSearchParams(location.hash.slice(1)).get('token')||'';if(location.hash)history.replaceState(null,'',location.pathname+location.search);let result=null,active='Final answer';const views=['Final answer','Analyses','Cross-examination','Proposed code','Attack findings','Votes','Safety & audit'];const tabs=document.getElementById('tabs'),out=document.getElementById('result');for(const v of views){const b=document.createElement('button');b.className='secondary';b.textContent=v;b.onclick=()=>{active=v;render()};tabs.appendChild(b)}async function api(path,body){const headers={'Authorization':'Bearer '+token};if(body)headers['Content-Type']='application/json';const r=await fetch(path,{method:body?'POST':'GET',headers,body:body?JSON.stringify(body):undefined});const d=await r.json();if(!r.ok)throw new Error(d.error||'Request failed');return d}function pre(t){const e=document.createElement('pre');e.textContent=t||'No content.';return e}function render(){for(const b of tabs.children)b.style.background=b.textContent===active?'var(--accent)':'#263651';out.replaceChildren();if(!result){out.textContent='No run yet.';return}let v='';if(active==='Final answer')v=[result.final_status,result.answer,result.summary,result.notes].filter(Boolean).join('\n\n');if(active==='Analyses')v=Object.entries(result.analyses||{}).map(([k,x])=>k+'\n'+x).join('\n\n');if(active==='Cross-examination')v=Object.entries(result.cross_reviews||{}).map(([k,x])=>k+'\n'+x).join('\n\n');if(active==='Proposed code')v=Object.entries(result.proposed_files||{}).map(([k,x])=>'FILE: '+k+'\n'+x).join('\n\n------------------------------\n\n');if(active==='Attack findings')v=(result.reviews||[]).map(r=>r.agent+' — '+r.vote+'\n'+JSON.stringify(r.findings||[],null,2)).join('\n\n');if(active==='Votes')v=(result.votes||[]).map(x=>x.agent+' — '+x.vote+'\n'+(x.reason||'')+'\nBlockers: '+JSON.stringify(x.remaining_blockers||[])).join('\n\n');if(active==='Safety & audit')v=JSON.stringify({model_profile:result.model_profile,safety_errors:result.safety_errors,safety_warnings:result.safety_warnings,can_apply:result.can_apply,report_path:result.report_path,candidate_path:result.candidate_path},null,2);out.appendChild(pre(v));document.getElementById('apply').disabled=!result.can_apply}document.getElementById('searchWeb').onclick=async()=>{const query=document.getElementById('webQuery').value.trim();if(!query){alert('Enter a web search query first.');return}if(!confirm('This exact query will be sent to an external public search provider:\n\n'+query+'\n\nContinue?'))return;const button=document.getElementById('searchWeb');button.disabled=true;document.getElementById('webResults').textContent='Searching public web results…';try{const d=await api('/search',{query});const box=document.getElementById('webResults');box.replaceChildren();const pre=document.createElement('pre');pre.textContent=d.context;box.appendChild(pre);const add=document.createElement('button');add.className='secondary';add.textContent='Add research to task';add.onclick=()=>{const task=document.getElementById('task');task.value=(task.value.trim()+'\n\n'+d.context).trim();document.getElementById('webResults').appendChild(document.createTextNode('\nAdded to task context. Treat snippets as untrusted and verify important claims.'))};box.appendChild(add)}catch(e){document.getElementById('webResults').textContent='Search failed: '+e.message}finally{button.disabled=false}};document.getElementById('run').onclick=async()=>{const task=document.getElementById('task').value.trim();if(!task){alert('Enter a task first.');return}document.getElementById('run').disabled=true;document.getElementById('apply').disabled=true;document.getElementById('status').textContent='Running local model through independent analyses, adversarial attacks, reviews, and votes. This can take a while.';try{const d=await api('/run',{task});result=d.result;document.getElementById('status').textContent=result.final_status;active='Final answer';render()}catch(e){document.getElementById('status').textContent='Error: '+e.message}finally{document.getElementById('run').disabled=false}};document.getElementById('apply').onclick=async()=>{if(!result?.can_apply)return;if(!confirm('Apply these files to the selected workspace? Existing files will be backed up. Review the proposal first.'))return;const typed=prompt('Type APPLY to confirm this write:');if(typed!=='APPLY')return;const applyCode=prompt('Enter the 9-digit one-time code printed in the computer terminal:');if(!/^\d{9}$/.test(applyCode||'')){alert('A valid 9-digit terminal code is required.');return}try{const d=await api('/apply',{run_id:result.run_id,confirm:typed,apply_code:applyCode});result=d.result;document.getElementById('status').textContent=result.final_status;render()}catch(e){alert(e.message)}};async function refreshFiles(){const box=document.getElementById('files');box.textContent='Loading project files…';try{const d=await api('/files');box.replaceChildren();if(!d.files.length){box.textContent='No project files found yet.';return}for(const f of d.files){const row=document.createElement('div');row.style.cssText='padding:8px 0;border-bottom:1px solid var(--line);overflow-wrap:anywhere';const name=document.createElement('strong');name.textContent=f.path;row.appendChild(name);const meta=document.createElement('div');meta.className='muted';meta.textContent=f.kind==='directory'?'Folder':`${f.size} bytes`;row.appendChild(meta);box.appendChild(row)}}catch(e){box.textContent='Unable to list files: '+e.message}}document.getElementById('refreshFiles').onclick=refreshFiles;api('/status').then(d=>document.getElementById('setup').textContent=d.status).catch(e=>document.getElementById('setup').textContent='Unable to connect: '+e.message);refreshFiles();
</script></body></html>"""

class SlidingWindowRateLimiter:
    """Small in-memory per-key request limiter with bounded key storage."""

    def __init__(self, max_keys: int = 2048):
        self.max_keys = max(32, int(max_keys))
        self._events: dict[str, deque[float]] = {}
        self._lock = threading.Lock()

    def allow(self, key: str, limit: int, window_seconds: float) -> bool:
        now = time.monotonic()
        cutoff = now - max(1.0, float(window_seconds))
        limit = max(1, int(limit))
        safe_key = str(key)[:200]
        with self._lock:
            events = self._events.get(safe_key)
            if events is None:
                if len(self._events) >= self.max_keys:
                    # Remove expired keys first; if still full, evict the oldest entry.
                    for old_key, old_events in list(self._events.items()):
                        while old_events and old_events[0] <= cutoff:
                            old_events.popleft()
                        if not old_events:
                            self._events.pop(old_key, None)
                    if len(self._events) >= self.max_keys:
                        oldest_key = min(self._events, key=lambda item: self._events[item][-1])
                        self._events.pop(oldest_key, None)
                events = deque()
                self._events[safe_key] = events
            while events and events[0] <= cutoff:
                events.popleft()
            if len(events) >= limit:
                return False
            events.append(now)
            return True


class BoundedThreadingHTTPServer(ThreadingHTTPServer):
    """Threaded HTTP server with a hard cap on simultaneously active handlers."""

    daemon_threads = True
    block_on_close = False
    request_queue_size = 16

    def __init__(self, server_address, RequestHandlerClass, max_workers: int = 8):
        self.max_workers = max(1, min(16, int(max_workers)))
        self._handler_slots = threading.BoundedSemaphore(self.max_workers)
        super().__init__(server_address, RequestHandlerClass)

    def process_request(self, request, client_address):
        if not self._handler_slots.acquire(blocking=False):
            try:
                request.sendall(
                    b"HTTP/1.1 503 Service Unavailable\r\n"
                    b"Connection: close\r\nContent-Length: 0\r\nRetry-After: 2\r\n\r\n"
                )
            except OSError:
                pass
            finally:
                self.shutdown_request(request)
            return
        try:
            super().process_request(request, client_address)
        except Exception:
            self._handler_slots.release()
            raise

    def process_request_thread(self, request, client_address):
        try:
            super().process_request_thread(request, client_address)
        finally:
            self._handler_slots.release()


def _read_json_object(raw: bytes) -> dict:
    """Parse a request body only when it is a JSON object, not an arbitrary value."""
    try:
        body = json.loads(raw or b"{}")
    except (json.JSONDecodeError, UnicodeDecodeError, TypeError) as exc:
        raise ValueError("Invalid JSON.") from exc
    if not isinstance(body, dict):
        raise ValueError("JSON request body must be an object.")
    return body


def _valid_bearer(authorization: str, token: str) -> bool:
    scheme, _, supplied = authorization.partition(" ")
    return scheme.lower() == "bearer" and bool(supplied) and secrets.compare_digest(supplied, token)


def _valid_apply_confirmation(typed: object, supplied_code: object, expected_code: str) -> bool:
    """Require a typed phrase and the current terminal-issued one-time code."""
    if not isinstance(typed, str) or typed != "APPLY":
        return False
    if not isinstance(supplied_code, str) or len(supplied_code) != 9 or not supplied_code.isdigit():
        return False
    return secrets.compare_digest(supplied_code, expected_code)


def lan_ip():
    s=socket.socket(socket.AF_INET,socket.SOCK_DGRAM)
    try:s.connect(("192.0.2.1",80));return s.getsockname()[0]
    except OSError:return "127.0.0.1"
    finally:s.close()

def _load_mobile_model(settings: dict):
    """Use the exact model backend and peer routing configured in the desktop app."""
    return build_model_router(settings)

def serve(host="127.0.0.1", port=8765, certfile=None, keyfile=None, allow_insecure_lan=False):
    is_loopback = str(host).strip().lower() in {"127.0.0.1", "localhost", "::1"}
    if not is_loopback and not (certfile and keyfile) and not allow_insecure_lan:
        raise SystemExit(
            "Refusing unencrypted mobile access on a non-loopback interface. "
            "Provide --certfile and --keyfile, use a VPN-secured path, or explicitly opt in with --allow-insecure-lan on a trusted private network."
        )
    settings=load_settings(); backend=settings.get("model_backend", "gguf"); model_path=str(settings.get("model_path","")).strip(); workspace=Path(str(settings.get("workspace_path","")).strip()).expanduser().resolve()
    if backend == "gguf" and (not model_path or not Path(model_path).is_file()):
        raise SystemExit("Choose an existing local GGUF model in desktop settings first. No API key is needed.")
    if not workspace.is_dir():raise SystemExit(f"Configured workspace folder does not exist: {workspace}")
    try:
        model = _load_mobile_model(settings)
    except Exception as exc:
        raise SystemExit(f"Could not initialize the configured local model backend: {exc}") from exc
    primary = model.primary
    primary_label = (Path(model_path).name if backend == "gguf" else f"{getattr(primary, 'model', 'local model')} at {settings.get('local_server_url', 'localhost')}")
    configured_roles = model.configured_roles()
    role_label = ", ".join(sorted(configured_roles)) if configured_roles else "primary model shared across all peers"
    token=secrets.token_urlsafe(32); mobile_csp_nonce=secrets.token_urlsafe(18); mobile_apply_code=f"{secrets.randbelow(1_000_000_000):09d}"; knowledge=KnowledgeStore(); state={"result":None,"busy":False,"apply_code":mobile_apply_code}; lock=threading.Lock()
    request_limiter = SlidingWindowRateLimiter()
    auth_failure_limiter = SlidingWindowRateLimiter()
    endpoint_limiter = SlidingWindowRateLimiter()
    class Handler(BaseHTTPRequestHandler):
        # Idle/slow clients must not hold a request thread indefinitely when LAN mode is enabled.
        def setup(self):
            self.request.settimeout(15)
            super().setup()
        def log_message(self,*args):pass
        def send_data(self,code,data,ctype="application/json; charset=utf-8"):
            raw=data.encode() if isinstance(data,str) else json.dumps(data,ensure_ascii=False).encode()
            self.send_response(code)
            self.send_header("Content-Type",ctype)
            self.send_header("Content-Length",str(len(raw)))
            self.send_header("Cache-Control","no-store")
            self.send_header("X-Content-Type-Options","nosniff")
            self.send_header("Referrer-Policy","no-referrer")
            self.send_header("X-Frame-Options","DENY")
            self.send_header("Content-Security-Policy", f"default-src 'none'; script-src 'nonce-{mobile_csp_nonce}'; style-src 'unsafe-inline'; connect-src 'self'; base-uri 'none'; form-action 'none'; frame-ancestors 'none'")
            self.end_headers()
            self.wfile.write(raw)
        def authorized(self):
            if _valid_bearer(self.headers.get("Authorization", ""), token):
                return True
            client = str(self.client_address[0])
            if not auth_failure_limiter.allow(client, 8, 60):
                self.send_data(429, {"error": "Too many failed authorization attempts. Try again in one minute."})
            else:
                self.send_data(403, {"error": "Missing or invalid access token."})
            return False
        def request_allowed(self, path):
            client = str(self.client_address[0])
            if not request_limiter.allow(client, 120, 60):
                self.send_data(429, {"error": "Request limit reached. Try again shortly."})
                return False
            return True
        def endpoint_allowed(self, path):
            client = str(self.client_address[0])
            limits = {"/search": 20, "/run": 6, "/apply": 10}
            if path in limits and not endpoint_limiter.allow(client + ":" + path, limits[path], 60):
                self.send_data(429, {"error": "This action is temporarily rate limited. Try again shortly."})
                return False
            return True
        def do_GET(self):
            path=urllib.parse.urlparse(self.path).path
            if not self.request_allowed(path): return
            # The static shell carries no data and can be served without a token.
            # The browser sends the secret only in Authorization headers after reading it
            # from a URL fragment, which is not transmitted in the initial HTTP request.
            if path=="/":return self.send_data(200,PAGE.replace("__COUNCIL_CSP_NONCE__", mobile_csp_nonce),"text/html; charset=utf-8")
            if not self.authorized():return
            if path=="/status":return self.send_data(200,{"status":f"Backend: {backend}\nPrimary model: {primary_label}\nPeer overrides: {role_label}\nWorkspace: {workspace}\nStop server to revoke mobile access."})
            if path=="/result":return self.send_data(200,{"result":state["result"]})
            if path=="/files":
                files=[]
                try:
                    for item in sorted(workspace.iterdir(), key=lambda x:(not x.is_dir(),x.name.lower())):
                        if item.name.startswith(".") and item.name not in {".github"}: continue
                        if item.is_symlink(): continue
                        if item.is_dir(): files.append({"path":item.name+"/","kind":"directory","size":0})
                        elif item.is_file(): files.append({"path":item.name,"kind":"file","size":item.stat().st_size})
                        if len(files)>=300: break
                except OSError as e:return self.send_data(500,{"error":f"Could not list workspace: {e}"})
                return self.send_data(200,{"workspace":str(workspace),"files":files})
            return self.send_data(404,{"error":"Not found"})
        def do_POST(self):
            path=urllib.parse.urlparse(self.path).path
            if not self.request_allowed(path): return
            if not self.authorized():return
            if not self.endpoint_allowed(path): return
            try:
                raw_length = self.headers.get("Content-Length")
                if raw_length is None:return self.send_data(411,{"error":"Content-Length is required."})
                if not raw_length.isdigit():return self.send_data(400,{"error":"Invalid content length."})
                length=int(raw_length)
                if length <= 0:return self.send_data(400,{"error":"A JSON request body is required."})
                if length>1_000_000:return self.send_data(413,{"error":"Request too large."})
                content_type = self.headers.get("Content-Type", "").split(";", 1)[0].strip().lower()
                if content_type != "application/json":
                    return self.send_data(415,{"error":"Content-Type must be application/json."})
                raw = self.rfile.read(length)
                if len(raw) != length:return self.send_data(400,{"error":"Request body ended before Content-Length bytes were received."})
                body=_read_json_object(raw)
            except ValueError as exc:return self.send_data(400,{"error":str(exc)})
            except (OSError, UnicodeDecodeError):return self.send_data(400,{"error":"Invalid JSON request body."})
            if path=="/search":
                query=body.get("query")
                if not isinstance(query,str) or not query.strip():return self.send_data(400,{"error":"A search query is required."})
                if len(query)>300:return self.send_data(400,{"error":"Search query must be 300 characters or fewer."})
                try:
                    results=search_web(query,limit=6,timeout=10)
                    return self.send_data(200,{"query":query,"results":results,"context":format_search_context(query,results)})
                except Exception as e:return self.send_data(502,{"error":str(e)[:500]})
            if path=="/run":
                if not isinstance(body.get("task"),str) or not body["task"].strip():return self.send_data(400,{"error":"A task is required."})
                with lock:
                    if state["busy"]:return self.send_data(409,{"error":"A council run is already active."})
                    state["busy"]=True
                try:
                    runner=CouncilRunner(model,workspace,allow_self_edit=bool(settings.get("allow_self_edit",False)),max_context_chars=settings.get("max_context_chars",12000),review_rounds=settings.get("review_rounds",1),knowledge=knowledge,max_tokens=settings.get("max_tokens",4096),web_research_enabled=False,max_peer_workers=settings.get("max_peer_workers",2),resource_settings=settings)
                    result=runner.run_task(body["task"][:12000]);state["result"]=json.loads(json.dumps(result,default=lambda o:o.__dict__));return self.send_data(200,{"result":state["result"]})
                except Exception as e:return self.send_data(500,{"error":str(e)[:1000]})
                finally:
                    with lock:state["busy"]=False
            if path=="/apply":
                # Serialize apply against runs and other applies; otherwise two requests can
                # both pass the initial state check before either updates workspace hashes.
                with lock:
                    if state["busy"]:return self.send_data(409,{"error":"A council run or apply is already active."})
                    state["busy"]=True
                try:
                    r=state["result"]
                    if not r or not r.get("can_apply"):return self.send_data(409,{"error":"No proposal passed host validation for manual Apply."})
                    if body.get("run_id")!=r.get("run_id") or not _valid_apply_confirmation(body.get("confirm"), body.get("apply_code"), state["apply_code"]):
                        return self.send_data(403,{"error":"Apply confirmation failed. Type APPLY and use the current one-time code printed in the computer terminal."})
                    from .council import RunResult
                    obj=RunResult(**{k:v for k,v in r.items() if k in RunResult.__dataclass_fields__})
                    apply_approved_result(obj,allow_self_edit=bool(settings.get("allow_self_edit",False)))
                    state["result"]=json.loads(json.dumps(obj,default=lambda o:o.__dict__))
                    state["apply_code"]=f"{secrets.randbelow(1_000_000_000):09d}"
                    print(f"\nNEXT MOBILE APPLY CODE: {state['apply_code']} (single-use; keep this terminal private)", flush=True)
                    return self.send_data(200,{"result":state["result"]})
                except Exception as e:return self.send_data(400,{"error":str(e)[:1000]})
                finally:
                    with lock:state["busy"]=False
            return self.send_data(404,{"error":"Not found"})
    server=BoundedThreadingHTTPServer((host,port),Handler,max_workers=8)
    if certfile and keyfile:
        try:
            tls_context = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
            tls_context.minimum_version = ssl.TLSVersion.TLSv1_2
            tls_context.load_cert_chain(certfile=certfile, keyfile=keyfile)
            server.socket = tls_context.wrap_socket(server.socket, server_side=True)
        except (OSError, ssl.SSLError) as exc:
            server.server_close()
            raise SystemExit(f"Could not enable mobile HTTPS: {exc}") from exc
    ip=lan_ip();scheme="https" if certfile and keyfile else "http"
    print("\nOFFLINE CODING COUNCIL — MOBILE MODE (local model, no cloud API)")
    print(f"Computer: {scheme}://127.0.0.1:{port}/#token={token}")
    if host in {"0.0.0.0", "::"}:
        print(f"Phone on same network: {scheme}://{ip}:{port}/#token={token}")
        if scheme == "http":
            print("WARNING: LAN mode is unencrypted. Use a trusted private network only; never use public Wi-Fi or port-forward this service. Prefer --certfile and --keyfile or a VPN-secured path.")
    elif host not in {"127.0.0.1", "localhost"}:
        print(f"Bound to {host}:{port}. Share only with trusted devices on a network you control.")
    else:
        print("Local-only mode: other devices cannot connect. To intentionally expose it on your private LAN, restart with --host 0.0.0.0.")
    print(f"ONE-TIME MOBILE APPLY CODE: {mobile_apply_code} (required in addition to typing APPLY; keep this terminal private)")
    print("The token is placed in the URL fragment and then removed from browser history; API calls use an Authorization header. Apply also requires a single-use terminal code. Stop with Ctrl+C to revoke mobile access.")
    try:server.serve_forever()
    except KeyboardInterrupt:print("Stopping mobile server.")
    finally:server.server_close()
def main():
    p=argparse.ArgumentParser(description="Responsive phone/tablet UI for the local coding council")
    p.add_argument("--host",default="127.0.0.1")
    p.add_argument("--port",type=int,default=8765)
    p.add_argument("--certfile",default="",help="Optional TLS certificate for HTTPS LAN access.")
    p.add_argument("--keyfile",default="",help="Optional TLS private key for HTTPS LAN access.")
    p.add_argument("--allow-insecure-lan",action="store_true",help="Explicitly allow plaintext HTTP on a trusted private LAN (not recommended).")
    a=p.parse_args()
    serve(a.host,a.port,a.certfile or None,a.keyfile or None,a.allow_insecure_lan)
if __name__=="__main__":main()
