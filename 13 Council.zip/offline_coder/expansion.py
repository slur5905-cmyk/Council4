"""Local resource assessment, bounded persistent memory, and resumable checkpoints."""
from __future__ import annotations

import hashlib
import json
import os
import platform
import re
import shutil
import sqlite3
import subprocess
import sys
import threading
import time
import uuid
from contextlib import contextmanager
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from .config import APP_DIR
from .safety import redact_sensitive_text

MEMORY_DB_PATH = APP_DIR / "expansion.sqlite3"
MEMORY_KINDS = {"project", "fact", "experience", "working"}
MEMORY_STATUSES = {"successful", "unsuccessful", "neutral"}
TOOLS_TO_DISCOVER = ("git", "python", "pytest", "docker", "ollama", "llama-server")
_WORD_RE = re.compile(r"[A-Za-z0-9_+-]{3,}")


def _available_memory() -> tuple[int | None, int | None]:
    total = available = None
    try:
        page_size = int(os.sysconf("SC_PAGE_SIZE"))
        total_pages = int(os.sysconf("SC_PHYS_PAGES"))
        total = page_size * total_pages
        available_pages = int(os.sysconf("SC_AVPHYS_PAGES"))
        available = page_size * available_pages
    except (AttributeError, OSError, TypeError, ValueError):
        pass
    if sys.platform.startswith("linux"):
        try:
            values = {}
            for line in Path("/proc/meminfo").read_text(encoding="ascii").splitlines():
                key, raw = line.split(":", 1)
                values[key] = int(raw.strip().split()[0]) * 1024
            total = values.get("MemTotal", total)
            available = values.get("MemAvailable", available)
        except (OSError, ValueError, IndexError):
            pass
        try:
            limit_text = Path("/sys/fs/cgroup/memory.max").read_text(encoding="ascii").strip()
            usage_text = Path("/sys/fs/cgroup/memory.current").read_text(encoding="ascii").strip()
            if limit_text != "max":
                cgroup_limit = int(limit_text)
                cgroup_available = max(0, cgroup_limit - int(usage_text))
                total = min(total, cgroup_limit) if total is not None else cgroup_limit
                available = min(available, cgroup_available) if available is not None else cgroup_available
        except (OSError, ValueError):
            pass
    if total is None or available is None:
        try:
            import psutil

            memory = psutil.virtual_memory()
            total = total if total is not None else int(memory.total)
            available = available if available is not None else int(memory.available)
        except (ImportError, OSError, AttributeError):
            pass
    return total, available


def _process_memory() -> tuple[int | None, int | None]:
    rss = peak = None
    if sys.platform.startswith("linux"):
        try:
            for line in Path("/proc/self/status").read_text(encoding="ascii").splitlines():
                if line.startswith("VmRSS:"):
                    rss = int(line.split()[1]) * 1024
                    break
        except (OSError, ValueError, IndexError):
            pass
    try:
        import resource

        peak_value = int(resource.getrusage(resource.RUSAGE_SELF).ru_maxrss)
        peak = peak_value if sys.platform == "darwin" else peak_value * 1024
    except (ImportError, OSError, ValueError):
        pass
    return rss, peak


def adaptive_worker_limit(configured_limit: int, available_bytes: int | None) -> int:
    """Reduce only the caller's requested concurrency when host memory is constrained."""
    configured = max(1, min(4, int(configured_limit)))
    if available_bytes is None:
        return 1
    if available_bytes < 4 * 1024**3:
        return 1
    if available_bytes < 8 * 1024**3:
        return min(configured, 2)
    return configured


def _gpu_inventory() -> dict[str, Any]:
    """Read GPU details from installed vendor tools; never installs or downloads anything."""
    executable = shutil.which("nvidia-smi")
    if not executable:
        return {"available": None, "devices": [], "status": "No supported GPU discovery tool found."}
    try:
        completed = subprocess.run(
            [
                executable,
                "--query-gpu=name,memory.total,memory.free,utilization.gpu",
                "--format=csv,noheader,nounits",
            ],
            capture_output=True,
            text=True,
            timeout=2,
            check=False,
        )
    except (OSError, subprocess.SubprocessError) as exc:
        return {"available": None, "devices": [], "status": f"GPU discovery failed: {exc}"}
    if completed.returncode != 0:
        detail = (completed.stderr or completed.stdout).strip()[:300]
        return {"available": None, "devices": [], "status": detail or "nvidia-smi returned an error."}
    devices = []
    for line in completed.stdout.splitlines():
        parts = [part.strip() for part in line.split(",", 3)]
        if len(parts) != 4:
            continue
        try:
            devices.append({
                "name": parts[0][:120],
                "total_vram_bytes": int(parts[1]) * 1024**2,
                "available_vram_bytes": int(parts[2]) * 1024**2,
                "utilization_percent": int(parts[3]),
            })
        except ValueError:
            continue
    return {
        "available": bool(devices),
        "devices": devices,
        "status": "Measured using nvidia-smi." if devices else "No readable NVIDIA devices were reported.",
    }


def _network_inventory() -> dict[str, Any]:
    """Report local interface hints without sending external network traffic."""
    interfaces: list[str] = []
    try:
        interfaces = [name[:100] for _, name in __import__("socket").if_nameindex()]
    except (OSError, AttributeError):
        pass
    has_default_route = None
    if sys.platform.startswith("linux"):
        try:
            routes = Path("/proc/net/route").read_text(encoding="ascii").splitlines()[1:]
            has_default_route = any(
                len(row.split()) > 1 and row.split()[1] == "00000000"
                for row in routes
            )
        except (OSError, UnicodeError):
            pass
    return {
        "interfaces": interfaces,
        "default_route_detected": has_default_route,
        "external_connectivity_tested": False,
        "note": "No external connection was attempted; interface/route presence does not prove Internet access.",
    }


def rank_model_candidates(
    candidates: list[dict[str, Any]],
    available_memory_bytes: int | None,
    task_type: str = "coding",
    minimum_context: int = 0,
    available_vram_bytes: int | None = None,
) -> dict[str, Any]:
    """Rank candidates by measured task quality and fit, never by parameter count alone.

    Candidate performance scores are optional measurements in [0, 1]. The observed
    score uses measured dimensions only, while ordering uses a conservative score
    that assigns neutral evidence to unmeasured dimensions. Coverage is exposed so
    callers can distinguish a high but narrow score from broad benchmark evidence.
    """
    task_dimension = "coding" if task_type == "coding" else "reasoning"
    ranked = []
    rejected = []
    for candidate in candidates:
        if not isinstance(candidate, dict) or not isinstance(candidate.get("id"), str):
            continue
        model_id = candidate["id"][:160]
        memory = candidate.get("estimated_memory_bytes")
        vram = candidate.get("estimated_vram_bytes")
        context = candidate.get("context_tokens")
        if memory is not None and (not isinstance(memory, int) or memory < 0):
            rejected.append({"id": model_id, "reason": "invalid memory estimate"})
            continue
        if vram is not None and (not isinstance(vram, int) or vram < 0):
            rejected.append({"id": model_id, "reason": "invalid VRAM estimate"})
            continue
        if context is not None and (not isinstance(context, int) or context < 0):
            rejected.append({"id": model_id, "reason": "invalid context capacity"})
            continue
        if available_memory_bytes is not None and memory is not None and memory > available_memory_bytes:
            rejected.append({"id": model_id, "reason": "estimated memory exceeds currently available RAM"})
            continue
        if available_vram_bytes is not None and vram is not None and vram > available_vram_bytes:
            rejected.append({"id": model_id, "reason": "estimated VRAM exceeds currently available GPU memory"})
            continue
        if context is not None and context < minimum_context:
            rejected.append({"id": model_id, "reason": "context capacity is below task requirement"})
            continue
        measurements = candidate.get("benchmarks", {})
        measurements = measurements if isinstance(measurements, dict) else {}
        weights = {
            task_dimension: 0.40, "tool_use": 0.22, "reliability": 0.18,
            "context": 0.10, "speed": 0.10,
        }
        known = {
            key: float(value)
            for key, value in measurements.items()
            if key in weights
            and isinstance(value, (int, float))
            and not isinstance(value, bool)
            and 0 <= value <= 1
        }
        measured_weight = sum(weights[key] for key in known)
        # Keep the observed score separate from the conservative ranking score.
        # Missing benchmark dimensions must not disappear from the denominator: a
        # near-perfect score on one narrow test is weaker evidence than a strong
        # score measured across the task-relevant dimensions. Unknown dimensions
        # receive a neutral prior (0.5), not an assumed perfect score.
        observed_score = (
            sum(known[key] * weights[key] for key in known) / measured_weight
            if measured_weight else None
        )
        evidence_adjusted_score = (
            sum(known[key] * weights[key] for key in known)
            + 0.5 * (1.0 - measured_weight)
            if known else None
        )
        ranked.append({
            "id": model_id,
            "score": observed_score,
            "evidence_adjusted_score": evidence_adjusted_score,
            "task_quality_measured": task_dimension in known,
            "measured_dimensions": sorted(known),
            "measurement_coverage": round(measured_weight, 3),
            "estimated_memory_bytes": memory,
            "estimated_vram_bytes": vram,
            "context_tokens": context,
            "quantization": str(candidate.get("quantization", "unknown"))[:40],
        })
    ranked.sort(key=lambda item: (
        item["evidence_adjusted_score"] is not None,
        item["evidence_adjusted_score"] if item["evidence_adjusted_score"] is not None else -1,
        item["measurement_coverage"],
        item["score"] if item["score"] is not None else -1,
        item["context_tokens"] or 0,
    ), reverse=True)
    selected = next((
        item for item in ranked
        if item["score"] is not None and item["task_quality_measured"]
    ), None)
    selection_note = None
    if selected is not None:
        selection_note = (
            "Task-specific performance is measured, but benchmark coverage is limited; treat this as provisional."
            if selected["measurement_coverage"] < 0.8 else
            "Task-specific performance and broad benchmark coverage are measured."
        )
    return {
        "selected": selected,
        "ranked": ranked,
        "rejected": rejected,
        "status": "measured recommendation" if selected else "insufficient task-specific benchmark evidence",
        "selection_note": selection_note,
        "task_dimension": task_dimension,
    }


class ResourceMonitor:
    """Low-frequency resource sampler; snapshots are reused between Council phases."""

    def __init__(self, settings: dict[str, Any] | None = None, interval_seconds: float = 10.0,
                 active_tasks: int = 0):
        self.settings = settings if isinstance(settings, dict) else {}
        self.interval_seconds = max(5.0, float(interval_seconds))
        self._stop = threading.Event()
        self._lock = threading.Lock()
        self._snapshot: dict[str, Any] = {}
        self._thread: threading.Thread | None = None
        self._active_tasks = max(0, int(active_tasks))
        self._active_workers = 0
        self._peak_active_workers = 0

    def _capture(self) -> dict[str, Any]:
        with self._lock:
            active_tasks = self._active_tasks
            active_workers = self._active_workers
            peak_workers = self._peak_active_workers
        snapshot = inspect_resources(
            self.settings, active_workers=active_workers, active_tasks=active_tasks
        )
        snapshot["workers"]["peak_active_workers"] = peak_workers
        return snapshot

    def start(self) -> None:
        if self._thread is not None:
            return
        self._snapshot = self._capture()
        self._thread = threading.Thread(target=self._sample, name="council-resource-monitor", daemon=True)
        self._thread.start()

    def _sample(self) -> None:
        while not self._stop.wait(self.interval_seconds):
            snapshot = self._capture()
            with self._lock:
                active_workers = self._active_workers
                snapshot["workers"]["active_workers"] = active_workers
                snapshot["workers"]["available_peer_slots"] = max(
                    0, snapshot["workers"]["adaptive_peer_limit"] - active_workers
                )
                snapshot["workers"]["peak_active_workers"] = self._peak_active_workers
                self._snapshot = snapshot

    def set_active_workers(self, count: int) -> None:
        active = max(0, int(count))
        with self._lock:
            self._active_workers = active
            self._peak_active_workers = max(self._peak_active_workers, active)
            if self._snapshot:
                self._snapshot["workers"]["active_workers"] = active
                self._snapshot["workers"]["available_peer_slots"] = max(
                    0, self._snapshot["workers"]["adaptive_peer_limit"] - active
                )
                self._snapshot["workers"]["peak_active_workers"] = self._peak_active_workers

    def snapshot(self) -> dict[str, Any]:
        with self._lock:
            return json.loads(json.dumps(self._snapshot))

    def stop(self) -> None:
        self._stop.set()
        if self._thread is not None:
            self._thread.join(timeout=self.interval_seconds + 1)
            self._thread = None


def inspect_resources(
    settings: dict[str, Any] | None = None,
    app_dir: Path = APP_DIR,
    active_workers: int | None = None,
    active_tasks: int = 0,
) -> dict[str, Any]:
    """Return observed host capacity separately from configured limits and estimates."""
    settings = settings if isinstance(settings, dict) else {}
    total_ram, free_ram = _available_memory()
    rss, peak_rss = _process_memory()
    cpu_count = _effective_cpu_count()
    try:
        load_average = list(os.getloadavg())
    except (AttributeError, OSError):
        load_average = None
    storage_free = storage_total = None
    try:
        disk_path = Path(app_dir).expanduser()
        while not disk_path.exists() and disk_path != disk_path.parent:
            disk_path = disk_path.parent
        usage = shutil.disk_usage(disk_path)
        storage_free, storage_total = usage.free, usage.total
    except OSError:
        pass

    configured_workers = max(1, min(4, int(settings.get("max_peer_workers", 1) or 1)))
    effective_workers = adaptive_worker_limit(configured_workers, free_ram)
    gpu = _gpu_inventory()
    network = _network_inventory()
    minimum_context = settings.get("minimum_context_tokens", 0)
    if not isinstance(minimum_context, int) or isinstance(minimum_context, bool):
        minimum_context = 0
    candidates = settings.get("model_candidates", [])
    model_selection = rank_model_candidates(
        candidates if isinstance(candidates, list) else [],
        free_ram,
        task_type=str(settings.get("task_type", "coding")),
        minimum_context=max(0, minimum_context),
        available_vram_bytes=max(
            (item["available_vram_bytes"] for item in gpu.get("devices", [])),
            default=None,
        ),
    )
    model_path = str(settings.get("model_path") or "")
    model_size = None
    model_compatibility = "not assessed"
    if settings.get("model_backend", "gguf") == "gguf" and model_path:
        try:
            model_file = Path(model_path).expanduser()
            model_size = model_file.stat().st_size
            if model_file.is_file() and model_file.suffix.lower() == ".gguf":
                model_compatibility = (
                    "estimated-fit"
                    if free_ram is not None and model_size * 1.3 < free_ram
                    else "unknown-or-insufficient-memory"
                )
            else:
                model_compatibility = "incompatible-file-type"
        except OSError:
            model_compatibility = "unavailable-or-unreadable"

    bottlenecks: list[str] = []
    opportunities: list[str] = []
    if free_ram is not None and free_ram < 2 * 1024**3:
        bottlenecks.append("Low available system RAM")
        opportunities.append("Use one peer worker; consider a smaller already-installed local model.")
    if storage_free is not None and storage_free < 1024**3:
        bottlenecks.append("Less than 1 GiB of free storage on the memory database volume")
        opportunities.append("Review cache/model files manually; no user data will be removed automatically.")
    if model_path and model_size is None:
        bottlenecks.append("Configured GGUF model file is unavailable or unreadable")
    if model_compatibility == "unknown-or-insufficient-memory":
        bottlenecks.append("Configured model may exceed available RAM; model load compatibility is not guaranteed")
    if configured_workers > effective_workers:
        bottlenecks.append("Configured peer concurrency exceeds the conservative RAM-based limit")
    if not bottlenecks:
        opportunities.append("No measured critical resource bottleneck; retain current settings until a benchmark justifies a change.")

    hardware_profile = (
        "constrained" if free_ram is not None and free_ram < 4 * 1024**3
        else "standard" if free_ram is not None and free_ram < 16 * 1024**3
        else "expanded" if free_ram is not None
        else "unknown"
    )
    return {
        "captured_at": datetime.now(timezone.utc).isoformat(),
        "hardware_profile": {
            "tier": hardware_profile,
            "purpose": "Resource scheduling hint only; it does not disable task capabilities.",
            "adaptive_peer_limit": effective_workers,
            "model_recommendation": model_selection["selected"],
            "model_recommendation_status": model_selection["status"],
        },
        "cpu": {
            "logical_cores": cpu_count,
            "architecture": platform.machine() or "unknown",
            "physical_cores": _physical_cpu_count(),
            "load_average_1_5_15": load_average,
            "configured_threads": settings.get("n_threads"),
        },
        "memory": {
            "total_bytes": total_ram,
            "available_bytes": free_ram,
            "process_rss_bytes": rss,
            "process_peak_rss_bytes": peak_rss,
        },
        "storage": {"total_bytes": storage_total, "free_bytes": storage_free},
        "gpu": gpu,
        "network": network,
        "persistent_memory": {
            "database_path": str(Path(app_dir).expanduser() / "expansion.sqlite3"),
            "configured_limit_bytes": settings.get("memory_max_bytes", 134217728),
        },
        "context": {
            "configured_tokens": settings.get("n_ctx"),
            "configured_context_chars": settings.get("max_context_chars"),
            "current_usage": "Not reported by the configured model backend",
        },
        "workers": {
            "active_tasks": max(0, int(active_tasks)),
            "active_workers": max(0, int(active_workers)) if active_workers is not None else None,
            "configured_peer_limit": configured_workers,
            "adaptive_peer_limit": effective_workers,
            "available_peer_slots": max(0, effective_workers - max(0, int(active_workers))) if active_workers is not None else None,
        },
        "model": {
            "backend": settings.get("model_backend", "gguf"),
            "configured_path_or_endpoint": model_path or (
                str(settings.get("local_server_url", "")) if settings.get("model_backend") == "local-server" else ""
            ),
            "file_bytes": model_size,
            "estimated_compatibility": model_compatibility,
            "compatibility_note": "File-size heuristics are not a model-load test; runtime, KV-cache, backend, and driver constraints may still prevent loading.",
            "capabilities": "Not benchmarked; context and output limits are configuration, not measured capability.",
        },
        "bottlenecks": bottlenecks,
        "opportunities": opportunities,
    }


def _physical_cpu_count() -> int | None:
    try:
        import psutil

        return psutil.cpu_count(logical=False)
    except (ImportError, OSError, AttributeError):
        return None


def _effective_cpu_count() -> int | None:
    count = os.cpu_count()
    if sys.platform.startswith("linux"):
        try:
            quota_text, period_text = Path("/sys/fs/cgroup/cpu.max").read_text(encoding="ascii").split()
            if quota_text != "max":
                quota_count = max(1, int(quota_text) // int(period_text))
                count = min(count, quota_count) if count is not None else quota_count
        except (OSError, ValueError, ZeroDivisionError):
            pass
    try:
        process_count = os.process_cpu_count()
        if process_count is not None:
            count = min(count, process_count) if count is not None else process_count
    except AttributeError:
        pass
    return count


def discover_local_tools() -> list[dict[str, str]]:
    """Locate a small allowlist of executables; never install, invoke, or approve them."""
    tools = []
    for name in TOOLS_TO_DISCOVER:
        path = shutil.which(name)
        tools.append({
            "name": name,
            "path": path or "",
            "status": "detected — not integrated; source, license, security, and compatibility review required"
            if path else "not found",
        })
    return tools


def _memory_digest(
    kind: str,
    project: str,
    summary: str,
    content: str,
    tags: str,
    status: str,
    version: int,
    supersedes: int | None = None,
    created_at: str | None = None,
    format_version: int = 1,
) -> str:
    values = [kind, project, summary, content, tags, status, version]
    if format_version >= 2:
        values.extend([supersedes, created_at])
    payload = json.dumps(values, ensure_ascii=False, separators=(",", ":"))
    return hashlib.sha256(payload.encode("utf-8")).hexdigest()


class NullExpansionStore:
    """No-op adapter used when optional advanced telemetry/memory is disabled."""

    enabled = False

    def start_checkpoint(self, task: str, task_id: str | None = None) -> str:
        return ""

    def update_checkpoint(self, task_id: str, stage: str, **values: Any) -> None:
        return None

    def get_checkpoint(self, task_id: str) -> dict[str, Any] | None:
        return None

    def list_checkpoints(self, include_completed: bool = False, limit: int = 100) -> list[dict[str, Any]]:
        return []

    def search(self, query: str, limit: int = 10, project: str = "") -> list[dict[str, Any]]:
        return []

    def add_memory(self, *args: Any, **kwargs: Any) -> None:
        return None

    def memory_status(self) -> dict[str, Any]:
        return {
            "records": 0, "intact_records": 0, "integrity_failures": 0,
            "checkpoint_records": 0, "database_bytes": 0,
            "configured_limit_bytes": 0, "search_index": "disabled",
        }


class ExpansionStore:
    """Append-only, hash-checked memory and task checkpoints in local SQLite storage."""

    def __init__(self, db_path: Path = MEMORY_DB_PATH, max_db_bytes: int = 134217728):
        self.db_path = Path(db_path).expanduser()
        self.max_db_bytes = max(1_048_576, min(4_294_967_296, int(max_db_bytes)))
        if self.db_path.is_symlink():
            raise ValueError(f"Refusing to use a symlink as the Council memory database: {self.db_path}")
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        self._fts_available = False
        with self._connect() as db:
            db.execute(
                """CREATE TABLE IF NOT EXISTS memories (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    kind TEXT NOT NULL,
                    project TEXT NOT NULL,
                    summary TEXT NOT NULL,
                    content TEXT NOT NULL,
                    tags TEXT NOT NULL,
                    status TEXT NOT NULL,
                    version INTEGER NOT NULL,
                    supersedes INTEGER,
                    digest TEXT NOT NULL,
                    digest_version INTEGER NOT NULL DEFAULT 1,
                    created_at TEXT NOT NULL,
                    UNIQUE(kind, project, digest)
                )"""
            )
            memory_columns = {row["name"] for row in db.execute("PRAGMA table_info(memories)").fetchall()}
            if "digest_version" not in memory_columns:
                db.execute("ALTER TABLE memories ADD COLUMN digest_version INTEGER NOT NULL DEFAULT 1")
            db.execute("CREATE INDEX IF NOT EXISTS memories_kind_project ON memories(kind, project, id)")
            db.execute(
                """CREATE TABLE IF NOT EXISTS checkpoints (
                    task_id TEXT PRIMARY KEY,
                    task TEXT NOT NULL,
                    stage TEXT NOT NULL,
                    status TEXT NOT NULL,
                    subtasks_json TEXT NOT NULL,
                    completed_json TEXT NOT NULL,
                    notes TEXT NOT NULL,
                    state_json TEXT NOT NULL DEFAULT '{}',
                    digest TEXT NOT NULL,
                    created_at TEXT NOT NULL,
                    updated_at TEXT NOT NULL
                )"""
            )
            checkpoint_columns = {
                row["name"] for row in db.execute("PRAGMA table_info(checkpoints)").fetchall()
            }
            if "state_json" not in checkpoint_columns:
                db.execute("ALTER TABLE checkpoints ADD COLUMN state_json TEXT NOT NULL DEFAULT '{}'")
            try:
                db.execute(
                    """CREATE VIRTUAL TABLE IF NOT EXISTS memories_fts USING fts5(
                        summary, content, tags, content='memories', content_rowid='id'
                    )"""
                )
                db.execute(
                    """CREATE TRIGGER IF NOT EXISTS memories_ai AFTER INSERT ON memories BEGIN
                        INSERT INTO memories_fts(rowid, summary, content, tags)
                        VALUES (new.id, new.summary, new.content, new.tags);
                    END"""
                )
                db.execute(
                    """CREATE TRIGGER IF NOT EXISTS memories_ad AFTER DELETE ON memories BEGIN
                        INSERT INTO memories_fts(memories_fts, rowid, summary, content, tags)
                        VALUES ('delete', old.id, old.summary, old.content, old.tags);
                    END"""
                )
                db.execute("INSERT INTO memories_fts(memories_fts) VALUES ('rebuild')")
                self._fts_available = True
            except sqlite3.OperationalError:
                self._fts_available = False
        try:
            self.db_path.chmod(0o600)
        except OSError:
            pass

    @contextmanager
    def _connect(self):
        db = sqlite3.connect(self.db_path, timeout=5.0)
        db.row_factory = sqlite3.Row
        try:
            page_size = int(db.execute("PRAGMA page_size").fetchone()[0])
            page_limit = self.max_db_bytes // page_size
            db.execute(f"PRAGMA max_page_count = {page_limit}")
            page_count = int(db.execute("PRAGMA page_count").fetchone()[0])
            if page_count > page_limit:
                raise OSError(
                    f"Council memory database already exceeds its configured {self.max_db_bytes}-byte limit."
                )
            yield db
            db.commit()
        except Exception:
            db.rollback()
            raise
        finally:
            db.close()

    def _ensure_capacity(self, incoming_bytes: int) -> None:
        try:
            current_bytes = self.db_path.stat().st_size
        except FileNotFoundError:
            current_bytes = 0
        if current_bytes + max(0, incoming_bytes) > self.max_db_bytes:
            raise OSError(
                f"Council memory limit reached ({self.max_db_bytes} bytes); no existing memory was changed."
            )

    @staticmethod
    def _text(value: Any, limit: int) -> str:
        return redact_sensitive_text(str(value or "").strip())[:limit]

    @classmethod
    def _safe_checkpoint_state(cls, value: Any) -> Any:
        if isinstance(value, str):
            return redact_sensitive_text(value)
        if isinstance(value, dict):
            return {str(key)[:200]: cls._safe_checkpoint_state(item) for key, item in value.items()}
        if isinstance(value, (list, tuple)):
            return [cls._safe_checkpoint_state(item) for item in value[:1000]]
        if value is None or type(value) in {bool, int, float}:
            return value
        raise ValueError(f"Unsupported checkpoint state value: {type(value).__name__}")

    def add_memory(
        self,
        kind: str,
        summary: str,
        content: str,
        project: str = "",
        tags: list[str] | tuple[str, ...] = (),
        status: str = "neutral",
        supersedes: int | None = None,
    ) -> int:
        if kind not in MEMORY_KINDS or status not in MEMORY_STATUSES:
            raise ValueError("Memory kind or outcome status is not supported.")
        safe_summary = self._text(summary, 1200)
        safe_content = self._text(content, 12000)
        safe_project = self._text(project, 400)
        safe_tags = sorted({self._text(tag, 80) for tag in tags if self._text(tag, 80)})
        if not safe_summary or not safe_content:
            raise ValueError("Memory summary and content are required.")
        if len(safe_tags) > 40:
            raise ValueError("Memory entries may contain at most 40 tags.")
        tags_json = json.dumps(safe_tags, ensure_ascii=False, separators=(",", ":"))
        with self._connect() as db:
            duplicate = db.execute(
                """SELECT * FROM memories WHERE kind=? AND project=? AND summary=? AND content=?
                   AND tags=? AND status=? AND supersedes IS ? ORDER BY id LIMIT 1""",
                (kind, safe_project, safe_summary, safe_content, tags_json, status, supersedes),
            ).fetchone()
            if duplicate is not None:
                if not self._row_is_intact(duplicate):
                    raise ValueError("An existing matching memory entry failed its integrity check.")
                return int(duplicate["id"])
            version = 1
            if supersedes is not None:
                previous = db.execute("SELECT * FROM memories WHERE id=?", (int(supersedes),)).fetchone()
                if previous is None:
                    raise ValueError("The memory entry to supersede was not found.")
                if previous["kind"] != kind or previous["project"] != safe_project:
                    raise ValueError("A memory version must retain its kind and project namespace.")
                if not self._row_is_intact(previous):
                    raise ValueError("The memory entry to supersede failed its integrity check.")
                version = int(previous["version"]) + 1
            created_at = datetime.now(timezone.utc).isoformat()
            digest = _memory_digest(
                kind, safe_project, safe_summary, safe_content, tags_json, status, version,
                supersedes, created_at, format_version=2,
            )
            self._ensure_capacity(len(safe_summary.encode("utf-8")) + len(safe_content.encode("utf-8")) + len(tags_json) + 2048)
            cursor = db.execute(
                """INSERT OR IGNORE INTO memories
                   (kind, project, summary, content, tags, status, version, supersedes, digest, digest_version, created_at)
                   VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 2, ?)""",
                (kind, safe_project, safe_summary, safe_content, tags_json, status, version, supersedes,
                 digest, created_at),
            )
            if cursor.rowcount == 0:
                row = db.execute(
                    "SELECT id FROM memories WHERE kind=? AND project=? AND digest=?",
                    (kind, safe_project, digest),
                ).fetchone()
                return int(row["id"])
            return int(cursor.lastrowid)

    @staticmethod
    def _row_is_intact(row: sqlite3.Row) -> bool:
        return _memory_digest(
            row["kind"], row["project"], row["summary"], row["content"], row["tags"],
            row["status"], int(row["version"]), row["supersedes"], row["created_at"],
            int(row["digest_version"]),
        ) == row["digest"]

    def search(
        self, query: str, limit: int = 8, project: str | None = None,
        max_age_days: int | None = None,
    ) -> list[dict[str, Any]]:
        terms = list(dict.fromkeys(_WORD_RE.findall(str(query).lower())))[:12]
        if not terms:
            return []
        limit = max(1, min(50, int(limit)))
        with self._connect() as db:
            if self._fts_available:
                match = " OR ".join(f'"{term.replace(chr(34), "")}"*' for term in terms)
                rows = db.execute(
                    """SELECT m.* FROM memories_fts f JOIN memories m ON m.id=f.rowid
                       WHERE memories_fts MATCH ? AND (? IS NULL OR m.project=?)
                         AND m.id NOT IN (SELECT supersedes FROM memories WHERE supersedes IS NOT NULL)
                       ORDER BY bm25(memories_fts), m.id DESC LIMIT ?""",
                    (match, project, project, limit * 4),
                ).fetchall()
            else:
                clauses = " OR ".join("(summary LIKE ? OR content LIKE ? OR tags LIKE ?)" for _ in terms)
                params: list[Any] = []
                for term in terms:
                    params.extend([f"%{term}%", f"%{term}%", f"%{term}%"])
                rows = db.execute(
                    f"SELECT * FROM memories WHERE ({clauses}) AND (? IS NULL OR project=?) "
                    "AND id NOT IN (SELECT supersedes FROM memories WHERE supersedes IS NOT NULL) "
                    "ORDER BY id DESC LIMIT ?",
                    (*params, project, project, limit * 4),
                ).fetchall()
        results = []
        now = datetime.now(timezone.utc)
        default_max_age = {"working": 14, "experience": 180, "project": 365, "fact": 365}
        if max_age_days is not None and (isinstance(max_age_days, bool) or int(max_age_days) < 1):
            raise ValueError("max_age_days must be a positive integer or None.")
        for row in rows:
            if not self._row_is_intact(row):
                continue
            item = dict(row)
            item["tags"] = json.loads(item["tags"])
            try:
                created = datetime.fromisoformat(item["created_at"].replace("Z", "+00:00"))
                if created.tzinfo is None:
                    created = created.replace(tzinfo=timezone.utc)
                age_days = max(0, (now - created.astimezone(timezone.utc)).days)
            except (TypeError, ValueError, AttributeError):
                age_days = None
            age_limit = int(max_age_days) if max_age_days is not None else default_max_age.get(item["kind"], 365)
            item["age_days"] = age_days
            item["staleness_limit_days"] = age_limit
            item["is_stale"] = age_days is None or age_days > age_limit
            results.append(item)
            if len(results) >= limit:
                break

        # Detect competing active memories with the same namespace and summary.
        # A superseding entry is a deliberate version chain, not a conflict.
        if results:
            with self._connect() as db:
                for item in results:
                    peers = db.execute(
                        "SELECT * FROM memories WHERE kind=? AND project=? AND summary=?",
                        (item["kind"], item["project"], item["summary"]),
                    ).fetchall()
                    intact_peers = [peer for peer in peers if self._row_is_intact(peer)]
                    peer_ids = [int(peer["id"]) for peer in intact_peers]
                    if peer_ids:
                        placeholders = ",".join("?" for _ in peer_ids)
                        references = db.execute(
                            f"SELECT supersedes FROM memories WHERE supersedes IN ({placeholders})",
                            peer_ids,
                        ).fetchall()
                        superseded_ids = {int(ref["supersedes"]) for ref in references if ref["supersedes"] is not None}
                    else:
                        superseded_ids = set()
                    active = [peer for peer in intact_peers if int(peer["id"]) not in superseded_ids]
                    distinct_content = {peer["content"] for peer in active}
                    item["conflict"] = len(distinct_content) > 1
                    item["conflicting_memory_ids"] = (
                        [int(peer["id"]) for peer in active] if item["conflict"] else []
                    )
        return results

    def list_memories(self, limit: int = 100) -> list[dict[str, Any]]:
        with self._connect() as db:
            rows = db.execute("SELECT * FROM memories ORDER BY id DESC LIMIT ?", (max(1, min(500, limit)),)).fetchall()
        results = []
        for row in rows:
            if self._row_is_intact(row):
                item = dict(row)
                item["tags"] = json.loads(item["tags"])
                results.append(item)
        return results

    def memory_status(self) -> dict[str, Any]:
        with self._connect() as db:
            cursor = db.execute("SELECT * FROM memories")
            total = intact = 0
            for rows in iter(lambda: cursor.fetchmany(500), []):
                total += len(rows)
                intact += sum(1 for row in rows if self._row_is_intact(row))
            checkpoint_count = int(db.execute("SELECT COUNT(*) FROM checkpoints").fetchone()[0])
        try:
            size_bytes = self.db_path.stat().st_size
        except OSError:
            size_bytes = 0
        return {
            "records": total,
            "intact_records": intact,
            "integrity_failures": total - intact,
            "checkpoint_records": checkpoint_count,
            "database_bytes": size_bytes,
            "configured_limit_bytes": self.max_db_bytes,
            "search_index": "FTS5" if self._fts_available else "SQLite LIKE fallback",
        }

    def delete_memory(self, memory_id: int) -> None:
        with self._connect() as db:
            db.execute("DELETE FROM memories WHERE id=?", (int(memory_id),))

    def start_checkpoint(self, task: str, task_id: str | None = None) -> str:
        task_id = task_id or str(uuid.uuid4())
        if not re.fullmatch(r"[A-Za-z0-9_-]{1,80}", task_id):
            raise ValueError("Checkpoint ID must be 1–80 safe identifier characters.")
        safe_task = self._text(task, 6000)
        if not safe_task:
            raise ValueError("Checkpoint task text is required.")
        self._ensure_capacity(len(safe_task.encode("utf-8")) + 2048)
        now = datetime.now(timezone.utc).isoformat()
        payload = self._checkpoint_payload(task_id, safe_task, "started", "running", [], [], "", "{}")
        digest = hashlib.sha256(payload.encode("utf-8")).hexdigest()
        with self._connect() as db:
            db.execute(
                """INSERT INTO checkpoints(task_id, task, stage, status, subtasks_json,
                   completed_json, notes, state_json, digest, created_at, updated_at)
                   VALUES (?, ?, 'started', 'running', '[]', '[]', '', '{}', ?, ?, ?)""",
                (task_id, safe_task, digest, now, now),
            )
        return task_id

    @staticmethod
    def _checkpoint_payload(task_id: str, task: str, stage: str, status: str,
                            subtasks_json: list[str], completed_json: list[str], notes: str,
                            state_json: str = "{}") -> str:
        return json.dumps(
            [task_id, task, stage, status, subtasks_json, completed_json, notes, state_json],
            ensure_ascii=False,
            separators=(",", ":"),
        )

    def update_checkpoint(
        self,
        task_id: str,
        stage: str,
        subtasks: list[str] | None = None,
        completed: list[str] | None = None,
        notes: str | None = None,
        status: str | None = None,
        state: dict[str, Any] | None = None,
    ) -> None:
        if status is not None and status not in {"running", "completed", "interrupted", "failed"}:
            raise ValueError("Checkpoint status is not supported.")
        with self._connect() as db:
            row = db.execute("SELECT * FROM checkpoints WHERE task_id=?", (task_id,)).fetchone()
            if row is None:
                raise ValueError("Checkpoint was not found.")
            if not self._checkpoint_is_intact(row):
                raise ValueError("Checkpoint integrity check failed; refusing to overwrite it.")
            subtask_values = [self._text(x, 500) for x in (subtasks if subtasks is not None else json.loads(row["subtasks_json"]))]
            completed_values = [self._text(x, 500) for x in (completed if completed is not None else json.loads(row["completed_json"]))]
            if len(subtask_values) > 8 or any(item not in subtask_values for item in completed_values):
                raise ValueError("Checkpoint progress must reference at most eight planned subtasks.")
            safe_stage = self._text(stage, 120) or "unknown"
            safe_notes = self._text(row["notes"] if notes is None else notes, 4000)
            safe_status = status or row["status"]
            state_json = row["state_json"] if state is None else json.dumps(
                self._safe_checkpoint_state(state), ensure_ascii=False, separators=(",", ":"), allow_nan=False
            )
            if len(state_json.encode("utf-8")) > 8 * 1024 * 1024:
                raise OSError("Task checkpoint exceeds the 8 MiB state limit; no checkpoint data was changed.")
            previous_state_bytes = len(row["state_json"].encode("utf-8"))
            self._ensure_capacity(max(0, len(state_json.encode("utf-8")) - previous_state_bytes) + 8192)
            payload = self._checkpoint_payload(
                task_id, row["task"], safe_stage, safe_status, subtask_values, completed_values,
                safe_notes, state_json,
            )
            digest = hashlib.sha256(payload.encode("utf-8")).hexdigest()
            db.execute(
                """UPDATE checkpoints SET stage=?, status=?, subtasks_json=?, completed_json=?,
                   notes=?, state_json=?, digest=?, updated_at=? WHERE task_id=?""",
                (safe_stage, safe_status, json.dumps(subtask_values, ensure_ascii=False),
                 json.dumps(completed_values, ensure_ascii=False), safe_notes, state_json, digest,
                 datetime.now(timezone.utc).isoformat(), task_id),
            )

    @classmethod
    def _checkpoint_is_intact(cls, row: sqlite3.Row) -> bool:
        payload = cls._checkpoint_payload(
            row["task_id"], row["task"], row["stage"], row["status"],
            json.loads(row["subtasks_json"]), json.loads(row["completed_json"]), row["notes"],
            row["state_json"],
        )
        if hashlib.sha256(payload.encode("utf-8")).hexdigest() == row["digest"]:
            return True
        # Verify legacy rows created before persistent execution state was added.
        legacy_payload = json.dumps(
            [row["task_id"], row["task"], row["stage"], row["status"],
             json.loads(row["subtasks_json"]), json.loads(row["completed_json"]), row["notes"]],
            ensure_ascii=False,
            separators=(",", ":"),
        )
        return hashlib.sha256(legacy_payload.encode("utf-8")).hexdigest() == row["digest"]

    def get_checkpoint(self, task_id: str) -> dict[str, Any] | None:
        with self._connect() as db:
            row = db.execute("SELECT * FROM checkpoints WHERE task_id=?", (task_id,)).fetchone()
        if row is None:
            return None
        if not self._checkpoint_is_intact(row):
            raise ValueError("Checkpoint integrity check failed.")
        item = dict(row)
        item["subtasks"] = json.loads(item.pop("subtasks_json"))
        item["completed"] = json.loads(item.pop("completed_json"))
        item["state"] = json.loads(item.pop("state_json"))
        item["remaining"] = [step for step in item["subtasks"] if step not in item["completed"]]
        return item

    def list_checkpoints(self, include_completed: bool = False, limit: int = 100) -> list[dict[str, Any]]:
        with self._connect() as db:
            rows = db.execute(
                "SELECT task_id FROM checkpoints WHERE (? OR status != 'completed') ORDER BY updated_at DESC LIMIT ?",
                (int(include_completed), max(1, min(500, int(limit)))),
            ).fetchall()
        return [self.get_checkpoint(row["task_id"]) for row in rows]

    def benchmark_search(self, query: str, rounds: int = 20) -> dict[str, Any]:
        rounds = max(1, min(200, int(rounds)))
        started = time.perf_counter()
        hits = 0
        for _ in range(rounds):
            hits = len(self.search(query, limit=50))
        elapsed_ms = (time.perf_counter() - started) * 1000
        with self._connect() as db:
            cursor = db.execute("SELECT * FROM memories")
            intact_records = 0
            total_records = 0
            for row in iter(lambda: cursor.fetchmany(500), []):
                total_records += len(row)
                intact_records += sum(1 for item in row if self._row_is_intact(item))
        integrity_failures = max(0, total_records - intact_records)
        return {
            "query": query[:200],
            "rounds": rounds,
            "hits": hits,
            "intact_records_checked": intact_records,
            "elapsed_ms": round(elapsed_ms, 3),
            "mean_query_ms": round(elapsed_ms / rounds, 3),
            "integrity_failures": integrity_failures,
            "status": "verified" if integrity_failures == 0 else "integrity-failure",
        }

    @staticmethod
    def compare_benchmarks(baseline: dict[str, Any], candidate: dict[str, Any]) -> dict[str, Any]:
        checks = {
            "integrity_preserved": candidate.get("integrity_failures", 1) <= baseline.get("integrity_failures", 0),
            "retrieval_not_regressed": candidate.get("hits", 0) >= baseline.get("hits", 0),
            "latency_not_regressed": candidate.get("mean_query_ms", float("inf")) <= baseline.get("mean_query_ms", 0) * 1.10,
        }
        return {
            "checks": checks,
            "accepted": all(checks.values()),
            "status": "verified" if all(checks.values()) else "not adopted",
            "scope": "Local memory retrieval only; does not measure model intelligence or answer quality.",
        }
