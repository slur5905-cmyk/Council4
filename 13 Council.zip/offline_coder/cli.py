from __future__ import annotations
import argparse
from pathlib import Path
from .config import load_settings, save_settings
from .model_backend import build_model_router
from .council import CouncilRunner, apply_approved_result
from .knowledge import KnowledgeStore
from .expansion import ExpansionStore, NullExpansionStore


def main():
    defaults = load_settings()
    parser = argparse.ArgumentParser(description="Offline local coding assistant with four role-based peer reviewers (no paid/cloud AI API).")
    parser.add_argument("--model", default=defaults.get("model_path", ""), help="Path to a local .gguf model file (GGUF backend)")
    parser.add_argument("--backend", choices=["gguf", "local-server"], default=defaults.get("model_backend", "gguf"), help="Use an in-process GGUF model or a verified loopback OpenAI-compatible server")
    parser.add_argument("--endpoint", default=defaults.get("local_server_url", "http://127.0.0.1:8080/v1"), help="Loopback-only local server base URL ending in /v1")
    parser.add_argument("--served-model", default=defaults.get("local_server_model", ""), help="Optional exact model ID listed by the local server")
    parser.add_argument("--workspace", default=defaults.get("workspace_path", ""), help="Only folder the council may read/write")
    parser.add_argument("--task", default="", help="What you want the council to do")
    parser.add_argument("--resume", default="", help="Resume a saved checkpoint ID from the local Council database")
    parser.add_argument("--list-checkpoints", action="store_true", help="List recoverable local task checkpoints and exit")
    parser.add_argument("--apply", action="store_true", help="Explicitly authorize applying the host-checked proposal after manual review")
    parser.add_argument("--ctx", type=int, default=int(defaults.get("n_ctx", 16384)))
    parser.add_argument("--threads", type=int, default=int(defaults.get("n_threads", 4)))
    parser.add_argument("--gpu-layers", type=int, default=int(defaults.get("n_gpu_layers", 0)))
    parser.add_argument("--tokens", type=int, default=int(defaults.get("max_tokens", 4096)))
    parser.add_argument("--revision-rounds", type=int, choices=[0, 1, 2], default=int(defaults.get("review_rounds", 1)))
    parser.add_argument("--peer-workers", type=int, choices=[1, 2, 3, 4], default=int(defaults.get("max_peer_workers", 2)),
                        help="Maximum simultaneous peer calls when different role-specific model instances are configured; shared instances are serialized")
    args = parser.parse_args()
    if args.list_checkpoints:
        checkpoints = (ExpansionStore(max_db_bytes=defaults.get("memory_max_bytes", 134217728)) if defaults.get("advanced_features_enabled", False) else NullExpansionStore()).list_checkpoints(
            include_completed=False, limit=100
        )
        if not checkpoints:
            print("No recoverable Council checkpoints.")
            return 0
        for checkpoint in checkpoints:
            print(
                f"{checkpoint['task_id']} | {checkpoint['status']} | {checkpoint['stage']} | "
                f"{len(checkpoint['completed'])}/{len(checkpoint['subtasks'])} phases | "
                f"{checkpoint['task'][:120]}"
            )
        return 0
    if args.resume:
        checkpoint = (ExpansionStore(max_db_bytes=defaults.get("memory_max_bytes", 134217728)) if defaults.get("advanced_features_enabled", False) else NullExpansionStore()).get_checkpoint(args.resume)
        if checkpoint is None:
            parser.error(f"Checkpoint not found: {args.resume}")
        if args.task and args.task != checkpoint["task"]:
            parser.error("--task must exactly match the selected checkpoint's saved task.")
        args.task = checkpoint["task"]
    elif not args.task:
        parser.error("Provide --task TEXT, --resume CHECKPOINT_ID, or --list-checkpoints.")
    if args.backend == "gguf" and not args.model:
        parser.error("Choose a local .gguf model using --model PATH, or use --backend local-server with a local server.")
    if not args.workspace:
        parser.error("Choose a workspace using --workspace PATH.")
    workspace = Path(args.workspace).expanduser().resolve()
    workspace.mkdir(parents=True, exist_ok=True)
    print("Loading and verifying local model backend. Public web research is manual-only and requires explicit confirmation.")
    model_settings = dict(defaults)
    model_settings.update({"model_backend": args.backend, "model_path": args.model,
        "local_server_url": args.endpoint, "local_server_model": args.served_model,
        "n_ctx": args.ctx, "n_threads": args.threads, "n_gpu_layers": args.gpu_layers,
        "max_tokens": args.tokens})
    model = build_model_router(model_settings)
    runner = CouncilRunner(model, workspace, allow_self_edit=bool(defaults.get("allow_self_edit", False)),
                           review_rounds=args.revision_rounds, knowledge=KnowledgeStore(),
                           logger=lambda msg: print("[COUNCIL] " + msg), max_tokens=args.tokens,
                           web_research_enabled=False,
                           max_peer_workers=args.peer_workers,
                           memory_max_bytes=defaults.get("memory_max_bytes", 134217728),
                           advanced_features_enabled=defaults.get("advanced_features_enabled", False),
                           resource_settings=model_settings)
    result = runner.run_task(args.task, resume_checkpoint_id=args.resume or None)
    print("\n=== ANSWER ===\n" + (result.answer or result.summary))
    print("\n=== STATUS ===\n" + result.final_status)
    if result.proposed_files:
        print("\n=== PROPOSED FILES ===")
        for name in result.proposed_files:
            print(" - " + name)
    if result.safety_errors:
        print("\n=== SAFETY ERRORS ===\n- " + "\n- ".join(result.safety_errors))
    if result.safety_warnings:
        print("\n=== RISK WARNINGS ===\n- " + "\n- ".join(result.safety_warnings))
    print(f"\nAudit report: {result.report_path}")
    if args.apply:
        if result.can_apply:
            answer = input("Host checks passed. Review the proposal, then type APPLY to authorize these exact file changes: ").strip()
            if answer == "APPLY":
                backup = apply_approved_result(result, allow_self_edit=bool(defaults.get("allow_self_edit", False)))
                print("Applied. Backups: " + backup)
            else:
                print("Not applied. User approval was not given.")
        else:
            print("Not applied: host checks did not make this proposal eligible for manual Apply.")
    elif result.can_apply:
        print("The proposal is eligible, but not applied. Re-run with --apply for an explicit confirmation prompt, or use the desktop GUI.")


if __name__ == "__main__":
    main()
