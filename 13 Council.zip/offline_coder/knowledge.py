"""Local source notebook with explicit provenance and a human verification flag."""
from __future__ import annotations
from contextlib import contextmanager
import hashlib
import html
import re
import sqlite3
from datetime import datetime, timezone
from pathlib import Path
from typing import Any
from .config import APP_DIR
from .safety import redact_sensitive_text

DB_PATH = APP_DIR / "knowledge.sqlite3"
TEXT_IMPORT_SUFFIXES = {
    ".txt", ".md", ".rst", ".py", ".js", ".jsx", ".ts", ".tsx", ".html", ".htm", ".css",
    ".json", ".toml", ".yaml", ".yml", ".xml", ".sql", ".sh", ".rs", ".go", ".java", ".cs",
    ".cpp", ".c", ".h", ".php", ".rb", ".swift", ".kt", ".vue", ".svelte", ".dart", ".pdf",
}


class KnowledgeStore:
    def __init__(self, db_path: Path = DB_PATH):
        self.db_path = Path(db_path)
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        with self._connect() as db:
            db.execute("""CREATE TABLE IF NOT EXISTS sources (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                title TEXT NOT NULL,
                origin TEXT NOT NULL,
                file_path TEXT NOT NULL,
                sha256 TEXT NOT NULL,
                verified INTEGER NOT NULL DEFAULT 0,
                project_scope TEXT NOT NULL DEFAULT '',
                body TEXT NOT NULL,
                added_at TEXT NOT NULL
            )""")
            columns = {row[1] for row in db.execute("PRAGMA table_info(sources)")}
            if "project_scope" not in columns:
                db.execute("ALTER TABLE sources ADD COLUMN project_scope TEXT NOT NULL DEFAULT ''")

    @contextmanager
    def _connect(self):
        db = sqlite3.connect(self.db_path, timeout=5.0)
        db.row_factory = sqlite3.Row
        try:
            yield db
            db.commit()
        except Exception:
            db.rollback()
            raise
        finally:
            db.close()

    @staticmethod
    def read_source(path: Path) -> str:
        path = path.expanduser().resolve()
        if not path.is_file():
            raise ValueError("Choose an existing local source file.")
        if path.stat().st_size > 8_000_000:
            raise ValueError("Source file is too large (8 MB maximum).")
        suffix = path.suffix.lower()
        if suffix not in TEXT_IMPORT_SUFFIXES:
            raise ValueError(f"Unsupported source type: {suffix}")
        if suffix == ".pdf":
            try:
                from pypdf import PdfReader
            except ImportError as exc:
                raise ValueError("PDF import needs an optional dependency: python -m pip install pypdf") from exc
            reader = PdfReader(str(path))
            pieces = []
            for page in reader.pages[:150]:
                pieces.append(page.extract_text() or "")
            text = "\n".join(pieces)
        else:
            text = path.read_text(encoding="utf-8", errors="replace")
            if suffix in {".html", ".htm"}:
                text = re.sub(r"(?is)<(script|style).*?>.*?</\1>", " ", text)
                text = re.sub(r"(?s)<[^>]+>", " ", text)
                text = html.unescape(text)
        return redact_sensitive_text(text[:500_000])

    @staticmethod
    def _scope_key(project_scope: str | Path | None) -> str:
        value = str(project_scope or "").strip()
        return str(Path(value).expanduser().resolve()) if value else ""

    def add_file(self, path: Path, title: str, origin: str = "Local file", verified: bool = False,
                 project_scope: str | Path | None = None) -> int:
        path = path.expanduser().resolve()
        body = self.read_source(path)
        if not body.strip():
            raise ValueError("No extractable text found in this source file.")
        digest = hashlib.sha256(body.encode("utf-8", errors="replace")).hexdigest()
        with self._connect() as db:
            cur = db.execute(
                 "INSERT INTO sources(title, origin, file_path, sha256, verified, project_scope, body, added_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
                 (title.strip() or path.name, origin.strip() or "Local file", str(path), digest, int(verified),
                  self._scope_key(project_scope), body,
                 datetime.now(timezone.utc).isoformat()),
            )
            return int(cur.lastrowid)

    def list_sources(self) -> list[dict[str, Any]]:
        with self._connect() as db:
            return [dict(row) for row in db.execute("SELECT id,title,origin,file_path,sha256,verified,project_scope,added_at FROM sources ORDER BY id DESC")]

    def get_source(self, source_id: int) -> dict[str, Any] | None:
        with self._connect() as db:
            row = db.execute("SELECT * FROM sources WHERE id=?", (source_id,)).fetchone()
            return dict(row) if row else None

    def verify_source(self, source_id: int) -> None:
        with self._connect() as db:
            row = db.execute("SELECT sha256,body FROM sources WHERE id=?", (source_id,)).fetchone()
            if row is None:
                raise ValueError("Source ID was not found.")
            digest = hashlib.sha256(row["body"].encode("utf-8", errors="replace")).hexdigest()
            if digest != row["sha256"]:
                raise ValueError("Source integrity check failed; re-import the source before verifying it.")
            cur = db.execute("UPDATE sources SET verified=1 WHERE id=?", (source_id,))
            if cur.rowcount == 0:
                raise ValueError("Source ID was not found.")

    def delete_source(self, source_id: int) -> None:
        with self._connect() as db:
            db.execute("DELETE FROM sources WHERE id=?", (source_id,))

    def relevant_sources(self, query: str, limit: int = 4,
                         project_scope: str | Path | None = None) -> list[dict[str, str]]:
        words = {w for w in re.findall(r"[a-zA-Z_][a-zA-Z0-9_+-]{2,}", query.lower())}
        if not words:
            return []
        scope_key = self._scope_key(project_scope)
        with self._connect() as db:
            rows = db.execute(
                "SELECT id,title,origin,sha256,body FROM sources WHERE verified=1 AND (project_scope='' OR project_scope=?)",
                (scope_key,),
            ).fetchall()
        ranked = []
        for row in rows:
            body = row["body"]
            digest = hashlib.sha256(body.encode("utf-8", errors="replace")).hexdigest()
            if digest != row["sha256"]:
                continue
            title = row["title"].lower()
            body_lower = body.lower()
            score = sum((2 if w in title else 0) + min(4, body_lower.count(w)) for w in words)
            if score:
                # Take a targeted excerpt near the best-matching keyword instead of blindly appending a whole manual.
                positions = [body_lower.find(w) for w in words if body_lower.find(w) >= 0]
                start = max(0, (min(positions) if positions else 0) - 600)
                snippet = body[start:start + 1600]
                ranked.append((score, {
                    "title": row["title"], "origin": row["origin"], "sha256": row["sha256"], "snippet": redact_sensitive_text(snippet),
                }))
        ranked.sort(key=lambda pair: pair[0], reverse=True)
        return [item for _, item in ranked[:limit]]
