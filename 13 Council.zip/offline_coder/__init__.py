"""Offline Coding Council — local inference, four peer reviewers, human-controlled writes."""
__version__ = "1.6.3"
