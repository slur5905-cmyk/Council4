"""Bounded, read-only repository intelligence with explicit confidence labels.

The index is an aid to navigation, not a complete compiler or proof of runtime behavior.
It never follows symlinks, reads secret-like paths, executes project code, or writes to the
workspace. Python uses the standard-library AST; other languages use conservative import
and symbol heuristics until a language parser is explicitly installed.
"""
from __future__ import annotations

import ast
import hashlib
import json
import os
import re
from collections import Counter, defaultdict
from pathlib import Path
from typing import Any

from .safety import IGNORED_DIRS, TEXT_SUFFIXES, is_secret_path, is_within, is_ignored_directory_name

MAX_FILES = 20_000
MAX_DIRS = 8_000
MAX_FILE_BYTES = 512_000
MAX_TOTAL_BYTES = 32 * 1024 * 1024
MAX_SYMBOLS = 30_000
MAX_EDGES = 60_000
MAX_CALL_EDGES = 80_000
CODE_SUFFIX_LANGUAGE = {
    ".py": "python", ".pyi": "python", ".js": "javascript", ".jsx": "javascript",
    ".mjs": "javascript", ".cjs": "javascript", ".ts": "typescript", ".tsx": "typescript",
    ".rs": "rust", ".go": "go", ".java": "java", ".cs": "csharp", ".cpp": "cpp",
    ".cc": "cpp", ".c": "c", ".h": "c-header", ".hpp": "cpp-header", ".php": "php",
    ".rb": "ruby", ".swift": "swift", ".kt": "kotlin", ".dart": "dart", ".sql": "sql",
    ".html": "html", ".htm": "html", ".css": "css", ".scss": "scss", ".vue": "vue",
    ".svelte": "svelte", ".sh": "shell", ".toml": "toml", ".json": "json",
    ".yaml": "yaml", ".yml": "yaml", ".xml": "xml",
}
_IMPORT_PATTERNS = {
    "javascript": re.compile(r"(?:import\s+(?:.+?\s+from\s+)?|export\s+.+?\s+from\s+|require\s*\()\s*['\"]([^'\"]+)['\"]"),
    "typescript": re.compile(r"(?:import\s+(?:.+?\s+from\s+)?|export\s+.+?\s+from\s+|require\s*\()\s*['\"]([^'\"]+)['\"]"),
    "go": re.compile(r"(?m)^\s*import\s+(?:\([^)]*\)|\"([^\"]+)\")"),
    "rust": re.compile(r"(?m)^\s*(?:pub\s+)?mod\s+([A-Za-z_][\w:]*)"),
}
_SYMBOL_PATTERNS = {
    "javascript": re.compile(r"\b(?:export\s+)?(?:async\s+)?function\s+([A-Za-z_$][\w$]*)|\bclass\s+([A-Za-z_$][\w$]*)|\b(?:export\s+)?(?:const|let|var)\s+([A-Za-z_$][\w$]*)\s*="),
    "typescript": re.compile(r"\b(?:export\s+)?(?:async\s+)?function\s+([A-Za-z_$][\w$]*)|\bclass\s+([A-Za-z_$][\w$]*)|\b(?:export\s+)?(?:const|let|var)\s+([A-Za-z_$][\w$]*)\s*="),
    "rust": re.compile(r"\b(?:pub\s+)?(?:fn|struct|enum|trait|mod|type)\s+([A-Za-z_][\w]*)"),
    "go": re.compile(r"\b(?:func|type|var|const)\s+([A-Za-z_][\w]*)"),
    "java": re.compile(r"\b(?:class|interface|enum|record)\s+([A-Za-z_$][\w$]*)"),
    "csharp": re.compile(r"\b(?:class|interface|struct|enum|record)\s+([A-Za-z_][\w]*)"),
}
_MANIFESTS = {
    "pyproject.toml", "setup.py", "setup.cfg", "requirements.txt", "Pipfile", "poetry.lock",
    "package.json", "package-lock.json", "pnpm-lock.yaml", "yarn.lock", "Cargo.toml", "Cargo.lock",
    "go.mod", "go.sum", "pom.xml", "build.gradle", "build.gradle.kts", "Gemfile", "Gemfile.lock",
    "composer.json", "composer.lock", "Dockerfile", "docker-compose.yml", "compose.yaml",
    "Makefile", "CMakeLists.txt", " justfile", "tox.ini", "pytest.ini", "tsconfig.json",
}
_ENTRY_NAMES = {"main.py", "app.py", "__main__.py", "main.js", "main.ts", "index.js", "index.ts", "server.js", "server.ts", "main.go", "main.rs", "Program.cs", "main.c", "main.cpp", "index.html"}


def _sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def _python_symbols(source: str, relative: str) -> tuple[list[dict[str, Any]], list[str], list[str]]:
    symbols: list[dict[str, Any]] = []
    imports: list[str] = []
    errors: list[str] = []
    try:
        tree = ast.parse(source, filename=relative)
    except SyntaxError as exc:
        return symbols, imports, [f"Python parse error at line {exc.lineno or '?'}: {exc.msg}"]
    for node in ast.walk(tree):
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)):
            symbols.append({"name": node.name, "kind": "class" if isinstance(node, ast.ClassDef) else "function", "line": node.lineno, "confidence": "AST"})
        elif isinstance(node, ast.Import):
            imports.extend(alias.name for alias in node.names)
        elif isinstance(node, ast.ImportFrom):
            imports.append("." * (node.level or 0) + (node.module or ""))
    return symbols, imports, errors



def _dotted_ast_name(node: ast.AST) -> str:
    if isinstance(node, ast.Name):
        return node.id
    if isinstance(node, ast.Attribute):
        parent = _dotted_ast_name(node.value)
        return f"{parent}.{node.attr}" if parent else node.attr
    if isinstance(node, ast.Call):
        return _dotted_ast_name(node.func)
    return ""


def _python_relationships(source: str, relative: str) -> tuple[list[dict[str, Any]], list[dict[str, Any]]]:
    """Extract conservative Python call and inheritance references with AST locations."""
    try:
        tree = ast.parse(source, filename=relative)
    except SyntaxError:
        return [], []

    calls: list[dict[str, Any]] = []
    inheritance: list[dict[str, Any]] = []

    class RelationshipVisitor(ast.NodeVisitor):
        def __init__(self):
            self.scope: list[str] = ["<module>"]

        def visit_ClassDef(self, node: ast.ClassDef) -> None:
            qualified = ".".join(self.scope + [node.name])
            for base in node.bases:
                base_name = _dotted_ast_name(base)
                if base_name:
                    inheritance.append({"file": relative, "child": qualified, "base": base_name,
                                        "line": node.lineno, "confidence": "AST-reference-unresolved"})
            self.scope.append(node.name)
            self.generic_visit(node)
            self.scope.pop()

        def visit_FunctionDef(self, node: ast.FunctionDef) -> None:
            self.scope.append(node.name)
            self.generic_visit(node)
            self.scope.pop()

        def visit_AsyncFunctionDef(self, node: ast.AsyncFunctionDef) -> None:
            self.scope.append(node.name)
            self.generic_visit(node)
            self.scope.pop()

        def visit_Call(self, node: ast.Call) -> None:
            name = _dotted_ast_name(node.func)
            if name:
                calls.append({"file": relative, "caller": ".".join(self.scope), "callee": name,
                              "line": getattr(node, "lineno", 0), "confidence": "AST-reference-unresolved"})
            self.generic_visit(node)

    RelationshipVisitor().visit(tree)
    return calls[:MAX_CALL_EDGES], inheritance[:MAX_SYMBOLS]

def _generic_symbols(source: str, language: str) -> list[dict[str, Any]]:
    pattern = _SYMBOL_PATTERNS.get(language)
    if not pattern:
        return []
    found: list[dict[str, Any]] = []
    for line_number, line in enumerate(source.splitlines(), 1):
        for match in pattern.finditer(line):
            name = next((group for group in match.groups() if group), "")
            if name:
                found.append({"name": name, "kind": "declaration", "line": line_number, "confidence": "heuristic"})
                if len(found) >= 500:
                    return found
    return found


def _resolve_local_import(import_name: str, current: Path, root: Path, language: str) -> str | None:
    name = import_name.strip()
    if not name or name.startswith(("http:", "https:", "node:", "@")):
        return None
    suffixes = {
        "python": [".py", "/__init__.py"],
        "javascript": [".js", ".mjs", ".cjs", ".jsx", ".json", "/index.js"],
        "typescript": [".ts", ".tsx", ".js", ".jsx", "/index.ts", "/index.tsx"],
        "rust": [".rs", "/mod.rs"],
    }.get(language, [])
    candidates: list[Path] = []
    base = current.parent
    if language == "python" and name.startswith("."):
        dots = len(name) - len(name.lstrip("."))
        module = name[dots:].replace(".", "/")
        base = current.parent
        for _ in range(max(0, dots - 1)):
            base = base.parent
        stem = (base / module) if module else base
    else:
        stem = base / name.replace(".", "/") if language == "python" else base / name
    candidates.append(stem)
    for suffix in suffixes:
        candidates.append(Path(str(stem) + suffix))
    for candidate in candidates:
        try:
            if candidate.is_symlink() or not is_within(candidate, root):
                continue
            if candidate.is_file():
                return candidate.relative_to(root).as_posix()
        except (OSError, ValueError):
            continue
    return None


def analyze_repository(root: Path, query: str = "", *, max_files: int = MAX_FILES,
                       max_bytes: int = MAX_TOTAL_BYTES) -> dict[str, Any]:
    """Create a bounded index of source symbols, manifests, entry points, and local imports."""
    root = Path(root).expanduser().resolve()
    if not root.exists() or not root.is_dir():
        return {"status": "unavailable", "root": str(root), "error": "Workspace does not exist or is not a directory."}
    files: list[Path] = []
    total_bytes = 0
    scanned_files = scanned_dirs = 0
    truncated = False
    for base, dirs, names in os.walk(root, followlinks=False):
        scanned_dirs += 1
        if scanned_dirs > MAX_DIRS:
            truncated = True
            break
        base_path = Path(base)
        dirs[:] = sorted(d for d in dirs if not is_ignored_directory_name(d) and not (base_path / d).is_symlink())
        for name in sorted(names):
            scanned_files += 1
            if scanned_files > MAX_FILES:
                truncated = True
                dirs[:] = []
                break
            path = base_path / name
            if path.is_symlink() or not is_within(path, root):
                continue
            try:
                size = path.stat().st_size
            except OSError:
                continue
            if size > MAX_FILE_BYTES or is_secret_path(path.relative_to(root).as_posix()):
                continue
            if path.suffix.lower() not in TEXT_SUFFIXES and name not in {"Makefile", "Dockerfile", "CMakeLists.txt"}:
                continue
            if total_bytes + size > max_bytes:
                truncated = True
                continue
            total_bytes += size
            files.append(path)
            if len(files) >= max_files:
                truncated = True
                break
        if len(files) >= max_files:
            break

    file_rows: list[dict[str, Any]] = []
    symbol_rows: list[dict[str, Any]] = []
    edge_rows: list[dict[str, str]] = []
    raw_call_rows: list[dict[str, Any]] = []
    raw_inheritance_rows: list[dict[str, Any]] = []
    manifests: list[str] = []
    entry_points: list[str] = []
    language_counts: Counter[str] = Counter()
    relative_by_path = {p: p.relative_to(root).as_posix() for p in files}
    query_terms = [x.casefold() for x in re.findall(r"[A-Za-z_][A-Za-z0-9_+-]{2,}", query)[:30]]
    for path in files:
        rel = relative_by_path[path]
        try:
            data = path.read_bytes()
            source = data.decode("utf-8", errors="replace")
        except OSError:
            continue
        language = CODE_SUFFIX_LANGUAGE.get(path.suffix.lower(), "configuration/text")
        language_counts[language] += 1
        if path.name in _MANIFESTS or path.name in {"Makefile", "Dockerfile", "CMakeLists.txt"}:
            manifests.append(rel)
        if path.name in _ENTRY_NAMES or re.search(r"(?i)(entry.?point|\"main\"\s*:)", source[:4000]):
            entry_points.append(rel)
        if path.suffix.lower() == ".py":
            symbols, imports, parse_errors = _python_symbols(source, rel)
            calls, inheritance = _python_relationships(source, rel)
            raw_call_rows.extend(calls[:max(0, MAX_CALL_EDGES - len(raw_call_rows))])
            raw_inheritance_rows.extend(inheritance[:max(0, MAX_SYMBOLS - len(raw_inheritance_rows))])
        else:
            symbols = _generic_symbols(source, language)
            pattern = _IMPORT_PATTERNS.get(language)
            imports = pattern.findall(source) if pattern else []
            imports = [next((v for v in item if v), item) if isinstance(item, tuple) else item for item in imports]
            parse_errors = []
        for symbol in symbols:
            if len(symbol_rows) >= MAX_SYMBOLS:
                truncated = True
                break
            symbol_rows.append({"file": rel, **symbol})
        for import_name in imports[:1000]:
            resolved = _resolve_local_import(str(import_name), path, root, language)
            if resolved and len(edge_rows) < MAX_EDGES:
                edge_rows.append({"from": rel, "to": resolved, "kind": "local_import", "confidence": "resolved-file"})
        digest = _sha(data)
        row = {"path": rel, "language": language, "bytes": len(data), "sha256": digest,
               "symbol_count": len(symbols), "parse_errors": parse_errors[:8], "confidence": "AST" if language == "python" else "heuristic"}
        if query_terms:
            lower = (rel + " " + source[:20000]).casefold()
            row["query_match_score"] = sum(min(5, lower.count(term)) for term in query_terms)
        file_rows.append(row)

    incoming: dict[str, int] = defaultdict(int)
    outgoing: dict[str, int] = defaultdict(int)
    for edge in edge_rows:
        outgoing[edge["from"]] += 1
        incoming[edge["to"]] += 1

    # Resolve call/base names only when the local source index provides evidence.
    # Attribute calls and dynamic dispatch remain explicitly ambiguous when multiple
    # declarations share a short name; no heuristic is promoted to a compiler result.
    locations_by_name: dict[str, list[dict[str, str]]] = defaultdict(list)
    for symbol in symbol_rows:
        locations_by_name[str(symbol.get("name", ""))].append({
            "file": str(symbol.get("file", "")), "name": str(symbol.get("name", "")),
            "kind": str(symbol.get("kind", "")),
        })
    call_rows = []
    call_incoming: dict[str, int] = defaultdict(int)
    call_outgoing: dict[str, int] = defaultdict(int)
    unresolved_calls = 0
    for raw in raw_call_rows:
        short_name = str(raw.get("callee", "")).split(".")[-1]
        candidates = locations_by_name.get(short_name, []) if short_name else []
        unique = {candidate["file"] for candidate in candidates}
        if len(unique) == 1:
            status = "unique-local-name-match"
            target_file = next(iter(unique))
            call_incoming[target_file] += 1
            call_outgoing[str(raw["file"])] += 1
        elif len(unique) > 1:
            status = "ambiguous-local-name-match"
            target_file = ""
            unresolved_calls += 1
        else:
            status = "unresolved-or-external"
            target_file = ""
            unresolved_calls += 1
        call_rows.append({**raw, "target_file": target_file, "resolution": status,
                          "candidate_targets": candidates[:5]})
    inheritance_rows = []
    for raw in raw_inheritance_rows:
        short_name = str(raw.get("base", "")).split(".")[-1]
        candidates = locations_by_name.get(short_name, []) if short_name else []
        files_for_base = {candidate["file"] for candidate in candidates}
        inheritance_rows.append({**raw,
            "base_file": next(iter(files_for_base)) if len(files_for_base) == 1 else "",
            "resolution": "unique-local-name-match" if len(files_for_base) == 1 else ("ambiguous-local-name-match" if files_for_base else "unresolved-or-external")})
    impact = []
    for path, degree in sorted(incoming.items(), key=lambda item: (-item[1], item[0]))[:100]:
        impact.append({"file": path, "direct_importers": degree, "direct_dependencies": outgoing.get(path, 0),
                       "confidence": "partial; only supported import forms resolved"})
    symbol_counts = Counter(item["kind"] for item in symbol_rows)
    return {
        "status": "completed", "root": str(root), "created_at": __import__("datetime").datetime.now(__import__("datetime").timezone.utc).isoformat(),
        "scanned_files": scanned_files, "indexed_files": len(file_rows), "indexed_bytes": total_bytes,
        "truncated": truncated, "languages": dict(language_counts), "manifests": sorted(manifests),
        "entry_points": sorted(set(entry_points)), "symbols": symbol_rows[:MAX_SYMBOLS],
        "symbol_counts": dict(symbol_counts), "dependency_edges": edge_rows[:MAX_EDGES],
        "call_edges": call_rows[:MAX_CALL_EDGES], "inheritance_edges": inheritance_rows[:MAX_SYMBOLS],
        "call_resolution": {"total_python_calls": len(raw_call_rows), "unique_local_targets": sum(1 for row in call_rows if row["resolution"] == "unique-local-name-match"),
                             "ambiguous_or_unresolved": unresolved_calls},
        "dependency_impact": impact, "call_impact": [
            {"file": name, "local_callers": count, "local_calls": call_outgoing.get(name, 0), "confidence": "conservative unique-name AST matches"}
            for name, count in sorted(call_incoming.items(), key=lambda item: (-item[1], item[0]))[:100]
        ], "files": sorted(file_rows, key=lambda row: (-row.get("query_match_score", 0), row["path"])),
        "limits_and_confidence": {
            "python_symbols": "Python AST; syntactic declarations and imports",
            "other_languages": "Conservative text heuristics; may miss syntax and resolve false positives",
            "call_graph": "Partial Python AST call references; a unique short-name match is not proof of runtime dispatch. Dynamic dispatch, reflection, decorators, callbacks, dependency injection, monkey-patching, macros, generated code, and runtime wiring may be unresolved",
            "coverage": "Symlinks, secret-like paths, ignored/generated/dependency directories, binary files, and oversized files are omitted",
            "truncated": truncated,
        },
    }


def format_repository_digest(report: dict[str, Any], *, max_chars: int = 9000) -> str:
    """Compact prompt-ready digest with uncertainty made explicit."""
    if report.get("status") != "completed":
        return "REPOSITORY INTELLIGENCE UNAVAILABLE: " + str(report.get("error", "unknown error"))[:500]
    files = report.get("files", [])
    symbols = report.get("symbols", [])
    edges = report.get("dependency_edges", [])
    lines = [
        "REPOSITORY INTELLIGENCE INDEX (read-only, bounded; not a complete semantic compiler):",
        f"Indexed {report.get('indexed_files', 0)} files / {report.get('indexed_bytes', 0)} bytes; truncated={report.get('truncated')}",
        f"Languages: {json.dumps(report.get('languages', {}), sort_keys=True)}",
        "Manifests: " + (", ".join(report.get("manifests", [])[:80]) or "none detected"),
        "Likely entry points: " + (", ".join(report.get("entry_points", [])[:60]) or "none detected"),
        "Highest-impact modules (partial import graph):",
    ]
    impact = report.get("dependency_impact", [])
    lines.extend(f"- {item['file']}: {item['direct_importers']} direct importer(s), {item['direct_dependencies']} direct dependency edge(s)" for item in impact[:40])
    lines.append("Symbols (AST for Python; heuristics for other languages):")
    lines.extend(f"- {item['file']}:{item['line']} {item['kind']} {item['name']} [{item['confidence']}]" for item in symbols[:180])
    lines.append("Resolved local import/dependency edges (partial):")
    lines.extend(f"- {item['from']} -> {item['to']}" for item in edges[:100])
    lines.append("Python call relationships (partial; unique short-name matches are not proof of runtime dispatch):")
    call_edges = report.get("call_edges", [])
    lines.extend(f"- {item['file']}:{item['line']} {item['caller']} -> {item['callee']} [{item['resolution']}]" for item in call_edges[:140])
    lines.append("Python inheritance references (partial):")
    lines.extend(f"- {item['file']}:{item['line']} {item['child']} extends {item['base']} [{item['resolution']}]" for item in report.get("inheritance_edges", [])[:60])
    lines.append("Do not infer a complete call graph or claim all project files were parsed. Inspect actual source and tests for every change.")
    text = "\n".join(lines)
    return text[:max_chars] + ("\n...[repository digest truncated]" if len(text) > max_chars else "")
