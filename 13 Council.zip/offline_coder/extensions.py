"""Capability extension registry with host-enforced permission declarations.

Manifests describe what an extension could do; this registry does not execute extensions,
install packages, grant permissions, or let extensions expand their own privileges.
"""
from __future__ import annotations

import json
import re
from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Any

from .config import APP_DIR

EXTENSION_DIR = APP_DIR / "extensions"
ALLOWED_PERMISSIONS = {"read_project", "write_candidate", "run_isolated_tests", "read_bundled_knowledge", "web_research_opt_in", "read_project_metadata"}
FORBIDDEN_PERMISSIONS = {"host_shell", "host_filesystem_unrestricted", "credential_access", "security_policy_write", "self_approve", "unrestricted_network", "host_process_control"}
_ID_RE = re.compile(r"^[a-z0-9][a-z0-9._-]{1,63}$")


@dataclass(frozen=True)
class ExtensionSpec:
    extension_id: str
    name: str
    category: str
    description: str
    permissions: tuple[str, ...]
    maturity: str = "capability_template"
    requires_external_runtime: bool = False


_BUILTINS = [
    ExtensionSpec("web-development", "Web development", "software", "Frontend, backend, API, browser, and accessibility project workflows.", ("read_project", "write_candidate", "run_isolated_tests", "read_bundled_knowledge")),
    ExtensionSpec("game-development", "Game development", "interactive", "Game loops, assets metadata, rendering, input, physics, and simulation architecture.", ("read_project", "write_candidate", "run_isolated_tests", "read_bundled_knowledge")),
    ExtensionSpec("3d-graphics", "3D graphics", "graphics", "3D scene, rendering pipeline, shader, and asset-pipeline design.", ("read_project", "write_candidate", "run_isolated_tests", "read_bundled_knowledge")),
    ExtensionSpec("scientific-simulation", "Scientific simulation", "science", "Numerical models, validation, reproducibility, and simulation test design.", ("read_project", "write_candidate", "run_isolated_tests", "read_bundled_knowledge")),
    ExtensionSpec("data-engineering", "Data engineering", "data", "Schema, data-pipeline, storage, and data-quality workflows.", ("read_project", "write_candidate", "run_isolated_tests", "read_bundled_knowledge")),
    ExtensionSpec("machine-learning", "Machine learning", "ai", "Local ML workflows, dataset validation, experiment tracking, and evaluation.", ("read_project", "write_candidate", "run_isolated_tests", "read_bundled_knowledge"), requires_external_runtime=True),
    ExtensionSpec("embedded-systems", "Embedded systems", "hardware", "Firmware, embedded code, peripheral abstractions, and hardware-in-loop planning.", ("read_project", "write_candidate", "run_isolated_tests", "read_bundled_knowledge"), requires_external_runtime=True),
    ExtensionSpec("mobile-apps", "Mobile applications", "software", "Responsive web/PWA and native mobile architecture and validation.", ("read_project", "write_candidate", "run_isolated_tests", "read_bundled_knowledge")),
    ExtensionSpec("security-review", "Security review", "security", "Threat modeling, static review, dependency inventory, and regression-test planning.", ("read_project", "write_candidate", "run_isolated_tests", "read_bundled_knowledge")),
    ExtensionSpec("devops-cloud", "DevOps and cloud", "operations", "Build, CI, deployment, infrastructure, monitoring, and recovery design.", ("read_project", "write_candidate", "run_isolated_tests", "read_bundled_knowledge"), requires_external_runtime=True),
    ExtensionSpec("systems-programming", "Systems programming", "software", "Operating systems, memory models, concurrency, networking, native runtimes, and performance-critical code.", ("read_project", "write_candidate", "run_isolated_tests", "read_bundled_knowledge")),
    ExtensionSpec("compiler-toolchains", "Compiler and toolchain engineering", "developer-tools", "Lexing, parsing, type systems, intermediate representations, code generation, linkers, build graphs, and static analysis.", ("read_project", "write_candidate", "run_isolated_tests", "read_bundled_knowledge")),
    ExtensionSpec("database-systems", "Database systems", "data", "Relational and non-relational data models, transactions, query planning, indexes, replication, and storage engines.", ("read_project", "write_candidate", "run_isolated_tests", "read_bundled_knowledge")),
    ExtensionSpec("distributed-systems", "Distributed systems", "architecture", "Consistency, consensus, partition tolerance, idempotency, queues, service discovery, and failure recovery.", ("read_project", "write_candidate", "run_isolated_tests", "read_bundled_knowledge")),
    ExtensionSpec("network-protocols", "Networking and protocols", "infrastructure", "TCP/IP, DNS, HTTP, TLS, message formats, protocol design, packet analysis, and network reliability.", ("read_project", "write_candidate", "run_isolated_tests", "read_bundled_knowledge")),
    ExtensionSpec("mobile-native", "Native mobile engineering", "software", "iOS and Android architecture, lifecycle, permissions, storage, accessibility, and device testing.", ("read_project", "write_candidate", "run_isolated_tests", "read_bundled_knowledge")),
    ExtensionSpec("desktop-applications", "Desktop applications", "software", "Cross-platform desktop applications, window systems, packaging, update paths, and platform integration.", ("read_project", "write_candidate", "run_isolated_tests", "read_bundled_knowledge")),
    ExtensionSpec("data-science-analytics", "Data science and analytics", "data", "Statistical analysis, reproducibility, data quality, visualization, experimentation, and responsible interpretation.", ("read_project", "write_candidate", "run_isolated_tests", "read_bundled_knowledge")),
    ExtensionSpec("ai-ml-engineering", "AI and machine-learning engineering", "ai", "Model evaluation, feature/data pipelines, training infrastructure, inference optimization, and reliability measurement.", ("read_project", "write_candidate", "run_isolated_tests", "read_bundled_knowledge"), requires_external_runtime=True),
    ExtensionSpec("formal-methods", "Formal methods and verification", "quality", "Specifications, invariants, property-based testing, model checking, and proof-oriented engineering.", ("read_project", "write_candidate", "run_isolated_tests", "read_bundled_knowledge")),
    ExtensionSpec("accessibility-localization", "Accessibility and localization", "quality", "Accessible interaction, semantic interfaces, assistive technology, internationalization, and localization testing.", ("read_project", "write_candidate", "run_isolated_tests", "read_bundled_knowledge")),
    ExtensionSpec("robotics-control", "Robotics and control systems", "hardware", "Kinematics, control theory, sensors, actuators, simulation, embedded interfaces, and safety cases.", ("read_project", "write_candidate", "run_isolated_tests", "read_bundled_knowledge"), requires_external_runtime=True),
    ExtensionSpec("graphics-media", "Graphics and media engineering", "graphics", "Rendering, geometry, image/audio/video pipelines, real-time constraints, and visual correctness tests.", ("read_project", "write_candidate", "run_isolated_tests", "read_bundled_knowledge")),
    ExtensionSpec("documentation-education", "Technical documentation and education", "knowledge", "API references, tutorials, architecture records, migration guides, and learning material with provenance.", ("read_project", "write_candidate", "run_isolated_tests", "read_bundled_knowledge")),
    ExtensionSpec("quantum-computing", "Quantum computing", "science", "Quantum information basics, circuit models, simulation, algorithm limits, and hardware-aware validation.", ("read_project", "write_candidate", "run_isolated_tests", "read_bundled_knowledge"), requires_external_runtime=True),
    ExtensionSpec("hardware-digital-logic", "Computer hardware and digital logic", "hardware", "Logic design, instruction sets, memory hierarchies, buses, FPGA workflows, and hardware/software interfaces.", ("read_project", "write_candidate", "run_isolated_tests", "read_bundled_knowledge"), requires_external_runtime=True),
]


class ExtensionRegistry:
    def __init__(self, extension_dir: Path = EXTENSION_DIR):
        self.extension_dir = Path(extension_dir)
        self.extension_dir.mkdir(parents=True, exist_ok=True)

    @staticmethod
    def validate_manifest(value: Any) -> dict[str, Any]:
        if not isinstance(value, dict):
            raise ValueError("Extension manifest must be a JSON object.")
        extension_id = str(value.get("id", ""))
        name = str(value.get("name", "")).strip()
        category = str(value.get("category", "")).strip()
        description = str(value.get("description", "")).strip()
        permissions = value.get("permissions", [])
        if not _ID_RE.fullmatch(extension_id) or not name or len(name) > 120 or not description or len(description) > 2000 or not category or len(category) > 80:
            raise ValueError("Extension id, name, category, or description is invalid.")
        if not isinstance(permissions, list) or len(permissions) > 12 or any(not isinstance(p, str) for p in permissions):
            raise ValueError("Extension permissions must be a bounded string list.")
        if any(p in FORBIDDEN_PERMISSIONS for p in permissions):
            raise PermissionError("Extension requests a forbidden host capability.")
        unknown = set(permissions) - ALLOWED_PERMISSIONS
        if unknown:
            raise PermissionError("Extension requests unsupported permissions: " + ", ".join(sorted(unknown)))
        return {"id": extension_id, "name": name, "category": category, "description": description,
                "permissions": sorted(set(permissions)), "version": str(value.get("version", "0.1.0"))[:40],
                "requires_external_runtime": bool(value.get("requires_external_runtime", False))}

    def list_extensions(self) -> list[dict[str, Any]]:
        items = [asdict(item) | {"permissions": list(item.permissions)} for item in _BUILTINS]
        for path in sorted(self.extension_dir.glob("*.json")):
            if path.is_symlink() or not path.is_file():
                continue
            try:
                item = self.validate_manifest(json.loads(path.read_text(encoding="utf-8")))
                item["maturity"] = "manifest_only_not_executable"
                items.append(item)
            except (OSError, UnicodeError, json.JSONDecodeError, ValueError, PermissionError):
                continue
        return items

    def add_manifest(self, value: Any) -> Path:
        item = self.validate_manifest(value)
        target = self.extension_dir / f"{item['id']}.json"
        if target.exists() or target.is_symlink():
            raise FileExistsError("An extension with that ID already exists.")
        target.write_text(json.dumps(item, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
        return target

    def get_extension(self, extension_id: str) -> dict[str, Any] | None:
        return next((item for item in self.list_extensions() if item.get("extension_id", item.get("id")) == extension_id), None)
