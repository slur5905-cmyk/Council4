# Technical debt, maintainability, and code quality

## Types of debt

Technical debt includes intentional shortcuts, accidental complexity, duplicated logic, weak tests, unclear boundaries, obsolete dependencies, undocumented assumptions, and operational fragility. Not every imperfect design is debt; record the future cost and context rather than labeling style preferences as defects.

## Code health

Maintainability benefits from clear names, small cohesive modules, explicit contracts, low coupling, useful abstractions, and consistent error handling. Excess abstraction can make simple behavior difficult to trace. Refactoring should preserve externally observable behavior unless a behavior change is explicit.

## Prioritization

Prioritize debt by user impact, failure likelihood, security exposure, frequency of change, and cost of future work. Track interest: how the debt makes future changes slower or riskier. Avoid broad rewrites without a migration strategy and independently verifiable milestones.

## Refactoring workflow

Establish baseline tests and behavior before editing. Change one boundary at a time, keep diffs reviewable, test each stage, and preserve a rollback path. Use static analysis and profiling to support claims. Do not claim code is cleaner or faster based only on line count.

## Governance

Architecture decision records capture context and trade-offs. Ownership and dependency maps help coordinate changes. Definition of done should include tests, documentation, security, accessibility, performance, and operations appropriate to the project risk.
