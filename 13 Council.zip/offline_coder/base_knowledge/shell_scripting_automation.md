# Shell scripting and automation

## Shells and processes

Bash, Zsh, PowerShell, and Windows command shells have different quoting, expansion, pipeline, variable, and error semantics. A script should identify its interpreter and target platform. Prefer argument arrays over concatenated command strings. Quote paths and values; account for whitespace, globbing, Unicode, and leading hyphens.

## Robust scripts

Use strict modes intentionally, but understand their edge cases. Check command exit codes and handle expected failures. Use temporary directories with predictable cleanup, traps or structured cleanup, bounded output, and timeouts. Avoid `eval` and shell construction from untrusted strings. Never print credentials in diagnostics.

## Files and automation

Use atomic writes where possible; verify checksums for downloaded artifacts; avoid following unexpected symlinks; and define how interrupted operations recover. A script that modifies files should support dry-run or clear preview where practical. Make repeated execution safe when the workflow is expected to be rerunnable.

## CI usage

CI jobs should have minimal permissions, pinned actions, isolated workers, controlled secrets exposure, and explicit artifacts. Treat pull-request code as untrusted. Avoid giving untrusted workflows access to deployment secrets. Limit job concurrency and artifact size. Keep logs useful but scrub credentials and personal data.

## Portability

Do not assume GNU-specific utilities, a particular shell, path separator, newline convention, or filesystem behavior. Use standard libraries or documented platform equivalents. Test on the actual environments that the project claims to support.
