# Quantum Computing Fundamentals

## Qubits and measurement
A qubit is a quantum two-level system described by amplitudes over basis states. A pure single-qubit state is a normalized complex superposition; measurement in a chosen basis produces a classical outcome according to squared amplitude magnitudes. A qubit is not simply a classical bit that stores both values for ordinary access. Measurement changes the state and yields limited classical information.

## Gates and entanglement
Quantum gates are unitary transformations. Multi-qubit systems can be entangled, meaning their joint state cannot be represented as independent states of each component. Quantum circuits compose gates and measurements. Algorithms exploit interference and entanglement for specific tasks; they do not make every computation faster. No-cloning prevents arbitrary unknown quantum states from being copied.

## Noise and error correction
Physical qubits are noisy and susceptible to decoherence, control errors, leakage, crosstalk, and measurement error. Quantum error correction encodes logical information across multiple physical qubits and requires repeated syndrome extraction and correction. Fault-tolerant computation has substantial overhead. Current device capabilities and error rates are hardware- and vendor-specific and change rapidly.

## Algorithms and limits
Shor's algorithm changes the complexity of factoring and discrete logarithms on sufficiently large fault-tolerant quantum computers. Grover's algorithm provides a quadratic query speedup for unstructured search, not an exponential speedup. Quantum simulation is a promising application. Classical computers remain essential for orchestration, error correction, data processing, and most workloads.

## Practical evaluation
Distinguish gate-based quantum computing, annealing, analog simulation, and quantum-inspired classical methods. Evaluate qubit quality, connectivity, circuit depth, error rates, compilation, queue time, and end-to-end cost. Do not claim quantum advantage from raw qubit counts or isolated demonstrations without a fair classical baseline and reproducible evidence.
