# Software architecture, domain modeling, and system boundaries

Architecture is a set of decisions about components, responsibilities, data ownership, dependencies, deployment, and change. A good architecture makes common changes local, critical behavior testable, and failure boundaries explicit. It is not measured by the number of layers, patterns, services, or diagrams.

## Requirements and quality attributes

Separate functional requirements from quality attributes such as performance, reliability, security, privacy, maintainability, portability, and accessibility. Turn vague goals into measurable scenarios: workload, environment, expected response, and threshold. Identify constraints that cannot be traded away, and record assumptions that need validation. A design can be correct for a prototype and inadequate for a regulated or high-availability environment.

## Decomposition and coupling

Partition by cohesive capabilities and ownership, not merely by technical layer. High cohesion groups things that change together; low coupling limits the effects of change across boundaries. Define interfaces and data contracts. Dependency direction should make core business rules independent of delivery frameworks and infrastructure where practical. Avoid circular dependencies and hidden global state.

A modular monolith can be easier to test and deploy than a distributed microservice system. Services introduce network failure, data ownership, deployment coordination, observability, and operational cost. Split a service when independent scaling, ownership, fault isolation, or release cadence justifies those costs—not because “microservices” are fashionable.

## Domain modeling

Domain-driven design uses bounded contexts to separate models whose terms or invariants differ. Entities have identity and lifecycle; value objects are defined by their values; aggregates enforce local consistency boundaries; domain events communicate meaningful state changes. Repositories abstract persistence for domain objects, but abstractions should not hide important transaction or query semantics.

Use ubiquitous language with domain experts. Distinguish commands that request changes from events that record facts. Avoid turning every field into a generic status or using one giant model for unrelated domains. Explicitly define invariants and which component owns each invariant.

## Architectural styles

Layered, hexagonal/ports-and-adapters, clean, event-driven, pipeline, actor, data-oriented, and client-server styles solve different problems. Ports-and-adapters isolate core logic from external systems. Event-driven systems reduce direct coupling but add eventual consistency and replay concerns. Actors can simplify single-owner mutable state but require message protocols and supervision. Data-oriented design can improve locality for simulations and high-throughput processing.

Patterns are tools, not requirements. Factories, strategies, adapters, observers, and dependency injection are useful when they simplify change or testing. Abstracting a single trivial function can create more complexity than it removes.

## Architecture decision records

Write short decision records for consequential choices: context, problem, options, decision, trade-offs, consequences, and revisit triggers. Preserve why a choice was made so later teams can distinguish intentional constraints from accidental behavior. Do not treat old decisions as immutable when evidence changes.

## Evolution and migration

Prefer incremental, reversible changes. Use feature flags, compatibility layers, staged data migrations, and shadow reads where appropriate. Define rollback and observability before risky changes. Track coupling, module dependency direction, build times, defect hotspots, and change lead time. Architecture quality is empirical: measure whether the system remains understandable and changeable as real requirements evolve.
