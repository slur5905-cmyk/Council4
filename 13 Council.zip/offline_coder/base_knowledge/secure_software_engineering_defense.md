# Secure software engineering and defensive application design

Security is a property of the entire system and its operating context, not a single scanner result. Start by identifying assets, trust boundaries, user roles, external dependencies, data sensitivity, attacker capabilities, and failure consequences. Threat models should be revisited when architecture, dependencies, deployment, or permissions change.

## Secure design principles

Use least privilege, deny by default, complete mediation, separation of duties, secure defaults, and defense in depth. Minimize secrets and sensitive data. Keep control planes separate from untrusted project content. Validate inputs at trust boundaries, encode output for its context, and use well-maintained cryptographic libraries instead of inventing primitives. Authentication proves an identity claim; authorization decides which actions that identity may perform.

## Common weakness families

Input and output errors can produce injection, cross-site scripting, path traversal, unsafe deserialization, and request-forgery problems. Access-control failures include insecure direct object references and relying on client-side hiding. Authentication failures include weak recovery flows, session fixation, insufficient rate limits, and poor token handling. Resource-exhaustion failures include unbounded uploads, recursion, expensive queries, concurrency, and decompression bombs. Supply-chain risks include compromised packages, mutable CI references, exposed build secrets, and unreviewed update scripts.

Defenses should be specific to the sink and protocol: parameterized database queries; context-aware output encoding; strict path normalization and canonical containment; safe serialization formats and schema validation; CSRF defenses for cookie-authenticated browser flows; secure cookies and session rotation; bounded sizes and timeouts; and pinned, reviewed dependencies. One generic “sanitize” function cannot safely address every class.

## Secrets and cryptography

Generate secrets with cryptographically secure randomness, keep them out of source control and logs, scope permissions, rotate with a tested process, and support revocation. Prefer managed key stores or OS-provided secret services where available. Encryption at rest does not protect data from a compromised process that can decrypt it. TLS protects data in transit only when certificate validation and endpoint identity checks are correct.

Use modern, reviewed protocols and high-level APIs. Keep password hashing separate from general-purpose hashing; use purpose-built password-hashing algorithms with salts and appropriate work factors. Never invent algorithms or hardcode keys. Plan for key backup, rotation, revocation, and recovery before deployment.

## Dependency and build security

Lock dependencies, verify package provenance where supported, review release artifacts, generate an inventory, and monitor advisories. Build systems are privileged: limit CI token scopes, avoid secrets on untrusted pull requests, pin actions and images to immutable versions or digests where practical, isolate build jobs, and protect release credentials. An inventory alone is not a vulnerability assessment; a scanner result alone is not proof of safety.

## Secure testing and response

Test authorization at server boundaries, malformed inputs, oversized inputs, replay behavior, resource caps, error paths, and dependency failures. Use static analysis, dynamic tests, dependency review, secret scanning, and manual threat review as complementary layers. Maintain a coordinated vulnerability-reporting process, patch plan, incident-response contacts, audit logs, and tested backups.

Security claims should state scope, version, environment, tools, and untested areas. Do not report “secure” merely because tests pass. Record an unresolved risk with owner, impact, likelihood, and mitigation rather than hiding uncertainty.
