# IoT and firmware device lifecycle

## Device constraints

Embedded and IoT devices may have limited CPU, memory, storage, power, connectivity, and physical access. Firmware interacts with sensors, actuators, radios, bootloaders, and hardware registers. Test exact board revisions, peripheral behavior, and electrical characteristics.

## Secure boot and updates

Secure boot verifies a chain of trust from immutable roots through bootloaders to firmware. Firmware updates need signature verification, rollback strategy, version checks, recovery from interrupted writes, and protected signing keys. Avoid unsigned update channels and weak default credentials.

## Communication

Devices may use Wi-Fi, Bluetooth LE, Ethernet, cellular, Zigbee, Thread, or field buses. Protocols have different range, bandwidth, power, topology, and security properties. Device identity, provisioning, key rotation, and loss of connectivity must be designed explicitly.

## Lifecycle

A device is not secure only at manufacture. Plan provisioning, monitoring, patching, decommissioning, data erasure, and end-of-support. Track model and firmware versions, vulnerability response, and spare/recovery procedures. Avoid deploying unsupported hardware without a maintenance plan.

## Validation

Use simulators, emulators, unit tests, hardware-in-loop, power-failure testing, fuzzing of parsers, and radio/network testing as suitable. Physical hardware can be damaged by incorrect voltages or wiring; consult board documentation and use controlled lab conditions.
