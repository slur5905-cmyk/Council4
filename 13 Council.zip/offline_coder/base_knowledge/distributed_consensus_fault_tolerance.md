# Distributed systems: consensus, failure, and fault tolerance

A distributed system contains components that communicate over networks and may fail independently. Network delay, packet loss, process pauses, clock drift, partitions, partial deployment, and correlated failures make a remote call fundamentally different from a local function call. A timeout means the caller did not receive a response in time; it does not prove the remote operation failed.

## Failure models and time

Distinguish crash failures, omission failures, arbitrary/malicious behavior, and network partitions. A system's guarantees depend on the failure model it claims to tolerate. Wall clocks can jump; monotonic clocks are appropriate for measuring elapsed time. Distributed timestamps do not automatically establish causality. Lamport clocks and vector clocks can model event ordering, but do not replace business-level conflict rules.

## Replication and consensus

Replication maintains copies of state. Leader-based systems route writes through a leader; followers may lag. Synchronous replication improves durability/consistency at a latency cost; asynchronous replication can lose recent acknowledged writes during some failures. Quorums rely on carefully chosen intersection properties and membership configuration.

Consensus protocols such as Raft or Paxos coordinate agreement under defined assumptions. They address leader election, ordered log commitment, and recovery from node failures. Consensus does not guarantee that application logic is correct, that a committed command has the intended meaning, or that external side effects happen exactly once. Membership changes, snapshots, log compaction, and recovery are substantial engineering concerns.

## Consistency models

Strong consistency provides a view close to a single up-to-date copy under defined operations. Eventual consistency allows replicas to converge when updates stop, but clients may read stale values. Causal consistency preserves cause-before-effect relationships. Linearizability, serializability, and sequential consistency refer to different guarantees. State the required operations and guarantees precisely; avoid marketing terms without definitions.

Conflict resolution can use last-writer-wins, application-specific merge rules, version vectors, CRDTs, or user intervention. Last-writer-wins can silently lose meaningful updates if clock assumptions are weak. CRDTs support convergence for selected data types under formal conditions, but not every business invariant is naturally mergeable.

## Reliable messaging and side effects

Messages can be delivered zero, one, or multiple times depending on system behavior. At-least-once delivery requires idempotent consumers. At-most-once delivery may lose work. “Exactly once” usually applies to a constrained transaction boundary and should not be assumed across a database, broker, and external API together. Use durable queues, acknowledgements, deduplication keys, outbox/inbox patterns, bounded retries, backoff, jitter, dead-letter handling, and replay-safe handlers.

## Resilience patterns

Set deadlines that propagate across service calls. Use circuit breakers to stop repeatedly calling a failing dependency, bulkheads to isolate resource pools, bounded queues for backpressure, and load shedding to preserve critical paths. Retries can amplify an outage; retry only transient failures and only within a deadline. Capacity planning must consider fan-out and the slowest dependency, not just average CPU usage.

## Testing and operations

Test partitions, delayed responses, duplicated messages, process restarts, leader changes, partial writes, clock behavior, and recovery from backups. Use deterministic fault injection where possible. Monitor freshness, replication lag, quorum availability, queue age, retry volume, and end-to-end business outcomes. Document which guarantees are provided during failure and what data may be lost. Do not infer correctness from a healthy dashboard alone.
