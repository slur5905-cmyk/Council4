# CPU Microarchitecture, Instruction Sets, and Low-Level Execution

## Instruction-set architecture
An ISA defines the software-visible instruction set, registers, memory operations, privilege model, exceptions, and calling conventions. Microarchitecture is how a processor implements that contract. Different processors can implement the same ISA with different pipelines, caches, execution units, and power characteristics. ISA compatibility does not imply identical performance.

## Execution pipelines
Modern processors may use pipelining, branch prediction, speculative execution, out-of-order execution, register renaming, and multiple issue. These features improve throughput but complicate timing and side-channel behavior. A source-level operation may compile into several machine instructions; inspect generated assembly when low-level performance or correctness matters.

## SIMD and vectorization
SIMD instructions apply operations to multiple data elements. Vectorization can improve throughput when data is regular and alignment, dependencies, and memory bandwidth permit it. Scalar tails, masks, floating-point reassociation, and target-specific instruction support affect correctness and portability. Use compiler vectorization reports and benchmark on target hardware.

## Memory ordering and atomics
Processors and compilers may reorder operations when the language memory model permits it. Data races in languages that define them as undefined behavior cannot be repaired by assuming a particular CPU order. Use language-defined atomics, locks, and synchronization primitives. Understand acquire/release and sequentially consistent ordering at the language level before reasoning about hardware instructions.

## Performance and security
Branch misses, cache misses, TLB misses, instruction dependencies, and memory bandwidth can dominate runtime. Microbenchmarks are sensitive to compiler optimization, CPU frequency scaling, thermal state, and background load. Speculative execution has also produced side-channel classes; follow current vendor and OS mitigations instead of attempting ad hoc barriers without evidence.
