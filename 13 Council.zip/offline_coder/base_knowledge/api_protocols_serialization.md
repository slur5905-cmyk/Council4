# APIs, Protocols, Serialization, and Compatibility Engineering

## Contracts
An API contract includes input schema, output schema, errors, side effects, authorization, ordering, idempotency, rate limits, timeouts, consistency, and versioning. A function signature alone is not a complete contract. Document preconditions, postconditions, invariants, and failure behavior. Avoid leaking internal representations that make compatible evolution difficult.

HTTP methods have conventional semantics: safe methods should not request state changes; idempotent methods can be repeated without changing the intended result after the first application. Retries are safe only when the operation and server behavior justify them. POST is not automatically idempotent. Use idempotency keys or explicit opt-in where duplicate side effects are dangerous. Respect retry budgets, server guidance such as `Retry-After`, exponential backoff with jitter, and deadlines.

## Protocols and transport
Separate application protocols from transport. DNS, TCP, UDP, QUIC, TLS, HTTP/1.1, HTTP/2, HTTP/3, WebSocket, Server-Sent Events, and message queues solve different problems. Understand connection lifecycle, name resolution, certificates, SNI, proxies, NAT, congestion control, keep-alive, flow control, framing, and partial reads/writes. Timeouts should cover connection, request, and total operation budgets. Do not treat an open socket as proof of service health.

## Serialization and schemas
JSON, CBOR, Protocol Buffers, Avro, MessagePack, XML, CSV, and binary custom formats have different size, type, evolution, and interoperability tradeoffs. Validate decoded values and impose size/depth limits before materializing large structures. Use explicit schema versions and compatibility tests. Unknown fields, enum additions, default values, integer ranges, Unicode, timestamps, decimal money, and nullability require deliberate policy.

## API evolution
Prefer additive changes when consumers are independently deployed. Use deprecation windows, compatibility adapters, migration tooling, contract tests, and version negotiation. Database migrations must account for old and new application versions coexisting. A breaking change is not safe merely because the local test suite passes.

## Security and observability
Authenticate identities, authorize individual actions, validate every boundary, avoid leaking secrets in errors, and apply rate/resource limits. Logs should contain correlation identifiers and useful event context but not credentials or sensitive payloads. Metrics should track latency distributions, error rates, saturation, retries, and queue depth. Traces should show cross-service dependencies without exposing private data.
