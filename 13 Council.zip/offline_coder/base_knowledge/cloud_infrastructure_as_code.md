# Cloud Infrastructure and Infrastructure as Code

## Desired state
Infrastructure as code declares desired resources and configuration so changes can be reviewed, repeated, and audited. Tools differ in declarative model, state storage, drift detection, dependency graph, and secret handling. Treat plans as proposals, inspect destructive changes, and protect state files that may contain sensitive metadata.

## Identity and network boundaries
Cloud security depends on identity policies, workload identity, service accounts, network segmentation, secret stores, encryption, and audit trails. Grant narrowly scoped roles. Avoid long-lived static credentials when short-lived identity mechanisms are available. Public network exposure and default permissions should be explicit and reviewed.

## Reliability and scaling
Design for zones or regions according to availability requirements, but understand data consistency, failover time, cost, and operational complexity. Autoscaling reacts to signals and can amplify instability when configured without limits. Use quotas, budgets, rate limits, health checks, circuit breakers, and backpressure. Capacity planning must include traffic spikes and dependency failure.

## Deployment practice
Use immutable artifacts, reproducible builds, staged rollout, health-based promotion, rollback, and database migration strategies compatible with mixed application versions. Keep deployment credentials out of build logs. Protect CI/CD with minimum permissions and immutable action references where supported. Separate build, test, approval, and production deployment identities.

## Cost and portability
Cloud abstractions can create vendor lock-in and hidden cost. Model data egress, storage operations, idle resources, logs, retention, support, and managed-service pricing. Use portable interfaces only when they provide value; avoid pretending every provider's service semantics are identical.
