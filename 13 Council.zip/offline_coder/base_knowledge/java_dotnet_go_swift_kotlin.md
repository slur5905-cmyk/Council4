# Java, .NET, Go, Swift, Kotlin, and Managed Runtime Engineering

## Managed runtimes
Java and .NET compile source into intermediate representations executed or JIT-compiled by managed runtimes. Garbage collection manages object memory but not every resource: files, sockets, database cursors, native handles, and GPU resources still require deterministic disposal. Understand allocation pressure, object lifetime, class loading, JIT warmup, reflection, runtime metadata, and garbage-collector pauses. Performance measurements should separate startup, warmup, steady state, and tail latency.

## Java and JVM ecosystem
The JVM bytecode and Java language are not the same thing; Kotlin, Scala, and other languages can target the JVM. Classpaths, modules, class loaders, reflection, generics erasure, synchronization, and memory visibility influence runtime behavior. Use try-with-resources, explicit executor lifecycle, bounded thread pools, and timeouts. Avoid unbounded futures and blocking calls inside event-loop frameworks.

## .NET ecosystem
.NET includes C#, F#, Visual Basic, the Common Language Runtime, managed assemblies, NuGet, and runtime-specific deployment options. Understand nullable reference types, async/await, task cancellation, `IDisposable`/`IAsyncDisposable`, dependency injection lifetimes, assembly loading, trimming, ahead-of-time compilation, and target framework monikers. A nullable annotation is not a runtime validator; validate external inputs.

## Go
Go emphasizes simple concurrency primitives, interfaces, explicit errors, modules, and garbage collection. Goroutines are lightweight but still consume resources; bound their creation and ensure every goroutine has a clear cancellation/exit path. Channels can communicate ownership, but mutexes may be simpler for shared state. Check `context.Context` cancellation, close resources, handle partial I/O, and run the race detector. Module versions and the `go` directive influence compatibility.

## Swift and Kotlin
Swift combines value and reference types, protocols, optionals, ARC, structured concurrency, actors, and platform frameworks. ARC can leak cycles; use weak/unowned references only with correct lifetime reasoning. Swift concurrency isolation does not remove domain-level logic errors. Kotlin combines JVM or native targets, null-safety, coroutines, extension functions, and platform interoperability. Structured coroutine scopes and cancellation are essential; a cancelled coroutine must not continue work accidentally.

## Engineering approach
For any managed platform, record runtime version, target framework, SDK, compiler, package lock, and deployment model. Test native platform integrations on the actual OS where feasible. Separate compiler diagnostics, static analysis, unit tests, integration tests, and runtime profiling. Confirm exact APIs against official docs for the deployed version, not an assistant's memory.
