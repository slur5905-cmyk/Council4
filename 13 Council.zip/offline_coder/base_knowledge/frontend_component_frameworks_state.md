# Frontend Frameworks, Component Systems, and State Management

## Component architecture
A component should have a coherent responsibility, explicit inputs, and predictable outputs. Separate rendering from domain logic and side effects. Use semantic HTML and platform controls where possible. Component abstraction should reduce repetition and clarify behavior rather than merely split every visual fragment into another layer.

## State models
Distinguish local UI state, shared client state, server state, URL state, and persisted state. Derived values should be computed from their source of truth rather than duplicated. Define loading, empty, error, stale, offline, and permission-denied states. Avoid race conditions from overlapping requests by using cancellation or request identity.

## Rendering and reconciliation
Virtual DOM and reactive systems track dependencies and update output when state changes. Stable keys preserve identity in lists. Excessive re-rendering, unstable keys, large component trees, and layout thrashing can affect performance. Memoization is useful only when it reduces measured work without creating stale values or complicated invalidation.

## Forms and accessibility
Forms need labels, input constraints, error association, keyboard operation, focus management, and clear submission state. Validation should occur on both client and server. Preserve user input after failures and avoid inaccessible custom controls. Test screen readers, zoom, reduced motion, and mobile virtual keyboards.

## Framework and version discipline
Framework APIs, routing, build tools, hydration, server components, and state libraries change across versions. Inspect the lockfile and installed version; prefer the project's existing conventions. Do not invent APIs based on a newer version or mix incompatible package versions. Verify current behavior using installed documentation, type definitions, and tests.
