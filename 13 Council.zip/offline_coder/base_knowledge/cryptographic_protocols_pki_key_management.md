# Cryptographic Protocols, PKI, and Key Management

## Cryptographic building blocks
Cryptographic hashes provide fixed-size digests; message-authentication codes provide integrity and authenticity with a shared key; digital signatures authenticate signed data using asymmetric keys; encryption provides confidentiality. These properties are different. Encoding, checksums, and password hashing are not interchangeable with encryption or signatures.

## Protocol construction
Secure protocols must address authentication, freshness, replay, downgrade, key confirmation, forward secrecy, transcript binding, and error behavior. Prefer established, reviewed protocols and maintained libraries. Do not design a new cipher, invent a handshake, or combine primitives ad hoc. Use authenticated encryption with carefully managed nonces and associated data.

## Public-key infrastructure
Certificates bind public keys to identities under a trust model. Validation includes chain construction, trust anchors, validity times, names, constraints, revocation policy, and algorithm policy. A certificate being syntactically valid does not mean the identity is trusted. TLS library defaults and platform trust stores should generally be used rather than implementing validation manually.

## Key lifecycle
Keys need generation, storage, access control, rotation, backup or escrow policy where appropriate, revocation, and destruction. Prefer operating-system keystores, hardware-backed protection, or managed key services according to the threat model. Do not log secrets, include keys in source control, or pass credentials in command-line arguments where process listings may expose them.

## Passwords and randomness
Store passwords using a dedicated password-hashing scheme with unique salts and suitable work factors, selected according to current guidance. Use cryptographically secure random generators for keys, tokens, and nonces. Ordinary pseudo-random generators are appropriate for simulation but not secrets. Verify the library's documented nonce and key-size requirements.
