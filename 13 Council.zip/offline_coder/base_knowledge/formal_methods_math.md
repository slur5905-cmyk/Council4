# Mathematics, Logic, Numerical Methods, and Formal Verification

## Discrete mathematics

Sets, relations, functions, equivalence classes, partial orders, graphs, trees, combinatorics, and recurrence relations support algorithms and data models. Understand injective/surjective/bijective functions, cardinality, permutations, combinations, and inclusion-exclusion. Modular arithmetic is useful for hashes, clocks, and cyclic buffers but not a substitute for safe overflow handling.

## Logic and proofs

Propositional and predicate logic express invariants and specifications. Quantifiers and scope matter. Proof techniques include direct proof, contradiction, contrapositive, induction, invariants, and exhaustive finite-state analysis. Hoare triples express precondition, program, and postcondition. A proof is only as sound as its specification and assumptions.

## Probability and statistics

Random variables, distributions, expectation, variance, covariance, conditional probability, Bayes' theorem, sampling, confidence intervals, hypothesis testing, and regression are useful in diagnostics and ML. Correlation does not imply causation. Avoid p-hacking, data leakage, multiple-comparison errors, and overstated conclusions. Understand base rates and selection bias.

## Linear algebra and optimization

Vectors, matrices, norms, eigenvalues, singular values, decompositions, and gradients underpin graphics, ML, robotics, and scientific computing. Numerical conditioning measures sensitivity to input perturbations. Optimization includes gradient descent, Newton/quasi-Newton methods, linear programming, and constrained optimization. Local minima, saddle points, constraints, and scaling matter.

## Numerical computing

Finite precision introduces rounding, cancellation, overflow, underflow, and accumulated error. Stable algorithms avoid amplifying numerical noise. Choose precision appropriate to the problem and validate with known solutions, error estimates, and higher-precision comparisons where feasible. Use dimensionless analysis and explicit units. Never treat a computed result as exact without justification.

## Formal methods

Model checking explores states under a formal model; theorem proving establishes properties from axioms and rules; static analysis approximates program behavior; symbolic execution explores paths with constraints; abstract interpretation computes safe approximations. Formal specifications should define invariants and environmental assumptions. Verification does not rescue an incorrect specification.

## State machines and protocols

Model state transitions explicitly, including allowed events, guards, actions, errors, timeouts, cancellation, and terminal states. Protocols should specify message grammar, ordering, retries, version negotiation, and backward compatibility. State-machine testing can cover transitions and transition pairs; property-based methods can explore sequences.

## Units and time

Use dimensional analysis to catch errors. Distinguish UTC instants, local civil time, time zones, offsets, monotonic clocks, and calendar periods. Daylight-saving changes can create missing or repeated local times. Use monotonic time for elapsed durations and timezone-aware timestamps for events. Store units and coordinate frames explicitly.
