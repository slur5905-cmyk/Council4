# Data formats, serialization, and interchange

## Format families

JSON and YAML are common human-oriented structured formats; XML supports document structure and namespaces; CSV is deceptively ambiguous without schema and quoting rules. Protocol Buffers, Avro, and Thrift define schema-based binary messages. Parquet and ORC are columnar analytics formats. MessagePack and CBOR are compact binary formats. Each has trade-offs in readability, size, typing, schema evolution, and ecosystem support.

## Schema evolution

Compatibility can be backward, forward, or full. Field numbers, defaults, optionality, enum additions, renames, and unknown-field handling affect compatibility. Use explicit schema versions and migrations. Avoid reusing removed field identifiers where a format prohibits it. Validate data at boundaries and keep examples for old and new payloads.

## Security

Parsing untrusted data can trigger resource exhaustion, deep recursion, entity expansion, unsafe object construction, or injection when later embedded into another language. Set size and depth limits. Disable unsafe XML external entities where appropriate. Never deserialize arbitrary executable object graphs from untrusted senders. Escape output for its destination context.

## Canonicalization and integrity

Equivalent data may have multiple textual representations. Cryptographic signatures require a well-defined canonical representation, stable field ordering, and exact encoding rules. A checksum detects accidental corruption but does not authenticate the origin. Preserve raw bytes when the original representation matters for signatures or audit evidence.

## Testing

Test malformed, truncated, oversized, unknown-field, duplicate-key, Unicode, timezone, numeric precision, and schema-version cases. Avoid assuming parsers agree on non-standard syntax. Verify content type and charset. Treat schemas as contracts that need review and migration plans.
