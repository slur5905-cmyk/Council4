# Memory management, garbage collection, and object lifetimes

Programs need a correct model for allocating, using, sharing, and releasing memory. The right strategy depends on language semantics, latency requirements, concurrency, object graph shape, and hardware. Memory bugs include leaks, use-after-free, double-free, out-of-bounds access, uninitialized reads, data races, and excessive allocation pressure.

## Storage regions and ownership

A process usually uses code and read-only regions, static/global data, stacks, and one or more heaps. Stack allocation is efficient for scoped data but does not make every object safe to return or share. Heap allocation supports flexible lifetimes but requires reclamation. Region/arena allocators allocate many objects together and free them as a unit; they are effective when lifetimes align. Object pools can reduce allocation overhead, but stale references and reuse bugs need careful handling.

Ownership systems encode who is responsible for a resource. Unique ownership makes transfer explicit; shared ownership uses reference counting or another lifetime protocol. Borrowing rules constrain references so an object is not freed while it is still used. These rules can prevent classes of memory errors, but interior mutability and concurrent sharing still require synchronization or atomics.

## Garbage collection

Tracing collectors start from roots such as stacks, registers, globals, and runtime handles, then visit reachable objects. Mark-sweep identifies live objects and reclaims others. Copying collectors move live objects between spaces. Generational collectors use the observation that many objects die young; barriers record references from older objects into younger generations. Concurrent and incremental collectors reduce pauses but require barriers, careful synchronization, and bounded work.

Reference counting reclaims objects when their count reaches zero. It offers prompt reclamation and simple local reasoning, but cycles need additional mechanisms and frequent count updates can be costly. Weak references do not keep objects alive, while finalizers/destructors introduce ordering and resurrection problems. Correct programs should not rely on an unspecified collection time for correctness.

## Lifetimes and resource cleanup

Memory lifetime and external-resource lifetime are different. Files, sockets, locks, database transactions, GPU buffers, and operating-system handles need deterministic cleanup. RAII, lexical scopes, `defer`, `using`, context managers, and structured resource APIs make cleanup visible. Cleanup should run on normal return and relevant error paths; cancellation and process termination require separate consideration. Destructors should not perform unreliable network operations or block indefinitely.

## Layout, cache, and false sharing

Object layout affects alignment, padding, pointer chasing, and cache locality. Arrays of structures and structures of arrays trade ergonomics against access patterns. False sharing occurs when independent frequently written values occupy the same cache line; it can slow multi-threaded programs even without a logical data race. Padding may help but should follow measurement. Compact layout can increase memory bandwidth efficiency but can make updates harder.

## Safe debugging

Use sanitizers and runtime diagnostics where available: address, undefined-behavior, thread, memory, and leak sanitizers each detect different classes of defects and have limitations. Use heap profiles, allocation traces, GC pause reports, and retained-object graphs. Minimize failing workloads and record build flags. A clean sanitizer run is evidence, not proof; untested paths and unsupported instrumentation remain.

Never solve a suspected leak by blindly increasing memory limits or forcing collection. Identify ownership, retention roots, object churn, and lifetime mismatches. Benchmark changes with realistic allocation patterns and concurrency, including tail latency and peak memory.
