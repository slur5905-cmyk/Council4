# Web Application Security: Sessions, Browser Boundaries, and Content Policy

## Identity and sessions
Authentication establishes an identity; authorization decides what that identity may do. Session identifiers are bearer credentials and must be unpredictable, protected in transit, and rotated after sensitive transitions. Cookie attributes such as Secure, HttpOnly, and SameSite reduce particular risks but do not replace server-side authorization. Apply expiration, revocation, and session renewal policies.

## Browser security boundaries
The same-origin policy limits script access across origins. CORS is a server-controlled sharing mechanism, not an authentication system. CSRF exploits ambient credentials; XSS executes attacker-controlled script in an origin. Use context-aware output encoding, safe DOM APIs, CSRF defenses where needed, and strict input validation. Client-side checks are usability aids, never authorization gates.

## Content Security Policy
CSP can restrict script, style, image, frame, worker, and connection sources. A carefully deployed policy can reduce the impact of some injection flaws. Start with report-only observation, then enforce a policy based on the app's required resources. Avoid broad wildcards and unsafe-inline/eval exceptions where possible. CSP does not fix unsafe server-side logic or trusted-script vulnerabilities.

## Server-side request and file risks
Validate outbound destinations to limit SSRF, including redirects, DNS resolution, private address ranges, and alternate IP representations. Enforce response-size and time limits. For uploads, inspect content rather than trusting extensions, store outside executable paths, and use bounded parsers. Avoid path traversal and archive extraction escapes.

## Security process
Use a threat model, dependency review, secure defaults, security headers, secret scanning, and regression tests. Record assumptions and accepted risks. Follow current OWASP guidance and browser specifications for version-sensitive recommendations; do not treat a static checklist as a security certification.
