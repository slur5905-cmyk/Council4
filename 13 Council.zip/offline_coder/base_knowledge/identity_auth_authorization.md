# Identity, Authentication, Authorization, and Session Security

## Identity concepts
Authentication establishes who or what is acting. Authorization decides what that identity may do to a specific resource in a specific context. Identification, authentication, authorization, and accounting are distinct. A user who has logged in is not automatically permitted to access every object. Apply least privilege and deny by default.

## Passwords and MFA
Passwords should be stored with a dedicated password hashing scheme such as Argon2id, scrypt, or an appropriately configured bcrypt/PBKDF2 implementation, with unique salts and suitable cost parameters. General-purpose hashes such as SHA-256 alone are not password hashing algorithms. Multi-factor authentication combines distinct factor classes; phishing-resistant authenticators such as passkeys/security keys are stronger against credential phishing than reusable codes. Recovery flows are part of the security model and must not silently weaken authentication.

## Sessions and tokens
Session identifiers must be unpredictable, protected in transit, rotated after authentication/privilege changes, and invalidated on logout or compromise. Cookie attributes include Secure, HttpOnly, and SameSite; scope and lifetime should be narrow. Bearer tokens are credentials: do not put them in URLs, logs, screenshots, error messages, or browser local storage without a deliberate threat analysis. Validate issuer, audience, signature, expiry, not-before, algorithm, and key rotation for signed tokens. A JWT is a format, not automatically an authentication system.

## Authorization models
RBAC assigns permissions to roles; ABAC evaluates attributes and context; relationship-based access control models ownership and relationships. Enforce object-level authorization on every server-side request. Avoid trusting client-provided role names or object IDs. Prevent IDOR/BOLA by checking that the authenticated principal is entitled to the exact referenced object and operation.

## Lifecycle and operations
Provisioning, deprovisioning, recovery, key rotation, device revocation, audit logs, and emergency access need clear ownership. Use short-lived credentials and workload identity where possible. Separate production and development identities. Monitor suspicious authentication patterns without collecting unnecessary personal data. Test account recovery, session revocation, privilege escalation, and tenant isolation.
