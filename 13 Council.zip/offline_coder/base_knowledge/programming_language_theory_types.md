# Programming language theory and type systems

## Language foundations

Programming languages define syntax, static or dynamic semantics, evaluation rules, runtime behavior, and interoperability. Grammars describe valid structure; operational or denotational semantics describe meaning. Lexers form tokens, parsers create syntax trees, and semantic analysis resolves names, types, scopes, and constraints. A syntax tree is not a complete semantic model.

## Type systems

Types classify values and constrain operations. Static typing checks properties before execution; dynamic typing checks during runtime. Nominal typing relies on declared identity, structural typing on shape, and gradual typing combines static and dynamic boundaries. Generics, polymorphism, subtyping, variance, type inference, effects, refinement types, and dependent types provide different expressive trade-offs.

## Memory and evaluation

Languages differ in ownership, borrowing, garbage collection, reference counting, manual allocation, value semantics, and object identity. Evaluation may be eager, lazy, strict, or staged. Exceptions, algebraic effects, continuations, coroutines, and async functions model control flow. Know the language's actual guarantees rather than importing expectations from another language.

## Design and interoperability

ABIs define calling conventions, data layout, symbol naming, exception behavior, and binary compatibility. FFI boundaries need explicit ownership and lifetime rules. Language bindings may alter error or null handling. Serialization is not equivalent to native object layout. Compiler versions, feature flags, target triples, and standard library versions can change supported behavior.

## Engineering approach

When changing language-specific code, consult the language specification or official documentation for the targeted version. Add compiler/type-checker tests and runtime tests where appropriate. Keep type annotations honest; avoid casts that suppress meaningful errors. Prefer APIs with explicit ownership and error handling over hidden global state.
