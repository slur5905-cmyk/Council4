# WebAssembly and edge runtimes

## WebAssembly model

WebAssembly defines a portable low-level bytecode and execution model with a linear memory model, typed instructions, modules, imports, exports, and validation. It is not a universal operating system or a direct replacement for native code. Host functions provide access to clocks, files, networking, and other capabilities, so the host determines much of the security boundary.

## WASI and components

WASI defines standardized system interfaces for WebAssembly runtimes. Interface and component-model versions evolve, and not all runtimes implement the same proposals. A module that compiles may not run in every browser, server, embedded runtime, or edge platform. Verify target features, ABI, resource limits, and host capabilities.

## Performance

Startup, compilation, JIT/AOT strategy, memory copies, host calls, and workload shape influence performance. Avoid assuming Wasm is always faster or safer than native code. Benchmark the exact target runtime and compare equivalent work. Memory growth and maximum limits need explicit planning.

## Security

Wasm modules are validated and sandboxed by runtimes, but imported host functions may expose sensitive resources. Apply least authority, memory and CPU limits, timeouts, and controlled filesystem/network preopens. Validate module provenance and dependencies. Treat runtime bugs and unsafe host integrations as part of the threat model.

## Engineering workflow

Use reproducible toolchains, target-specific tests, interface contracts, and a runtime matrix. Test both module logic and host bindings. Record runtime and feature versions because browser engines and server runtimes differ.
