# Python Engineering: Runtime, Packaging, Typing, and Performance

## Runtime model
Python source is parsed into an AST, compiled to code objects/bytecode, and executed by an implementation such as CPython. Language guarantees and implementation details differ: CPython reference counting and its global interpreter lock are implementation-specific, and free-threaded builds or other Python implementations can behave differently. Do not rely on object identity, finalizer timing, dictionary memory layout, or bytecode unless the supported runtime guarantees it.

Names are bindings to objects. Assignment does not copy a mutable object. Default argument expressions are evaluated once when a function is defined; use `None` or a sentinel when a per-call mutable default is needed. Understand lexical scope, closures, descriptors, class creation, method binding, generators, coroutines, context managers, and exception chaining. Use `with` or `try/finally` to release files, locks, sockets, and resources deterministically.

## Types and interfaces
Type annotations support documentation and static analysis; most annotations are not runtime enforcement. Use `Protocol` for structural interfaces, generics for reusable abstractions, `TypedDict` or dataclasses for structured records, `Enum` for finite choices, and explicit optional/result types for absence and failure. Avoid `Any` spreading across boundaries. Validate untrusted data at runtime even when annotations exist.

## Packaging and environments
Use isolated virtual environments and declared project configuration. Distinguish a library's supported dependency range from a deployment lockfile. Pin transitive dependencies for reproducible applications. Editable installs, namespace packages, entry points, wheels, source distributions, native extensions, and platform tags have different behaviors. Test the built wheel in a clean environment rather than relying only on the source checkout. Keep secrets, virtual environments, caches, and model weights out of source control.

## Concurrency and async
Threads, processes, asyncio tasks, and interpreter-specific parallelism have different cost and safety profiles. `asyncio` is cooperative: blocking CPU or synchronous I/O can stall the event loop. Use bounded queues and semaphores, timeouts, cancellation handling, and structured task lifetimes. Process pools incur serialization and startup costs. Shared mutable state requires synchronization or ownership discipline. Do not swallow cancellation errors unintentionally.

## Performance and reliability
Profile before optimizing. Measure wall time, CPU, allocations, peak memory, I/O wait, and tail latency. Consider algorithmic complexity before micro-optimizations. `time.perf_counter()` is for elapsed duration; wall-clock timestamps are not reliable duration clocks. Cache keys must include every input that affects output; caches need bounds, invalidation, and concurrency policy. Avoid unbounded lists, task creation, recursion, file reads, and logs.

Use pytest or unittest for behavior, property-based tests for broad input ranges, and type/lint checks as additional signals. Test supported Python minor versions and operating systems. Check exact library APIs against current official documentation; standard-library APIs evolve.
