# CPU architecture, caches, memory ordering, and performance

Modern processors execute instructions through pipelines and multiple levels of cache. Performance depends on instruction dependencies, branch prediction, memory access, vectorization, thread scheduling, and power management—not simply clock frequency or core count.

## Instruction execution

A CPU fetches, decodes, schedules, executes, and retires instructions. Out-of-order cores may execute independent instructions before earlier stalled work completes, while preserving architectural results. Branch prediction speculates on future control flow; a misprediction discards speculative work and costs cycles. Instruction-level parallelism is limited by dependencies, cache misses, branch behavior, and available execution units.

Instruction set architectures define the machine-visible contract; microarchitectures implement it differently. The same ISA can have different cache sizes, pipeline depths, vector units, and power characteristics. Compiler flags and runtime dispatch should match the target but retain fallbacks for older processors.

## Cache hierarchy and locality

Registers, L1/L2/L3 caches, main memory, and storage have different capacity and latency. Caches move data in cache lines. Temporal locality reuses recently accessed data; spatial locality accesses nearby addresses. Pointer-heavy structures can be slow due to cache misses even when the algorithm's asymptotic complexity is good. Data-oriented layouts and contiguous arrays often improve locality.

Cache coherence protocols maintain consistent views of shared cache lines among cores, but coherence does not make all concurrent programs correct. False sharing can cause cache-line ownership to bounce between cores. Aligning and separating hot mutable data may help, but profile before padding structures and increasing memory use.

## Memory models and atomics

Compilers and processors may reorder operations when the language memory model permits it. A data race can make program behavior undefined or otherwise invalid under the language's rules. Atomics define ordered operations; relaxed, acquire, release, and sequentially consistent modes provide different guarantees. Use the synchronization primitive that expresses the actual relationship. `volatile` is not a general replacement for atomic operations or locks.

Happens-before relationships define which writes are visible to which reads. Locks, condition variables, channels, barriers, and thread joins can establish such ordering. Lock-free algorithms require careful reasoning about memory reclamation and ABA problems; use proven libraries unless the performance need is demonstrated.

## SIMD and vectorization

SIMD applies one instruction to multiple data lanes. Auto-vectorization relies on alignment, aliasing, loop structure, and target capabilities. Explicit intrinsics can improve performance but increase complexity and reduce portability. Tail handling, mask semantics, and floating-point rounding must be tested. GPU execution uses a different parallel model and is not simply a wider CPU vector instruction.

## Benchmark methodology

Measure end-to-end tasks with warmup and repeated trials. Track throughput and latency percentiles. Control background load, CPU governor, temperature, compiler flags, and input shape where possible. Avoid timing a tiny operation with an inaccurate clock. Use hardware counters and profilers to test hypotheses about branch misses, cache misses, cycles, and bandwidth. Optimize only a measured bottleneck, then re-run representative tests for correctness and performance regressions.
