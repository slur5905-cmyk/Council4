# Digital Signal Processing and Audio Engineering

## Sampling and representation
A digital signal samples an analog process at discrete times. Sampling rate, bit depth, channel layout, quantization, clipping, and dither affect quality. Frequencies above the Nyquist limit cannot be represented without aliasing; anti-alias filtering is required before downsampling. Audio samples may use integer PCM or floating-point representations.

## DSP building blocks
Convolution applies finite impulse response filtering. Fourier transforms represent signals in frequency space. IIR filters use feedback and require stability analysis. Resampling requires interpolation and filtering. Window functions reduce spectral leakage in finite observations. Normalize levels deliberately; peak and loudness are different measurements.

## Real-time audio
Audio callbacks have strict timing constraints. Avoid blocking I/O, unpredictable allocation, locks, and long-running work on the real-time thread. Use bounded buffers and safe handoff to worker threads. Latency includes buffer size, scheduling, device, conversion, and transport delays.

## Media pipelines
Codecs trade compression ratio, quality, latency, licensing, and hardware support. Container formats package audio/video streams and metadata but are not codecs themselves. Streaming requires buffering, clock synchronization, error recovery, and adaptive bitrate behavior. Test exact decoder and browser/device combinations.

## Evaluation
Use objective metrics as partial evidence and listen under controlled conditions where subjective quality matters. Check clipping, channel mapping, sample-rate conversion, synchronization, and boundary behavior. Document input levels and test signals for reproducibility.
