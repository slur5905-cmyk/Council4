# Static Analysis, Program Analysis, and Symbolic Execution

## Static analysis
Static analysis inspects code without executing every path. Techniques include parsing, control-flow graphs, data-flow analysis, type checking, taint analysis, abstract interpretation, and rule-based pattern detection. Tools trade precision, speed, language coverage, and false positives. A clean report only means the configured checks found no issue within their modeled scope.

## Control and data flow
A control-flow graph represents possible execution paths. Data-flow analyses track definitions, uses, liveness, reaching definitions, and tainted values. Call graphs approximate function calls but become uncertain with dynamic dispatch, reflection, function pointers, generated code, plugins, and runtime mutation. Label unresolved relationships instead of inventing exact edges.

## Symbolic execution and SMT
Symbolic execution runs program paths with symbolic inputs and accumulates path constraints. A solver can determine whether a path is feasible or find an input that reaches a condition. Path explosion, environment modeling, concurrency, native dependencies, and solver timeouts limit coverage. A timeout is unknown, not proof of safety.

## Abstract interpretation
Abstract interpretation computes a sound approximation of program properties using abstract domains such as intervals, signs, nullness, or taint. Soundness and completeness differ: conservative approximations may report infeasible issues, while incomplete tools may miss defects. Understand the analyzer's guarantees and configuration.

## Engineering use
Combine static checks with tests, fuzzing, code review, and runtime monitoring. Pin tool versions, retain configs, suppress findings with documented justification, and prioritize exploitable paths. Never interpret static-analysis success as proof that the full application is secure or correct.
