# Probability, Statistics, and Experimental Design for Computing

## Probability foundations
Random variables represent uncertain outcomes. Distributions describe their possible values; expectation summarizes a weighted average, while variance measures spread. Conditional probability and Bayes' rule update beliefs given evidence. Independence is a strong condition and must not be inferred merely because two values were collected separately.

## Statistical reasoning
A sample statistic estimates a population property and carries uncertainty. Confidence intervals describe a procedure's long-run coverage, not the probability that one fixed parameter lies in a particular interval under the frequentist interpretation. P-values are not the probability that a hypothesis is true. Effect sizes and uncertainty intervals are usually more useful than isolated significance labels.

## Experiments and benchmarks
Define the question, target population, workload, baseline, candidate, metrics, exclusion rules, and stopping plan before collecting data. Control confounders such as hardware load, cache state, compiler flags, warm-up, input mix, and model randomness. Use paired comparisons when runs share conditions. Randomize order when order effects are possible. Preserve raw measurements and environment metadata.

## Performance measurement
Report distributions, not only a single average. Median and tail percentiles reveal latency behavior; throughput and latency are not interchangeable. Distinguish cold-start from steady-state performance. Repeat runs enough to reveal variability, and avoid treating many correlated samples as independent experiments. State whether measurements include I/O, initialization, compilation, and network time.

## AI evaluation
Use held-out tasks, explicit rubrics, repeated trials, blind scoring when practical, and task-level evidence. Separate answer quality from runtime correctness, safety, and cost. Prevent benchmark leakage and avoid optimizing exclusively for a public test set. A score improvement must be accompanied by unchanged or improved regression and safety results.
