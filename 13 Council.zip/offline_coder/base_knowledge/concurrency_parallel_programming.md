# Concurrency and parallel programming

## Concurrency models

Concurrency is overlapping progress; parallelism is simultaneous execution. Common models include threads, processes, event loops, async tasks, actors, message passing, data parallelism, and GPU kernels. Each has different scheduling, failure, memory-sharing, and cancellation behavior. Async code does not automatically run on multiple CPU cores, and adding threads does not automatically speed up I/O or CPU work.

## Shared state and memory models

Data races occur when unsynchronized concurrent accesses include a write and violate the language's memory model. Locks, atomics, immutable data, ownership/borrowing, channels, and transactional abstractions provide different safety guarantees. Understand visibility, ordering, happens-before relations, reentrancy, and lock scope. Avoid relying on incidental interpreter or hardware behavior for correctness.

## Deadlocks and liveness

Deadlock can arise from circular wait, hold-and-wait, no preemption, and mutual exclusion. Reduce risk with consistent lock ordering, short critical sections, timeouts, structured concurrency, and avoiding callbacks while holding locks. Also test starvation, livelock, queue growth, cancellation races, and partial failures. Correctness includes making progress, not merely avoiding crashes.

## Performance strategy

Parallel speedup is limited by serial work, synchronization, memory bandwidth, scheduling, and communication overhead. Use profiling to find a bottleneck before introducing concurrency. Bound worker pools, queues, retries, and in-flight requests. Apply backpressure rather than allowing unbounded memory growth. Avoid oversubscription and nested pools unless measured.

## Testing

Concurrency bugs are timing-dependent. Use deterministic synchronization primitives in tests instead of sleep-based guesses. Test cancellation, shutdown, timeout, retry, duplicate delivery, and failure at every await/lock boundary. Stress testing, race detectors, model checking, and repeated seeded schedules can discover issues, but no finite run proves race freedom. State which guarantees the selected language/runtime actually provides.
