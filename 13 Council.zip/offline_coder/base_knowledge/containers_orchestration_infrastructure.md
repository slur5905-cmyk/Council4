# Containers, orchestration, and infrastructure

## Containers

Containers package processes with filesystem, network, namespace, and control-group isolation. They share the host kernel and are not equivalent to virtual machines. Use minimal, trusted base images, pin image digests for reproducibility, run as non-root where possible, drop unnecessary capabilities, and set CPU, memory, process, and filesystem limits.

## Image and build design

Use multi-stage builds, explicit dependency versions, small build contexts, and secret-safe build steps. Never bake credentials into image layers. Scan images and dependencies, sign artifacts, and record provenance. Image labels and SBOM data help identify ownership and contents but do not prove safety.

## Orchestration

Schedulers manage placement, health, scaling, configuration, and rolling updates. Readiness, liveness, and startup probes have different purposes. Resource requests and limits affect scheduling and stability. Persistent storage, network policy, service identity, and secret distribution need explicit design.

## Infrastructure as code

Declarative infrastructure makes desired state reviewable but can still create destructive changes. Review plans, protect state files, restrict credentials, and separate environments. Drift detection and rollback matter. Apply operations should be approval-gated for production and should have a clear blast-radius limit.

## Reliability

Plan for capacity, failure domains, backup and restore, disaster recovery, observability, and incident response. Autoscaling cannot compensate for every bottleneck. Test recovery and upgrades under representative load. The behavior of cloud APIs and orchestrators is version-specific; verify the exact provider and runtime.
