# Ruby, PHP, and dynamic-language engineering

## Runtime and execution

Dynamic languages move many checks to runtime and provide flexible object and metaprogramming systems. This flexibility can reduce boilerplate but makes contracts, dynamic dispatch, reflection, and implicit coercion important review topics. Understand the target runtime version, dependency manager, autoloader, and standard library.

## Ruby

Ruby emphasizes objects, blocks, modules, mixins, exceptions, and dynamic dispatch. Gems are commonly managed through Bundler and a lockfile. Be aware of monkey patching, method lookup, keyword-argument behavior, frozen objects, and thread/runtime implementation characteristics. Prefer explicit interfaces and focused tests around dynamic behavior.

## PHP

PHP is widely used for web applications and has runtime-specific request handling, type declarations, namespaces, autoloading, and Composer dependency management. Understand strict typing, nullability, superglobals, session handling, output encoding, and framework lifecycle. Escape output for the destination context and use parameterized database operations.

## Testing and deployment

Use the project's supported runtime, lockfile, formatter, static analyzer, and test framework. Test serialization, error boundaries, security filters, and upgrade migrations. Avoid assuming a dependency's current API from memory; check the installed package version and documentation. Configuration and secrets should be injected safely, not committed.
