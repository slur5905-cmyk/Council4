# Web Platform and Browser Architecture

## Browser subsystems
A browser coordinates networking, HTML parsing, CSS style calculation, layout, paint, compositing, JavaScript execution, storage, permissions, and process isolation. The DOM tree, CSSOM, accessibility tree, and render tree are related but not identical. Layout thrashing occurs when code alternates layout reads and writes. Large DOMs, forced synchronous layout, unbounded event handlers, oversized images, and main-thread CPU work can harm responsiveness.

## Origin and security model
The same-origin policy restricts many cross-origin interactions. CORS is a server-controlled permission mechanism for selected cross-origin requests; it is not authentication. Cookies, local storage, session storage, IndexedDB, Cache Storage, service workers, and browser credential stores have different lifecycle and security properties. Use HTTPS, secure cookies, CSP, Trusted Types where applicable, and strict input/output handling. Avoid placing secrets in browser-delivered code.

## Rendering and accessibility
Semantic HTML gives native behavior and accessibility meaning. CSS layout systems include normal flow, flexbox, grid, positioning, and container/media queries. Prefer responsive intrinsic layout over device-specific hacks. Interactive controls need keyboard support, visible focus, labels, status announcements, and sensible touch targets. Test zoom, reduced motion, contrast, and assistive technology.

## Performance and lifecycle
Use performance timelines, network waterfalls, long-task observation, memory tooling, and Core Web Vitals as diagnostic evidence. Lazy loading, code splitting, caching, compression, image sizing, and preloading must be chosen based on measured bottlenecks. Background tabs can be throttled or suspended. Service workers have separate lifecycles and may serve stale assets. Deploy cache invalidation and update flows deliberately.

## Compatibility
Feature support differs across browsers and embedded webviews. Use capability detection, progressive enhancement, and a defined support matrix. Polyfills add code and may not fully emulate platform semantics. Test the actual mobile browser and operating system where the project will be used.
