# Distributed Systems: Consistency, Coordination, and Failure

## Partial failure
In a distributed system, components fail independently and communication can be delayed, duplicated, reordered, or lost. A timeout does not prove the remote operation failed; it may have completed while the response was lost. Retrying can duplicate effects. Design idempotency, deduplication, deadlines, retry budgets, circuit breakers, backpressure, and compensating actions explicitly.

## Replication and consistency
Replication improves availability and read capacity but creates consistency questions. Strong consistency, linearizability, sequential consistency, causal consistency, eventual consistency, and read-your-writes are different guarantees. Quorum protocols depend on replica count and failure assumptions. Leader election and consensus algorithms coordinate decisions under specified fault models, not arbitrary malicious behavior. Understand split brain, fencing tokens, epochs, leases, and stale leaders.

## Transactions and workflows
A local ACID transaction provides atomicity, consistency, isolation, and durability within its system. Distributed transactions can require two-phase commit or other coordination and may reduce availability. Sagas split workflows into steps with compensating actions; compensation is not always a true rollback. Outbox/inbox patterns help coordinate database state and event publication. Avoid dual writes without a consistency strategy.

## Messaging and event-driven architecture
Queues buffer work; streams retain ordered event logs; pub/sub distributes notifications. Delivery can be at-most-once, at-least-once, or effectively-once under carefully defined deduplication and transaction boundaries. “Exactly once” is not a blanket guarantee across arbitrary systems. Consumers should be idempotent, acknowledgements should follow durable processing, and poison messages need bounded retry/dead-letter policies.

## Partitioning and scalability
Sharding distributes data but adds routing, hot-key, rebalancing, cross-shard query, and operational complexity. Caches reduce latency but need invalidation and freshness rules. CAP is about tradeoffs during network partitions under consistency/availability definitions; it is not a simplistic statement that every database permanently chooses two of three properties. Use workload-specific measurements and failure injection.

## Design procedure
State the failure model, consistency need, data ownership, retry semantics, and recovery process. Test node loss, network partition, duplicate messages, clock skew, slow dependencies, partial writes, and recovery. Measure tail latency and saturation. Never claim fault tolerance without testing realistic failure paths and documenting assumptions.
