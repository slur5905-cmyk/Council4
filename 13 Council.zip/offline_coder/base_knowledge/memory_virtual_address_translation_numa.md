# Virtual Memory, Address Translation, and NUMA

## Virtual address spaces
Processes normally operate in virtual address spaces translated by hardware and the operating system. Page tables map virtual pages to physical frames and carry access permissions. The TLB caches translations. Page faults may represent normal demand paging, copy-on-write, memory-mapped file activity, or invalid access; the OS determines the response.

## Allocation and locality
Heap allocation, stack allocation, memory mapping, shared memory, and huge pages have different lifetimes and performance properties. Allocators manage fragmentation, metadata, arenas, and reuse. Use-after-free, double-free, out-of-bounds access, and data races are distinct classes of memory defects. Safe language abstractions reduce exposure but do not eliminate all resource and logic errors.

## NUMA systems
Non-uniform memory access means memory latency and bandwidth depend on the CPU/socket locality of the memory. First-touch placement, thread affinity, workload partitioning, and cross-socket traffic can influence performance. A program can have abundant free RAM but perform poorly because of remote access, bandwidth contention, or poor locality.

## Memory pressure
Memory pressure may cause reclaim, swapping, compression, page eviction, or termination by the OS. RSS, virtual size, committed memory, resident pages, and container memory limits measure different things. Do not interpret one metric as total available memory. Resource governors should inspect platform-specific limits and leave headroom for the OS and other processes.

## Engineering guidance
Measure allocation rate, peak live set, page faults, cache behavior, and working-set locality. Use bounded queues and streaming for large data. Make ownership and lifetime rules explicit. Test under constrained memory and verify graceful failure rather than assuming the machine can always satisfy allocations.
