# Accessibility, Standards, Interoperability, and Compatibility

## Standards and specifications

Standards define protocols, file formats, accessibility expectations, language behavior, and interoperability contracts. Distinguish normative requirements (for example MUST/SHOULD in standards) from explanatory guidance. Identify the exact edition/version, errata, profiles, and implementation requirements. Vendor documentation may explain an implementation but does not replace a protocol standard.

## Compatibility

Compatibility has source, binary, API, ABI, data, network-protocol, behavioral, and user-experience dimensions. A change may compile but break serialized data or external clients. Use semantic and schema versioning, compatibility tests, migration tooling, deprecation windows, and explicit support matrices. Test old data with new software and, where required, new data with old software.

## File formats and serialization

Formats may be text, binary, containerized, or streaming. Validate magic bytes, lengths, checksums, schemas, encodings, and version fields. Set maximum nesting, object counts, and payload sizes. Avoid trusting file extensions. Define canonical forms where signatures or hashing require stable representation. Preserve unknown fields when forward compatibility requires it.

## Accessibility

Accessibility includes visual, auditory, motor, cognitive, and speech access. Follow current WCAG and platform-specific recommendations. Use semantic structure, keyboard operation, sufficient contrast, scalable text, labels, captions, clear focus, understandable error feedback, and alternatives to color-only information. Automated checks are partial; manual assistive-technology testing is necessary.

## Internationalization and localization

Separate translatable content from code. Use locale-aware formatting for dates, numbers, units, currency, plural forms, sorting, and calendars. Avoid concatenating translated fragments. Support bidirectional text and expansion of translated strings. Do not assume the language, timezone, currency, or measurement system from a country alone.

## Privacy and interoperability

Data exchange needs purpose limitation, consent/legal basis where applicable, minimization, access control, retention, deletion, and secure transport. An open format does not imply data is public. Prefer documented export/import APIs and standards-based schemas. Record provenance and transformations so imported data remains traceable.
