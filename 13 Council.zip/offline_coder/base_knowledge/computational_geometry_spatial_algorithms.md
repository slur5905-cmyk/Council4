# Computational geometry and spatial algorithms

## Geometric representations

Points, vectors, lines, planes, polygons, meshes, curves, bounding boxes, and coordinate transforms form the basis of spatial computing. Define coordinate system, units, handedness, axes, origin, and precision. A transform's multiplication order matters and differs across APIs and conventions.

## Spatial queries

Nearest-neighbor lookup, collision detection, ray casting, visibility, intersection, containment, and path planning are common tasks. Brute force may be fine for small data; grids, k-d trees, quadtrees, R-trees, bounding-volume hierarchies, and spatial hashes can accelerate large workloads. Choose based on update frequency and data distribution.

## Numerical robustness

Floating-point error can make theoretically equal geometry compare unequal or flip orientation tests. Robust predicates, tolerances, exact arithmetic, and consistent snapping policies may be required. A universal epsilon is rarely correct across all scales. Degenerate inputs and nearly coincident geometry deserve explicit tests.

## Algorithms and topology

Convex hulls, triangulation, polygon clipping, Voronoi diagrams, Delaunay triangulation, mesh topology, and computational topology have specialized invariants. Check whether polygons are simple, vertices ordered, and winding conventions consistent. Mesh validation should detect holes, non-manifold edges, self-intersections, and degenerate faces where relevant.

## Testing

Use known geometric fixtures, symmetry and invariance properties, randomized generated shapes with reproducible seeds, and boundary perturbations. Test scale extremes and transformations. Visual inspection is useful but does not replace numeric assertions.
