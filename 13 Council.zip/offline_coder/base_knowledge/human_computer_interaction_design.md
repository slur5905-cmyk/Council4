# Human-computer interaction and interface design

## User goals and mental models

Interfaces should make system state, available actions, consequences, and recovery paths understandable. User-centered design starts with goals and contexts, not merely visual style. Use consistent terminology and predictable behavior. Avoid making users remember hidden modes or invisible state.

## Interaction principles

Provide feedback after actions, prevent accidental destructive operations, and make undo/recovery available where practical. Keep controls discoverable, keyboard-accessible, and usable with touch and assistive technologies. Use progressive disclosure for complexity without hiding critical information. Errors should explain what happened and a practical next step.

## Evaluation

Usability testing observes representative users performing realistic tasks. Heuristic review can find issues but is not a substitute for testing. Measure task success, errors, time, comprehension, and accessibility. Avoid overfitting to one person's preferences or one device size.

## Visual communication

Typography, hierarchy, spacing, alignment, contrast, and motion should support comprehension. Do not encode status only by color. Respect reduced-motion settings. Use consistent component behavior and clear state transitions. Visual snapshot testing detects rendering changes, not whether an interface is understandable.

## Product quality

A polished design must still protect user data, handle slow networks, support localization, and recover from errors. Include empty, loading, offline, permission-denied, and degraded states. Make privacy choices understandable and avoid dark patterns.
