# iOS and Android Native Platform Engineering

## Application lifecycle
Mobile operating systems control foreground, background, suspension, termination, and restoration. Background execution is restricted and varies by platform and app capability. Persist important state before suspension, resume safely, and do not promise continuous work after the user closes a browser or app.

## Permissions and privacy
Camera, microphone, location, contacts, files, Bluetooth, notifications, and health-related permissions require transparent purpose and platform-specific prompts. Ask only when needed and handle denial or revocation. Minimize collection and retention. Store sensitive data using OS-backed secure storage rather than plain preferences or source files.

## UI and performance
Touch targets, safe areas, dynamic text, orientation, keyboard behavior, battery use, network transitions, and accessibility affect mobile UX. Avoid long main-thread work. Use platform profilers, memory warnings, battery diagnostics, and real-device testing. Simulators cannot represent every hardware, thermal, radio, or vendor behavior.

## Distribution and updates
iOS and Android have distinct packaging, signing, entitlement, review, update, and store requirements. Verify signing keys and build provenance. Test clean install, upgrade, rollback where supported, migration, and data retention. Do not embed service secrets or unrestricted credentials in an application binary.

## Cross-platform design
Cross-platform frameworks trade native integration, runtime size, rendering, and maintenance. Hide platform differences behind explicit adapters. Keep critical business rules testable without UI. Maintain a supported device and OS matrix and test on physical devices before release.
