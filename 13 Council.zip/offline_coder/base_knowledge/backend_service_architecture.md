# Backend and service architecture

## Boundaries

A service should have explicit responsibilities, contracts, ownership of data, and error semantics. Modular monoliths can be simpler than microservices; distributed boundaries add network failure, deployment coordination, observability, and consistency costs. Choose service boundaries based on stable domain responsibilities, not fashion.

## API design

Specify input schemas, output schemas, status/error forms, pagination, filtering, authentication, authorization, versioning, idempotency, rate limits, and compatibility. Validate at trust boundaries. Do not reveal stack traces, secrets, or internal topology to clients. Add request IDs and structured logs while protecting sensitive fields.

## Reliability

Use deadlines and propagate cancellation. Bound queues, concurrency, payload sizes, and retry budgets. Apply retries only when operations are safe to repeat. Design graceful degradation and explicit overload behavior. Health endpoints should distinguish process liveness from service readiness and dependency health.

## Data consistency

Transactions, optimistic concurrency, event sourcing, outbox patterns, sagas, and read models solve different consistency problems. Avoid distributed transactions unless justified. Make duplicate message processing safe, preserve event ordering only where required, and define replay and schema-evolution policies.

## Operations

Instrument metrics, logs, and traces with stable, privacy-safe identifiers. Define service-level indicators and objectives that users can understand. Document deployment, migration, rollback, recovery, and incident procedures. Test configuration parsing and startup failure paths. Do not claim a distributed system is highly available without evidence from failure and recovery testing.
