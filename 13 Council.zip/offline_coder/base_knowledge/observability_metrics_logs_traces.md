# Observability: logs, metrics, and traces

## Three complementary signals

Logs describe individual events; metrics aggregate numerical behavior over time; traces connect work across service boundaries. Correlate them with stable request or trace identifiers without exposing personal data. A large log volume is not automatically useful observability.

## Metrics

Counters measure event totals, gauges measure current values, and histograms summarize distributions. Track latency percentiles, throughput, error rates, queue depth, saturation, and resource pressure. Avoid high-cardinality labels such as user IDs, arbitrary URLs, or raw exception messages; they can exhaust monitoring systems and reveal sensitive information.

## Distributed tracing

Spans represent timed operations with parent/child context. Propagation needs consistent standards and sampling strategy. Missing spans do not prove work did not happen; sampling and instrumentation gaps matter. Record failures and retries while avoiding duplicate or misleading trace structure.

## Reliability objectives

Service-level indicators measure user-facing outcomes; objectives set target ranges. Error budgets can guide release risk. Alerts should be actionable and tied to symptoms rather than noisy low-level events. Evaluate detection delay and recovery time during exercises.

## Privacy and security

Redact credentials and sensitive payloads before logs leave the process. Restrict access, set retention limits, secure exporters, and protect telemetry endpoints. Treat telemetry as a data store with a threat model. Validate sampling and redaction under failure paths too.
