# Numerical and Scientific Computing

## Floating-point behavior
Floating-point numbers approximate real numbers with finite precision. Rounding, cancellation, overflow, underflow, subnormals, NaN, infinities, and non-associativity can change results. Reordering arithmetic for parallel execution or compiler optimization may alter output. Use tolerances based on numerical error and problem scale rather than exact equality for approximate calculations. Decimal or integer fixed-point arithmetic may be more appropriate for money or exact decimal rules.

## Numerical methods
Numerical work includes root finding, interpolation, numerical integration, differential equations, linear algebra, optimization, Monte Carlo methods, and simulation. Stability and conditioning are different: conditioning describes problem sensitivity; stability describes algorithm sensitivity to perturbations. Validate convergence, error bounds, step size, conservation laws, and units. Choose solvers based on stiffness, smoothness, constraints, and cost.

## Reproducibility
Record algorithm, parameters, seeds, input data, compiler/library versions, hardware, precision, and environment. Parallel floating-point reductions may be nondeterministic. Random seeds improve repeatability but do not guarantee bitwise-identical results across hardware or library versions. Use independent validation cases, known analytical solutions, dimensional analysis, and conservation checks.

## Scientific data and visualization
Preserve raw data and transformations. Track calibration, uncertainty, missing observations, sensor bias, and measurement units. Visualizations can hide outliers, truncation, and distribution structure; label scales, units, sample sizes, and uncertainty honestly. Avoid smoothing or aggregation that changes scientific interpretation.

## Simulation validation
Compare model predictions with analytical limits, reference implementations, experimental measurements, and property-based invariants. Validate boundary conditions, numerical stability, timestep sensitivity, and scaling. A visually plausible simulation is not evidence that its physics or science is correct.
