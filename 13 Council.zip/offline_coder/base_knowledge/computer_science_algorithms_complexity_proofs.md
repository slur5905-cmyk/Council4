# Algorithm analysis, complexity, and correctness proofs

Algorithms describe procedures for transforming inputs into outputs. Choosing an algorithm requires understanding constraints, data size, input distribution, correctness, memory use, and operational requirements. A theoretically efficient method can be slower on small inputs due to constants; a simple method can fail at scale due to growth rate.

## Complexity analysis

Big-O describes an asymptotic upper bound, often used to compare growth rates. Big-Theta describes a tight asymptotic bound and Big-Omega a lower bound. Analyze time and space separately. Worst-case, average-case, amortized, and expected costs answer different questions. A hash table may have expected constant-time operations under assumptions while retaining a linear worst case. Dynamic arrays have amortized constant append cost even though occasional resize operations are linear.

Input-size definitions matter. For graph algorithms, use both vertices and edges. For numeric algorithms, input bit length can matter more than numeric value. For sorting, distinguish comparisons, moves, stability, and external-memory I/O. Complexity should reflect the representation and operations actually used.

## Correctness reasoning

State preconditions, postconditions, and invariants. A loop invariant must hold before the first iteration, remain preserved by each iteration, and combine with termination to imply the desired result. A termination measure decreases in a well-founded order. Recursive proofs need a base case and a reduction to smaller subproblems. Preconditions should be checked or clearly delegated to callers.

For greedy algorithms, justify the greedy-choice property and optimal substructure. For dynamic programming, define state, recurrence, base cases, evaluation order, and reconstruction. For graph algorithms, state assumptions such as nonnegative edge weights or graph connectivity. An implementation should encode these assumptions in validation or documentation.

## Data structures

Arrays provide compact indexing; linked lists provide pointer-based insertion but poor locality. Hash maps trade ordering for expected fast lookup. Balanced trees provide ordered operations; heaps support priority queues; tries handle prefix queries; B-trees and LSM trees target storage systems. Disjoint-set union supports connectivity queries. Bloom filters provide probabilistic membership with false positives but no false negatives under standard assumptions. Each structure has memory, mutation, iteration, and concurrency semantics.

## Graphs and optimization

Breadth-first search finds shortest paths in unweighted graphs; Dijkstra's algorithm assumes nonnegative weights; Bellman-Ford supports negative weights but detects negative cycles. Minimum spanning trees, topological sorting, strongly connected components, max flow, and matching solve different structures. Dynamic programming is useful when subproblems overlap; memoization trades memory for repeated-computation reduction.

## Randomized and approximate algorithms

Randomized algorithms use probability to improve expected performance or simplify design. Record seeds for reproducibility when appropriate. Approximation algorithms trade exact optimality for bounded quality and often provide a ratio guarantee. Heuristics may work well but lack such guarantees. Distinguish measured success on a sample from a proven bound.

## Practical workflow

Start with a simple correct baseline. Define constraints and edge cases. Choose a known algorithm whose assumptions fit the data. Compare brute force for tiny inputs, use property tests for invariants, and generate adversarial shapes such as empty, repeated, sorted, skewed, sparse, dense, or maximal-size inputs. Benchmark representative distributions. If correctness depends on a precondition, make that precondition explicit rather than assuming it silently.
