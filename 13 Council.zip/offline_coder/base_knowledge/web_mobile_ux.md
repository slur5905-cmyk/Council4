# Web, Mobile, and User Experience Engineering

## Browser architecture

A browser parses HTML into a DOM, CSS into style/layout structures, and JavaScript into executable code. Rendering includes style calculation, layout, paint, compositing, and rasterization. Main-thread long tasks harm responsiveness. Use semantic HTML, efficient DOM updates, event delegation where appropriate, and web workers for suitable CPU work. Browser APIs have security and permission constraints; feature-detect and provide fallbacks.

## HTML, CSS, and JavaScript

HTML represents document structure and semantics. CSS controls layout and presentation through cascade, specificity, inheritance, layout algorithms, and media/container queries. JavaScript is dynamically typed and event-loop driven. Understand promises, microtasks, tasks, async/await, modules, closures, prototypes, and garbage collection. Avoid blocking the main thread, unsafe DOM injection, uncontrolled global state, and assuming browser APIs are uniform across devices.

## Frontend architecture

Separate state, domain logic, view rendering, and side effects. Define a source of truth; keep derived UI state derived. Handle loading, empty, success, error, offline, and permission-denied states. Component boundaries should reflect reusable behavior, not just visual fragments. Avoid prop drilling or global stores until complexity justifies them. Prevent stale asynchronous results using cancellation, request identity, or lifecycle cleanup.

## Backend and service design

A backend validates requests, authenticates and authorizes users, applies business rules, accesses data, and returns explicit responses. Validate types, lengths, formats, ownership, and limits at the boundary. Enforce authorization on every object/action, not only in the UI. Use timeouts, structured errors, rate limits, request IDs, and safe logs. Keep long jobs in durable queues with status tracking and cancellation semantics.

## HTTP and browser security

Same-origin policy controls cross-origin document access; CORS selectively allows browser reads. Cookies need appropriate Secure, HttpOnly, and SameSite settings. CSRF defenses are needed where ambient credentials are used. Content Security Policy reduces injection impact. Use output encoding appropriate to HTML, attributes, URLs, CSS, and JavaScript contexts. Never treat client-side validation as a security control. Avoid exposing secrets in bundled code.

## Responsive design

Use fluid layouts, relative units, flexible grids, responsive images, media/container queries, and content-driven breakpoints. Test small and large viewports, portrait/landscape, touch, mouse, keyboard, zoom, safe areas, virtual keyboards, and high-density displays. Do not assume mobile is just a smaller desktop. Avoid tiny tap targets and horizontal overflow. Respect reduced-motion and user font-size settings.

## Mobile application engineering

Native, hybrid, and progressive web apps have different lifecycle, storage, permissions, background execution, and distribution constraints. Mobile operating systems suspend or kill background tasks. Do not promise continuous computation from a browser/PWA while suspended. Handle app resume, network changes, permission revocation, battery constraints, storage limits, push-notification consent, and offline synchronization. Secure local data and platform credentials using OS-provided facilities where appropriate.

## Performance

Measure Core Web Vitals and real-user metrics where relevant: loading, interactivity, visual stability, and responsiveness. Optimize image formats/sizes, code splitting, caching, critical rendering, network requests, and CPU work. Avoid premature micro-optimizations. Performance budgets should be explicit and tested on realistic low-end devices and networks.

## Accessibility

Use semantic controls, associated labels, keyboard support, visible focus, logical tab order, meaningful headings, accessible names, text alternatives, sufficient contrast, captions/transcripts, reduced motion, and announcements for dynamic changes. Test with automated tools and actual keyboard/screen-reader workflows. Automated accessibility scans catch only a subset of issues. Follow the relevant WCAG version and platform guidance.

## UX and product behavior

Make system status visible. Prevent errors with clear affordances and constraints; explain recovery in error messages. Preserve user work. Use consistent language, predictable navigation, undo for destructive actions, and confirmations proportional to risk. Avoid dark patterns. Test tasks with representative people and observe real behavior. Analytics should minimize personal data and be transparent.

## Web project acceptance checklist

- Build and serve the actual configured entry point.
- Test key flows, refresh/deep links, offline behavior, invalid inputs, and failures.
- Test browser/device compatibility and responsive viewports.
- Inspect console/network errors; distinguish blocked external assets from application defects.
- Check keyboard, labels, focus, contrast, zoom, and reduced motion.
- Verify authorization server-side and protect against XSS, CSRF, SSRF, and injection.
