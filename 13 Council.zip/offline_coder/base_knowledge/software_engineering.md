# Software Engineering, Architecture, and Product Delivery

## Requirements and task framing

Separate goals, explicit requirements, non-goals, constraints, assumptions, and unresolved questions. Convert requirements into observable acceptance criteria. Distinguish user-visible behavior from implementation choices. Prioritize risks and dependencies. Use examples and counterexamples to reveal ambiguity. Do not silently turn a preference into a hard requirement or an assumption into a fact.

## Architecture and decomposition

Architecture describes components, responsibilities, data flows, runtime boundaries, persistence, deployment, and quality attributes. Common styles include layered, modular monolith, hexagonal/ports-and-adapters, clean architecture, event-driven, service-oriented, microservices, client-server, peer-to-peer, and serverless. Choose the simplest style that meets real constraints. Microservices add network, deployment, data consistency, observability, and operational costs; they are not automatically more scalable.

Apply separation of concerns, information hiding, high cohesion, low coupling, explicit ownership, and dependency inversion. Avoid both giant modules and excessive fragmentation. A module should own a coherent invariant or capability. Document module contracts and failure behavior.

## Interface and API design

Design APIs around domain concepts and stable contracts. Specify input schemas, output schemas, error codes, idempotency, pagination, timeouts, retries, ordering, authorization, quotas, and compatibility. Validate at trust boundaries. Make operations idempotent where retries are possible. Avoid ambiguous null/empty/error values. Version public APIs carefully and plan migrations.

## State and data flow

Identify the source of truth for each important piece of state. Avoid duplicated mutable state unless synchronization is explicit. Define transitions, invariants, ownership, persistence, recovery, and concurrency rules. Event sourcing records state changes but increases schema evolution and replay complexity. CQRS separates reads and writes for specific needs; it is not a default requirement. Caches must define invalidation, staleness, and consistency.

## Code quality

Prefer clear names, small coherent functions, explicit errors, predictable side effects, and simple control flow. Keep abstractions proportional to demonstrated reuse. Use comments to explain why, not restate what. Avoid hidden global state and premature optimization. Preserve formatting and conventions. Treat lint/format checks as tools, not quality proof. Refactor behavior-preservingly with tests.

## Design patterns

Patterns include dependency injection, strategy, adapter, decorator, observer/pub-sub, factory, builder, command, state, repository, unit of work, circuit breaker, bulkhead, saga, and pipeline. Apply patterns to solve actual recurring problems. A pattern name is not evidence that a design is correct.

## Change management

Inspect the project before editing. Build a dependency/change graph. Identify interfaces, callers, data migrations, platform differences, tests, and deployment artifacts. Make small patches; preserve unrelated work; protect secrets and generated files. Keep a rollback path. Verify pre-change hashes where concurrent edits are possible. Never use a stale review or test report for a changed candidate.

## Code review

Review the exact immutable candidate. Trace data/control flow. Check behavior, boundaries, errors, concurrency, security, compatibility, tests, maintainability, and user requirements. Every finding should include affected code, failure mechanism, severity, reproducer, and proposed test/fix. Distinguish confirmed defects from plausible risks. Independent agents using one model are diverse prompts, not independent evidence.

## Documentation and knowledge

Documentation should explain setup, architecture, supported versions, commands, configuration, security assumptions, data formats, APIs, failure modes, and limitations. Keep examples executable where possible. Link to primary references. Date or version information for volatile topics. Knowledge records need provenance, scope, confidence, freshness, and conflict handling.

## Project governance

Use small reviewable changes, semantic commit messages, issue linkage, changelogs, versioning, release notes, and deprecation plans as appropriate. Record architecture decisions (ADRs) for consequential tradeoffs. Prefer reversible decisions when uncertainty is high. Measure outcomes rather than treating activity as progress.

## Engineering decision framework

For each major choice, compare correctness, security, maintainability, performance, portability, cost, complexity, user experience, and reversibility. Explicitly identify the cost of not changing anything. Optimize for the real user and workload, not an abstract ideal.
