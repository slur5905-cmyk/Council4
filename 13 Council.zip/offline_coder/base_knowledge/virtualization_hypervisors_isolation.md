# Virtualization, hypervisors, and isolation

## Virtual machines and containers

A virtual machine emulates or virtualizes hardware and runs a guest operating system with its own kernel. Containers isolate processes while sharing a host kernel. Sandboxes may combine namespaces, access controls, syscall filters, language runtimes, and virtualized hardware. These mechanisms provide different threat boundaries and performance costs.

## Hypervisor concepts

Type-1 and type-2 hypervisors manage guest execution, virtual CPUs, memory translation, devices, snapshots, and virtual networks. Hardware virtualization extensions accelerate execution but do not automatically make a guest secure. Device emulation and shared folders expand the attack surface.

## Isolation design

A secure execution boundary needs explicit CPU, RAM, disk, process, network, file, and time limits. Remove host credentials and sensitive mounts. Prefer read-only base images and disposable workspaces. Prevent privilege escalation and avoid passing arbitrary host sockets into a guest. Logs and artifacts should be size-bounded.

## Snapshot and recovery

Snapshots capture a point-in-time state but can include secrets and may be inconsistent across active systems. Validate restore and migration paths. Do not confuse a snapshot with a backup if it shares the same failure domain or storage.

## Evidence boundary

A sandbox reduces risk but is not an absolute guarantee. Kernel, hypervisor, runtime, configuration, and hardware vulnerabilities remain possible. Use a dedicated environment for untrusted code and do not place sensitive accounts or data inside it.
