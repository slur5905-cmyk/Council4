# Build, Release Engineering, Package Security, and Provenance

## Build integrity
A build should be repeatable from declared source, toolchain, dependencies, configuration, and environment. Lockfiles and pinned toolchains reduce drift but do not prove dependencies are trustworthy. Record artifact hashes, source revision, build parameters, and environment. Separate source, build outputs, signing keys, release credentials, and deployment permissions.

## Dependency management
A software bill of materials (SBOM) inventories components and relationships. CycloneDX and SPDX are common SBOM formats. An unresolved manifest inventory is not the same as a fully resolved SBOM containing transitive dependency versions and metadata. Vulnerability databases are time-sensitive; a clean scan today is not a future guarantee. Review license obligations separately from vulnerabilities.

## CI/CD security
Use least-privilege job permissions, short-lived credentials, protected deployment environments, immutable action/container references where feasible, branch protection, and required human review for critical policy changes. Treat pull-request code and build output as untrusted. Protect artifact storage and cache keys. Never expose deployment secrets to untrusted fork workflows.

## Release verification
Test packaged artifacts, not only source trees. Verify signatures, hashes, provenance, dependency resolution, runtime configuration, and upgrade/rollback paths. Canary deployments and staged rollouts reduce blast radius. Keep a recovery plan and test it. A signed artifact proves possession of a signing key, not that the source is safe or correct.
