# Computer Graphics, Game Development, Physics, and Simulation

## Graphics pipeline

A real-time graphics pipeline transforms scene data through coordinate spaces, vertex processing, primitive assembly, clipping, rasterization, fragment/pixel shading, depth/stencil tests, blending, and presentation. Understand model, world, view, clip, normalized device, and screen spaces. Matrices, quaternions, and coordinate conventions must be consistent. GPU APIs expose different abstractions and synchronization rules; verify against the exact API/version.

## Rendering techniques

Rasterization, ray tracing, path tracing, global illumination, shadow maps, screen-space effects, physically based rendering, deferred/forward rendering, and temporal reconstruction each trade quality, memory, and speed. Materials use shaders and texture data. Color management should distinguish linear and display color spaces. Anti-aliasing reduces sampling artifacts. GPU profiling and frame captures reveal bottlenecks.

## Game architecture

Game loops coordinate input, simulation, update, rendering, audio, and persistence. Fixed simulation timesteps with interpolated rendering can improve deterministic physics; variable timesteps require careful stability handling. Entity-component-system architectures separate entity identity, components, and systems but need deliberate data layout and scheduling. Scene graphs, state machines, event buses, and object pooling each serve specific needs.

## Physics simulation

Rigid-body simulation includes position, orientation, velocity, angular velocity, forces, constraints, collision detection, and response. Numerical integration methods (Euler, semi-implicit Euler, Verlet, Runge-Kutta) have stability/accuracy tradeoffs. Collision detection uses broadphase then narrowphase; continuous collision detection handles fast-moving objects where discrete steps tunnel. Constraint solvers approximate contacts and joints. Units, timestep, solver iterations, damping, friction, restitution, and mass properties need explicit definitions.

## Ecosystems and agent simulation

Agent-based models represent individual entities and local rules; population-level outcomes emerge from interactions. Model assumptions, parameters, stochasticity, update order, and boundary conditions determine results. Validate micro-level rules and macro-level behavior against expected properties or empirical data. Avoid claiming biological realism from visually plausible behavior. Separate simulation logic from rendering and UI. Use deterministic seeds, event logs, and reproducible checkpoints.

## Scale and optimization

Large populations need spatial partitioning (uniform grids, spatial hashes, quadtrees/octrees, BVHs), level of detail, batching, vectorization, job scheduling, and data-oriented layouts. Avoid all-pairs O(n²) interactions where local neighborhoods suffice. Profile memory bandwidth and GPU/CPU synchronization. Simplify far-away or inactive entities while preserving important simulation invariants. Define what full fidelity means and test degradation policies.

## Determinism and persistence

Floating-point operations, thread scheduling, random number streams, and physics engines can introduce nondeterminism. Deterministic replay requires event/input recording, stable ordering, versioned state schemas, seeds, and deterministic logic. Save data separately from transient UI/render state. Use atomic snapshots, checksums, migrations, and crash recovery. A save that records only visible fields may not reproduce the same world.

## Game AI and evolution

Behavior trees, finite-state machines, utility systems, planners, reinforcement learning, genetic algorithms, and evolutionary strategies solve different problems. Specify fitness, selection, mutation, crossover, constraints, population diversity, and evaluation environments. Prevent reward hacking and selection collapse. Distinguish an evolutionary simulation mechanism from real biological evolution and validate inheritance/selection rules.

## Accessibility and usability

Provide remappable controls, readable UI, color-independent feedback, reduced motion options, scalable text, clear menus, save recovery, and adjustable difficulty. Test input latency, frame pacing, crash recovery, and device thermal behavior.
