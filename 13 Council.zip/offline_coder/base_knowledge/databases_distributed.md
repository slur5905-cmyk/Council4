# Databases, Storage Engines, and Distributed Systems

## Data modeling

Model entities, relationships, constraints, ownership, and lifecycle. Normalize relational schemas to reduce update anomalies; denormalize deliberately for measured read patterns. Choose keys carefully. Natural keys can change; surrogate keys need stable mapping. Use foreign keys, uniqueness, check constraints, and non-null constraints where appropriate. Record time zones and units explicitly.

## Relational databases and SQL

Relational databases represent relations and use declarative queries. SQL includes DDL, DML, DCL, and transaction control. Understand joins, grouping, window functions, null semantics, three-valued logic, indexes, query plans, and parameterized queries. Never concatenate untrusted values into SQL. Use bound parameters; dynamic identifiers require strict allowlists. Indexes speed some reads but cost storage and write work. Examine execution plans on representative data.

## Transactions and ACID

Atomicity groups changes; consistency preserves declared invariants; isolation controls concurrent visibility; durability preserves committed data according to configuration. Isolation levels differ: read uncommitted, read committed, repeatable read, snapshot isolation, and serializable. Anomalies include dirty/nonrepeatable/phantom reads, lost updates, write skew, and serialization failures. Use explicit transactions and retry only documented retryable conflicts. Keep transactions short and avoid network calls inside them.

## NoSQL and specialized stores

Key-value stores suit simple lookup; document stores fit flexible nested records; wide-column stores support partitioned large-scale access; graph databases model relationships; time-series databases specialize timestamped data; search engines index text and facets; object stores hold large blobs. Choose by access pattern, consistency, query needs, scaling, operational skill, and backup strategy. NoSQL does not mean schema-free or consistency-free.

## Caching and queues

Caches improve latency/throughput when invalidation and staleness are managed. Consider TTL, version keys, write-through, write-back, cache-aside, stampede control, and negative caching. Message brokers decouple producers/consumers. At-least-once delivery can duplicate messages; exactly-once claims are usually bounded by system and transaction scope. Make consumers idempotent, track offsets/acknowledgments, and use dead-letter/retry policies with limits.

## Distributed systems

Networks can delay, duplicate, reorder, partition, and lose messages. Nodes can fail independently. Clocks drift; timestamps do not create a reliable global order. Partial failure is normal. CAP describes tradeoffs during network partition; it is not a simple universal choice between consistency and availability. Consistency models include linearizability, sequential consistency, causal consistency, eventual consistency, and read-your-writes/session guarantees.

## Replication and partitioning

Replication improves availability and read scale but introduces lag and conflict handling. Leader/follower and multi-leader models differ. Partitioning/sharding distributes data; key selection affects hotspots, rebalancing, and query routing. Consensus protocols such as Paxos and Raft coordinate replicated state under stated failure assumptions, but do not eliminate all operational complexity. Quorum arithmetic depends on membership, failure model, and protocol.

## Distributed transactions and sagas

Two-phase commit coordinates transactions but can block and increases coupling. Sagas split work into local transactions with compensating actions; compensation is not always a true inverse. Use outbox/inbox patterns to reliably connect database commits and message publication/consumption. Design for duplicate requests, retries, timeout ambiguity, and idempotency keys.

## Backup and recovery

A backup is useful only if it can be restored. Define RPO and RTO, perform restore drills, verify integrity, retain off-site/offline copies, and protect backups against deletion or ransomware. Replication is not a backup. Test schema migrations on realistic copies and retain rollback/forward-fix plans.

## Data governance

Classify sensitive data, minimize collection, restrict access, encrypt where appropriate, define retention/deletion, log access safely, and consider jurisdictional obligations. Avoid storing secrets in databases, logs, analytics, test fixtures, or model prompts.
