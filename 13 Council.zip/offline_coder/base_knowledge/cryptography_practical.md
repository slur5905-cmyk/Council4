# Practical Cryptography and Key Management

## Primitive selection
Use established cryptographic libraries and protocols rather than inventing algorithms. Hash functions provide fixed-length digests; keyed MACs authenticate data; digital signatures authenticate data and bind it to a private key; authenticated encryption protects confidentiality and integrity. Encryption without authentication can permit tampering. Password hashing is deliberately slow and distinct from general hashing.

## Keys and randomness
Keys must be generated with a cryptographically secure random source, stored with access control, rotated according to risk, and destroyed or revoked when compromised. Never hard-code secrets or derive keys from usernames, timestamps, ordinary PRNG values, or public configuration. Use envelope encryption and key-encryption keys for large datasets. Back up keys securely and test recovery; encrypted backups without recoverable keys are lost data.

## Protocol and algorithm agility
Prefer modern, maintained protocol configurations and library defaults. TLS protects transport only when certificate validation and endpoint identity checks are correct. Certificate expiration, trust roots, hostname validation, downgrade behavior, and private key protection matter. Do not disable certificate verification to fix connection problems. Plan key and algorithm rotation without allowing an attacker-controlled downgrade.

## Common implementation hazards
Nonce reuse can undermine some authenticated-encryption modes. Randomness failure, side channels, timing differences, padding oracles, unsafe key derivation, and incorrect signature verification can defeat otherwise sound primitives. Constant-time operations matter for secret-dependent comparisons and cryptographic code. Avoid parsing custom cryptographic formats without strict length and canonicalization rules.

## Privacy and data lifecycle
Encryption does not solve excessive collection, weak authorization, metadata exposure, insecure logs, or retention beyond purpose. Classify data, minimize collection, define deletion/retention, control backups, and consider derived data and telemetry. Threat-model key compromise, insider access, endpoint malware, and recovery operations. Treat cryptography as a tool within a larger security design, not a universal guarantee.
