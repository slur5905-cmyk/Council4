# Linux and Unix-Like Operating-System Engineering

## Processes and descriptors
Unix-like systems expose processes, signals, file descriptors, pipes, sockets, and filesystem namespaces. A file descriptor is a process-local handle, not necessarily a disk file. Standard input/output/error are descriptors; pipelines connect process streams. Handle partial reads/writes, interrupted system calls, descriptor leaks, and child-process lifecycle explicitly.

## Permissions and identity
User and group IDs, supplementary groups, mode bits, ACLs, capabilities, namespaces, and mandatory access-control systems contribute to authorization. Root is not a safe default for application processes. Apply least privilege, use dedicated service identities, and avoid unsafe temporary files and world-writable directories.

## Filesystems and durability
A successful write to a userspace buffer does not necessarily mean data is durable on storage. Filesystem journaling, writeback, ordering, and device caches affect crash behavior. Use documented synchronization operations and atomic replacement patterns when durability matters. Test recovery after interrupted writes and power-loss-like failures where practical.

## Services and observability
Service managers supervise processes, restart policies, environment, dependencies, and logs. Containers add namespaces, cgroups, mounts, and network isolation but still share the host kernel. Inspect actual limits and permissions; do not assume a container is a virtual machine. Use structured logs and resource metrics without exposing secrets.

## Portability
POSIX describes a common interface family, but Linux-specific system calls, GNU utilities, BSD variants, and macOS behavior differ. Shell scripts should quote expansions, validate inputs, handle exit codes, and avoid relying on unspecified command output. Use capability detection rather than guessing the platform from a name alone.
