# Database transactions, storage engines, and query execution

A database combines a data model, query interface, transaction system, storage engine, concurrency control, durability mechanisms, and operational tooling. SQL's relational model represents information as relations with constraints; document, key-value, graph, time-series, and columnar systems make different trade-offs. Choose based on query patterns, consistency, scale, operations, and correctness requirements rather than popularity alone.

## Query planning

A query parser produces an internal representation. The optimizer considers join orders, indexes, statistics, predicate pushdown, projection pruning, and available execution operators. The planner estimates row counts and costs; inaccurate statistics can select a poor plan. `EXPLAIN` and runtime plans help distinguish estimates from actual work. Indexes improve some reads but consume storage, slow writes, and may not help low-selectivity predicates. Composite index order and covering properties should match actual queries.

Execution engines may use iterators, vectorized batches, or compiled operators. Joins include nested-loop, hash, and merge strategies. Aggregations can be streaming or hash-based. Sorting and large joins may spill to disk. Query improvements should be measured with realistic data distributions and concurrency; a plan that works on a tiny fixture may fail at production cardinality.

## Transactions and isolation

Atomicity, consistency, isolation, and durability are commonly summarized as ACID. Transactions define a unit of change. Isolation levels define which concurrent observations are allowed; names and exact semantics vary by engine. Read committed, repeatable read, snapshot isolation, and serializable isolation do not mean the same thing across all systems. Write skew, lost updates, phantom reads, and stale reads are concrete phenomena to reason about.

Two-phase locking holds locks according to a protocol; multiversion concurrency control (MVCC) keeps versions so readers can see a consistent snapshot. MVCC reduces reader/writer blocking but creates cleanup and vacuum work. Deadlocks are possible when transactions acquire locks in conflicting orders; databases may abort a victim. Applications must retry appropriate transient failures without duplicating external side effects.

## Durability and recovery

Write-ahead logging records changes before affected data pages are persisted. On restart, recovery replays or rolls back work based on log records and checkpoints. Replication adds another layer: an acknowledged commit may or may not survive failure depending on synchronous/asynchronous policy and quorum rules. Backups must be restorable, not merely successfully created. Point-in-time recovery depends on base backups and retained logs.

## Schema evolution and application design

Constraints belong in the database where they can protect all writers: primary keys, foreign keys, uniqueness, checks, and not-null rules. Application validation improves error messages but should not replace integrity constraints. Schema changes should use staged expand/migrate/contract steps for rolling deployments: add compatible fields, deploy code that understands both states, backfill safely, then remove obsolete structures only after old clients are gone.

Use parameterized queries. Avoid building SQL through string concatenation. Keep transactions short and avoid holding locks while calling remote services. Use idempotency keys, outbox patterns, and explicit retry policies when a database commit must coordinate with a message broker or external service.

## Operations

Monitor latency percentiles, connection pools, lock waits, replication lag, disk usage, cache hit rates, vacuum/compaction, error rates, and query plans. Define retention and privacy rules. Encrypt backups and test recovery exercises. Database migrations, restore procedures, and failover should be tested under controlled conditions before being trusted in production.
