# Operating systems, processes, and memory

## Process and thread model

An operating system manages processes, threads, virtual address spaces, scheduling, interrupts, system calls, devices, and permissions. A process normally has an isolated virtual address space; threads within a process share memory and resources but have separate stacks and execution state. Context switches, scheduling policy, CPU affinity, and synchronization influence latency and throughput.

## Virtual memory

Virtual memory maps process-visible addresses to physical pages or other backing. The memory-management unit and page tables enforce translation and protection. Page faults can be valid demand paging, copy-on-write, mapped-file access, or actual errors. Memory pressure may trigger reclaim or swapping. A program's virtual size is not equivalent to resident physical memory. Understand stack, heap, static storage, memory mapping, allocation arenas, and garbage-collected heaps for the chosen runtime.

## Resource lifecycle

Files, sockets, processes, locks, memory mappings, GPU contexts, and handles are finite resources. Acquire and release them predictably using structured cleanup, RAII, `with` blocks, `defer`, or `try/finally` as appropriate. Avoid descriptor leaks, zombie processes, deadlocks, resource starvation, and unbounded queues. Shutdown paths deserve tests, not just startup paths.

## Filesystems and permissions

Filesystems organize names, metadata, directories, links, permissions, journaling, and storage allocation. Paths may be relative, absolute, case-sensitive, Unicode-normalized, or affected by mount namespaces. Treat symlinks and path traversal as security concerns. Atomic rename can support durable replacement patterns, but durability also depends on flush and filesystem guarantees. Do not infer portability from behavior on one operating system.

## OS-facing engineering

Use documented system APIs and check errors. Distinguish recoverable errors from invariant violations. Understand signals, cancellation, process exit status, environment variables, user identities, sandboxing, and privilege boundaries. Prefer least privilege and explicit resource limits. OS behavior varies by version, kernel, filesystem, and container/runtime configuration; verify against the target environment.
