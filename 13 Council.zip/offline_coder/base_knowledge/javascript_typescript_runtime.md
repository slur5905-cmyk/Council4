# JavaScript and TypeScript: Language Semantics and Runtime Engineering

## JavaScript semantics
JavaScript is dynamically typed, prototype-based, and uses lexical scoping. Distinguish `undefined`, `null`, missing properties, `NaN`, falsy values, object identity, and structural equality. `==` performs coercion; `===` avoids most implicit coercion but does not compare object contents. Floating-point numbers use IEEE 754 binary64 semantics; integer precision is bounded for ordinary `Number`, while `BigInt` has separate rules and cannot be freely mixed with `Number`.

The event loop coordinates a call stack, task queues, microtasks, timers, I/O callbacks, and rendering. Promise callbacks and `queueMicrotask` run at microtask checkpoints; timers are minimum scheduling delays, not precise clocks. `async` functions return promises. Errors must be observed, cancellation and timeouts need explicit design, and CPU-heavy work can block the main thread. Web Workers, worker threads, and service workers have different lifecycles and capabilities.

## Modules and packages
ES modules have static import/export syntax and live bindings; CommonJS uses `require` and module exports. Interoperability, package `type`, file extensions, conditional exports, bundlers, and runtime versions can change module behavior. Avoid relying on undocumented resolution fallbacks. Lock dependencies, inspect install scripts, and distinguish development from production dependencies.

## TypeScript
TypeScript checks types before runtime but erases most type syntax when emitting JavaScript. Types do not validate network payloads or user input. `unknown` is safer than `any`; narrow it through runtime checks. Understand structural typing, generics, unions, discriminated unions, variance, declaration files, module resolution, `strictNullChecks`, and target/lib settings. A passing type check does not prove runtime behavior or compatibility with a package's actual exports.

## Browser and server runtimes
Browser code operates within origin, permission, storage, rendering, and lifecycle constraints. The DOM is mutable shared state; avoid unsafe HTML injection, race-prone event handling, layout thrashing, and leaking listeners. Server-side JavaScript has filesystem, process, and network APIs that browser code does not. Do not assume APIs available in Node exist in browsers or vice versa.

## Engineering and testing
Use linting, type checking, unit tests, DOM/browser tests, and end-to-end flows as distinct evidence. Test keyboard interaction, focus management, responsive behavior, network failure, race conditions, stale requests, and cleanup. Prefer abortable requests and explicit state transitions. Escape or safely encode untrusted content for the context in which it is inserted. Avoid `eval`, dynamic `Function`, and unsafe deserialization. Pin runtime and package versions and verify version-sensitive APIs against official documentation.
