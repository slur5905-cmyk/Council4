# Version Control, Build Systems, DevOps, Cloud, and Operations

## Version control

Git stores content-addressed snapshots in commits, with branches and tags referencing history. Use small commits, meaningful messages, reviewable diffs, and tested merges. Understand merge conflicts, rebases, resets, cherry-picks, tags, and reflogs. Never rewrite shared history without coordination. Protect secrets from commits and use history scanning/remediation if leaked; deleting a file in a later commit does not remove it from history.

## Build systems

Build tools resolve source inputs, dependencies, generated artifacts, compiler flags, and outputs. Reproducible builds require pinned dependencies, deterministic inputs, controlled environment variables, toolchain versions, timestamps, and consistent paths. Incremental build caches need correct dependency keys and invalidation. Build scripts execute code and should be treated as untrusted when imported from external projects.

## Dependency management

Use ecosystem-native manifests and lockfiles. Understand semver ranges, transitive dependencies, optional/peer dependencies, platform markers, and source registries. Review install scripts, native extensions, binary artifacts, checksums, provenance, licenses, and update policies. Use minimal dependencies and isolated build environments.

## Containers and orchestration

Containers package processes and filesystem layers while sharing the host kernel. Images should be minimal, pinned by digest when practical, scanned, signed/verified where available, and rebuilt regularly. Run as non-root, drop capabilities, use read-only filesystems, resource limits, seccomp/AppArmor/SELinux profiles, minimal mounts, and restricted network policies. Orchestration systems add scheduling, service discovery, secrets, health checks, rolling updates, and failure recovery; configuration errors can widen access.

## CI/CD

Continuous integration runs automated checks on changes; continuous delivery keeps release artifacts deployable; continuous deployment automatically releases under policy. Pipelines should have least privilege, protected branches/environments, pinned actions, isolated jobs, short-lived credentials, artifact provenance, and auditable approvals. Never expose release secrets to untrusted pull-request code.

## Cloud fundamentals

Cloud resources include compute, storage, databases, networks, identity, queues, observability, and managed platforms. Shared responsibility varies by service model. Understand regions/availability zones, quotas, IAM, private networking, egress, backup, failover, and data residency. Cloud services are not inherently secure or infinitely scalable. Track cost, latency, capacity, and lock-in.

## Infrastructure as code

IaC declares infrastructure desired state and changes through plans/apply cycles. Review plans before applying. Protect state files and secrets. Use versioned modules, state locking, drift detection, policy checks, and rollback strategies. Avoid broad wildcards and unreviewed destructive replacements.

## Operations

Use health/readiness/liveness checks carefully; a liveness failure can restart a service unnecessarily. Deploy progressively (canary, blue/green, rolling) and monitor. Maintain runbooks, alerts, incident response, backups, restore drills, and disaster-recovery exercises. Measure service levels. Keep logs, metrics, traces, and audit records separate with proper access controls and retention.

## Deployment portability

Identify OS, architecture, runtime, filesystem case behavior, environment variables, ports, TLS, process supervisor, and static hosting constraints. A local app, PWA, serverless function, and long-running worker have different lifecycle guarantees. Never claim a suspended mobile browser can maintain continuous compute. State what must run on a persistent host.
