# Database Internals, Query Planning, and Data Modeling

## Relational fundamentals
A relational database organizes data into relations with keys and constraints. Normalization reduces update anomalies; denormalization can improve read workloads but introduces synchronization and consistency costs. Use primary keys, foreign keys, unique constraints, check constraints, and not-null constraints to enforce invariants at the database boundary. Application validation is not a substitute for database constraints.

## Transactions and isolation
ACID properties describe transactional guarantees. Isolation levels range from read uncommitted through read committed, repeatable read, and serializable, but exact behavior varies across products. Anomalies include dirty reads, non-repeatable reads, phantom reads, write skew, lost updates, and serialization failures. Use optimistic concurrency tokens or row locks where appropriate. Keep transactions short and define retry policy for serialization/deadlock errors.

## Indexes and query plans
B-tree indexes support ordered lookup and range scans; hash indexes, inverted indexes, bitmap indexes, spatial indexes, and columnar structures suit other workloads. Indexes increase storage and write amplification. Composite index column order matters. Inspect execution plans, row estimates, actual row counts, join algorithms, sort/hash memory, and I/O. A sequential scan can be optimal for small or low-selectivity tables. Never add indexes solely because a column appears in a WHERE clause.

## Storage and recovery
Databases use pages, logs, checkpoints, write-ahead logging, replication logs, buffer pools, and recovery protocols. Durability depends on flush and replication configuration. Backups must be restorable and tested; snapshots alone may not capture all required external objects or keys. Point-in-time recovery requires continuous logs and consistent restore procedures.

## NoSQL and specialized stores
Key-value, document, wide-column, graph, time-series, search, and vector databases optimize different access patterns. Choose based on query shape, consistency, throughput, operational expertise, and data relationships. Schemaless does not mean schema-free: every application still has data contracts and validation. Vector similarity search is approximate in many implementations; evaluate recall, filtering, index updates, and privacy.

## Migrations and data quality
Use expand-migrate-contract patterns for zero-downtime schema evolution. Backfill in bounded batches, make operations resumable, preserve old-client compatibility, and measure lock duration. Validate data before and after migration. Test restore and rollback strategies against a representative copy; destructive production migrations need explicit human approval.
