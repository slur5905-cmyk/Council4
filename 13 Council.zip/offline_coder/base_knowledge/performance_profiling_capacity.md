# Performance Engineering, Profiling, and Capacity Planning

## Measurement first
Performance includes latency, throughput, resource use, scalability, responsiveness, and cost. Measure a representative workload under controlled conditions. Record warmup, input size, environment, runtime, concurrency, cache state, and variance. Avoid microbenchmarks that do not resemble production behavior. Compare distributions and tail percentiles rather than only averages.

## Bottleneck analysis
Amdahl's law limits speedup when part of the workload remains serial. CPU profiles reveal hot code; allocation profiles reveal memory pressure; I/O traces reveal waits; flame graphs summarize sampled stacks. GPU workloads need device-side timing and synchronization-aware measurement. Network and storage bottlenecks require end-to-end tracing. Profiling overhead can change observed performance.

## Capacity and queueing
Capacity planning considers arrival rate, service time, concurrency, queue depth, burstiness, resource limits, and headroom. As utilization approaches saturation, latency can rise sharply. Apply backpressure and bounded queues rather than allowing unlimited work accumulation. Use admission control, load shedding, batching, caching, and horizontal scaling only when the workload supports them.

## Benchmark integrity
Use the same input, environment, compiler flags, model file, runtime settings, and warmup policy for comparisons. Repeat runs and report medians, ranges, and outliers. Separate model inference time from orchestration, filesystem, browser, and GPU-server costs. Do not equate a larger model, more agents, longer output, or higher parameter count with better task performance.
