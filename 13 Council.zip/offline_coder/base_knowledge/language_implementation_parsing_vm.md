# Language implementation: grammars, parsers, interpreters, and virtual machines

A programming language implementation turns source text into behavior. A typical path is source bytes → tokens → syntax tree → semantic analysis → intermediate representation (IR) → machine code or bytecode → execution. Not every language uses every stage: an interpreter may walk an AST directly, a compiler may generate native code, and a hybrid runtime may compile frequently executed functions after interpreting them.

## Lexing and parsing

A lexer groups characters into tokens such as identifiers, keywords, literals, punctuation, and operators. It must define how whitespace, comments, escape sequences, Unicode identifiers, and malformed input are handled. Longest-match rules and keyword priority matter: `<=` should normally be one token rather than `<` followed by `=`. A parser checks token structure against a grammar and creates an abstract syntax tree (AST). Concrete syntax trees preserve punctuation and formatting details; ASTs omit details that are not needed by later semantic stages.

Context-free grammars are commonly described using production rules. Recursive-descent and Pratt parsers are approachable for many languages; Pratt parsing is especially useful for operator precedence. LR-family parsers handle broader grammar classes. Parser generators can reduce implementation effort, but generated parsers still need good diagnostics and recovery behavior. Ambiguous grammar rules should be resolved explicitly rather than patched with accidental parser behavior.

## Semantic analysis

A syntactically valid program can still be invalid. Name resolution connects identifier uses to declarations. Scope rules define where bindings are visible. Type checking validates operations and function contracts. Other semantic passes may check definite assignment, access control, mutability, exhaustiveness, effects, ownership, or control-flow rules. Symbol tables and typed AST nodes help later passes avoid repeating work.

Diagnostics should identify the source span, explain the violated rule, and suggest a plausible correction without pretending that a guess is certain. Error recovery should avoid cascading dozens of misleading diagnostics after one missing delimiter or unknown name.

## Intermediate representations and execution

An IR expresses program behavior in a form easier to optimize or target. Common forms include control-flow graphs, static single assignment (SSA), bytecode, and typed high-level IRs. SSA gives each value a single definition and makes data dependencies explicit. Lowering progressively replaces high-level constructs with simpler operations. A backend maps IR to machine instructions, registers, calling conventions, and object-file formats.

An interpreter executes instructions directly. A bytecode virtual machine defines an instruction set and runtime rules for values, calls, exceptions, memory, and modules. A JIT compiler translates selected code at runtime. Dynamic-language runtimes may use inline caches, hidden classes/shapes, speculative optimization, and deoptimization when assumptions become invalid. These optimizations need guards and safe fallback behavior.

## Runtime responsibilities

The runtime may provide allocation, garbage collection, exceptions, stack traces, reflection, module loading, standard libraries, thread scheduling, and foreign-function interfaces. Language semantics should be separated from implementation details where possible. For example, a language's memory model specifies which concurrent observations are valid, while a particular runtime decides how to implement those guarantees.

## Engineering and testing

Build small vertical slices: tokenizer, parser, source spans, basic AST, evaluator, then types and modules. Test lexical boundaries, operator precedence, nested scopes, shadowing, malformed input, Unicode, exception propagation, and deterministic output. Add golden tests for diagnostics, property tests for parser/evaluator invariants, and differential tests against a reference implementation when one exists. Fuzz parsers with bounded inputs and make sure malformed source fails safely rather than hanging or consuming unbounded memory.

Do not claim full language compatibility from a handful of examples. Specify the supported grammar, numeric behavior, evaluation order, standard-library surface, module format, and error semantics. Keep the grammar, implementation, and tests versioned together.
