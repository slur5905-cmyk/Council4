# Robotics, Control Systems, and Real-Time Computing

## Robot architecture
Robots combine sensors, estimation, planning, control, actuators, power, communications, and safety systems. Sensor observations are noisy, delayed, and incomplete. Calibration, coordinate frames, units, timestamps, and synchronization matter. State estimation may use filtering, sensor fusion, localization, mapping, or probabilistic methods. A planner proposes actions; a controller turns them into actuator commands within physical constraints.

## Control theory
Open-loop control applies commands without feedback; closed-loop control measures error and adjusts action. PID control combines proportional, integral, and derivative terms but requires tuning, saturation handling, anti-windup, filtering, and sampling analysis. Stability, delay, actuator limits, disturbance rejection, and system identification must be considered. A controller that appears stable in simulation may fail on real hardware due to unmodeled friction, backlash, latency, and sensor noise.

## Real-time systems
Real-time correctness includes meeting timing constraints, not just producing the right logical result. Hard real-time deadlines require carefully bounded worst-case execution and scheduling assumptions. Soft real-time systems tolerate occasional missed deadlines with reduced quality. Interrupt handlers should be short, priority inversion must be managed, and shared resources need bounded access. Average timing is not proof of worst-case timing.

## Safety engineering
Define safe states for communication loss, sensor disagreement, overtemperature, low battery, actuator faults, and unexpected obstacles. Use physical limits, watchdogs, emergency stops, independent interlocks, and validated shutdown sequences where appropriate. Test failures in simulation and controlled hardware environments. Never assume an AI planner is itself a safety controller.
