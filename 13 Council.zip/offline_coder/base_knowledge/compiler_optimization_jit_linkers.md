# Compiler optimization, JIT compilation, and linking

A compiler translates a program while preserving the language's defined behavior. Optimization is not permission to change semantics: it is a transformation justified by assumptions in the language and compilation model. Undefined behavior, overflow rules, aliasing, exceptions, floating-point semantics, and concurrency rules can change which transformations are legal.

## Optimization pipeline

Typical stages include parsing, semantic analysis, IR lowering, control-flow construction, optimization, instruction selection, register allocation, scheduling, and object-file emission. A compiler may repeat optimization at multiple levels. High-level passes can simplify loops and data structures while type information is available; low-level passes understand machine instructions and registers.

Common optimizations include constant folding, constant propagation, dead-code elimination, common-subexpression elimination, strength reduction, loop-invariant code motion, inlining, devirtualization, escape analysis, and vectorization. Every pass should state its preconditions and preserve debug/source-location information where feasible. Optimization pipelines should be tested by comparing optimized and unoptimized results across generated programs, not only by checking that the compiler emits code.

## Static single assignment and control flow

In SSA, each value is assigned once. Merge nodes (often represented by phi functions) join values from different predecessor blocks. Dominator trees and use-def chains support data-flow analyses. A control-flow graph makes branches, loops, exceptional exits, and unreachable blocks explicit. Incorrect CFG construction can lead to miscompilation, especially around exceptions, cleanup, and language-specific control flow.

## Machine code and register allocation

Instruction selection maps IR operations to target instructions. Register allocation assigns live values to limited physical registers; values may spill to stack slots. Linear-scan allocation is fast and useful for JITs; graph-coloring approaches can optimize more aggressively but are more complex. Calling conventions define argument registers, return values, preserved registers, stack alignment, and unwind behavior. ABI mismatches often cause failures that look like random memory corruption.

## Static and dynamic linking

Compilers generally emit object files containing machine code, symbol tables, relocation entries, and metadata. A static linker resolves symbols, lays out sections, applies relocations, and produces an executable or library. A dynamic loader maps shared libraries, resolves imports, applies relocations, and initializes runtime state. Position-independent code, address-space layout randomization, symbol visibility, library search paths, and ABI versioning affect deployment.

A package may compile successfully but fail to link because a required symbol is missing or incompatible. It may link but fail at runtime because the expected shared library is unavailable. Diagnoses should distinguish compile errors, link errors, loader errors, ABI mismatch, and runtime faults.

## JIT-specific engineering

A JIT compiles code while a program runs. It must balance startup latency, compilation cost, code-cache size, and steady-state speed. Tiered compilation can first interpret or compile quickly, then optimize hot code. Speculative optimizations rely on guards; when an assumption fails, deoptimization reconstructs a valid lower-tier execution state. Profiling data must not be mistaken for a proof that an optimization is always safe.

JIT code memory has security and platform constraints. W^X policies avoid pages being writable and executable simultaneously; runtimes can generate code into writable pages, transition permissions, and use controlled code-cache APIs. Instruction-cache coherency differs across architectures. Generated code must also integrate with stack walking, exceptions, debugging, and garbage collection.

## Validation

Use compiler test suites, IR verifier passes, differential execution, random program generation, and reduced failing examples. For performance claims, pin toolchain and target versions, warm up JITs consistently, isolate measurement noise, use representative workloads, and compare distributions. A faster microbenchmark can regress full applications due to cache, allocation, code-size, or compilation effects.
