# Optimization, Operations Research, and Decision Models

## Optimization problem structure
An optimization model defines decision variables, an objective, constraints, and a feasible region. Linear programming uses linear objectives and constraints; integer programming restricts some variables to discrete values; nonlinear optimization handles nonlinear relationships. A solver's result is meaningful only if the model accurately represents the real problem.

## Algorithms and tradeoffs
Exact methods include simplex, branch-and-bound, cutting planes, dynamic programming, and constraint programming. Heuristics and metaheuristics can find useful solutions when exact optimization is too expensive, but generally do not prove optimality. Greedy methods are optimal only for problem structures with the required properties. Approximation algorithms provide bounded guarantees under stated assumptions.

## Scheduling and resource allocation
Scheduling problems include precedence constraints, deadlines, machine capacities, fairness, and uncertainty. Queueing models help reason about utilization and waiting time; systems near full utilization can experience rapidly increasing delays. Backpressure and admission control can protect overloaded services. Batch size, concurrency, and priority policies should be measured against real workload distributions.

## Multi-objective decisions
Real systems balance correctness, latency, throughput, memory, energy, cost, fairness, and maintainability. A Pareto frontier identifies solutions where one objective cannot improve without worsening another. Do not collapse all objectives into a single score without explaining weights and tradeoffs. Preserve hard safety constraints as constraints, not as small penalties.

## Practical workflow
Validate units and dimensions, test boundary cases, inspect solver status, and independently recompute key constraints. Distinguish infeasible, unbounded, optimal, approximate, and time-limited outcomes. Record the formulation, solver version, tolerances, random seed, and termination status so results can be reproduced.
