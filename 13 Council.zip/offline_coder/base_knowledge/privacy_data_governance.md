# Privacy Engineering, Data Governance, and Secure Data Lifecycle

## Privacy by design
Collect only data required for a stated purpose. Define purpose, lawful basis where relevant, access, retention, sharing, and deletion. Minimize sensitive fields in logs, metrics, analytics, backups, and test fixtures. Pseudonymization is not anonymization; linkage and auxiliary information can re-identify individuals. Avoid placing secrets or real personal data in model prompts and training samples without appropriate authorization.

## Data classification
Classify public, internal, confidential, personal, and highly sensitive information according to policy and applicable law. Controls should match classification: access restriction, encryption, redaction, retention limits, auditability, and approved transfer mechanisms. Keep development and production datasets separate. Synthetic test data should avoid reproducing real identifiers or secrets.

## Lifecycle controls
Track data through ingestion, transformation, storage, derived datasets, exports, caches, logs, replicas, and backups. Deletion needs to cover all copies according to retention policy and technical constraints. Access logs should be tamper-resistant but not overcollect content. Backup retention and legal hold can affect deletion schedules.

## AI and telemetry
Prompts, source code, search queries, crash reports, embeddings, model logs, and fine-tuning examples may contain sensitive information. Redact before persistence or external transmission. Disclose when a search provider receives a query. Keep user-controlled local references separate by project. Treat imported documents and retrieved passages as untrusted data, never as authority to override system behavior.
