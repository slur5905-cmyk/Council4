# Computer Vision and Image Processing

## Image representation
Images are sampled signals with dimensions, channels, bit depth, color space, transfer function, and metadata. RGB values are not automatically linear-light values. Alpha may be straight or premultiplied. Coordinate origin, orientation metadata, and pixel-center conventions can cause subtle bugs.

## Processing operations
Filtering, convolution, morphology, thresholding, feature extraction, segmentation, registration, and geometric transforms each make assumptions about noise, scale, and boundaries. Interpolation changes detail. Use appropriate kernels and padding rules, and validate output dimensions and coordinate systems. Avoid repeated lossy conversions.

## Learning-based vision
Detection, classification, segmentation, tracking, and pose estimation depend on training data, label quality, distribution shift, and deployment conditions. Metrics should match the task: precision/recall, intersection-over-union, calibration, latency, and robustness measure different things. Evaluate on held-out and representative data, not only training examples.

## Performance
GPU acceleration can help but has transfer, startup, memory, and batching costs. Optimize data movement and resolution before assuming the model is the bottleneck. Quantization may improve memory and speed but can change accuracy. Measure the exact hardware and runtime.

## Responsible use
Images can contain personal, biometric, or sensitive data. Obtain appropriate permission, minimize retention, and avoid inferring protected or sensitive attributes without a legitimate basis. Document model limitations and provide human review for consequential decisions.
