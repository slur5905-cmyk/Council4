# Programming Languages, Compilers, and Runtime Systems

## Language design and paradigms

A programming language defines syntax and semantics for expressing computation. Paradigms include imperative, procedural, object-oriented, functional, declarative, logic, event-driven, dataflow, concurrent, and reactive programming. Real languages usually combine paradigms. Choose a style that makes state, ownership, invariants, and effects understandable; avoid dogmatic rewrites.

## Syntax, parsing, and semantics

Lexers turn characters into tokens; parsers form syntax trees; semantic analysis resolves names, types, scopes, and constraints. Abstract syntax trees omit some concrete formatting detail; concrete syntax trees preserve it. Interpreters execute representations directly; compilers translate to lower-level forms such as bytecode, intermediate representation, assembly, or machine code. JIT compilers compile hot paths during execution. Linkers resolve symbols and combine object files/libraries. Loaders map program components into memory and initialize runtime state.

A grammar describes valid syntax. Static semantics specify constraints such as types and declarations. Dynamic semantics specify runtime behavior. The language specification is the authority; implementation behavior not guaranteed by the spec should not be relied upon. Undefined behavior, unspecified behavior, implementation-defined behavior, exceptions, panics, and checked errors are distinct concepts.

## Type systems

Types classify values and constrain operations. Static typing checks many errors before execution; dynamic typing checks at runtime. Strong/weak typing are informal labels and are not a sufficient description of a language. Nominal typing identifies declared types; structural typing checks shape. Subtyping, generics, parametric polymorphism, ad-hoc polymorphism, type inference, union/intersection types, algebraic data types, refinement types, dependent types, and gradual typing solve different problems.

Use types to make invalid states hard to represent. Model absence explicitly (Option/Maybe/nullability), errors explicitly (Result/Either/exception contracts), and units/domain values with distinct types when mixups are costly. Type assertions and casts require evidence. Static type checks do not prove runtime correctness, security, or external API compatibility.

## Memory, ownership, and resource management

Languages may use garbage collection, reference counting, ownership/borrowing, RAII/destructors, arenas, or manual allocation. Understand allocation, lifetime, aliasing, mutation, cyclic references, finalization, and resource release. Files, sockets, locks, GPU buffers, and database transactions need deterministic cleanup even in garbage-collected languages. Use context managers, defer/finally, RAII, or equivalent constructs.

## APIs, modules, and packages

Modules define namespaces and compilation or import boundaries. Public APIs should have explicit contracts, stable semantics, clear errors, versioning, and compatibility policy. Avoid exposing internal representations unnecessarily. Semantic versioning is a convention, not a guarantee that every project applies correctly. Package managers resolve dependency graphs; lockfiles capture concrete resolutions. Pin critical dependencies, review transitive dependencies, and avoid silently relying on floating versions.

## Concurrency and asynchronous programming

Concurrency concerns overlapping tasks; parallelism concerns simultaneous execution. Threads share memory; processes usually have separate address spaces; actors communicate through messages; coroutines/fibers are cooperatively scheduled; async/await represents suspended computations. Event loops multiplex I/O. Race conditions, deadlocks, livelocks, starvation, priority inversion, and data races require explicit design. Use immutable data, ownership, message passing, synchronization primitives, and bounded queues. Never assume async means CPU-parallel.

## Language interoperability

FFI boundaries must agree on calling conventions, data layout, ownership, error representation, string encoding, and thread safety. C ABIs are common but not universally portable. Serialization formats need schema/version handling, size limits, validation, and compatibility tests. Avoid passing language-managed objects across ABI boundaries unless explicitly supported.

## Choosing a language

Evaluate ecosystem maturity, runtime needs, performance, safety properties, team knowledge, deployment targets, libraries, build tooling, observability, interoperability, and maintenance horizon. Benchmarks must represent the real workload. A rewrite is justified by measurable needs, not language fashion.

## Common language pitfalls

- Integer division, overflow, coercion, truthiness, and evaluation order differ.
- Variable capture, closure lifetime, shadowing, and mutation can surprise.
- Equality may mean identity, structural equality, or overloaded comparison.
- Exceptions can bypass expected control flow; async errors may be unobserved.
- Unicode indexing and locale-sensitive formatting are subtle.
- Time zones, daylight-saving transitions, monotonic clocks, and calendar time differ.
- Floating-point calculations need numerical error analysis.
- Reflection, dynamic imports, macros, and code generation make static indexing incomplete.

## Language-specific work procedure

Before generating code, identify language version, compiler/interpreter version, formatter/linter/type checker, package manager, lockfile, target platform, and existing style. Consult version-matched official docs for new APIs. Compile or parse with the actual configured toolchain when available. Do not invent exact method signatures based only on memory.
