# Storage systems and distributed filesystems

## Storage hierarchy

Registers, CPU caches, RAM, persistent memory, SSDs, HDDs, and remote object stores differ in latency, throughput, durability, capacity, and failure behavior. Sequential and random access have different costs. Flash storage has write amplification and finite endurance; filesystems and controllers manage these details imperfectly.

## Data durability

A successful write call may mean data reached a page cache, not necessarily durable media. Durability depends on flush semantics, filesystem, controller, device cache, and power-loss protection. Atomic rename is useful but does not by itself guarantee a durable multi-file transaction. Design recovery and journal behavior explicitly.

## Distributed storage

Replication, erasure coding, sharding, quorum reads/writes, leases, and consensus solve different storage problems. Replicas can be stale; network partitions can prevent progress; concurrent updates require conflict semantics. A backup should be isolated enough to survive accidental deletion or compromise and should be restore-tested.

## Object and block storage

Block devices expose addressable blocks; filesystems organize files; object stores use keys and metadata with provider-specific consistency and lifecycle behavior. Multipart upload, versioning, retention, encryption, and access policies need explicit handling. Do not assume all object stores implement identical semantics.

## Capacity planning

Measure IOPS, throughput, queue depth, latency percentiles, cache hit rates, compaction, and growth. Storage benchmarks should reflect payload size, concurrency, and read/write mix. Track the cost of indexes, replicas, snapshots, and backups.
