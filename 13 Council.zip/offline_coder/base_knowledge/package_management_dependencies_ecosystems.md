# Package management, dependency ecosystems, and software supply chains

Package managers resolve and install reusable code, runtimes, plugins, and system libraries. A dependency is executable supply-chain input, not merely a name in a manifest. Dependencies can introduce vulnerabilities, license obligations, unexpected install scripts, transitive complexity, compatibility conflicts, or maintenance risk.

## Manifests, lockfiles, and resolution

A manifest expresses direct dependencies and allowed version ranges. A lockfile records a resolved dependency graph and usually pins exact versions and integrity metadata. Ranges support updates but can produce different graphs over time; reproducible builds generally require a committed lockfile and deterministic tooling. Some ecosystems resolve peer dependencies, optional features, platform-specific packages, or native extensions differently. Document the package-manager version and supported runtime.

Semantic versioning is a convention, not a universal guarantee. Pre-release labels, build metadata, zero-major versions, vendor patches, and ecosystem-specific comparison rules matter. A pinned version can still contain a vulnerability or be compromised. A version range does not prove that every matching release is compatible.

## Dependency minimization

Prefer a small number of well-maintained, necessary dependencies. Evaluate ownership, release history, support policy, package provenance, transitive dependencies, install scripts, license, and whether the package is actually imported at runtime. Avoid copying a package solely because it is familiar. Native dependencies need compiler toolchains and compatible ABI targets. Vendored source needs update and license tracking.

## Reproducible and hermetic builds

A reproducible build aims to generate identical artifacts from the same inputs. Record source revision, dependency lockfiles, compiler and build tool versions, environment variables, target architecture, and build flags. Hermetic builds restrict undeclared network and host inputs. Build caches must be keyed by all relevant inputs; stale caches can conceal missing dependencies or wrong artifacts.

## Supply-chain controls

Use trusted registries, checksums or signatures where supported, protected release workflows, least-privilege build tokens, immutable workflow action references, isolated builders, and artifact provenance. Generate a software bill of materials using a defined format and scope. A source manifest is not necessarily a resolved SBOM; identify whether components are declared, resolved, bundled, or actually present at runtime.

Run dependency audits against current advisory databases and review affected versions and exploitability. A scanner can produce false positives or miss vulnerabilities; a clean scan is not a security certification. Pinning prevents unexpected upgrades but can preserve an old vulnerable version, so combine reproducibility with planned update review.

## Licensing and governance

Check direct and transitive licenses, attribution requirements, source disclosure obligations, patent terms where relevant, and compatibility with distribution plans. Record approval for unusual or restricted licenses. Avoid bulk-importing third-party documentation or source without checking rights. Maintain an inventory owner and a process for abandoned or compromised packages.

## Operations

Automate lockfile consistency checks, dependency review in pull requests, scheduled update proposals, build verification, and release artifact checksums. Update in small batches and run tests against the exact upgraded graph. Keep an emergency process for critical vulnerabilities. Do not automatically install or execute arbitrary packages merely because a manifest names them.
