# API design, contracts, and compatibility engineering

An API is a contract between independently evolving components. Good API design describes inputs, outputs, errors, authentication, authorization, side effects, limits, consistency, versioning, and compatibility. It should be understandable without reading the implementation and testable independently of the client.

## Contract design

Define resources or operations using domain language. Separate identifiers from display labels, and define whether values are nullable, optional, immutable, or server-generated. Specify units, time zones, precision, pagination, sorting, filtering, and ordering. Prefer unambiguous timestamps and explicit units over values whose meaning depends on context. Establish maximum lengths, payload sizes, and collection bounds.

Errors should be structured, stable, and actionable. Distinguish validation errors, authentication/authorization failures, conflicts, rate limits, missing resources, transient infrastructure faults, and internal errors. Avoid leaking credentials, internal hostnames, stack traces, or sensitive database details. Give each request a correlation identifier and define retryability explicitly.

## Protocol styles

REST commonly models resources over HTTP methods and status codes. HTTP semantics include safe and idempotent methods; idempotency keys can make selected POST operations safe to retry. GraphQL provides a typed query graph and client-selected fields but needs complexity limits, authorization at field boundaries, and careful caching. gRPC uses typed service definitions and efficient binary messages, with streaming and deadline propagation; browser interoperability may require a gateway or gRPC-Web. Message brokers use asynchronous envelopes and need schema versioning, delivery semantics, and replay policy.

Do not treat an architectural style as an automatic guarantee. A REST endpoint can still be poorly designed; GraphQL can still leak data; gRPC can still have incompatible schemas; a message queue can still duplicate messages.

## Compatibility

Backward compatibility can be source, binary, wire, behavioral, or data compatibility. Removing an optional field may be wire-compatible for some clients but break generated code. Changing a default can alter behavior without changing the schema. Enum additions, field presence, numeric precision, and unknown-field handling need explicit rules. Consumers should ignore unknown fields where appropriate; producers should avoid changing existing meanings.

Use consumer-driven contract tests and schema compatibility checks. For rolling upgrades, deploy readers that understand both old and new data before writers produce the new form. Avoid a flag-day migration where old and new versions must switch simultaneously. Deprecation needs usage measurement, migration documentation, and a communicated removal window.

## Security and operational controls

Authenticate identities, authorize each operation and resource, validate input on the server, and enforce ownership boundaries even when the client UI hides controls. Apply rate, concurrency, payload, query-depth, and execution-time limits. Use TLS and secure secret management. Protect webhook endpoints with signature validation, timestamps, replay detection, and explicit event schemas. Do not trust a client-supplied role, user ID, price, or permission flag.

Observability should include structured logs, latency histograms, error categories, trace context, and business-level outcome metrics. Avoid logging secrets or unnecessary personal information. Document quotas and retry behavior so clients do not create retry storms.

## Design workflow

Start from use cases and failure cases. Write an OpenAPI, protobuf, GraphQL, or event schema before or alongside implementation. Review the contract with client authors. Generate test fixtures, compatibility checks, and SDKs from the schema when useful, but manually review generated clients. Version only when compatibility policy requires it; a version number alone does not solve breaking behavior.
