# AI and machine-learning engineering

## Data and training

Machine-learning systems depend on data provenance, labeling quality, representativeness, leakage prevention, feature definitions, train/validation/test separation, and reproducible preprocessing. Track dataset versions and transformations. Avoid using test data to tune repeatedly. Evaluate performance across relevant subgroups and failure conditions without making unsupported generalizations.

## Model evaluation

Use task-specific metrics and human review where needed. Accuracy alone can hide class imbalance, calibration errors, distribution shift, and harmful failure modes. Separate benchmark performance from real-world performance. Keep test sets protected and report uncertainty, sample size, and evaluation protocol.

## Deployment and inference

Inference systems need resource budgets, batching, timeouts, fallback behavior, monitoring, and model/version tracking. Local model performance depends on hardware, quantization, context length, memory bandwidth, and workload. More parameters or longer outputs do not automatically improve task quality. Evaluate with repeated, blinded comparisons where possible.

## Safety and privacy

Treat user content, retrieved documents, model outputs, and tool results according to their trust level. Minimize sensitive training and telemetry data. Bound tool permissions and validate actions outside the model. For agentic systems, log decisions and evidence, require authorization for high-impact operations, and prevent untrusted text from changing policy.

## Lifecycle

Monitor drift, regressions, latency, resource use, and feedback quality. Preserve a rollback path. Document training/evaluation limitations. A benchmark score is only meaningful for its suite and configuration; it is not a universal intelligence measurement.
