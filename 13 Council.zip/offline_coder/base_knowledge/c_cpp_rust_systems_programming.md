# C, C++, and Rust: Systems Programming and Memory Safety

## C and C++ foundations
Systems code interacts with memory, CPU instructions, operating-system interfaces, ABIs, and hardware. In C, pointer validity, object lifetime, bounds, alignment, integer overflow, aliasing, and ownership are programmer responsibilities. A pointer may be null, dangling, misaligned, out of bounds, or refer to an object whose lifetime ended. Buffer sizes must be explicit and checked before arithmetic or copying.

C++ adds constructors/destructors, RAII, references, templates, exceptions, move semantics, standard containers, smart pointers, and a complex object model. Prefer automatic storage and standard abstractions over raw owning pointers. `unique_ptr` expresses exclusive ownership; `shared_ptr` expresses shared lifetime but can create cycles; `weak_ptr` can break cycles. Destructors should not unexpectedly throw. Understand copy/move operations and exception-safety guarantees.

Undefined behavior permits compilers to make assumptions that invalidate intuitive reasoning. Data races are undefined behavior in the C++ memory model. Integer overflow rules differ between signed and unsigned types and between languages. Use sanitizers and static analysis where appropriate, but tests cannot prove absence of undefined behavior.

## Rust ownership and borrowing
Rust uses ownership, borrowing, and lifetimes to restrict aliasing and mutation. The borrow checker checks many memory-safety properties at compile time, but unsafe blocks, FFI, logic bugs, deadlocks, resource exhaustion, and incorrect synchronization remain possible. `Send` and `Sync` describe thread-safety properties; `Result` and `Option` encode error and optional values; traits define shared behavior. Avoid broad `unsafe` blocks and document the invariant each unsafe operation relies on.

## Concurrency and atomics
The memory model specifies which writes are visible across threads. Mutexes, read-write locks, channels, atomics, barriers, and condition variables solve different coordination problems. Atomicity alone does not imply ordering or a correct algorithm. Establish happens-before relationships; avoid double-checked locking without required memory-order reasoning. Identify lock order to prevent deadlocks and keep critical sections short.

## Native build and integration
The ABI governs calling conventions, register usage, stack layout, alignment, symbol names, and data representation. FFI boundaries must specify allocation ownership, string encoding, error translation, and callback lifetimes. Build flags, target triples, linker choice, runtime libraries, and CPU feature levels affect portability. Compile for the actual target and test on the target architecture when hardware or ABI behavior matters.

Use fuzzing, property tests, sanitizers, static analysis, and code review together. Do not execute untrusted native binaries on the host; compile and test them in a deliberately isolated, resource-limited environment.
