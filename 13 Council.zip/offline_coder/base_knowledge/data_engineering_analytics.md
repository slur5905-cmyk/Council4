# Data Engineering, Analytics, and Data Quality

## Data lifecycle
Data pipelines ingest, validate, transform, store, serve, and retire information. Batch pipelines process bounded datasets; streaming pipelines process events continuously or near-real-time. Each stage needs schemas, lineage, ownership, retention, quality rules, and failure handling. Distinguish event time from processing time and define late-arriving or duplicated event behavior.

## Data modeling and formats
Relational modeling emphasizes keys and constraints. Analytical warehouses often use star or snowflake schemas with facts and dimensions. Data lakes and lakehouses store files or tables with different transaction and governance properties. CSV is simple but ambiguous around types, encoding, delimiters, and null values. Columnar formats such as Parquet are efficient for analytical scans. Schema evolution must preserve reader/writer compatibility.

## Quality and lineage
Quality checks should cover completeness, validity, uniqueness, consistency, freshness, distribution drift, referential integrity, and business invariants. Record input versions, transformation code, run IDs, and output hashes where feasible. Make pipelines idempotent and restartable. Quarantine malformed records rather than silently dropping important data. Reconcile source and destination counts and values.

## Scale and privacy
Partition by access patterns and time where appropriate; avoid tiny-file explosions and skew. Distributed processing has serialization, shuffling, backpressure, checkpointing, and retry costs. Minimize sensitive attributes, apply access controls, and aggregate or de-identify only with a clear threat model. Test retention and deletion across derived tables, caches, backups, and exports.

## Analytics and experiments
Separate descriptive, diagnostic, predictive, and causal claims. Correlation does not establish causation. Define the population, sampling process, outcome metric, confounders, missingness, and uncertainty. For A/B tests, predefine hypotheses and stopping rules, guard against multiple comparisons and sample-ratio mismatch, and consider novelty and interference effects. Preserve reproducibility with versioned data and code.
