# Cloud networking and edge reliability

## Cloud network building blocks

Virtual networks, subnets, route tables, security groups, network ACLs, gateways, load balancers, private endpoints, and service meshes compose cloud connectivity. Names and semantics vary among providers. Understand the effective path from a workload to a dependency instead of trusting one security-group rule in isolation.

## Identity-based access

Prefer workload identity and short-lived credentials over embedded static secrets. Scope permissions to the resource and action required. Rotate and revoke credentials, audit policy changes, and separate development from production. Network location alone is not a reliable identity boundary.

## Edge trade-offs

Edge compute can reduce latency and move data processing near users or devices, but creates distributed deployment, synchronization, cache invalidation, and observability challenges. Data locality and residency constraints may matter. Define what happens when edge nodes are offline or stale.

## Failure handling

Cloud services can throttle, fail over, change limits, and experience regional outages. Use bounded retries, idempotency, circuit breakers where appropriate, graceful degradation, and tested recovery. Avoid retry storms and cascading dependency failures. Capacity planning should include quota and rate limits.

## Cost and governance

Track resource use, data transfer, storage retention, logging, and idle capacity. Use tags, budgets, policy checks, and cleanup processes. Cost optimization must not remove backups, monitoring, or needed security controls.
