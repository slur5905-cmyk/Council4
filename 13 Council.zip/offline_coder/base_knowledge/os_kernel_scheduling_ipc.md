# Operating-system kernels, scheduling, and inter-process communication

An operating system mediates access to processors, memory, devices, files, and network interfaces. Applications usually run in user mode and request privileged operations through system calls. The kernel validates arguments and permissions, manages shared resources, and returns errors according to documented contracts.

## Processes and threads

A process provides an address space and resource boundary. Threads share process memory but have separate execution state such as registers and stacks. Context switches save and restore execution state; they can be expensive due to scheduler work, cache disruption, and memory-translation effects. Green threads or coroutines multiplex logical tasks onto fewer operating-system threads; the runtime must define blocking behavior, cancellation, and fairness.

Schedulers balance latency, throughput, fairness, power, and locality. Time slicing prevents one runnable task from monopolizing a CPU. Priority systems need starvation protection and priority inheritance or ceiling protocols for certain real-time locks. Work-stealing schedulers help parallel workloads, while event loops are effective for many I/O-bound tasks. No single scheduler policy is optimal for every workload.

## Virtual memory

Virtual memory maps per-process virtual addresses to physical pages or backing storage. Page tables, translation lookaside buffers, page faults, copy-on-write, memory mapping, and swapping influence performance and isolation. Allocation success does not always mean physical memory is immediately available. Large working sets can thrash when active pages exceed memory capacity. Memory-mapped files share page-cache behavior with ordinary file I/O.

Memory protections distinguish read, write, and execute permissions. Address-space randomization, guard pages, non-executable data, kernel/user separation, and process isolation reduce the consequences of faults. These mechanisms are defense in depth, not a substitute for correct bounds and lifetime management.

## System calls and I/O

System calls expose operations such as open/read/write, process creation, networking, polling, memory mapping, and synchronization. API details differ across operating systems. Robust code handles partial reads/writes, interruption, nonblocking results, timeouts, cancellation, permissions, and resource exhaustion. `select`, `poll`, `epoll`, `kqueue`, IOCP, and completion-based APIs have different scaling and semantics; choose an interface that fits the supported platforms.

Buffered I/O, direct I/O, asynchronous I/O, and memory mapping have different consistency and cache behavior. File replacement may require write, flush, rename, and directory synchronization to meet durability expectations. Do not assume that a successful write means data has reached stable storage.

## IPC and isolation

Processes communicate through pipes, sockets, shared memory, message queues, signals, files, and platform-specific facilities. Pipes provide byte streams; message queues preserve message boundaries; shared memory is fast but requires explicit synchronization and lifecycle management. Local sockets can provide permission controls and credential passing. Protocol framing, backpressure, and resource bounds matter even for local IPC.

Containers generally share the host kernel while isolating namespaces and resource controls. Virtual machines run a guest kernel over virtualized hardware. These provide different isolation boundaries. A container is not a complete security boundary against a malicious kernel exploit and must not be described as equivalent to a dedicated virtual machine in every threat model.

## Cross-platform engineering

Prefer portable APIs or an explicit platform abstraction. Test filesystem case sensitivity, path rules, line endings, process signals, shell behavior, permissions, file locking, clocks, and socket semantics on every supported OS. Detect capabilities rather than guessing from platform names. Document optional behavior and report missing system tools as unavailable, not passed.
