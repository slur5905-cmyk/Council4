# Logic, Proofs, Sets, and Type-Theoretic Foundations

## Propositional and predicate logic
Propositional logic models statements joined by Boolean operators. Predicate logic adds objects, relations, and quantifiers. Quantifier scope matters: “for every input there exists an output” differs from “there exists one output for every input.” Translate requirements into precise predicates before implementing subtle authorization, validation, or data-integrity rules.

## Sets, relations, and functions
Sets model collections; relations model connections; functions associate each input with at most one output. Injective, surjective, and bijective functions have different guarantees. Equivalence relations partition values into classes. Partial functions may be undefined for some inputs, so programs should model failure explicitly rather than silently assuming totality.

## Proof techniques
Direct proof follows definitions. Contradiction assumes the opposite and derives an impossibility. Induction proves a base case and a preserved step. Invariants describe facts that remain true across state transitions. Preconditions and postconditions specify what a routine requires and guarantees. A loop invariant should hold before and after each iteration and help establish termination and correctness.

## Types and propositions
A type system restricts which values and operations are valid. Algebraic data types make alternatives explicit; refinement types add predicates; dependent types can express properties involving values. In the Curry–Howard correspondence, propositions correspond to types and proofs to programs, but practical languages support different fragments of this idea. Static types reduce classes of mistakes; they do not prove all runtime behavior or external assumptions.

## Practical method
For a critical algorithm, define input domains, output guarantees, edge cases, and invariants first. Use property-based tests to sample the domain, and formal verification where the cost and risk justify it. Distinguish a proof about a model from proof that the implementation, compiler, hardware, and deployment match that model.
