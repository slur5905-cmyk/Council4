# Formal Verification, Model Checking, and Program Reasoning

## Specifications and invariants
Formal methods use mathematical models to reason about system behavior. A specification describes allowable states and transitions. Invariants must hold in every reachable state; preconditions constrain operations; postconditions describe results. Temporal properties describe what must eventually happen or what must always remain true. A precise specification reduces ambiguity but does not guarantee the model matches reality.

## Program verification
Hoare logic expresses `{P} C {Q}`: if precondition P holds and command C terminates, postcondition Q holds. Loop invariants and ranking functions support reasoning about correctness and termination. Refinement types and dependent types can encode stronger conditions, though tooling and proof burden vary. Static type safety is not proof of all program properties.

## Model checking
A model checker explores a finite or bounded state space to find counterexamples to properties. State explosion is a major constraint; abstraction, symmetry reduction, partial-order reduction, and bounded depth can help. A found counterexample can be useful evidence. No counterexample found only means none was found within the checked model, state bounds, and assumptions.

## Property-based and metamorphic testing
Property-based testing generates many structured inputs and checks invariants. Shrinking reduces failing cases to simpler counterexamples. Metamorphic testing checks relations between outputs when a direct oracle is unavailable. Fuzzing explores malformed or unexpected inputs. These approaches complement examples and scenario tests but do not prove universal correctness unless paired with formal arguments and complete assumptions.

## Applying methods
Use stronger formal methods for safety-critical algorithms, protocols, parsers, authorization, state machines, financial logic, and concurrency primitives. Start with explicit invariants and failure models. Preserve proof assumptions and tool versions. Review the trusted computing base and validate that implemented code corresponds to the model.
