# Operating Systems, Systems Programming, and Networking

## Operating-system responsibilities

An operating system manages processes, threads, scheduling, virtual memory, filesystems, devices, IPC, users, permissions, and system calls. Kernel space has privileged access; user space is restricted. System calls cross that boundary and can fail due to permissions, resource limits, unavailable devices, or interruption. Distinguish process IDs, thread IDs, handles, file descriptors, and sockets.

## Processes and threads

A process has an address space and resources; threads share process memory. Context switches have cost. Scheduling policies balance fairness, latency, throughput, and priority. Threads require synchronization around shared mutable state. Process isolation reduces accidental memory sharing but IPC introduces serialization and failure handling. Avoid unbounded thread/process creation; use bounded pools and queues.

## Filesystems

Filesystems map names to metadata and data blocks. Understand paths, current working directory, permissions, ownership, links, mount points, case sensitivity, atomic rename, durability, and symlink attacks. Validate paths lexically and after resolution, reject unexpected links, avoid time-of-check/time-of-use assumptions, and use atomic writes where supported. File deletion and recursive operations require especially careful boundaries.

## Memory management

Virtual memory provides address translation and process isolation. Page faults may be minor or require disk I/O. Stack exhaustion, heap fragmentation, leaks, use-after-free, double-free, buffer overflows, and data races are common failure classes. Bounds checks, safe languages, sanitizers, static analysis, fuzzing, and ownership systems reduce risk. Resource budgets should include memory, CPU, disk, processes, file handles, and execution time.

## IPC and synchronization

IPC includes pipes, sockets, shared memory, signals, message queues, RPC, and OS-specific mechanisms. Shared memory is fast but requires synchronization and lifecycle control. Mutexes, read/write locks, semaphores, condition variables, atomics, barriers, and channels provide different guarantees. Define lock ordering, timeouts, cancellation, and shutdown behavior. Avoid calling arbitrary callbacks while holding critical locks.

## Network fundamentals

Networks move packets through layers. Link layer handles local media; IP routes packets; TCP provides ordered reliable byte streams; UDP provides datagrams without built-in delivery/ordering guarantees; QUIC provides transport features over UDP; DNS maps names to records; TLS protects transport confidentiality/integrity and authenticates peers when configured correctly. HTTP defines application semantics; HTTP/1.1, HTTP/2, and HTTP/3 differ in framing and transport. Firewalls, NAT, proxies, load balancers, and CDNs affect paths.

## TCP/IP practical issues

A successful DNS lookup does not prove service reachability. A connection does not prove an application request will succeed. Model DNS, connection, TLS, authentication, request validation, server processing, and response parsing separately. Handle timeouts, resets, partial reads/writes, retries, congestion, packet loss, proxies, and rate limits. Use exponential backoff with jitter and bounded retry budgets. Never retry non-idempotent writes blindly.

## HTTP and APIs

Use correct methods, status codes, headers, content types, cache controls, and idempotency rules. Validate redirect behavior, origin policy, CORS, cookies, authentication, CSRF, and request size. CORS is a browser access-control mechanism, not server authentication. Treat URLs as potentially hostile; prevent server-side request forgery by validating destinations, resolving IPs carefully, blocking private/link-local/loopback ranges when appropriate, and controlling redirects.

## Security boundaries

Least privilege, user separation, capability restrictions, sandboxing, seccomp-like policies, namespaces, containers, and virtualization provide layers. A container is not automatically a strong security boundary. Test untrusted projects with network disabled, minimal mounts, non-root users, low privileges, resource limits, read-only roots, and disposable copies. Avoid executing user code on the host.

## Operational reliability

Use explicit timeouts on network and filesystem operations where feasible. Bound buffers and queues. Distinguish transient from permanent errors. Provide graceful shutdown, cleanup, cancellation, and recovery. Monitor latency, error rates, saturation, and resource exhaustion. Do not interpret an interface or default route as proof of Internet connectivity.
