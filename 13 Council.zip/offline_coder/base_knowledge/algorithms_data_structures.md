# Algorithms and data structures

## Core structures

Arrays and dynamic arrays provide indexed access and locality. Linked lists trade locality for cheap relinking when node references are already available. Stacks and queues model last-in-first-out and first-in-first-out work. Hash maps provide expected constant-time lookup under suitable hashing assumptions, while balanced search trees provide ordered operations with logarithmic height. Heaps support priority queues; tries support prefix lookup; graphs model relationships and paths; disjoint-set union structures maintain connected components.

## Algorithm design

Choose algorithms from the problem's required semantics, constraints, and data distribution. Common techniques include sorting, binary search, two pointers, sliding windows, divide-and-conquer, greedy choice, dynamic programming, backtracking, branch-and-bound, graph traversal, shortest paths, minimum spanning trees, and randomized algorithms. Prove preconditions and invariants; an attractive complexity bound is irrelevant if the algorithm solves a different problem.

## Complexity and trade-offs

Analyze time and space in terms of input size and state assumptions. Distinguish worst-case, average-case, expected, amortized, and output-sensitive bounds. Big-O is an asymptotic upper-bound notation, not a benchmark measurement. Constant factors, allocations, cache behavior, I/O, data shape, and concurrency can dominate real workloads. Measure representative workloads as well as reasoning about complexity.

## Correctness habits

Define input domains, output contracts, mutation behavior, stability, and error handling. Use loop invariants, induction, ranking functions, and adversarial examples. Test empty and singleton inputs, duplicates, sorted and reverse-sorted data, extreme magnitudes, invalid values, and large cases. For randomized algorithms, use fixed seeds in reproducibility tests and test distributions without assuming one run proves quality.

## Selection guide

Prefer the simplest structure that meets required operations and scale. Ordered iteration may need a tree or sorting; fast membership may suit a set; frequent range queries may suit a segment tree or Fenwick tree; graph connectivity may suit disjoint-set union. State complexity and trade-offs in terms users can verify. Do not claim a data structure is constant-time without naming the assumptions and operation.
