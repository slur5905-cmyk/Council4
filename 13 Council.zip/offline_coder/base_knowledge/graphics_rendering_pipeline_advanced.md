# Advanced Graphics, Rendering, and GPU Programming

## Graphics pipeline
A real-time rendering pipeline typically includes application updates, command submission, vertex processing, primitive assembly, clipping, rasterization, fragment/pixel processing, depth/stencil operations, blending, and presentation. Modern APIs expose explicit resources, command buffers, synchronization, descriptors, and render passes or equivalent concepts. Resource lifetime and synchronization are major sources of GPU bugs.

## Coordinate systems and mathematics
Understand model, world, view, clip, normalized-device, and screen spaces. Matrix multiplication order, handedness, coordinate conventions, depth ranges, and projection types vary by engine/API. Use consistent units. Transform normals with the appropriate inverse-transpose when nonuniform scaling is present. Floating-point precision can become problematic in large worlds; origin rebasing or hierarchical coordinates can help.

## GPU architecture
GPUs execute many parallel work items and are often throughput-oriented. Memory bandwidth, coalescing, occupancy, register pressure, divergence, cache behavior, synchronization, and transfer overhead affect performance. GPU compute may lose to CPU for small workloads because launch and transfer costs dominate. Profile the complete pipeline.

## Rendering techniques
Rasterization, ray tracing, path tracing, deferred rendering, forward rendering, physically based shading, global illumination, shadows, ambient occlusion, temporal antialiasing, and upscaling each have tradeoffs. Correct color spaces, gamma, tone mapping, material models, sampling, and denoising matter. A visually plausible result may still violate physical assumptions.

## Engine architecture
Separate simulation state from rendering state. Use deterministic update steps where gameplay or replay requires them. Handle asset streaming, LOD, occlusion, batching, instancing, culling, and GPU resource cleanup. Profile CPU, GPU, memory, draw calls, shader compilation, and frame-time spikes across target devices.
