# Windows and macOS Platform Internals

## Operating-system interfaces
Windows exposes Win32 and related APIs, handles, services, tokens, registry, job objects, and security descriptors. macOS builds on Darwin and provides Mach, BSD interfaces, launch services, sandboxing, and platform security controls. These are not interchangeable with POSIX even where similar abstractions exist. Use documented platform APIs and isolate platform-specific code behind narrow interfaces.

## Processes and permissions
A process runs with an access token or credentials that determine its authority. Services and background agents have separate lifecycles and identities. File and registry permissions, application sandboxing, code-signing policy, and device permissions must be handled explicitly. Do not assume a desktop application can access all files or continue running indefinitely in the background.

## Packaging and updates
Windows installers, MSIX, macOS app bundles, notarization, code signing, package managers, and auto-updaters each have platform-specific requirements. Verify signatures and update provenance. Use staged rollout and rollback plans. Never place secrets in client bundles or installer scripts.

## Native integration
Windowing, input, accessibility, filesystem notifications, power management, networking, and media APIs vary by OS and version. Use feature detection, supported compatibility matrices, and tests on real target versions. Avoid relying on undocumented behavior that can change without notice.

## Diagnostics
Use platform-native crash reports, event logs, performance profilers, memory tools, and process inspectors. Record OS build, architecture, runtime, and relevant configuration when reporting bugs. A successful compile on one OS does not prove correct behavior on another.
