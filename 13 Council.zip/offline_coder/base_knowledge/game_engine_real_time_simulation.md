# Game engines and real-time simulation architecture

## Main loop and time

A real-time simulation often separates fixed-step state updates from variable-rate rendering. Fixed time steps improve deterministic physics and stability; interpolation smooths rendering between updates. Large frame delays need a bounded catch-up policy to avoid a spiral of death. Pause, speed changes, and save/load should have explicit time semantics.

## Entity and world models

Entity-component systems, object hierarchies, data-oriented designs, and actor models organize world state differently. Spatial partitions such as grids, quadtrees, octrees, and bounding-volume hierarchies reduce neighborhood queries. Choose data layouts for actual access patterns and test correctness at different entity counts.

## Physics and AI

Simulation systems need units, coordinate conventions, integration methods, collision handling, and stable time steps. Behavior trees, finite-state machines, utility systems, planners, and learned policies are alternatives for agent behavior. Keep decision logic distinct from rendering so headless tests can validate the world.

## Performance

Profile update phases, memory allocations, spatial queries, rendering, and GPU uploads. Use level of detail, instancing, batching, culling, and simulation tiers carefully; simplified distant simulation must preserve the intended invariants. Benchmark realistic entity distributions and report quality-performance trade-offs.

## Reproducibility

Deterministic simulation requires controlling random seeds, time steps, iteration order, floating-point behavior, and asynchronous events. Save all state needed for a consistent resume, version save formats, and test migration. Rendering snapshots do not prove simulation correctness.
