# Computer Fundamentals and Architecture

## Information representation

A computer stores and transforms information as states represented by bits. Eight bits form a byte. Unsigned integers represent values modulo a power of two; signed integer representations are architecture/language-defined, with two's complement used by mainstream systems. Integer overflow behavior differs by language and operation: some languages define wraparound, some raise, and some treat overflow as undefined behavior. Never assume without checking the language specification. Floating-point values usually follow IEEE 754 binary formats, with finite precision, rounding, signed zero, infinities, and NaN. Decimal fractions such as 0.1 often have no exact binary representation. Compare floating-point values with a domain-appropriate tolerance, not naive equality, where numerical approximation is expected.

Text is encoded using character sets and encodings. Unicode assigns code points; UTF-8 encodes code points using one to four bytes and is the dominant interchange encoding. A user-visible character may contain multiple code points (combining marks, emoji sequences, grapheme clusters). Do not equate bytes, code points, and displayed characters. Normalize text only when the domain requires it; preserve original input when exact representation matters.

Images are commonly represented as raster pixels or vector instructions. Audio is sampled over time; sample rate and bit depth constrain fidelity. Video combines timed frames and audio, often with compression. Compression can be lossless or lossy. File extensions are hints, not proof of actual format or safety; inspect magic bytes and parse with bounded, trusted libraries.

## Boolean logic and digital circuits

Boolean variables have two logical values. AND, OR, NOT, XOR, implication, equivalence, and truth tables describe combinational logic. De Morgan's laws transform expressions. Combinational circuits depend on current inputs; sequential circuits also depend on stored state, often synchronized by a clock. Adders, multiplexers, decoders, registers, counters, and finite-state machines are building blocks. Setup/hold timing, clock domains, metastability, propagation delay, and fan-out matter in hardware design.

## CPU and instruction execution

A CPU fetches, decodes, and executes machine instructions. Architectures expose instruction sets (for example x86-64, AArch64, RISC-V), registers, memory models, exceptions, and calling conventions. Microarchitectures implement the instruction set using pipelines, branch prediction, speculative execution, caches, execution units, and out-of-order scheduling. Architectural behavior is the contract; microarchitectural behavior affects performance and sometimes side-channel risk. Assembly, compiler output, and profiling can illuminate performance but should not replace measurement.

A process's virtual address space is mapped to physical memory by hardware and the operating system. Pages, page tables, translation lookaside buffers, permissions, copy-on-write, and page faults govern access. A pointer is meaningful only in its address space and lifetime. Memory can be stack-, heap-, static-, or arena-allocated. Ownership, borrowing, garbage collection, reference counting, RAII, and manual allocation are alternative lifetime-management approaches, each with tradeoffs.

## Memory and storage hierarchy

Registers are fastest and smallest; caches (often L1/L2/L3), RAM, SSDs, and remote storage trade latency, throughput, capacity, and persistence. Locality has temporal and spatial forms. Cache lines, false sharing, alignment, NUMA locality, paging, memory bandwidth, and allocation patterns influence performance. RAM is volatile; persistent storage survives power loss subject to durability guarantees. Storage controllers, write caches, filesystem journaling, SSD wear leveling, and flush semantics matter for durability.

## I/O and buses

Devices communicate through memory-mapped I/O, ports, interrupts, DMA, and buses such as PCIe, USB, I2C, SPI, UART, and CAN. Drivers translate operating-system interfaces into device operations. Interrupt handlers should do minimal work; deferred work handles longer tasks. DMA reduces CPU copying but requires careful cache coherency and buffer ownership. Device permissions and driver boundaries are security-sensitive.

## CPU, GPU, accelerators

CPUs optimize for flexible low-latency general execution; GPUs use many parallel execution lanes and high memory bandwidth for throughput workloads. GPUs are effective when work is sufficiently parallel and data movement does not dominate. SIMD/vector instructions process multiple values per instruction. TPUs/NPUs and FPGAs target specialized workloads. Benchmark end-to-end, including transfers, compilation, warm-up, and memory use. A bigger accelerator or model is not automatically faster or better.

## Performance and scaling

Use algorithmic complexity to reason about growth, then profile real workloads. Latency and throughput are different. Amdahl's law limits speedup when some work remains serial; Gustafson's law considers scaling problem size. Little's law relates concurrency, throughput, and latency in stable systems. Queueing can create nonlinear latency increases near saturation. Measure CPU, memory, I/O, network, lock contention, cache misses, allocations, and tail latency. Optimize a measured bottleneck, preserve correctness, and remeasure.

## Boot, firmware, and virtualization

Boot firmware initializes hardware and selects a boot device, then a bootloader loads an operating system kernel. Secure Boot verifies trusted boot components where configured. Firmware is persistent low-level software and can brick devices if updated incorrectly. Virtual machines emulate or virtualize hardware boundaries; containers share a host kernel while isolating processes and resources. Sandboxes provide narrower capabilities, but isolation strength depends on kernel, configuration, runtime, and threat model.

## Computer organization checklist

- Identify architecture, OS, ABI, word size, byte order, and runtime.
- Know which resources are scarce: CPU, memory, VRAM, bandwidth, storage, file descriptors, threads, or power.
- Check alignment, bounds, lifetime, concurrency, and error handling at binary boundaries.
- Separate measured performance from estimates and theoretical limits.
- Record platform-specific assumptions and validate on target hardware.
