# Computer Architecture, Instruction Sets, and Memory Hierarchies

## Processor architecture
A CPU executes instructions described by an instruction-set architecture (ISA). Microarchitecture determines how a particular implementation executes them: pipelines, branch prediction, out-of-order execution, register renaming, caches, execution units, and speculative behavior. Two processors implementing the same ISA can have different performance and power characteristics. ISA compatibility does not guarantee identical timing or side-channel behavior.

## Memory hierarchy
Registers, L1/L2/L3 caches, RAM, persistent storage, and remote memory have different latency, bandwidth, capacity, and persistence. Cache lines, locality, prefetching, false sharing, TLBs, page tables, NUMA, and cache coherence affect performance. Sequential access may outperform random access even when the byte count is equal. Large working sets can cause cache misses and paging. Measure on target hardware.

## Parallel computing
SIMD executes one instruction over multiple data elements; GPUs execute many threads or lanes under their execution model; multicore CPUs use shared-memory parallelism; distributed systems communicate over networks. Parallel work introduces synchronization, communication, divergence, load balance, and data-movement costs. Amdahl's law limits speedup from serial fractions; memory bandwidth can dominate arithmetic throughput.

## I/O and persistence
DMA, interrupts, polling, memory-mapped I/O, storage queues, write caches, and flush semantics affect how data moves. Volatile memory loses state when power is removed; persistent memory and storage devices have their own durability guarantees. Atomic rename is not the same as durable commit. Understand filesystem and device flush behavior for critical writes.

## Hardware-aware optimization
Profile before using low-level intrinsics or assembly. Benchmark representative workloads with warmups, multiple trials, CPU affinity or load awareness where appropriate, and variance reporting. Record CPU model, architecture, compiler flags, and runtime. Optimize algorithmic complexity and data layout before relying on microarchitectural assumptions that may not transfer to other systems.
