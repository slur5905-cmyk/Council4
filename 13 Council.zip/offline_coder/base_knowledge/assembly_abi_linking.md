# Assembly, ABIs, and linking

## Machine-level model

Assembly languages expose registers, instructions, addressing modes, flags, memory operations, branches, and calling conventions for a particular instruction set architecture. x86-64, AArch64, RISC-V, and other architectures differ. Machine code is target-specific; compiler output and optimization vary by compiler, flags, and target.

## Calling conventions and ABI

An application binary interface defines how functions receive arguments, return values, preserve registers, lay out stack frames, align data, and represent symbols. ABI mismatches can corrupt state even when source-level types appear compatible. Foreign-function interfaces should specify ownership, lifetime, alignment, error representation, and unwind behavior.

## Object files and linking

Compilers commonly emit object files containing machine code, symbols, relocation entries, and metadata. Linkers resolve symbols and relocations into executables or shared libraries. Static and dynamic linking have different deployment, security, and compatibility trade-offs. Symbol visibility, versioning, loader search paths, and position-independent code affect runtime behavior.

## Low-level reliability

Memory safety, integer overflow, alignment, aliasing, undefined behavior, and concurrency become especially important at low level. Use sanitizers and static analysis when available. Inspect disassembly only when needed to answer a concrete performance or correctness question. Do not generalize instruction timing across CPUs; microarchitecture and workload matter.
