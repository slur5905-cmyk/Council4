# Stream Processing, Event-Driven Systems, and Messaging

## Messages and delivery guarantees
Queues decouple producers and consumers. Delivery may be at-most-once, at-least-once, or effectively-once within a carefully defined transactional boundary. “Exactly once” is not a universal end-to-end property; retries, external side effects, and cross-system boundaries complicate it. Consumers should be idempotent and tolerate duplicates where possible.

## Ordering and partitions
Ordering is usually guaranteed only within a defined partition, key, or queue scope. Partition keys affect parallelism and hotspots. Rebalancing can move work between consumers. Sequence numbers, event timestamps, and watermarks help reason about event time, processing time, late arrivals, and out-of-order data.

## Stream processing
Windowing groups events by time or count. Stateful operators need checkpointing, recovery, and retention policies. Backpressure prevents fast producers from overwhelming downstream consumers. State size, skew, serialization, and checkpoint cost affect performance. Reprocessing should be reproducible and should not duplicate irreversible external effects.

## Event sourcing and change data capture
Event sourcing stores domain events as an append-only history and derives projections. It supports auditability but adds schema evolution, replay, projection rebuilding, and eventual consistency complexity. Change data capture streams database changes and requires careful handling of transaction boundaries, deletes, snapshots, and schema changes.

## Operations
Define dead-letter handling, retry limits, poison-message policy, retention, consumer lag monitoring, schema compatibility, and replay controls. Protect sensitive payloads and validate message origin. Avoid unbounded retries and unbounded queues, which can turn a short outage into a larger failure.
