# Real-Time and Safety-Critical Software Engineering

## Real-time properties
Real-time correctness includes meeting timing deadlines, not simply producing the right result eventually. Hard real-time systems treat missed deadlines as failures; soft real-time systems tolerate some lateness with degraded quality. Analyze worst-case execution time, interrupt latency, scheduling, resource contention, and I/O behavior rather than relying only on average benchmarks.

## Scheduling and determinism
Periodic, sporadic, and aperiodic tasks have different timing patterns. Rate-monotonic and earliest-deadline-first are examples of scheduling approaches under specific assumptions. Priority inversion can delay a high-priority task; priority inheritance or ceiling protocols may help. Avoid unbounded queues, unbounded retries, and nondeterministic operations in critical paths.

## Safety cases
Safety-critical development uses hazard analysis, requirements traceability, fault containment, independent verification, configuration control, and documented assurance arguments. Failure mode and effects analysis, fault trees, and hazard logs help reason about risk. A test passing does not replace required certification or independent assessment.

## Defensive design
Use watchdogs, safe states, redundant sensing where justified, plausibility checks, bounds checking, explicit state machines, and graceful degradation. Define what happens when sensors, networks, clocks, storage, or power fail. Design recovery to avoid unsafe oscillation or repeated fault activation.

## Domain standards
Aviation, automotive, medical, industrial, and other regulated domains use different standards and assurance processes. Identify the applicable jurisdiction, product class, hazard level, and current standard edition. Do not present generic guidance as compliance or certification advice.
