# Frontend engineering, accessibility, and user experience

## Browser platform

The browser coordinates parsing, DOM construction, CSS style calculation, layout, painting, compositing, JavaScript execution, storage, networking, and accessibility interfaces. Long tasks and forced synchronous layout harm responsiveness. Use semantic HTML, progressive enhancement, and browser APIs according to their compatibility and security behavior.

## UI architecture

Separate domain state, view state, and derived state. Make loading, empty, success, partial, and error states explicit. Keep forms accessible, validate on both client and server, and make asynchronous actions cancellable or idempotent where appropriate. Avoid global mutable state unless ownership and lifecycle are clear. Treat untrusted text as text, not executable HTML.

## Accessibility

Use semantic landmarks, headings, labels, buttons, links, keyboard support, visible focus, sensible focus order, and sufficient contrast. Provide text alternatives for meaningful images and captions/transcripts for media where appropriate. Dynamic updates should be announced thoughtfully without overwhelming assistive technology. Do not use color alone to communicate status. Zoom, reduced motion, and high-contrast settings need consideration.

## Responsive behavior

Design for content and constraints, not named devices alone. Test small and large widths, touch targets, orientation, text scaling, overflow, and virtual keyboards. CSS pixels differ from physical pixels. Responsive screenshots can detect changes but cannot establish accessibility or correct behavior on every real device.

## Performance and security

Measure real user experience. Optimize critical rendering paths, images, fonts, bundles, and caching while preserving correctness. Use a strict Content Security Policy and safe output encoding. Avoid unsafe HTML insertion and overly broad cross-origin permissions. Browser storage is not a safe place for long-lived high-value secrets. Verify current platform APIs and browser support for target versions.
