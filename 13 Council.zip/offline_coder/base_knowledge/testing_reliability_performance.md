# Testing, Reliability, Observability, and Performance Engineering

## Test levels

- Unit tests isolate a function/component and run quickly.
- Component tests verify a module with controlled boundaries.
- Integration tests verify real collaboration among components or services.
- Contract tests verify agreed API/schema behavior across producers and consumers.
- End-to-end tests exercise user journeys through a realistic application.
- Acceptance tests demonstrate explicit user requirements.
- Performance, load, stress, soak, resilience, accessibility, security, migration, and recovery tests address distinct quality attributes.

A large number of passing tests is not proof of correctness if they test the wrong behavior. Tie every acceptance criterion to evidence. Tests should fail when the defect is present and pass when corrected.

## Test design

Use arrange-act-assert, descriptive names, deterministic fixtures, isolated state, cleanup, and focused assertions. Cover normal, boundary, invalid, failure, concurrency, and recovery paths. Property-based tests check general invariants over generated inputs. Fuzzing explores malformed inputs and edge cases. Mutation testing estimates whether tests detect injected faults. Golden/snapshot tests are useful for stable outputs but can preserve bugs and require review.

Use test doubles carefully. Mocks can hide integration defects; prefer real implementations where affordable. Make time, randomness, network, filesystem, and scheduling controllable. Test retries and timeouts without unbounded sleeps. Ensure tests do not depend on order or shared global state.

## Evidence and result states

Every check should identify target revision/hash, command/tool version, environment, duration, exit code, and bounded output. Distinguish PASSED, FAILED, SKIPPED, UNAVAILABLE, NOT_APPLICABLE, and NO_TESTS. A skipped check is not a pass. If only syntax passed, do not claim behavior passed. Test output is untrusted and should not authorize writes. Rerun affected regression tests after a candidate changes; old evidence cannot approve a new hash.

## Continuous integration

Use reproducible build environments, pinned actions/dependencies, least-privilege CI tokens, cache boundaries, artifact retention, and explicit matrix coverage. Fail fast on syntax/type/lint where appropriate, but retain enough reporting for diagnosis. Separate required checks from advisory checks. Validate CI configuration itself and protect release workflows.

## Reliability engineering

Define service-level indicators and objectives (SLIs/SLOs) for latency, availability, correctness, and freshness. Error budgets guide release risk. Avoid treating an SLO as a legal guarantee. Identify single points of failure, capacity limits, dependency outages, data corruption, and operator mistakes. Practice graceful degradation and recovery.

## Failure handling

Use timeouts, bounded retries with jitter, circuit breakers, bulkheads, backpressure, queue limits, idempotency, and dead-letter handling. Avoid retry storms. Distinguish transient, permanent, and ambiguous outcomes. Make shutdown and cancellation explicit. Clean up resources deterministically. Keep a safe fallback that does not silently corrupt state.

## Observability

Logs describe events; metrics quantify behavior; traces connect operations across boundaries. Use structured logs, correlation IDs, stable error categories, latency histograms, and redaction. Avoid logging secrets and high-cardinality personal data. Monitoring should cover golden signals: latency, traffic, errors, and saturation. Alerts need actionable thresholds and ownership. Observability is not surveillance; collect only what is needed.

## Performance engineering

Start with a workload model and measurable target. Profile CPU, allocations, memory, garbage collection, database queries, network, rendering, lock contention, and I/O. Distinguish cold start from steady state. Report distributions and p50/p90/p95/p99, not just averages. Benchmark representative inputs, warm-up, versions, and hardware. Avoid microbenchmarks that do not predict end-to-end performance.

## Capacity and scaling

Load tests measure expected traffic; stress tests find breaking points; soak tests expose leaks; spike tests assess sudden changes. Model throughput, concurrency, queue length, and tail latency. Scale vertically or horizontally based on bottlenecks and state ownership. Sharding, caching, replicas, and async work add complexity. Resource limits should be explicit; when capacity is unknown, degrade gracefully rather than claiming infinite scale.

## Recovery and data integrity

Back up, restore, validate checksums, test migrations, and practice disaster recovery. Replication is not backup. Use write-ahead logs or equivalent durability mechanisms. Reconcile partial work after crashes. Keep rollback and forward-fix strategies. Test interrupted writes and concurrent edits.


### Project-owned tests are diagnostic, not independent proof

A project may control its own test files, import hooks, test manifests, and test output. Those tests can exit early, forge success markers, or simply assert trivial conditions. Execute them only in a disposable sandbox and label their result as untrusted project evidence. Do not use them to select a winning candidate or authorize unattended writes. Candidate eligibility requires a separate host-owned acceptance suite and an attestation bound to the exact candidate fingerprint; the current Council intentionally abstains until that channel exists.
