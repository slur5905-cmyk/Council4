# Computer networking: sockets, HTTP, and application transport

Network programming turns application messages into byte streams or packets delivered across systems that may be slow, unavailable, reordered, or malicious. A local method call normally has one execution context and immediate errors; a network call needs deadlines, serialization, authentication, retries, and explicit failure handling.

## Sockets and byte streams

TCP provides a reliable ordered byte stream, not message boundaries. Applications need framing: length prefixes, delimiters with escaping, or a structured streaming format. Reads may return fewer bytes than requested; writes may be partial. Handle interruption, EOF, half-close, backpressure, and connection reset. UDP preserves datagram boundaries but can lose, duplicate, or reorder packets; applications that need reliability must implement suitable mechanisms or use another protocol.

Use nonblocking sockets or asynchronous APIs for many simultaneous connections. Bound pending tasks and buffers. A client must not create unbounded work when a peer is slow. Set connect, read, write, and overall deadlines. Close sockets on every exit path and decide how cancellation affects outstanding operations.

## HTTP behavior

HTTP defines methods, status codes, headers, caching, content negotiation, authentication schemes, and intermediary behavior. GET should be safe; PUT and DELETE are defined as idempotent in HTTP semantics, though application implementations must honor the contract. POST is not automatically safe to retry. Use conditional requests and validators when useful. Distinguish client errors, server errors, rate limits, and gateway failures. Redirects can change destination and method behavior; security-sensitive clients should constrain where credentials may be sent.

Proxies, load balancers, caches, gateways, and CDNs can alter routing and timing. Trust boundaries exist between each hop. Forwarded identity headers should be accepted only from trusted proxies. Cache keys must include relevant authorization and representation dimensions; otherwise private data can leak between users.

## TLS and identity

TLS provides an encrypted authenticated channel when certificate verification, hostname checks, trust roots, and protocol configuration are correct. Encryption without identity verification is vulnerable to interception. Do not disable certificate validation to fix a local development issue. Use modern maintained TLS libraries, supported cipher suites, and certificate rotation. Mutual TLS can authenticate clients as well as servers but requires careful certificate lifecycle and authorization mapping.

## DNS and naming

DNS maps names to records with caching and time-to-live behavior. Resolution can return multiple addresses, fail transiently, or differ across networks. DNS is not an identity proof. Applications need connection timeout and address selection policies. Private-address restrictions and rebinding protections matter when a server fetches user-supplied URLs.

## Resilience and diagnostics

Use request IDs, structured logs, trace propagation, and metrics for connection failures, DNS time, handshake time, request latency, response size, and retry counts. Retry only idempotent or safely deduplicated operations, with bounded exponential backoff and jitter. Circuit breakers and bulkheads can protect local capacity. Avoid retrying a large request indefinitely or retrying all error codes.

## Security and testing

Validate destination hosts and resolved addresses when making server-side requests; re-check redirects and DNS resolution to reduce SSRF risk. Avoid embedding credentials in URLs. Limit response size, content type, decompression, and timeout. Test fragmentation, coalescing, slow peers, malformed lengths, dropped connections, invalid certificates, DNS failures, large headers, and proxy behavior. Network correctness is not established by one successful localhost request.
