# Cloud-Native Systems, Site Reliability, and Observability

## Reliability objectives
Availability is a user-visible property, not merely process uptime. Define service-level indicators (SLIs), service-level objectives (SLOs), and error budgets. Metrics should include request success, latency percentiles, traffic, saturation, queue depth, and resource exhaustion. Averages hide tail latency. Alert on actionable symptoms and user impact rather than every internal fluctuation.

## Resilience patterns
Use bounded retries with jitter and deadlines, circuit breakers, bulkheads, queue limits, admission control, graceful degradation, and health checks that reflect readiness rather than just process existence. A retry storm can amplify an outage. Liveness and readiness are distinct. A system should fail safely when dependencies are unavailable and should not report success before durable work is committed.

## Deployment and rollout
Immutable artifacts, environment separation, infrastructure as code, and repeatable pipelines reduce drift. Rolling, blue-green, and canary deployments have different capacity and rollback properties. Database migrations and message schema changes must support overlap between versions. Rollback is not always possible after irreversible data changes; plan forward repair and recovery.

## Containers and orchestration
Containers share the host kernel and are not equivalent to virtual machines. Image provenance, base-image freshness, non-root users, read-only filesystems, dropped capabilities, resource requests/limits, seccomp, and network policy matter. Orchestrators add scheduling, health probes, service discovery, secrets management, and rollout control, but also increase operational complexity.

## Telemetry and incident learning
Logs are event records; metrics aggregate numerical behavior; traces connect operations across boundaries. Correlation IDs should not contain secrets or personal data. Sample traces carefully and bound log cardinality. Incident response should preserve evidence, communicate impact, mitigate safely, and produce blameless learning actions. Test backups, restore, failover, and disaster recovery; an untested procedure is an assumption.
