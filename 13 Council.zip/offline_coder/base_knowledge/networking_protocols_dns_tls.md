# Computer networking and application protocols

## Layered concepts

Networking spans link, network, transport, and application layers. IP provides addressing and routing; TCP provides an ordered byte stream with congestion and flow control; UDP provides datagrams without TCP's delivery guarantees. QUIC builds multiplexed streams over UDP. DNS maps names to records and has caching, TTL, delegation, and failure modes. NAT, firewalls, proxies, and load balancers affect reachability and source identity.

## Protocol correctness

An application protocol needs explicit framing, encoding, versioning, timeouts, error semantics, limits, and compatibility rules. TCP does not preserve message boundaries. HTTP defines request/response semantics, methods, status codes, caching, redirects, content negotiation, and authentication conventions. WebSocket, SSE, and streaming RPC have distinct connection and lifecycle behavior. Validate all untrusted lengths and parsed fields.

## Security and identity

TLS provides channel confidentiality and integrity when configured and validated correctly. Certificate chain validation, hostname verification, trust stores, expiry, and key rotation matter. Do not disable certificate checks to silence errors. DNS and routing are not proof of server identity. Avoid leaking tokens or personal data in URLs, logs, telemetry, and exception messages.

## Reliability

Networks fail partially: latency, loss, duplication, reordering, partitions, DNS failures, and server overload are normal conditions. Use bounded timeouts, retry only when semantics permit, exponential backoff with jitter, Retry-After support, circuit breakers where justified, and idempotency keys for operations that must not duplicate effects. Retries can amplify outages, so impose budgets and honor cancellation.

## Testing and diagnostics

Test protocol boundaries, slow responses, malformed frames, disconnects, large payloads, duplicate messages, and clock skew. Distinguish connect, TLS, request, first-byte, and total deadlines. Use packet capture only on networks and systems you are authorized to inspect. Prefer synthetic local test servers; never assume a successful ping proves an application endpoint works.
