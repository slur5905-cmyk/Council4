# Network protocol testing and fault injection

## Protocol conformance

Test requests and responses against a documented schema and state machine. Include invalid sequencing, duplicate messages, partial frames, malformed encodings, missing headers, unknown fields, and version negotiation. Fuzz parsers and state transitions in a bounded test target.

## Network fault simulation

Introduce controlled latency, packet loss, reordering, disconnection, DNS errors, rate limiting, slow streams, and server restarts in a local test environment. Verify timeout propagation, retry budgets, cancellation, duplicate suppression, and recovery. Do not test against public systems without authorization.

## Determinism

Use local fixtures, fixed clock sources, deterministic fake servers, and recorded message transcripts. Avoid relying solely on sleeps. Separate network protocol correctness from internet reachability. Test TLS trust and certificate expiry with local test certificates.

## Performance

Measure latency distributions, throughput, concurrency, memory, connection reuse, queue depth, and behavior under overload. A single happy-path request cannot establish capacity. Use representative payload sizes and concurrency patterns, and report environment details.

## Result interpretation

A fault-injection test demonstrates only the specific fault and code path exercised. Record seed, configuration, environment, and exact binary/source hashes. Failures may reveal infrastructure assumptions rather than code defects; isolate the trigger before making a fix.
