# IP Routing, Wireless Networks, and Internet Routing

## IP and routing
IP provides addressing and packet forwarding across networks. Routers consult forwarding information derived from routing protocols and local policy. Subnets, prefixes, gateways, route metrics, NAT, and firewalls affect reachability. A host's default route is not the same as an application's DNS or proxy configuration.

## Transport and congestion
TCP provides an ordered reliable byte stream with congestion control and flow control. UDP provides datagrams without those guarantees; applications may add reliability and ordering. QUIC integrates transport mechanisms over UDP and is used by HTTP/3. Packet loss, path MTU, retransmissions, congestion windows, and connection setup affect latency and throughput.

## Routing protocols
Interior gateway protocols exchange routes within an autonomous system; BGP exchanges reachability between autonomous systems using policy. Route selection is not simply shortest geographic distance. Misconfiguration, route leaks, hijacks, and filtering errors can disrupt connectivity. Network policy and provider configuration are operational concerns, not something a desktop application should attempt to manipulate.

## Wireless systems
Wi-Fi performance depends on channel width, interference, signal strength, roaming, access-point load, security mode, and client implementation. Bluetooth targets different ranges and use cases. Cellular networks add mobility, radio scheduling, carrier policy, and variable latency. Test on realistic networks and tolerate intermittent connectivity.

## Diagnostics
Use DNS lookup, route inspection, socket statistics, packet captures, and application telemetry to isolate layers. Capture only authorized traffic and minimize personal data. A successful ping does not prove an application's TLS, authentication, proxy, or service dependency works.
