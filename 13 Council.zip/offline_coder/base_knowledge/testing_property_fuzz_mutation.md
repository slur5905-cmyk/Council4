# Testing, property-based testing, fuzzing, and mutation testing

## Test levels

Unit tests check small contracts; integration tests check boundaries between components; end-to-end tests check a user-visible path; system tests exercise a deployed configuration. Contract tests check compatibility between producers and consumers. Choose tests based on risk and failure mode, not on a single coverage percentage.

## Test design

For each behavior, cover normal, boundary, invalid, failure, and recovery cases. Use deterministic fixtures and dependency injection for clocks, random seeds, network clients, and storage. Avoid tests that merely repeat implementation details. Assert externally meaningful outcomes and preserve regression tests for discovered defects.

## Property-based and metamorphic tests

Property-based testing generates many inputs and checks invariants such as round-trip behavior, monotonicity, idempotency, bounds, or equivalence. Shrinking can reduce failures to simpler examples. Metamorphic tests compare related inputs when a direct oracle is difficult. State assumptions so a property does not accidentally encode a false universal claim.

## Fuzzing

Fuzzers explore unexpected inputs and execution paths. Use a bounded, authorized target, reproducible corpus, resource limits, and triage workflow. Coverage-guided fuzzing can find issues but does not prove absence. Avoid fuzzing production services or third-party targets without permission.

## Mutation testing and coverage

Mutation testing changes code in small ways to see whether tests detect meaningful faults. Surviving mutations indicate weak or irrelevant tests, but some mutations are equivalent. Line coverage measures execution, not assertion quality. Keep independent verification separate from the model's own claims, and record exact source and test hashes for repeatability.
