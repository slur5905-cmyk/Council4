# SQL, relational data, and transactions

## Relational foundations

A relational database models data as relations with attributes and constraints. Primary keys identify rows; foreign keys enforce references; unique, check, and not-null constraints express invariants. Normalization reduces update anomalies, while denormalization may be justified for read patterns or performance. Use explicit schema migrations and preserve compatibility across deployment stages.

## Query semantics

SQL operates on sets or multisets and uses three-valued logic for NULL. Joins, grouping, aggregation, window functions, subqueries, and common table expressions have precise semantics. Avoid assuming row order without ORDER BY. Parameterize values rather than concatenating user input. Dynamic identifiers need allowlists because parameters generally represent values, not SQL syntax.

## Transactions

ACID describes atomicity, consistency, isolation, and durability. Isolation levels differ in anomalies they prevent; serializable behavior may require retries. Multi-statement workflows need explicit transaction boundaries and rollback handling. Deadlocks and serialization failures are expected operational outcomes that applications should handle safely.

## Indexes and query plans

B-tree, hash, bitmap, inverted, spatial, and composite indexes serve different query shapes. Indexes consume storage and slow writes. Query planners estimate selectivity and choose scans, joins, and access paths from statistics. Inspect execution plans and measure representative data; a query that is fast on a tiny fixture may degrade at production scale.

## Operational safety

Use backups, restore tests, migrations, retention policies, least-privilege accounts, encryption, and monitoring. Replication is not backup. Avoid destructive schema changes without staged rollouts and rollback plans. Treat logs and query traces as potentially sensitive. Database engines differ; verify syntax and transaction semantics against the actual engine and version.
