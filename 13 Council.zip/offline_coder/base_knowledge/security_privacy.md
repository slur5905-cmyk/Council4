# Security, Privacy, and Secure Software Development

## Security principles

Use least privilege, defense in depth, secure defaults, complete mediation, fail-safe behavior, economy of mechanism, separation of duties, and explicit trust boundaries. Security is a system property; a prompt, framework, test, or single library cannot guarantee it. Model threats based on assets, actors, capabilities, exposure, impact, and mitigations.

## Threat modeling

Map data flows, entry points, identities, trust zones, stores, and external dependencies. Consider spoofing, tampering, repudiation, information disclosure, denial of service, and elevation of privilege (STRIDE is one useful framework). Identify misuse cases and abuse paths. Rate likelihood and impact, but do not treat a numeric risk score as objective truth. Revisit threats when architecture or dependencies change.

## Input and output safety

Validate data at trust boundaries using allowlists, size limits, canonicalization, and domain-specific constraints. Escaping is context-specific. Use parameterized SQL, safe process APIs with argument arrays, safe templating, and strict path handling. Reject path traversal, symlink tricks, archive bombs, decompression bombs, malformed encodings, and unexpectedly large payloads. Parsing is safer than regex for structured formats. Avoid unsafe deserialization and dynamic code execution.

## Authentication and authorization

Authentication establishes identity; authorization checks whether that identity can perform an action on a resource. Use established protocols and libraries. Prefer short-lived scoped tokens, secure password hashing (Argon2id, scrypt, or bcrypt with appropriate parameters), MFA where appropriate, and secure session rotation/revocation. Apply object-level authorization server-side. Avoid designing custom cryptography or authentication protocols.

## Cryptography concepts

Cryptographic hashes provide fixed-size digests and integrity comparison; password hashing needs deliberately expensive salted algorithms. MACs authenticate messages with a shared secret; digital signatures use private/public key pairs. Symmetric encryption uses shared keys; public-key cryptography supports key exchange and signatures. TLS authenticates and protects transport. Random keys and nonces must come from secure random sources and satisfy algorithm requirements. Key management, rotation, storage, access, and compromise response are as important as algorithms. Do not invent crypto schemes or reuse nonces where prohibited.

## Application security risks

Common risks include injection, broken access control, authentication failures, cryptographic failures, insecure design, security misconfiguration, vulnerable/outdated components, identification/authentication issues, software/data integrity failures, logging/monitoring gaps, and SSRF. Review the current OWASP Top 10/API Security guidance for version-specific detail. Threats change; official current references should be consulted.

## Supply-chain security

Inventory direct and transitive dependencies. Use lockfiles, pinned versions, trusted registries, package provenance/signatures where available, reproducible builds, minimal dependencies, and prompt patching. Generate an SBOM (for example CycloneDX or SPDX). Scan vulnerabilities with suitable tools (for example OSV-Scanner, pip-audit, npm audit, cargo-audit, or ecosystem-specific tools). Scanner output needs triage: assess reachability, exposure, version constraints, exploitability, and compensating controls. Never auto-install a security tool or dependency without an explicit policy.

## Secrets and data protection

Keep credentials out of source, logs, client bundles, screenshots, issue reports, test output, and model prompts. Use secret managers or environment injection with strict access controls. Redact logs but avoid destructive over-redaction of useful diagnostics. Classify personal/sensitive data, minimize collection, encrypt at rest/in transit as appropriate, limit retention, define deletion, and control export. Consider jurisdiction and regulatory requirements without assuming one compliance framework covers all cases.

## Sandboxing and code execution

Treat repository content, package scripts, tests, build configuration, archives, prompts, and generated code as untrusted. Do not execute arbitrary project code on the host. Prefer disposable isolated workers with no network, non-root users, read-only root filesystem, restricted mounts, dropped capabilities, syscall filtering, CPU/memory/process/time limits, output limits, and cleanup. Isolation is defense-in-depth, not proof of security. Never let generated code change the host's permission policy or silently approve its own writes.

## Security testing and response

Use static analysis, dependency scanning, secret scanning, fuzzing, dynamic tests, penetration testing by authorized people, and secure code review. Test rate limits, authZ boundaries, malformed input, error leakage, race conditions, and resource exhaustion. Keep incident logs, patch procedures, backups, restore exercises, and disclosure processes. Do not claim certification from passing a scanner.
