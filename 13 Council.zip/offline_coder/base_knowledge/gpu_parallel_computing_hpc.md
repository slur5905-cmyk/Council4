# GPU programming, parallel computing, and high-performance computing

Parallel computing divides work across multiple execution units. The main challenge is often moving data and coordinating work, not simply increasing arithmetic operations. CPU cores, vector instructions, GPUs, accelerators, and distributed clusters have different execution models and memory hierarchies.

## Parallel decomposition

Identify independent work, shared state, ordering constraints, and reduction operations. Data parallelism applies the same operation to many elements; task parallelism runs different tasks concurrently; pipeline parallelism overlaps stages. Amdahl's law limits speedup when part of a workload is serial. Gustafson's law considers scaling problem size with available processors. More workers can reduce performance through synchronization, scheduling, communication, contention, and cache effects.

## GPU execution

GPUs execute many lightweight threads in groups (warps/wavefronts) on streaming multiprocessors or compute units. Threads often execute in lockstep or groups of lanes; divergence can reduce throughput. Global memory is high-bandwidth but relatively high-latency, while registers and shared/local memory are faster and limited. Coalesced access, occupancy, register pressure, shared-memory use, and kernel launch overhead all matter.

A typical GPU workflow allocates buffers, transfers or maps data, launches kernels, synchronizes when needed, and reads results. Minimize unnecessary host-device transfers. Use streams and asynchronous copies only with correct dependency management. Every buffer must have a clear owner and lifetime; asynchronous work can continue after the caller returns.

## Numerical concerns

Floating-point addition is not associative, so parallel reductions can produce different rounding than serial execution. Reproducibility may require a fixed reduction tree, deterministic algorithms, controlled precision, or tolerance-based validation. Mixed precision can improve speed but needs error analysis. Integer overflow, atomics, race conditions, and nondeterministic scheduling can affect correctness.

## Distributed HPC

Clusters distribute work over nodes connected by interconnects. MPI-style communication, collective operations, domain decomposition, checkpointing, and data locality are central concerns. Communication volume and synchronization can dominate useful compute. Strong scaling reduces runtime for fixed problem size; weak scaling increases problem size with resources. Fault tolerance is important because larger jobs run longer and use more components.

## Profiling workflow

Start with a correct CPU reference and representative input. Profile the whole pipeline, separating compute, allocation, transfers, synchronization, and I/O. Then optimize the measured bottleneck. Compare warm and cold runs, include compilation or JIT startup when relevant, and use statistically meaningful repetitions. Inspect occupancy and memory bandwidth only when the profiler supports it. Avoid optimizing a synthetic kernel while ignoring the application's real data path.

## Portability and validation

Backends such as CUDA, HIP, SYCL, OpenCL, Vulkan compute, Metal, and WebGPU have different capabilities and toolchains. Build explicit capability fallbacks and document tested devices and driver versions. Compare outputs to reference tolerances, test edge dimensions, non-multiple block sizes, empty data, and large values. A kernel that passes on one GPU is not automatically correct on all vendors or architectures.
