# Theory of Computation, Automata, and Decidability

## Models of computation
Finite automata recognize regular languages and are useful for lexical analysis, protocol states, and simple validation. Pushdown automata add a stack and model context-free languages such as nested expressions. Turing machines provide a general model of effective computation. These models describe classes of problems and limitations; they are not interchangeable implementation recipes.

## Grammars and parsing
Regular expressions are appropriate for regular-language recognition, not arbitrary nested syntax. Context-free grammars describe recursive syntax. Parser strategies include recursive descent, Pratt parsing, LL, LR, and parser combinators. Error recovery, ambiguity, precedence, associativity, and source-location tracking are part of a useful parser design. A parser should reject malformed input safely and avoid unbounded recursion or pathological backtracking.

## Decidability and computability
A problem is decidable when an algorithm always halts with a correct yes/no answer. Some well-defined problems are undecidable; no general algorithm can solve every instance. The halting problem is the classic example. Practical static analysis therefore uses restricted models, approximations, heuristics, bounded execution, or sound-but-incomplete checks. Do not promise that a general analyzer can prove arbitrary program behavior.

## Complexity and reductions
A reduction maps instances of one problem to another while preserving the relevant yes/no property. Reductions help compare problem difficulty. Complexity classes describe resource growth under specified machine and input models. NP-complete does not mean impossible or necessarily slow on every real instance; structure and approximation can make useful solutions practical. State the model, input size, and complexity measure when making performance claims.

## Engineering uses
Use finite-state machines for protocol and UI workflows, grammars for parsers, and model checking for bounded state spaces. Define states, transitions, invariants, and invalid transitions explicitly. When full proofs are infeasible, combine property tests, fuzzing, static analysis, and runtime monitoring, documenting what each method can and cannot establish.
