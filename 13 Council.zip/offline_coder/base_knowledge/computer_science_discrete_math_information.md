# Discrete mathematics and information theory for computing

## Logic and proofs

Propositional and predicate logic support specifications, invariants, query reasoning, and program verification. Proof techniques include direct proof, contradiction, induction, and construction. Quantifiers and assumptions matter: a proof that silently narrows the input domain does not establish the advertised contract.

## Sets, relations, and graphs

Sets model collections; relations model associations and orderings; functions model mappings. Equivalence relations, partial orders, and graph properties underpin databases, dependency analysis, scheduling, and networks. Graph algorithms operate on explicit assumptions about direction, weights, cycles, and connectivity.

## Combinatorics and probability

Counting, permutations, combinations, conditional probability, independence, expected value, and distributions appear in algorithm analysis, randomized systems, testing, and reliability. Do not confuse correlation with causation or a sample estimate with certainty. Report sample sizes and confidence intervals where relevant.

## Information theory

Entropy measures uncertainty under a probability distribution. Compression exploits redundancy; lossless and lossy approaches have different guarantees. Checksums detect accidental changes but do not authenticate data. Cryptographic hashes provide stronger collision resistance assumptions; message authentication and digital signatures address integrity and authenticity under key assumptions.

## Numerical care

Floating-point arithmetic is finite-precision and non-associative. Rounding, overflow, underflow, cancellation, and conditioning affect results. Exact integer or rational reasoning may be needed for some domains. Define tolerances and numerical error budgets rather than comparing floats blindly.
