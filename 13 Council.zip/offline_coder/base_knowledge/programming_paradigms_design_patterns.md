# Programming Paradigms, Design Patterns, and Software Architecture

## Paradigms
Imperative code describes steps and state changes; declarative code describes desired outcomes or constraints. Functional programming emphasizes pure functions, immutable data, and composition. Object-oriented designs organize state and behavior around objects and interfaces. Event-driven systems react to messages and state changes. Dataflow systems emphasize dependencies between values or computations. Most practical systems combine paradigms.

## Design patterns
Patterns such as Strategy, Adapter, Decorator, Observer, Command, Factory, Builder, Repository, and State describe recurring design structures. They are vocabulary, not mandatory templates. Apply a pattern when it simplifies a real problem; unnecessary indirection can make code harder to understand. Dependency injection improves substitution and testability when lifetimes and ownership are explicit.

## Architecture styles
Layered, hexagonal/ports-and-adapters, clean, modular monolith, microservices, event-driven, actor, plugin, and serverless architectures organize boundaries differently. Microservices introduce network failure, distributed data, deployment coordination, observability, and operational costs; they are not automatically more scalable. A modular monolith can preserve clear boundaries without distributed complexity.

## Domain modeling
Identify actors, entities, value objects, aggregates, invariants, commands, events, and bounded contexts. Keep business rules out of transport and persistence layers where practical. Model state transitions explicitly. Avoid anemic abstractions that merely mirror database tables when domain behavior is complex; also avoid speculative abstraction for hypothetical future needs.

## Decision quality
Record important architectural decisions, constraints, alternatives, consequences, and conditions that would justify revisiting them. Prefer reversible decisions when uncertainty is high. Use measurable nonfunctional requirements such as latency, throughput, uptime, privacy, cost, and maintainability. Evaluate the simplest design that satisfies current requirements and a realistic evolution path.
