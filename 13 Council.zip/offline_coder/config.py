"""User-owned settings. These are stored outside any project workspace."""
from __future__ import annotations
import json
import os
import math
from pathlib import Path
from .safety import atomic_write_text

APP_DIR = Path.home() / ".offline_coding_council"
SETTINGS_PATH = APP_DIR / "settings.json"

DEFAULT_SETTINGS = {
    "model_path": "",
    "model_backend": "gguf",
    "local_server_url": "http://127.0.0.1:8080/v1",
    "local_server_model": "",
    "local_server_role_models": {},
    "role_model_paths": {},
    "workspace_path": str(Path.home() / "OfflineCodingWorkspace"),
    "n_ctx": 16384,
    "n_threads": max(1, (os.cpu_count() or 4) - 1),
    "n_gpu_layers": 0,
    "max_tokens": 4096,
    "model_timeout_seconds": 600,
    "temperature": 0.2,
    "review_rounds": 1,
    "allow_self_edit": False,
    "auto_apply_approved": False,
    "autonomous_web_research": False,
    "max_context_chars": 12000,
    "memory_max_bytes": 134217728,
    "advanced_features_enabled": False,
    # Parallelize peer calls only when distinct role-specific model instances
    # are configured. The router serializes calls that share one model object.
    "max_peer_workers": 2,
    # GGUF models are loaded on demand; default one resident model minimizes RAM use.
    "max_loaded_peer_models": 1,
    "peer_dialogue_enabled": True,
    "peer_dialogue_max_interactions": 4,
    "component_collaboration_enabled": True,
}


def _validated_settings(values: dict) -> dict:
    """Merge only type-safe, bounded settings into defaults.

    Settings are user-editable local data. Malformed JSON values must not crash
    startup or feed arbitrary types/ranges into model and workspace constructors.
    """
    settings = DEFAULT_SETTINGS.copy()
    if not isinstance(values, dict):
        return settings

    string_keys = {"model_path", "model_backend", "local_server_url", "local_server_model", "workspace_path"}
    for map_key in ("local_server_role_models", "role_model_paths"):
        raw_map = values.get(map_key, {})
        if isinstance(raw_map, dict):
            safe_map = {}
            for role, model_value in raw_map.items():
                if role in {"architect", "correctness", "security", "redteam"} and isinstance(model_value, str) and len(model_value) <= 4096 and "\x00" not in model_value:
                    safe_map[role] = model_value
            settings[map_key] = safe_map
    bool_keys = {"allow_self_edit", "peer_dialogue_enabled", "component_collaboration_enabled", "advanced_features_enabled"}
    int_ranges = {
        "n_ctx": (2048, 131072),
        "n_threads": (1, 256),
        "n_gpu_layers": (-1, 256),
        "max_tokens": (64, 32768),
        "model_timeout_seconds": (30, 600),
        "review_rounds": (0, 2),
        "max_context_chars": (6000, 100000),
        "memory_max_bytes": (1_048_576, 4_294_967_296),
        "max_peer_workers": (1, 4),
        "max_loaded_peer_models": (1, 4),
        "peer_dialogue_max_interactions": (1, 4),
    }
    for key in string_keys:
        value = values.get(key, settings[key])
        if isinstance(value, str) and len(value) <= 4096 and "\x00" not in value:
            settings[key] = value
    if settings["model_backend"] not in {"gguf", "local_server", "local-server"}:
        settings["model_backend"] = DEFAULT_SETTINGS["model_backend"]
    elif settings["model_backend"] == "local_server":
        settings["model_backend"] = "local-server"
    for key in bool_keys:
        value = values.get(key, settings[key])
        if type(value) is bool:
            settings[key] = value
    for key, (low, high) in int_ranges.items():
        value = values.get(key, settings[key])
        if isinstance(value, int) and not isinstance(value, bool):
            settings[key] = max(low, min(high, value))
    temperature = values.get("temperature", settings["temperature"])
    if isinstance(temperature, (int, float)) and not isinstance(temperature, bool):
        try:
            numeric_temperature = float(temperature)
        except (OverflowError, ValueError):
            numeric_temperature = float("nan")
        if math.isfinite(numeric_temperature):
            settings["temperature"] = max(0.0, min(2.0, numeric_temperature))
    # Public web research and unattended Apply are always disabled in this build.
    # Ignore any legacy persisted opt-ins instead of merely hiding the controls.
    settings["autonomous_web_research"] = False
    settings["auto_apply_approved"] = False
    return settings


def load_settings() -> dict:
    try:
        APP_DIR.mkdir(parents=True, exist_ok=True)
        if SETTINGS_PATH.exists() and not SETTINGS_PATH.is_symlink() and SETTINGS_PATH.is_file():
            if SETTINGS_PATH.stat().st_size > 1_000_000:
                return DEFAULT_SETTINGS.copy()
            loaded = json.loads(SETTINGS_PATH.read_text(encoding="utf-8"))
            return _validated_settings(loaded)
    except (OSError, ValueError, UnicodeError, RecursionError):
        pass
    return DEFAULT_SETTINGS.copy()


def save_settings(settings: dict) -> None:
    APP_DIR.mkdir(parents=True, exist_ok=True)
    safe = _validated_settings(settings)
    # Use a random same-directory temporary file and reject symlink targets.
    # The old predictable settings.tmp path followed symlinks and could overwrite
    # an unrelated file before os.replace replaced the link itself.
    atomic_write_text(SETTINGS_PATH, json.dumps(safe, indent=2))
