"""Host-owned application policy, separate from model prompt orchestration.

This module contains deterministic policy helpers. Model votes and reviews are
stored as advice, never used as write authorization. Final writes must still pass
host-side validation and exact candidate/context fingerprint checks.
"""
from __future__ import annotations

import hashlib
import json
import math
from pathlib import Path
from typing import Any, Iterable


def review_gate_errors(reviews: list[dict[str, Any]], expected_peers: Iterable[str]) -> list[str]:
    """Return warnings about malformed or dissenting model reviews."""
    expected = set(expected_peers)
    if not isinstance(reviews, list) or len(reviews) != len(expected):
        return [f"Expected exactly {len(expected)} structured code reviews."]
    names = [r.get("agent") for r in reviews if isinstance(r, dict)]
    if len(names) != len(expected) or set(names) != expected:
        return ["Code reviews must contain exactly one review from each known peer."]
    errors: list[str] = []
    allowed_votes = {"APPROVE", "REQUEST_CHANGES", "REJECT"}
    allowed_severity = {"BLOCKER", "HIGH", "MEDIUM", "LOW"}
    for review in reviews:
        peer = str(review.get("agent", "unknown"))
        review_vote = str(review.get("vote", "")).upper()
        if review_vote not in allowed_votes:
            errors.append(f"{peer}: missing or invalid review vote.")
        elif review_vote != "APPROVE":
            errors.append(f"{peer}: code review vote is {review_vote}; inspect the dissent before applying.")
        findings = review.get("findings")
        if not isinstance(findings, list):
            errors.append(f"{peer}: findings must be a structured list.")
            continue
        if review_vote == "APPROVE":
            checks = review.get("checks_performed")
            if not isinstance(checks, list) or not any(isinstance(item, str) and len(item.strip()) >= 12 for item in checks):
                errors.append(f"{peer}: approval lacks a concrete self-reported attack-surface/check list.")
            strengths = review.get("strengths")
            if not isinstance(strengths, list) or not any(isinstance(item, str) and item.strip() for item in strengths):
                errors.append(f"{peer}: approval lacks a substantive strengths/evidence summary.")
            confidence = review.get("confidence")
            if (isinstance(confidence, bool) or not isinstance(confidence, (int, float))
                    or not math.isfinite(float(confidence)) or not 0.0 <= float(confidence) <= 1.0):
                errors.append(f"{peer}: approval confidence must be a finite number from 0 to 1.")
        for finding in findings:
            if not isinstance(finding, dict):
                errors.append(f"{peer}: malformed finding; inspect this reviewer output manually.")
                continue
            severity = str(finding.get("severity", "")).upper()
            detail = str(finding.get("detail", "")).strip()
            if severity not in allowed_severity or not detail:
                errors.append(f"{peer}: finding is missing valid severity/detail.")
                continue
            normalized = detail.casefold().strip(" .!\t\n")
            if severity in {"BLOCKER", "HIGH", "MEDIUM"} and normalized not in {"none", "no issue", "no issues", "n/a", "na"}:
                errors.append(f"{peer}: model-reported unresolved {severity} finding in {finding.get('file') or 'unspecified file'}: {detail[:240]}")
    return errors


def vote_gate_errors(votes: list[dict[str, Any]], expected_peers: Iterable[str]) -> list[str]:
    """Return warnings about incomplete or dissenting model votes."""
    expected = set(expected_peers)
    if not isinstance(votes, list) or len(votes) != len(expected):
        return [f"Expected exactly {len(expected)} final votes."]
    names = [v.get("agent") for v in votes if isinstance(v, dict)]
    if len(names) != len(expected) or set(names) != expected:
        return ["Final votes must contain exactly one vote from each known peer."]
    errors: list[str] = []
    for vote in votes:
        if str(vote.get("vote", "")).upper() != "APPROVE":
            errors.append(f"{vote.get('agent')}: did not approve.")
        reason = vote.get("reason")
        if not isinstance(reason, str) or len(reason.strip()) < 12:
            errors.append(f"{vote.get('agent')}: final vote is missing a substantive reason.")
        blockers = vote.get("remaining_blockers")
        if not isinstance(blockers, list) or blockers:
            errors.append(f"{vote.get('agent')}: reported blockers or missing blocker data; inspect before applying.")
    return errors


def can_autonomously_apply(result: Any, require_runtime_tests: bool = True) -> bool:
    """Unattended writes remain disabled until host-owned test attestation exists."""
    return False


def candidate_fingerprint(files: dict[str, str]) -> str:
    """Stable digest binding review/test records to exact file paths and contents."""
    canonical = json.dumps(files, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
    return hashlib.sha256(canonical.encode("utf-8")).hexdigest()


def apply_context_fingerprint(result: Any) -> str:
    """Bind the candidate to its workspace, old file hashes, and run identifier."""
    payload = {
        "candidate_sha256": candidate_fingerprint(result.proposed_files),
        "workspace": str(Path(result.workspace).expanduser().resolve()),
        "hashes_before": result.hashes_before,
        "run_id": result.run_id,
    }
    canonical = json.dumps(payload, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
    return hashlib.sha256(canonical.encode("utf-8")).hexdigest()
