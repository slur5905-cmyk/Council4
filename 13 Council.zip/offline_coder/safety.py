"""Host-enforced write policy. Generated code is never executed by this module."""
from __future__ import annotations
import ast
import hashlib
import json
import os
import re
import shutil
import stat
import tempfile
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Mapping

PROJECT_ROOT = Path(__file__).resolve().parents[1]
MANAGED_DIR_NAME = ".council"
IGNORED_DIRS = {
    ".git", ".hg", ".svn", ".venv", "venv", "env", "node_modules", "__pycache__",
    ".idea", "site-packages", "dist", "build", "target", ".next", ".turbo",
}
IGNORED_DIRS_CASEFOLD = frozenset(str(item).casefold() for item in IGNORED_DIRS)


def is_ignored_directory_name(name: str) -> bool:
    """Match private/generated directory names case-insensitively on every platform."""
    folded = str(name or "").casefold()
    return folded == MANAGED_DIR_NAME.casefold() or folded in IGNORED_DIRS_CASEFOLD


BLOCKED_NAMES = {
    ".env", ".env.local", ".env.production", "id_rsa", "id_ed25519", "authorized_keys",
    "credentials", "credentials.json", "secrets.json", "secrets.yaml", "secrets.yml",
    "known_hosts", "master.key", "server.key", "client.key",
}
BLOCKED_SUFFIXES = {".pem", ".key", ".p12", ".pfx", ".keystore", ".sqlite", ".sqlite3", ".db"}
TEXT_SUFFIXES = {
    ".py", ".pyi", ".js", ".jsx", ".ts", ".tsx", ".mjs", ".cjs", ".html", ".htm", ".css",
    ".scss", ".sass", ".less", ".json", ".jsonc", ".json5", ".md", ".txt", ".rst", ".toml",
    ".ini", ".cfg", ".yaml", ".yml", ".xml", ".svg", ".sql", ".sh", ".bash", ".zsh", ".ps1",
    ".bat", ".cmd", ".rs", ".go", ".java", ".kt", ".kts", ".cs", ".cpp", ".c", ".h", ".hpp",
    ".swift", ".m", ".mm", ".rb", ".php", ".vue", ".svelte", ".dart", ".ex", ".exs", ".erl",
    ".hs", ".lua", ".pl", ".r", ".R", ".jl", ".tf", ".hcl", ".gradle", ".properties", ".make",
    ".mk", ".dockerfile", ".gitignore", ".editorconfig", ".lock", ".graphql", ".proto",
}
# Self-editing the Council's own installation is deliberately allowlist-based.
# Anything under the application source, command/control surfaces, test harnesses,
# workflows, dependency metadata, or phone/browser servers can change authority.
# Only documentation and the curated knowledge corpus are eligible for self-edit.
SELF_EDIT_ALLOWED_ROOT_DOCS = frozenset({
    "README.md", "START_HERE.md", "STATUS.md", "CHANGELOG.md",
})
SELF_EDIT_ALLOWED_PREFIXES = (
    "docs/",
    "offline_coder/base_knowledge/",
)
SELF_EDIT_ALLOWED_SUFFIXES = frozenset({".md", ".txt", ".rst"})


def self_edit_path_allowed(relative: str) -> bool:
    normalized = str(relative).replace("\\", "/").casefold()
    path = Path(normalized)
    if normalized in {name.casefold() for name in SELF_EDIT_ALLOWED_ROOT_DOCS}:
        return path.suffix.casefold() in SELF_EDIT_ALLOWED_SUFFIXES
    return (path.suffix.casefold() in SELF_EDIT_ALLOWED_SUFFIXES
            and any(normalized.startswith(prefix.casefold()) for prefix in SELF_EDIT_ALLOWED_PREFIXES))
ENV_CREDENTIAL_ASSIGNMENT = re.compile(
    r"(?im)(\b[A-Z0-9_]*(?:AWS_SECRET_ACCESS_KEY|AWS_ACCESS_KEY_ID|SECRET_KEY|CLIENT_SECRET|DATABASE_URL|API_TOKEN)\b\s*=\s*)([^\s#;]+)"
)
SECRET_PATTERNS = [
    ENV_CREDENTIAL_ASSIGNMENT,
    re.compile(r"-----BEGIN (?:RSA |EC |OPENSSH |DSA )?PRIVATE KEY-----"),
    re.compile(r"\bAKIA[0-9A-Z]{16}\b"),
    re.compile(r"\bgh[pousr]_[A-Za-z0-9]{20,}\b"),
    re.compile(r"\bxox[baprs]-[A-Za-z0-9-]{20,}\b"),
    re.compile(r"\bsk-(?:ant-)?[A-Za-z0-9_-]{20,}\b"),
    re.compile(r"\bAIza[0-9A-Za-z_-]{30,}\b"),
    re.compile(r'''(?i)["']?\b(?:api[_-]?key|access[_-]?token|auth[_-]?token|client[_-]?secret|password|passwd|secret|token|private[_-]?key)\b["']?\s*[:=]\s*["'](?!(?:your[_-]|change[_-]?me|example|placeholder|replace[_-]?me|redacted|dummy|test|none|null))[^"'\r\n]{8,}["']'''),
]
SENSITIVE_ASSIGNMENT_PATTERN = re.compile(
    r'''(?i)(["']?(?:api[_-]?key|access[_-]?token|auth[_-]?token|client[_-]?secret|password|passwd|secret|token|private[_-]?key|authorization|refresh[_-]?token)["']?\s*[:=]\s*)(?:"[^"\r\n]{4,}"|'[^'\r\n]{4,}'|Bearer\s+[A-Za-z0-9._~+/-]{12,}=?|[^\s,;}\]]{6,})'''
)
SENSITIVE_LITERAL_PATTERNS = [
    (re.compile(r"-----BEGIN (?:RSA |EC |OPENSSH |DSA )?PRIVATE KEY-----[\s\S]*?-----END (?:RSA |EC |OPENSSH |DSA )?PRIVATE KEY-----"), "[REDACTED PRIVATE KEY BLOCK]"),
    (re.compile(r"\bAKIA[0-9A-Z]{16}\b"), "[REDACTED AWS KEY]"),
    (re.compile(r"\bgh[pousr]_[A-Za-z0-9]{20,}\b"), "[REDACTED GIT TOKEN]"),
    (re.compile(r"\bxox[baprs]-[A-Za-z0-9-]{20,}\b"), "[REDACTED SLACK TOKEN]"),
    (re.compile(r"\bsk-(?:ant-)?[A-Za-z0-9_-]{20,}\b"), "[REDACTED API TOKEN]"),
    (re.compile(r"\bAIza[0-9A-Za-z_-]{30,}\b"), "[REDACTED API TOKEN]"),
    (re.compile(r"\bglpat-[A-Za-z0-9_-]{20,}\b"), "[REDACTED GITLAB TOKEN]"),
    (re.compile(r"\beyJ[A-Za-z0-9_-]{8,}\.eyJ[A-Za-z0-9_-]{8,}\.[A-Za-z0-9_-]{8,}\b"), "[REDACTED JWT]"),
    (re.compile(r"(?i)\bBearer\s+[A-Za-z0-9._~+/-]{20,}=?"), "Bearer [REDACTED TOKEN]"),
]


def redact_sensitive_text(text: str) -> str:
    """Redact common credential assignments and token formats before model context use."""
    if not isinstance(text, str) or not text:
        return text if isinstance(text, str) else ""
    redacted = ENV_CREDENTIAL_ASSIGNMENT.sub(lambda m: m.group(1) + '"[REDACTED]"', text)
    redacted = SENSITIVE_ASSIGNMENT_PATTERN.sub(lambda m: m.group(1) + '"[REDACTED]"', redacted)
    for pattern, replacement in SENSITIVE_LITERAL_PATTERNS:
        redacted = pattern.sub(replacement, redacted)
    return redacted


RISK_PATTERNS = [
    ("dynamic code execution", re.compile(r"\b(?:eval|exec)\s*\(")),
    ("shell execution", re.compile(r"\b(?:os\.system|subprocess\.(?:run|Popen|call|check_output))\s*\(")),
    ("shell=True", re.compile(r"\bshell\s*=\s*True\b")),
    ("recursive deletion", re.compile(r"\b(?:shutil\.rmtree|Path\([^\n]*\)\.rmdir)\s*\(")),
    ("network access", re.compile(r"\b(?:requests\.(?:get|post|put|delete)|urllib\.request|socket\.socket|httpx\.)")),
]


@dataclass
class ValidationResult:
    ok: bool
    errors: list[str] = field(default_factory=list)
    warnings: list[str] = field(default_factory=list)
    hashes_before: dict[str, str | None] = field(default_factory=dict)
    hashes_after: dict[str, str] = field(default_factory=dict)
    self_edit_targets: list[str] = field(default_factory=list)


def sha256_text(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8", errors="replace")).hexdigest()


def sha256_bytes(data: bytes) -> str:
    """Hash exact bytes so invalid UTF-8 cannot normalize distinct files."""
    return hashlib.sha256(data).hexdigest()


def sha256_file(path: Path, chunk_size: int = 1024 * 1024) -> str:
    """Hash a file incrementally to avoid loading large existing files into memory."""
    digest = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for chunk in iter(lambda: stream.read(chunk_size), b""):
            digest.update(chunk)
    return digest.hexdigest()


def atomic_write_text(path: Path, text: str) -> None:
    """Atomically replace a regular text file without following a leaf symlink."""
    target = Path(path)
    parent = target.parent
    if parent.is_symlink() or not parent.is_dir():
        raise ValueError(f"Refusing to write through an unsafe parent directory: {parent}")
    if target.is_symlink():
        raise ValueError(f"Refusing to overwrite a symlink: {target}")
    fd, temp_name = tempfile.mkstemp(prefix=f".{target.name}.tmp-", dir=str(parent))
    temp = Path(temp_name)
    try:
        with os.fdopen(fd, "w", encoding="utf-8", newline="") as stream:
            stream.write(text)
            stream.flush()
            os.fsync(stream.fileno())
        # os.replace replaces the directory entry itself; it does not follow a
        # symlink that appears at target after the preflight check.
        os.replace(temp, target)
    finally:
        temp.unlink(missing_ok=True)


def append_text_no_follow(path: Path, text: str) -> None:
    """Append text to a regular file while refusing leaf symlinks where supported."""
    target = Path(path)
    if target.parent.is_symlink() or not target.parent.is_dir():
        raise ValueError(f"Refusing to append through an unsafe parent directory: {target.parent}")
    if target.is_symlink():
        raise ValueError(f"Refusing to append through a symlink: {target}")
    flags = os.O_WRONLY | os.O_CREAT | os.O_APPEND
    flags |= getattr(os, "O_NOFOLLOW", 0)
    fd = os.open(target, flags, 0o600)
    try:
        if not stat.S_ISREG(os.fstat(fd).st_mode):
            raise ValueError(f"Refusing to append to a non-regular file: {target}")
        data = text.encode("utf-8")
        view = memoryview(data)
        while view:
            written = os.write(fd, view)
            if written <= 0:
                raise OSError("Could not finish appending journal entry")
            view = view[written:]
        os.fsync(fd)
    finally:
        os.close(fd)


def is_within(path: Path, root: Path) -> bool:
    try:
        path.resolve().relative_to(root.resolve())
        return True
    except (ValueError, OSError):
        return False




def ensure_managed_directory(workspace: Path, *parts: str) -> Path:
    """Create a path under .council while refusing symlinks in the managed tree."""
    root = workspace.expanduser().resolve()
    if not root.exists() or not root.is_dir():
        raise ValueError("Workspace does not exist or is not a directory.")
    cursor = root
    for part in (MANAGED_DIR_NAME, *parts):
        cursor = cursor / part
        if cursor.is_symlink():
            raise ValueError(f"Refusing to use a symlink in the audit/backup area: {cursor}")
        if cursor.exists() and not cursor.is_dir():
            raise ValueError(f"Managed audit/backup path is not a directory: {cursor}")
        cursor.mkdir(exist_ok=True)
        if not is_within(cursor, root):
            raise ValueError(f"Managed audit/backup path escaped the workspace: {cursor}")
    return cursor

def is_secret_path(relative: str) -> bool:
    p = Path(relative)
    parts = [part.lower() for part in p.parts]
    name = p.name.lower()
    if name in BLOCKED_NAMES or name.startswith(".env"):
        return True
    if p.suffix.lower() in BLOCKED_SUFFIXES:
        return True
    if any(part in {".ssh", ".aws", ".azure", ".gnupg", ".kube", "secrets", "credentials"} or part.startswith(".env") for part in parts):
        return True
    if any(term in name for term in ("password", "passwd", "secret", "credential", "private_key", "apikey")):
        return True
    return False


def validate_proposed_files(workspace: Path, files: Mapping[str, str], allow_self_edit: bool = False) -> ValidationResult:
    root = workspace.expanduser().resolve()
    result = ValidationResult(ok=True)
    if not files:
        return result
    if not root.exists() or not root.is_dir():
        return ValidationResult(False, ["Workspace does not exist or is not a directory."])
    for raw, content in files.items():
        if not isinstance(raw, str) or not isinstance(content, str):
            result.errors.append("Every proposed file must have a string path and string contents.")
            continue
        rel = raw.replace("\\", "/").strip()
        p = Path(rel)
        # Validation and the actual writer must interpret a path identically on every OS.
        # The writer uses mapping keys, so non-canonical aliases (backslashes, surrounding
        # whitespace, repeated separators, or ./ segments) must be rejected rather than
        # validated as one path and then written as another.
        if raw != raw.strip() or "\\" in raw or (rel and p.as_posix() != rel):
            result.errors.append(f"Blocked non-canonical path: {raw!r}. Use a clean relative path with forward slashes.")
            continue
        if not rel or p.is_absolute() or re.match(r"^[A-Za-z]:", rel) or ".." in p.parts:
            result.errors.append(f"Blocked unsafe path: {raw!r}")
            continue
        if rel.startswith("/") or any(part.lower() in IGNORED_DIRS for part in p.parts):
            result.errors.append(f"Blocked path inside a private, generated, or dependency directory: {rel}")
            continue
        if p.parts and p.parts[0].lower() == MANAGED_DIR_NAME.lower():
            result.errors.append(f"The assistant's audit, settings, and backup area is protected: {rel}")
            continue
        if is_secret_path(rel):
            result.errors.append(f"Blocked sensitive file path: {rel}")
            continue
        if p.suffix.lower() not in TEXT_SUFFIXES and p.name.lower() not in {"makefile", "dockerfile", ".gitignore", ".editorconfig"}:
            result.errors.append(f"Only recognized text/source files can be written automatically: {rel}")
            continue
        if len(content.encode("utf-8")) > 1_000_000:
            result.errors.append(f"File is over the 1 MB automatic-write limit: {rel}")
            continue
        target = root / p
        if not is_within(target, root):
            result.errors.append(f"Blocked path that escapes the workspace: {rel}")
            continue
        # Existing symlinks could redirect writes outside the workspace.
        cursor = root
        unsafe_link = False
        for part in p.parts:
            cursor = cursor / part
            if cursor.is_symlink():
                unsafe_link = True
                break
        if unsafe_link:
            result.errors.append(f"Blocked symlink target: {rel}")
            continue
        result.hashes_before[rel] = sha256_file(target) if target.is_file() else None
        result.hashes_after[rel] = sha256_text(content)
        if is_within(target, PROJECT_ROOT):
            result.self_edit_targets.append(rel)
            normalized = rel.replace("\\", "/")
            if not allow_self_edit:
                result.errors.append(f"Self-editing is off; turn it on in the UI to propose application-source changes: {rel}")
            elif not self_edit_path_allowed(normalized):
                result.errors.append(
                    f"Self-edit allowlist blocked application code or an authority surface: {rel}. "
                    "Only documentation and the curated base-knowledge corpus may be self-edited."
                )
        for pattern in SECRET_PATTERNS:
            if pattern.search(content):
                result.errors.append(f"Possible credential/private-key material found in proposed file: {rel}")
                break
        for label, pattern in RISK_PATTERNS:
            if pattern.search(content):
                result.warnings.append(f"{rel}: contains {label}; inspect this code carefully before applying or running it.")
        suffix = p.suffix.lower()
        if suffix == ".py":
            try:
                ast.parse(content, filename=rel)
            except SyntaxError as exc:
                result.errors.append(f"Python syntax error in {rel}, line {exc.lineno}: {exc.msg}")
        elif suffix == ".json":
            try:
                json.loads(content)
            except json.JSONDecodeError as exc:
                result.errors.append(f"Invalid JSON in {rel}, line {exc.lineno}, column {exc.colno}: {exc.msg}")
    result.ok = not result.errors
    return result


def apply_files(workspace: Path, files: Mapping[str, str], expected_hashes: Mapping[str, str | None],
                allow_self_edit: bool = False) -> Path:
    """Write approved text files with stale-state checks and best-effort rollback.

    This narrows common path/hash hazards but cannot eliminate races with another
    process modifying the workspace concurrently; callers should serialize writes.
    """
    root = workspace.expanduser().resolve()
    if not files:
        raise ValueError("Refusing to apply an empty proposal.")
    if not isinstance(expected_hashes, Mapping) or set(expected_hashes) != set(files):
        raise ValueError("Expected hashes must contain exactly one reviewed entry for every proposed path.")

    validation = validate_proposed_files(root, files, allow_self_edit=allow_self_edit)
    if not validation.ok:
        raise ValueError("Safety checks blocked apply:\n- " + "\n- ".join(validation.errors))

    # Revalidate path components and hashes immediately before staging. Hash entries
    # for new files must explicitly be None; a missing entry is never treated as None.
    for rel in files:
        path = root / rel
        cursor = root
        for part in Path(rel).parts:
            cursor = cursor / part
            if cursor.is_symlink():
                raise ValueError(f"{rel} now contains a symlink; refusing to write.")
        if path.exists() and not path.is_file():
            raise ValueError(f"{rel} exists but is not a regular file; refusing to replace it.")
        current_hash = sha256_file(path) if path.is_file() else None
        if current_hash != expected_hashes[rel]:
            raise ValueError(f"{rel} changed after review. Run the council again so it reviews the current file.")

    stamp = datetime.now().strftime("%Y%m%d_%H%M%S_%f")
    backup_root = ensure_managed_directory(root, "backups", stamp)
    manifest_targets = []
    for rel in files:
        path = root / rel
        existed = path.is_file()
        manifest_targets.append({"path": rel, "existed": existed, "sha256_before": expected_hashes[rel]})
        if existed:
            backup = backup_root / rel
            backup.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(path, backup)
    manifest = backup_root / "manifest.json"
    manifest.write_text(json.dumps({"targets": manifest_targets, "created_at": datetime.now().isoformat()}, indent=2), encoding="utf-8")

    staged: list[tuple[Path, Path]] = []
    replaced: list[Path] = []
    try:
        # Stage each file beside its destination so os.replace stays on one filesystem.
        for rel, content in files.items():
            dest = root / rel
            # Re-check each parent before creating or using it. These checks reduce, but
            # cannot completely eliminate, races with another process changing directories.
            cursor = root
            for part in Path(rel).parts[:-1]:
                cursor = cursor / part
                if cursor.is_symlink():
                    raise ValueError(f"{rel} acquired a symlink parent before staging; refusing to write.")
                if cursor.exists() and not cursor.is_dir():
                    raise ValueError(f"{rel} has a non-directory parent; refusing to write.")
                cursor.mkdir(exist_ok=True)
                if not is_within(cursor, root):
                    raise ValueError(f"{rel} parent escaped the workspace; refusing to write.")
            if dest.is_symlink() or (dest.exists() and not dest.is_file()):
                raise ValueError(f"{rel} changed into an unsafe target before staging.")
            fd, temp_name = tempfile.mkstemp(prefix=f".{dest.name}.council-", dir=str(dest.parent))
            temp = Path(temp_name)
            try:
                with os.fdopen(fd, "w", encoding="utf-8", newline="") as stream:
                    stream.write(content)
                    stream.flush()
                    os.fsync(stream.fileno())
            except Exception:
                temp.unlink(missing_ok=True)
                raise
            staged.append((temp, dest))
        for temp, dest in staged:
            # Recheck state immediately before each replace to reduce the review/write gap.
            rel = dest.relative_to(root).as_posix()
            cursor = root
            for part in Path(rel).parts[:-1]:
                cursor = cursor / part
                if cursor.is_symlink() or not cursor.is_dir() or not is_within(cursor, root):
                    raise ValueError(f"{rel} parent changed into an unsafe target before replacement.")
            if dest.is_symlink() or (dest.exists() and not dest.is_file()):
                raise ValueError(f"{rel} changed into an unsafe target before replacement.")
            current_hash = sha256_file(dest) if dest.is_file() else None
            if current_hash != expected_hashes[rel]:
                raise ValueError(f"{rel} changed during apply; refusing to overwrite it.")
            os.replace(temp, dest)
            replaced.append(dest)
    except Exception as exc:
        rollback_errors: list[str] = []
        for temp, _ in staged:
            try:
                temp.unlink(missing_ok=True)
            except OSError as cleanup_exc:
                rollback_errors.append(f"temporary file cleanup failed: {cleanup_exc}")
        # Only roll back files that this invocation successfully replaced. Restoring every
        # planned target could overwrite an unrelated concurrent edit, or delete a new file
        # created by another process after review.
        for dest in reversed(replaced):
            rel = dest.relative_to(root).as_posix()
            backup = backup_root / rel
            try:
                if dest.is_symlink() or (dest.exists() and not dest.is_file()):
                    raise OSError("target became a symlink or non-regular file during rollback")
                current_hash = sha256_file(dest) if dest.is_file() else None
                if current_hash != validation.hashes_after[rel]:
                    raise OSError("target changed after this invocation wrote it; preserving concurrent change")
                if expected_hashes[rel] is not None:
                    if not backup.is_file() or backup.is_symlink():
                        raise OSError("original backup is missing or unsafe")
                    restore_tmp = dest.with_name(f".{dest.name}.council-restore-{stamp}")
                    try:
                        shutil.copy2(backup, restore_tmp)
                        os.replace(restore_tmp, dest)
                    finally:
                        restore_tmp.unlink(missing_ok=True)
                else:
                    dest.unlink()
            except OSError as rollback_exc:
                rollback_errors.append(f"{rel}: {rollback_exc}")
        if rollback_errors:
            raise RuntimeError(
                f"Apply failed ({exc}); rollback was incomplete. Backup retained at {backup_root}. "
                + "Rollback errors: " + "; ".join(rollback_errors)
            ) from exc
        raise
    return backup_root


def inspect_generated_code(files: Mapping[str, str]) -> list[str]:
    """Advisory risk flags; this never executes or imports generated code."""
    findings: list[str] = []
    for rel, content in files.items():
        for label, pattern in RISK_PATTERNS:
            if pattern.search(content):
                findings.append(f"{rel}: {label}")
    return findings
