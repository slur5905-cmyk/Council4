"""Task-aware test matrix planning and evidence normalization."""
from __future__ import annotations

import hashlib
import json
import platform
import shutil
import sys
from pathlib import Path
from typing import Any


def build_test_matrix(workspace: Path, proposed_files: dict[str, str] | None = None) -> dict[str, Any]:
    proposed_files = proposed_files or {}
    root = Path(workspace).expanduser().resolve()
    names = set(proposed_files)
    existing = {p.name for p in root.iterdir()} if root.is_dir() else set()
    all_names = names | existing
    python = any(Path(x).suffix.lower() in {".py", ".pyi"} for x in names) or "pyproject.toml" in all_names or "requirements.txt" in all_names
    js = any(Path(x).suffix.lower() in {".js", ".mjs", ".cjs", ".ts", ".tsx", ".jsx"} for x in names) or "package.json" in all_names
    web = any(Path(x).suffix.lower() in {".html", ".htm", ".css", ".jsx", ".tsx", ".vue", ".svelte"} for x in names) or any(x in all_names for x in ("index.html", "main.html", "app.html", "council.visual.json"))
    system_suffixes = {".rs": ("rustc",), ".go": ("go",), ".java": ("javac",),
                       ".cs": ("dotnet",), ".cpp": ("c++", "g++", "clang++"),
                       ".c": ("cc", "gcc", "clang"), ".swift": ("swiftc",),
                       ".kt": ("kotlinc",)}
    systems = any(Path(x).suffix.lower() in system_suffixes for x in names)
    recommended = [
        {"id": "static-path-and-secret-validation", "category": "host", "status": "REQUIRED", "why": "Every candidate must pass deterministic host path/protected-file validation."},
    ]
    if python:
        recommended.extend([
            {"id": "python-parse-compile", "category": "syntax", "status": "RECOMMENDED", "why": "Compile/parse changed Python files in isolation."},
            {"id": "python-unit-regression", "category": "unit", "status": "RECOMMENDED", "why": "Run discovered Python unit tests in a disposable no-network environment."},
            {"id": "python-type-lint", "category": "static-analysis", "status": "PLANNED", "why": "Use project-configured type/lint tools when safely provisioned; not auto-installed."},
        ])
    if js:
        recommended.extend([
            {"id": "javascript-syntax", "category": "syntax", "status": "RECOMMENDED", "why": "Check changed JavaScript syntax with a compatible local runtime."},
            {"id": "javascript-unit-regression", "category": "unit", "status": "RECOMMENDED", "why": "Run discovered node:test suite where supported."},
        ])
    if web:
        recommended.extend([
            {"id": "browser-render-and-actions", "category": "end-to-end", "status": "OPTIONAL", "why": "Use existing Playwright visual runner and council.visual.json when Playwright/browser are installed."},
            {"id": "accessibility-manual", "category": "accessibility", "status": "REQUIRED_REVIEW", "why": "Automated checks are partial; keyboard, labels, focus, contrast, zoom, and screen-reader flows need review."},
            {"id": "responsive-viewports", "category": "visual", "status": "OPTIONAL", "why": "Validate narrow phone, tablet, and desktop sizes."},
        ])
    if systems:
        detected = []
        for suffix, tools in system_suffixes.items():
            if any(Path(x).suffix.lower() == suffix for x in names):
                found = next((tool for tool in tools if shutil.which(tool)), "")
                detected.append({"language_suffix": suffix, "compiler": found, "status": "AVAILABLE_NOT_RUN" if found else "UNAVAILABLE"})
        recommended.extend([
            {"id": "native-toolchain-availability", "category": "build", "status": "INSPECTED", "toolchains": detected,
             "why": "Local native compilers are detected but not automatically invoked; no toolchain is downloaded."},
            {"id": "sanitizer-or-fuzz-tests", "category": "robustness", "status": "OPTIONAL", "why": "Use sanitizers/fuzzers on an isolated, authorized test target."},
        ])
    if "council.simulations.json" in names or (root / "council.simulations.json").is_file():
        recommended.append({"id": "declared-runtime-simulations", "category": "integration", "status": "RECOMMENDED", "why": "Execute bounded Python/Node scenarios in the existing offline container runner."})
    # CI and supply-chain checks are deliberately advisory until a dedicated parser/scanner runs.
    if any(x.startswith(".github/workflows/") for x in names) or (root / ".github" / "workflows").is_dir():
        recommended.append({"id": "ci-workflow-hardening-review", "category": "supply-chain", "status": "REVIEW_REQUIRED",
                            "why": "Review workflow permissions, untrusted pull-request triggers, and immutable action pins."})
    recommended.append({"id": "dependency-vulnerability-scan", "category": "supply-chain", "status": "AVAILABLE_IF_TOOL_INSTALLED",
                        "why": "Use a project-appropriate local scanner (for example pip-audit, osv-scanner, cargo-audit, govulncheck, or Trivy) after user approval; this planner does not run it."})
    return {
        "status": "planned", "workspace": str(root), "platform": platform.platform(),
        "python": sys.version.split()[0], "checks": recommended,
        "warning": "This is a plan, not test evidence. Actual runner reports determine PASSED/FAILED/SKIPPED/UNAVAILABLE/NOT_APPLICABLE.",
    }


def normalize_test_evidence(
    report: dict[str, Any], candidate_hash: str,
    environment: dict[str, Any] | None = None,
    changed_files: dict[str, str] | None = None,
) -> dict[str, Any]:
    """Bind runner output to a candidate fingerprint and reject inconsistent PASS summaries."""
    if not isinstance(candidate_hash, str) or len(candidate_hash) != 64 or any(c not in "0123456789abcdef" for c in candidate_hash.lower()):
        raise ValueError("Candidate hash must be a SHA-256 hex digest.")
    raw = json.dumps(report, sort_keys=True, ensure_ascii=False, default=str)
    status = str(report.get("status", "UNKNOWN")).upper()
    checks = report.get("checks")
    check_statuses: list[str] = []
    malformed_checks = False
    if isinstance(checks, dict):
        for value in checks.values():
            child_status = value.get("status") if isinstance(value, dict) else None
            if not isinstance(child_status, str) or not child_status.strip():
                check_statuses.append("INVALID")
                malformed_checks = True
            else:
                check_statuses.append(child_status.strip().upper())
    elif checks is not None:
        malformed_checks = True
    # A top-level PASS without at least one well-formed, passing host check is not evidence.
    inconsistent = status == "PASSED" and (
        not isinstance(checks, dict) or not checks or malformed_checks
        or len(check_statuses) != len(checks) or any(item != "PASSED" for item in check_statuses)
    )
    if inconsistent:
        status = "INVALID_EVIDENCE"
    file_hashes = {}
    if isinstance(changed_files, dict):
        for name, content in sorted(changed_files.items()):
            if isinstance(name, str) and isinstance(content, str):
                file_hashes[name] = hashlib.sha256(content.encode("utf-8")).hexdigest()
    return {
        "candidate_sha256": candidate_hash.lower(),
        "changed_file_sha256": file_hashes,
        "report_sha256": hashlib.sha256(raw.encode("utf-8")).hexdigest(),
        "status": status,
        "nested_check_count": len(check_statuses),
        "nested_check_statuses": check_statuses,
        "inconsistent_top_level_pass": bool(inconsistent),
        "summary": str(report.get("summary", ""))[:3000],
        "environment": environment or {"platform": platform.platform(), "python": sys.version.split()[0]},
        "scope": "Host-generated integrity envelope around runner output; hashes bind it to named candidate files but are not a cryptographic attestation of arbitrary project code.",
    }
