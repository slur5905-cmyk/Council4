"""Persistent, bounded peer communication and evidence-aware collective learning.

Messages are internal work records, not executable commands. Discussion-derived lessons
start as provisional and must be explicitly confirmed before becoming trusted knowledge.
"""
from __future__ import annotations

from contextlib import contextmanager
from datetime import datetime, timezone
import hashlib
import json
import re
import sqlite3
import uuid
from pathlib import Path
from typing import Any

from .config import APP_DIR
from .safety import redact_sensitive_text

DB_PATH = APP_DIR / "peer_communication.sqlite3"
PEER_NAMES = (
    "Peer A — Architect / Breaker",
    "Peer B — Correctness & Test Auditor / Breaker",
    "Peer C — Security & Reliability Auditor / Breaker",
    "Peer D — Independent Red-Team Verifier",
)
MESSAGE_STATUSES = {"recorded", "awaiting_response", "open", "resolved", "proposed_not_applied", "needs_follow_up", "disagree", "cannot_verify"}
MESSAGE_KINDS = {
    "question", "investigation", "code_challenge", "collaboration_request",
    "response", "follow_up", "resolution", "component_contribution",
}
_DISCUSSION_STATUSES = {"open", "resolved", "closed"}
_LESSON_STATUSES = {"provisional", "verified", "rejected"}


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()


def _clean_text(value: Any, limit: int, field: str) -> str:
    if not isinstance(value, str):
        raise ValueError(f"{field} must be text.")
    value = value.strip()
    if not value:
        raise ValueError(f"{field} cannot be empty.")
    if len(value) > limit:
        raise ValueError(f"{field} exceeds the {limit:,}-character limit.")
    # Store redacted text rather than persisting credential-like values in a long-lived DB.
    return redact_sensitive_text(value)


def _safe_code_ref(value: Any) -> str:
    if value is None or value == "":
        return ""
    value = _clean_text(value, 400, "code_ref")
    normalized = value.replace("\\", "/")
    parts = normalized.split("/")
    if normalized.startswith("/") or re.match(r"^[A-Za-z]:", normalized) or any(p == ".." for p in parts):
        raise ValueError("Code references must be relative and cannot traverse outside the project.")
    return normalized


class PeerCommunicationStore:
    """SQLite-backed communication log and reviewable collective lesson store."""

    def __init__(self, db_path: Path = DB_PATH):
        self.db_path = Path(db_path)
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        with self._connect() as db:
            db.execute("PRAGMA journal_mode=WAL")
            db.execute("""CREATE TABLE IF NOT EXISTS discussions (
                id TEXT PRIMARY KEY,
                run_id TEXT NOT NULL UNIQUE,
                task_digest TEXT NOT NULL,
                task_summary TEXT NOT NULL,
                status TEXT NOT NULL DEFAULT 'open',
                created_at TEXT NOT NULL,
                updated_at TEXT NOT NULL
            )""")
            db.execute("""CREATE TABLE IF NOT EXISTS messages (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                discussion_id TEXT NOT NULL,
                sender TEXT NOT NULL,
                recipient TEXT NOT NULL DEFAULT '',
                kind TEXT NOT NULL,
                subject TEXT NOT NULL DEFAULT '',
                body TEXT NOT NULL,
                code_ref TEXT NOT NULL DEFAULT '',
                status TEXT NOT NULL DEFAULT 'recorded',
                related_message_id INTEGER,
                body_sha256 TEXT NOT NULL,
                created_at TEXT NOT NULL,
                FOREIGN KEY(discussion_id) REFERENCES discussions(id),
                FOREIGN KEY(related_message_id) REFERENCES messages(id)
            )""")
            db.execute("CREATE INDEX IF NOT EXISTS idx_peer_messages_discussion ON messages(discussion_id, id)")
            db.execute("CREATE INDEX IF NOT EXISTS idx_peer_messages_recipient ON messages(recipient, status)")
            db.execute("""CREATE TABLE IF NOT EXISTS lessons (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                discussion_id TEXT NOT NULL,
                topic TEXT NOT NULL,
                lesson TEXT NOT NULL,
                evidence TEXT NOT NULL,
                status TEXT NOT NULL DEFAULT 'provisional',
                content_sha256 TEXT NOT NULL,
                created_at TEXT NOT NULL,
                reviewed_at TEXT NOT NULL DEFAULT '',
                UNIQUE(discussion_id, content_sha256),
                FOREIGN KEY(discussion_id) REFERENCES discussions(id)
            )""")
            db.execute("CREATE INDEX IF NOT EXISTS idx_peer_lessons_status ON lessons(status, id)")

    @contextmanager
    def _connect(self):
        if self.db_path.is_symlink() or self.db_path.parent.is_symlink():
            raise ValueError("Refusing to access the peer database through a symlink.")
        db = sqlite3.connect(self.db_path, timeout=8.0)
        db.row_factory = sqlite3.Row
        db.execute("PRAGMA foreign_keys=ON")
        try:
            yield db
            db.commit()
        except Exception:
            db.rollback()
            raise
        finally:
            db.close()

    def begin_discussion(self, run_id: str, task: str) -> str:
        run_id = _clean_text(run_id, 128, "run_id")
        task = _clean_text(task, 12000, "task")
        digest = hashlib.sha256(task.encode("utf-8")).hexdigest()
        summary = re.sub(r"\s+", " ", task)[:500]
        stamp = _now()
        with self._connect() as db:
            row = db.execute("SELECT id, task_digest FROM discussions WHERE run_id=?", (run_id,)).fetchone()
            if row:
                if row["task_digest"] != digest:
                    raise ValueError("The run ID is already associated with a different task.")
                return str(row["id"])
            discussion_id = uuid.uuid4().hex
            db.execute(
                "INSERT INTO discussions(id,run_id,task_digest,task_summary,status,created_at,updated_at) VALUES(?,?,?,?,?,?,?)",
                (discussion_id, run_id, digest, summary, "open", stamp, stamp),
            )
        return discussion_id

    def add_message(self, discussion_id: str, sender: str, recipient: str, kind: str,
                    subject: str, body: str, code_ref: str = "", status: str = "recorded",
                    related_message_id: int | None = None) -> int:
        if sender not in PEER_NAMES:
            raise ValueError("Unknown peer sender.")
        if recipient and recipient not in PEER_NAMES:
            raise ValueError("Unknown peer recipient.")
        if recipient and recipient == sender:
            raise ValueError("A peer cannot direct a message to itself.")
        if kind not in MESSAGE_KINDS:
            raise ValueError("Unsupported peer message kind.")
        subject = _clean_text(subject or "(untitled peer exchange)", 300, "subject")
        body = _clean_text(body, 12000, "body")
        code_ref = _safe_code_ref(code_ref)
        status = _clean_text(status, 40, "status")
        if status not in MESSAGE_STATUSES:
            raise ValueError("Unsupported peer message status.")
        digest = hashlib.sha256(body.encode("utf-8")).hexdigest()
        with self._connect() as db:
            if not db.execute("SELECT 1 FROM discussions WHERE id=?", (discussion_id,)).fetchone():
                raise ValueError("Discussion not found.")
            if related_message_id is not None:
                related = db.execute("SELECT discussion_id FROM messages WHERE id=?", (int(related_message_id),)).fetchone()
                if not related or related["discussion_id"] != discussion_id:
                    raise ValueError("Related message must belong to the same discussion.")
            message_count = db.execute("SELECT COUNT(*) AS n FROM messages WHERE discussion_id=?", (discussion_id,)).fetchone()["n"]
            if int(message_count) >= 250:
                raise ValueError("This discussion reached its bounded 250-message history limit.")
            cur = db.execute(
                """INSERT INTO messages(discussion_id,sender,recipient,kind,subject,body,code_ref,status,
                   related_message_id,body_sha256,created_at) VALUES(?,?,?,?,?,?,?,?,?,?,?)""",
                (discussion_id, sender, recipient, kind, subject, body, code_ref, status,
                 related_message_id, digest, _now()),
            )
            db.execute("UPDATE discussions SET updated_at=? WHERE id=?", (_now(), discussion_id))
            return int(cur.lastrowid)

    def list_messages(self, discussion_id: str, limit: int = 100) -> list[dict[str, Any]]:
        limit = max(1, min(500, int(limit)))
        with self._connect() as db:
            rows = db.execute(
                "SELECT * FROM messages WHERE discussion_id=? ORDER BY id LIMIT ?",
                (discussion_id, limit),
            ).fetchall()
        out = []
        for row in rows:
            item = dict(row)
            actual = hashlib.sha256(item["body"].encode("utf-8")).hexdigest()
            item["integrity_valid"] = actual == item["body_sha256"]
            if not item["integrity_valid"]:
                item["body"] = "[Message integrity check failed; content withheld.]"
            out.append(item)
        return out

    def set_discussion_status(self, discussion_id: str, status: str) -> None:
        if status not in _DISCUSSION_STATUSES:
            raise ValueError("Invalid discussion status.")
        with self._connect() as db:
            cur = db.execute("UPDATE discussions SET status=?,updated_at=? WHERE id=?", (status, _now(), discussion_id))
            if cur.rowcount != 1:
                raise ValueError("Discussion not found.")

    def list_open_discussions(self, query: str = "", limit: int = 5) -> list[dict[str, Any]]:
        limit = max(1, min(20, int(limit)))
        terms = [x for x in re.findall(r"[a-zA-Z0-9_+-]{3,}", query.casefold())]
        with self._connect() as db:
            rows = db.execute("SELECT * FROM discussions WHERE status='open' ORDER BY updated_at DESC LIMIT 100").fetchall()
        ranked = []
        for row in rows:
            item = dict(row)
            hay = (item["task_summary"] + " " + " ".join(m["body"] for m in self.list_messages(item["id"], limit=30))).casefold()
            score = sum(min(3, hay.count(term)) for term in terms)
            if not terms or score:
                ranked.append((score, item))
        ranked.sort(key=lambda pair: (pair[0], pair[1]["updated_at"]), reverse=True)
        return [item for _, item in ranked[:limit]]

    def add_lesson(self, discussion_id: str, topic: str, lesson: str, evidence: str,
                   status: str = "provisional") -> int:
        if status != "provisional":
            raise ValueError("New discussion lessons must start as provisional.")
        topic = _clean_text(topic, 500, "topic")
        lesson = _clean_text(lesson, 4000, "lesson")
        evidence = _clean_text(evidence, 5000, "evidence")
        if len(evidence) < 12:
            raise ValueError("A lesson needs a meaningful evidence/outcome note.")
        digest = hashlib.sha256((topic + "\n" + lesson + "\n" + evidence).encode("utf-8")).hexdigest()
        with self._connect() as db:
            if not db.execute("SELECT 1 FROM discussions WHERE id=?", (discussion_id,)).fetchone():
                raise ValueError("Discussion not found.")
            cur = db.execute(
                "INSERT OR IGNORE INTO lessons(discussion_id,topic,lesson,evidence,status,content_sha256,created_at) VALUES(?,?,?,?,?,?,?)",
                (discussion_id, topic, lesson, evidence, "provisional", digest, _now()),
            )
            if cur.rowcount == 0:
                row = db.execute("SELECT id FROM lessons WHERE discussion_id=? AND content_sha256=?", (discussion_id, digest)).fetchone()
                return int(row["id"])
            return int(cur.lastrowid)

    def list_lessons(self, status: str | None = None, limit: int = 100) -> list[dict[str, Any]]:
        limit = max(1, min(500, int(limit)))
        if status is not None and status not in _LESSON_STATUSES:
            raise ValueError("Invalid lesson status.")
        with self._connect() as db:
            if status:
                rows = db.execute("SELECT * FROM lessons WHERE status=? ORDER BY id DESC LIMIT ?", (status, limit)).fetchall()
            else:
                rows = db.execute("SELECT * FROM lessons ORDER BY id DESC LIMIT ?", (limit,)).fetchall()
        out = []
        for row in rows:
            item = dict(row)
            digest = hashlib.sha256((item["topic"] + "\n" + item["lesson"] + "\n" + item["evidence"]).encode("utf-8")).hexdigest()
            item["integrity_valid"] = digest == item["content_sha256"]
            if not item["integrity_valid"]:
                item["lesson"] = "[Lesson integrity check failed; content withheld.]"
            out.append(item)
        return out

    def review_lesson(self, lesson_id: int, decision: str) -> None:
        if decision not in {"verified", "rejected"}:
            raise ValueError("Lesson decision must be verified or rejected.")
        with self._connect() as db:
            cur = db.execute(
                "UPDATE lessons SET status=?,reviewed_at=? WHERE id=? AND status='provisional'",
                (decision, _now(), int(lesson_id)),
            )
            if cur.rowcount != 1:
                raise ValueError("Provisional lesson not found or already reviewed.")

    def relevant_lessons(self, query: str, limit: int = 4) -> list[dict[str, str]]:
        terms = set(re.findall(r"[a-zA-Z_][a-zA-Z0-9_+-]{2,}", query.casefold()))
        if not terms:
            return []
        with self._connect() as db:
            rows = db.execute("SELECT * FROM lessons WHERE status IN ('verified','provisional') ORDER BY id DESC LIMIT 500").fetchall()
        ranked = []
        for row in rows:
            item = dict(row)
            digest = hashlib.sha256((item["topic"] + "\n" + item["lesson"] + "\n" + item["evidence"]).encode("utf-8")).hexdigest()
            if digest != item["content_sha256"]:
                continue
            hay = " ".join((item["topic"], item["lesson"], item["evidence"])).casefold()
            score = sum(min(3, hay.count(term)) for term in terms)
            if score:
                ranked.append((score, {
                    "topic": item["topic"], "lesson": item["lesson"], "evidence": item["evidence"],
                    "status": item["status"],
                }))
        ranked.sort(key=lambda pair: (pair[0], pair[1]["status"] == "verified"), reverse=True)
        return [item for _, item in ranked[:max(0, min(10, limit))]]
