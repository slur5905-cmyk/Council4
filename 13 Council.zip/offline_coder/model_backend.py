"""In-process local GGUF inference. No network calls or API server are used."""
from __future__ import annotations
from pathlib import Path
import threading


class LocalModelError(RuntimeError):
    pass


class LocalModel:
    def __init__(self, model_path: str, n_ctx: int = 8192, n_threads: int = 4,
                 n_gpu_layers: int = 0, max_tokens: int = 4096, temperature: float = 0.2):
        path = Path(model_path).expanduser().resolve()
        if not path.is_file():
            raise LocalModelError(f"Model file not found: {path}\nChoose a local .gguf model file first.")
        if path.suffix.lower() != ".gguf":
            raise LocalModelError("This build expects a GGUF model file (.gguf).")
        try:
            from llama_cpp import Llama
        except ImportError as exc:
            raise LocalModelError(
                "The local inference library is not installed. Install it with:\n"
                "  python -m pip install llama-cpp-python\n\n"
                "No API key or remote AI service is required."
            ) from exc
        self.max_tokens = int(max_tokens)
        self.temperature = float(temperature)
        try:
            self._llm = Llama(
                model_path=str(path),
                n_ctx=max(2048, int(n_ctx)),
                n_threads=max(1, int(n_threads)),
                n_gpu_layers=int(n_gpu_layers),
                verbose=False,
            )
        except Exception as exc:
            raise LocalModelError(
                f"Could not load the model. The file may be incompatible or too large for your RAM/VRAM.\n{exc}"
            ) from exc
        self.model_path = str(path)

    def generate(self, system: str, user: str, max_tokens: int | None = None,
                 temperature: float | None = None) -> str:
        cap = max(64, int(max_tokens or self.max_tokens))
        temp = self.temperature if temperature is None else float(temperature)
        try:
            result = self._llm.create_chat_completion(
                messages=[{"role": "system", "content": system}, {"role": "user", "content": user}],
                max_tokens=cap,
                temperature=temp,
                top_p=0.9,
                repeat_penalty=1.08,
            )
            content = result["choices"][0]["message"].get("content", "")
            if isinstance(content, str) and content.strip():
                return content.strip()
            raise LocalModelError("The local model returned an empty answer.")
        except LocalModelError:
            raise
        except Exception as exc:
            raise LocalModelError(f"Local model generation failed: {exc}") from exc


class LocalServerModel:
    """Verified OpenAI-compatible model served on this computer (loopback only).

    This adapter deliberately refuses non-loopback hosts so a configuration typo cannot
    silently turn the local-first app into a remote inference client.
    """
    def __init__(self, base_url: str = "http://127.0.0.1:8080/v1", model: str = "",
                 max_tokens: int = 4096, temperature: float = 0.2, timeout: int = 180,
                 verified_model_ids: set[str] | None = None):
        import json
        from urllib.parse import urlparse
        parsed = urlparse(str(base_url).strip().rstrip("/"))
        if parsed.scheme != "http" or parsed.hostname not in {"127.0.0.1", "localhost", "::1"}:
            raise LocalModelError("Local server mode only accepts loopback hosts: http://127.0.0.1, http://localhost, or http://[::1] endpoints. HTTPS and remote hosts are refused.")
        if parsed.username or parsed.password or parsed.query or parsed.fragment:
            raise LocalModelError("The local server URL must not contain credentials, a query string, or a fragment.")
        self.base_url = str(base_url).strip().rstrip("/")
        self.max_tokens = int(max_tokens)
        self.temperature = float(temperature)
        self.timeout = max(5, min(int(timeout), 600))
        self.model = str(model or "").strip()
        if verified_model_ids is None:
            try:
                payload = self._request("/models", method="GET")
            except Exception as exc:
                raise LocalModelError(f"Could not verify the local model server at {self.base_url}. Start a compatible local server and try again. Details: {exc}") from exc
            entries = payload.get("data", []) if isinstance(payload, dict) else []
            ids = [str(item.get("id", "")) for item in entries if isinstance(item, dict) and item.get("id")]
        else:
            # build_model_router passes the IDs returned by the primary adapter's
            # successful /models request. This avoids four redundant discovery calls.
            ids = sorted({str(item) for item in verified_model_ids if str(item)})
        if not ids:
            raise LocalModelError("The server responded, but /models did not list any usable model IDs. The backend could not be verified.")
        self.available_model_ids = tuple(ids)
        if self.model and self.model not in ids:
            raise LocalModelError(f"Configured model '{self.model}' was not listed by the local server. Available model IDs: {', '.join(ids[:10])}")
        self.model = self.model or ids[0]
        self.model_path = f"local-server:{self.base_url}/{self.model}"

    def _request(self, path: str, method: str = "POST", body: dict | None = None) -> dict:
        import json
        from urllib.request import Request, build_opener, HTTPRedirectHandler, ProxyHandler
        from urllib.error import HTTPError, URLError
        class NoRedirect(HTTPRedirectHandler):
            def redirect_request(self, req, fp, code, msg, headers, newurl):
                return None
        data = json.dumps(body).encode("utf-8") if body is not None else None
        req = Request(self.base_url + path, data=data, method=method,
                      headers={"Content-Type": "application/json", "Accept": "application/json"})
        try:
            opener = build_opener(ProxyHandler({}), NoRedirect())
            with opener.open(req, timeout=self.timeout) as response:
                raw = response.read(8_000_000).decode("utf-8", errors="replace")
        except HTTPError as exc:
            detail = exc.read(4000).decode("utf-8", errors="replace")
            raise LocalModelError(f"Local model server returned HTTP {exc.code}: {detail}") from exc
        except (URLError, TimeoutError, OSError) as exc:
            raise LocalModelError(f"Local model server connection failed: {exc}") from exc
        try:
            result = json.loads(raw)
        except json.JSONDecodeError as exc:
            raise LocalModelError("Local model server returned invalid JSON.") from exc
        if not isinstance(result, dict):
            raise LocalModelError("Local model server returned an unexpected response shape.")
        return result

    def generate(self, system: str, user: str, max_tokens: int | None = None,
                 temperature: float | None = None) -> str:
        payload = self._request("/chat/completions", body={
            "model": self.model,
            "messages": [{"role": "system", "content": system}, {"role": "user", "content": user}],
            "max_tokens": max(64, int(max_tokens or self.max_tokens)),
            "temperature": self.temperature if temperature is None else float(temperature),
            "top_p": 0.9,
        })
        choices = payload.get("choices", [])
        content = choices[0].get("message", {}).get("content") if choices and isinstance(choices[0], dict) else None
        if not isinstance(content, str) or not content.strip():
            raise LocalModelError("The verified local server returned an empty or unsupported chat completion.")
        return content.strip()


class LocalModelManager:
    """Lazy, bounded LRU manager for in-process GGUF models.

    Only models needed for the current call are resident. Idle models are evicted
    before another one is loaded when the configured resident-model limit is reached.
    Active models are never evicted. A condition variable coordinates concurrent calls.
    """
    def __init__(self, max_loaded_models: int = 1, model_options: dict | None = None):
        import threading
        self.max_loaded_models = max(1, min(4, int(max_loaded_models)))
        self.model_options = dict(model_options or {})
        self._condition = threading.Condition(threading.RLock())
        self._loaded: dict[str, LocalModel] = {}
        self._active: dict[str, int] = {}
        self._last_used: dict[str, int] = {}
        self._loading: set[str] = set()
        self._clock = 0
        self.load_count = 0
        self.eviction_count = 0

    def _acquire(self, model_path: str) -> LocalModel:
        import gc
        while True:
            evicted = None
            with self._condition:
                if model_path in self._loaded:
                    self._active[model_path] = self._active.get(model_path, 0) + 1
                    self._clock += 1
                    self._last_used[model_path] = self._clock
                    return self._loaded[model_path]
                if model_path in self._loading:
                    self._condition.wait(timeout=1.0)
                    continue
                if len(self._loaded) + len(self._loading) >= self.max_loaded_models:
                    idle = [key for key in self._loaded if self._active.get(key, 0) == 0]
                    if idle:
                        victim = min(idle, key=lambda key: self._last_used.get(key, 0))
                        evicted = self._loaded.pop(victim)
                        self._last_used.pop(victim, None)
                        self._active.pop(victim, None)
                        self.eviction_count += 1
                    else:
                        self._condition.wait(timeout=1.0)
                        continue
                else:
                    self._loading.add(model_path)
            if evicted is not None:
                del evicted
                gc.collect()
                continue
            try:
                loaded = LocalModel(model_path, **self.model_options)
            except Exception:
                with self._condition:
                    self._loading.discard(model_path)
                    self._condition.notify_all()
                raise
            with self._condition:
                self._loading.discard(model_path)
                self._loaded[model_path] = loaded
                self._active[model_path] = 1
                self._clock += 1
                self._last_used[model_path] = self._clock
                self.load_count += 1
                self._condition.notify_all()
                return loaded

    def _release(self, model_path: str) -> None:
        with self._condition:
            active = self._active.get(model_path, 0)
            self._active[model_path] = max(0, active - 1)
            self._clock += 1
            self._last_used[model_path] = self._clock
            self._condition.notify_all()

    def generate(self, model_path: str, system: str, user: str,
                 max_tokens: int | None = None, temperature: float | None = None) -> str:
        model = self._acquire(model_path)
        try:
            return model.generate(system, user, max_tokens=max_tokens, temperature=temperature)
        finally:
            self._release(model_path)

    def snapshot(self) -> dict:
        with self._condition:
            return {
                "max_loaded_models": self.max_loaded_models,
                "currently_loaded": len(self._loaded),
                "loaded_model_files": [Path(path).name for path in self._loaded],
                "active_model_calls": sum(self._active.values()),
                "load_count": self.load_count,
                "eviction_count": self.eviction_count,
                "policy": "lazy LRU; active models are never evicted",
            }


class ManagedLocalModel:
    """Model-compatible lazy proxy, so existing role routing stays unchanged."""
    def __init__(self, manager: LocalModelManager, model_path: str):
        self.manager = manager
        self.model_manager = manager
        path = Path(model_path).expanduser().resolve()
        if not path.is_file():
            raise LocalModelError(f"Model file not found: {path}\nChoose an existing local .gguf model file.")
        if path.suffix.lower() != ".gguf":
            raise LocalModelError("This build expects a GGUF model file (.gguf).")
        self.model_path = str(path)

    def generate(self, system: str, user: str, max_tokens: int | None = None,
                 temperature: float | None = None) -> str:
        return self.manager.generate(
            self.model_path, system, user, max_tokens=max_tokens, temperature=temperature
        )


class RoleModelRouter:
    """Route Council roles to separately configured local models.

    Missing role assignments deliberately fall back to the primary local model.
    No hosted API, credentials, or network model discovery is performed here.
    """
    def __init__(self, primary, role_models: dict[str, object] | None = None):
        self.primary = primary
        self.role_models = dict(role_models or {})
        self.model_manager = getattr(primary, "model_manager", None)
        self.model_path = getattr(primary, "model_path", "local-primary")
        # A number of in-process inference backends (notably llama.cpp bindings)
        # are not safe to call concurrently through the same model instance. Keep
        # one lock per distinct instance: peers using the same model serialize,
        # while genuinely different specialist models can run in parallel.
        self._model_locks: dict[int, threading.RLock] = {}
        self._events_lock = threading.Lock()
        self.fallback_events: list[dict[str, str]] = []
        for model in [self.primary, *self.role_models.values()]:
            self._model_locks.setdefault(id(model), threading.RLock())

    @staticmethod
    def _label(model: object) -> str:
        model_id = getattr(model, "model", None)
        if isinstance(model_id, str) and model_id:
            return "local-server:" + model_id[:120]
        raw = str(getattr(model, "model_path", "") or "")
        if raw.startswith("local-server:"):
            return "local-server:" + raw.rsplit("/", 1)[-1][:120]
        return Path(raw).name[:120] if raw else type(model).__name__[:80]

    def generate(self, system: str, user: str, max_tokens: int | None = None,
                 temperature: float | None = None, role: str | None = None) -> str:
        model = self.role_models.get(str(role or ""), self.primary)
        lock = self._model_locks.setdefault(id(model), threading.RLock())
        if model is self.primary:
            with lock:
                return model.generate(system, user, max_tokens=max_tokens, temperature=temperature)
        try:
            with lock:
                return model.generate(system, user, max_tokens=max_tokens, temperature=temperature)
        except Exception as specialist_error:
            primary_lock = self._model_locks.setdefault(id(self.primary), threading.RLock())
            try:
                with primary_lock:
                    output = self.primary.generate(
                        system, user, max_tokens=max_tokens, temperature=temperature
                    )
            except Exception as primary_error:
                raise LocalModelError(
                    f"Assigned local model '{self._label(model)}' failed ({specialist_error}); "
                    f"the primary fallback '{self._label(self.primary)}' also failed ({primary_error})."
                ) from primary_error
            with self._events_lock:
                self.fallback_events.append({
                    "role": str(role or "unassigned")[:80],
                    "failed_model": self._label(model),
                    "fallback_model": self._label(self.primary),
                    "reason": str(specialist_error)[:500],
                })
                del self.fallback_events[:-100]
            return output

    def configured_roles(self) -> dict[str, str]:
        return {role: str(getattr(model, "model_path", type(model).__name__))
                for role, model in self.role_models.items()}


def build_model_router(settings: dict):
    """Build a primary model and reuse instances for identical peer assignments.

    Loading the same GGUF file four times can exhaust RAM/VRAM for no benefit.
    Local-server role adapters also share the primary adapter's verified model list,
    so model discovery happens once per router construction.
    """
    backend = settings.get("model_backend", "gguf")
    valid_roles = {"architect", "correctness", "security", "redteam"}
    role_models: dict[str, object] = {}

    if backend == "local-server":
        base_url = settings.get("local_server_url", "http://127.0.0.1:8080/v1")
        common = {
            "max_tokens": settings.get("max_tokens", 4096),
            "temperature": settings.get("temperature", 0.2),
            "timeout": settings.get("model_timeout_seconds", 600),
        }
        primary = LocalServerModel(base_url, settings.get("local_server_model", ""), **common)
        cache = {primary.model: primary}
        role_ids = settings.get("local_server_role_models", {})
        if isinstance(role_ids, dict):
            for role, raw_model_id in role_ids.items():
                if role not in valid_roles or not isinstance(raw_model_id, str) or not raw_model_id.strip():
                    continue
                model_id = raw_model_id.strip()
                if model_id not in cache:
                    cache[model_id] = LocalServerModel(
                        base_url, model_id, verified_model_ids=set(primary.available_model_ids), **common
                    )
                if model_id != primary.model:
                    role_models[role] = cache[model_id]
    else:
        common = {
            "n_ctx": settings.get("n_ctx", 8192),
            "n_threads": settings.get("n_threads", 4),
            "n_gpu_layers": settings.get("n_gpu_layers", 0),
            "max_tokens": settings.get("max_tokens", 4096),
            "temperature": settings.get("temperature", 0.2),
        }
        primary_path = Path(settings.get("model_path", "")).expanduser().resolve()
        manager = LocalModelManager(
            max_loaded_models=settings.get("max_loaded_peer_models", 1),
            model_options=common,
        )
        primary = ManagedLocalModel(manager, str(primary_path))
        cache = {str(primary_path): primary}
        role_paths = settings.get("role_model_paths", {})
        if isinstance(role_paths, dict):
            for role, raw_path in role_paths.items():
                if role not in valid_roles or not isinstance(raw_path, str) or not raw_path.strip():
                    continue
                model_path = str(Path(raw_path).expanduser().resolve())
                if model_path not in cache:
                    cache[model_path] = ManagedLocalModel(manager, model_path)
                if model_path != str(primary_path):
                    role_models[role] = cache[model_path]
    return RoleModelRouter(primary, role_models)
