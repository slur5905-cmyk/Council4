"""Bounded, read-only workspace scanner."""
from __future__ import annotations
from pathlib import Path
import re
from .safety import IGNORED_DIRS, TEXT_SUFFIXES, is_secret_path, is_within, is_ignored_directory_name, redact_sensitive_text

PRIORITY_NAMES = ["readme", "pyproject", "package.json", "Cargo.toml", "go.mod", "requirements", "main", "app", "index"]
QUERY_STOP_WORDS = {
    "about", "after", "also", "and", "are", "for", "from", "implement", "into", "its",
    "make", "need", "please", "should", "that", "the", "their", "them", "then", "this",
    "with", "would", "your",
}
MAX_RELEVANCE_CONTENT_FILES = 4000
RELEVANCE_SAMPLE_CHARS = 4096


def _priority(path: Path) -> tuple[int, int, str]:
    name = path.name.lower()
    order = 0
    for i, term in enumerate(PRIORITY_NAMES):
        if term in name:
            order = i + 1
            break
    suffix_order = 0 if path.suffix.lower() in {".py", ".ts", ".tsx", ".js", ".jsx", ".rs", ".go", ".java", ".cs", ".cpp", ".c"} else 1
    return (0 if order else 1, order or suffix_order, name)


def _query_terms(query: str | None) -> list[str]:
    terms = re.findall(r"[a-zA-Z_][a-zA-Z0-9_+-]{2,}", str(query or "").lower())
    return list(dict.fromkeys(term for term in terms if term not in QUERY_STOP_WORDS))[:40]


def _task_relevance(path: Path, root: Path, terms: list[str], inspect_content: bool) -> int:
    relative = path.relative_to(root).as_posix().lower()
    filename = path.name.lower()
    score = 0
    for term in terms:
        if term in filename:
            score += 12
        elif term in relative:
            score += 8
    if inspect_content:
        try:
            with path.open("r", encoding="utf-8", errors="replace") as stream:
                sample = stream.read(RELEVANCE_SAMPLE_CHARS).lower()
        except OSError:
            sample = ""
        score += sum(min(3, sample.count(term)) for term in terms)
    return score


def collect_workspace_context(workspace: Path, max_chars: int = 24000, max_files: int = 90, max_scan_files: int = 20000, max_scan_dirs: int = 8000, query: str | None = None) -> str:
    root = workspace.expanduser().resolve()
    if not root.exists() or not root.is_dir():
        return "[No valid workspace selected. The task may still be answered conceptually.]"
    candidates: list[Path] = []
    scanned_files = 0
    scanned_dirs = 0
    scan_truncated = False
    for base, dirs, files in __import__("os").walk(root, followlinks=False):
        scanned_dirs += 1
        if scanned_dirs > max_scan_dirs:
            scan_truncated = True
            break
        base_path = Path(base)
        dirs[:] = sorted(d for d in dirs if not is_ignored_directory_name(d) and not (base_path / d).is_symlink())
        for name in sorted(files):
            scanned_files += 1
            if scanned_files > max_scan_files:
                scan_truncated = True
                dirs[:] = []
                break
            p = base_path / name
            if p.is_symlink() or not is_within(p, root):
                continue
            rel = p.relative_to(root).as_posix()
            if is_secret_path(rel):
                continue
            if p.suffix.lower() in TEXT_SUFFIXES or name.lower() in {"makefile", "dockerfile", ".gitignore", ".editorconfig"}:
                try:
                    if p.stat().st_size <= 160_000:
                        candidates.append(p)
                except OSError:
                    pass
    candidates.sort(key=_priority)
    terms = _query_terms(query)
    if terms:
        ranked = []
        for index, path in enumerate(candidates):
            score = _task_relevance(path, root, terms, index < MAX_RELEVANCE_CONTENT_FILES)
            ranked.append((-score, _priority(path), path.as_posix().lower(), path))
        candidates = [item[3] for item in sorted(ranked)]
    chunks: list[str] = []
    used = 0
    for path in candidates[:max_files]:
        try:
            data = path.read_text(encoding="utf-8", errors="replace")
            data = redact_sensitive_text(data)
        except OSError:
            continue
        rel = path.relative_to(root).as_posix()
        header = f"\n===== FILE: {rel} =====\n"
        allowance = max_chars - used - len(header)
        if allowance <= 0:
            break
        if len(data) > allowance:
            data = data[:allowance] + "\n...[truncated to fit context]..."
        block = header + data
        chunks.append(block)
        used += len(block)
        if used >= max_chars:
            break
    if not chunks:
        empty = "[Workspace contains no readable source/text files, or it is currently empty.]"
        return empty + ("\n[Workspace scan stopped at its configured safety limit; context may be incomplete.]" if scan_truncated else "")
    context = "\n".join(chunks)
    if scan_truncated:
        context += "\n\n[Workspace scan stopped at its configured safety limit; context may be incomplete.]"
    return context
