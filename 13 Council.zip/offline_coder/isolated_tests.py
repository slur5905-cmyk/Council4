"""Optional Docker-isolated smoke tests for Python proposals.

The host never executes generated code directly. If Docker and the exact local image
are already installed, run tests in a no-network, resource-limited disposable container.
If the isolation runtime is unavailable, report SKIPPED rather than pretending tests ran.
"""
from __future__ import annotations
import json
import os
import re
import shutil
import subprocess
import tempfile
from pathlib import Path
from typing import Mapping, Any
from .safety import IGNORED_DIRS, MANAGED_DIR_NAME, is_secret_path, is_ignored_directory_name

IGNORED = {'.git', '.venv', 'venv', 'env', 'node_modules', '__pycache__', '.council', 'dist', 'build', 'target'}
MAX_COPY_BYTES = 30 * 1024 * 1024
MAX_COPY_FILES = 20_000
MAX_COPY_DIRS = 8_000
MAX_PROPOSED_FILES = 500
MAX_PROPOSED_BYTES = 30 * 1024 * 1024
MAX_SIMULATION_MANIFEST_BYTES = 1_000_000


def _overlay_proposed_files(snapshot: Path, proposed_files: Mapping[str, str], runner_label: str) -> str | None:
    """Overlay a bounded proposal into a disposable snapshot using canonical safe paths."""
    if not isinstance(proposed_files, Mapping):
        return f"Invalid proposal refused by {runner_label}: expected a path-to-text mapping."
    if len(proposed_files) > MAX_PROPOSED_FILES:
        return f"Proposal has more than {MAX_PROPOSED_FILES} files; {runner_label} refused it."
    total_bytes = 0
    normalized: list[tuple[Path, str, str]] = []
    for raw, content in proposed_files.items():
        if not isinstance(raw, str) or not isinstance(content, str):
            return f"Invalid proposal refused by {runner_label}: paths and contents must be strings."
        rel = Path(raw)
        if (not raw or raw != raw.strip() or "\\" in raw or rel.is_absolute()
                or rel.as_posix() != raw or ".." in rel.parts
                or (rel.parts and len(rel.parts[0]) >= 2 and rel.parts[0][1] == ":")):
            return f"Unsafe or non-canonical proposed path refused by {runner_label}: {raw}"
        if not rel.parts or any(part.lower() in IGNORED_DIRS or part.lower() == MANAGED_DIR_NAME.lower() for part in rel.parts):
            return f"Protected or generated path refused by {runner_label}: {raw}"
        if is_secret_path(rel.as_posix()):
            return f"Sensitive path refused by {runner_label}: {raw}"
        size = len(content.encode("utf-8"))
        if size > 1_000_000:
            return f"Proposed file exceeds the 1 MB limit in {runner_label}: {raw}"
        total_bytes += size
        if total_bytes > MAX_PROPOSED_BYTES:
            return f"Proposal exceeds the 30 MB snapshot limit in {runner_label}."
        normalized.append((rel, raw, content))

    for rel, raw, content in normalized:
        target = snapshot / rel
        current = snapshot
        for part in rel.parts[:-1]:
            current = current / part
            if current.is_symlink():
                return f"Symlink parent refused by {runner_label}: {raw}"
            if current.exists() and not current.is_dir():
                return f"Non-directory parent refused by {runner_label}: {raw}"
        if target.is_symlink() or (target.exists() and not target.is_file()):
            return f"Unsafe existing target refused by {runner_label}: {raw}"
        try:
            target.parent.mkdir(parents=True, exist_ok=True)
            # Re-check after directory creation to catch obvious path substitutions.
            current = snapshot
            for part in rel.parts[:-1]:
                current = current / part
                if current.is_symlink() or not current.is_dir():
                    return f"Unsafe parent refused by {runner_label}: {raw}"
            if target.is_symlink() or (target.exists() and not target.is_file()):
                return f"Unsafe target refused by {runner_label}: {raw}"
            target.write_text(content, encoding="utf-8")
        except OSError as exc:
            return f"Could not stage proposed file in {runner_label} ({raw}): {exc}"
    return None


def _copy_workspace(root: Path, dest: Path) -> None:
    copied = 0
    visited_files = 0
    visited_dirs = 0
    for base, dirs, files in os.walk(root, followlinks=False):
        visited_dirs += 1
        if visited_dirs > MAX_COPY_DIRS:
            raise ValueError(f"Workspace has more than {MAX_COPY_DIRS:,} directories; automatic tests were skipped.")
        bp = Path(base)
        dirs[:] = sorted(d for d in dirs if not is_ignored_directory_name(d) and not (bp / d).is_symlink() and not is_secret_path((bp / d).relative_to(root).as_posix()))
        for name in sorted(files):
            visited_files += 1
            if visited_files > MAX_COPY_FILES:
                raise ValueError(f"Workspace has more than {MAX_COPY_FILES:,} files; automatic tests were skipped.")
            src = bp / name
            if src.is_symlink() or src.suffix.lower() in {'.sqlite', '.sqlite3', '.db', '.pem', '.key', '.p12', '.pfx'}:
                continue
            try:
                rel = src.relative_to(root)
                if is_secret_path(rel.as_posix()):
                    continue
                if not src.is_file() or src.stat().st_size > 1_000_000:
                    continue
                copied += src.stat().st_size
                if copied > MAX_COPY_BYTES:
                    raise ValueError('Workspace test snapshot exceeds 30 MB; automatic tests were skipped.')
                target = dest / rel
                target.parent.mkdir(parents=True, exist_ok=True)
                shutil.copyfile(src, target)
            except OSError:
                continue


def run_isolated_python_checks(workspace: Path, proposed_files: Mapping[str, str], timeout: int = 45) -> dict[str, Any]:
    """Test a candidate in a disposable Docker container with network disabled.

    Only runs if a Python file exists and Docker plus python:3.12-slim are already
    available locally. Never pulls an image automatically. Tests can still be buggy;
    the container limits risk but is not a formally verified sandbox.
    """
    if not any(Path(name).suffix.lower() == '.py' for name in proposed_files):
        return {'status': 'NOT_APPLICABLE', 'summary': 'No proposed Python files; no Python test run was needed.', 'output': ''}
    docker = shutil.which('docker')
    if not docker:
        return {'status': 'SKIPPED', 'summary': 'Docker is not installed; generated code was not executed.', 'output': ''}
    image = 'python:3.12-slim'
    try:
        inspect = subprocess.run([docker, 'image', 'inspect', image], capture_output=True, text=True, timeout=8)
    except (OSError, subprocess.SubprocessError) as exc:
        return {'status': 'SKIPPED', 'summary': f'Could not inspect the preinstalled Python image safely: {exc}', 'output': ''}
    if inspect.returncode != 0:
        return {'status': 'SKIPPED', 'summary': f'Docker image {image} is not already installed; no image was downloaded and no code was executed.', 'output': ''}

    root = Path(workspace).expanduser().resolve()
    try:
        with tempfile.TemporaryDirectory(prefix='coding-council-test-') as td:
            snapshot = Path(td) / 'workspace'
            snapshot.mkdir()
            _copy_workspace(root, snapshot)
            overlay_error = _overlay_proposed_files(snapshot, proposed_files, "Python test runner")
            if overlay_error:
                return {'status': 'FAILED', 'summary': overlay_error, 'output': ''}
            for directory, subdirs, files in os.walk(snapshot):
                try:
                    Path(directory).chmod(0o777)
                except OSError:
                    pass
                for filename in files:
                    try:
                        (Path(directory) / filename).chmod(0o666)
                    except OSError:
                        pass
            runner_script = (
                'import compileall, pathlib, sys, unittest; '
                'root=pathlib.Path("/workspace"); '
                'ok=compileall.compile_dir(str(root), quiet=1, force=True); '
                'print("PYTHON_COMPILE:", "PASS" if ok else "FAIL"); '
                'sys.exit(2) if not ok else None; '
                'tests=root/"tests"; '
                'suite=unittest.defaultTestLoader.discover(str(tests), top_level_dir=str(root)) if tests.is_dir() else unittest.TestSuite(); '
                'print("UNITTEST_DISCOVERY:", "tests found" if suite.countTestCases() else "no unittest tests discovered"); '
                'result=unittest.TextTestRunner(verbosity=2).run(suite); '
                'skipped=len(getattr(result, "skipped", [])); '
                'executed=max(0, result.testsRun-skipped); '
                'print(f"UNITTEST_RESULTS: run={result.testsRun} skipped={skipped} executed={executed} failures={len(result.failures)} errors={len(result.errors)}"); '
                'sys.exit(0 if result.wasSuccessful() else 1)'
            )
            cmd = [docker, 'run', '--rm', '--network', 'none', '--read-only', '--cap-drop', 'ALL',
                   '--security-opt', 'no-new-privileges', '--memory', '512m', '--cpus', '1', '--pids-limit', '128',
                   '--tmpfs', '/tmp:rw,noexec,nosuid,size=64m', '-v', f'{snapshot}:/workspace:rw', '-w', '/workspace',
                   '--user', '65534:65534', image, 'python', '-c', runner_script]
            try:
                run = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout)
            except subprocess.TimeoutExpired as exc:
                out = (exc.stdout or '') + '\n' + (exc.stderr or '')
                return {'status': 'FAILED', 'summary': f'Isolated Python checks exceeded {timeout} seconds and were stopped.', 'output': out[-12000:]}
            output = ((run.stdout or '') + '\n' + (run.stderr or '')).strip()[-12000:]
            # A successful empty unittest suite is not evidence that behavior was tested.
            no_tests = 'UNITTEST_DISCOVERY: no unittest tests discovered' in output
            results_match = re.search(r'UNITTEST_RESULTS: run=(\d+) skipped=(\d+) executed=(\d+)', output)
            no_executed_tests = bool(results_match and int(results_match.group(3)) == 0)
            if run.returncode != 0:
                status = 'FAILED'
                summary = f'Isolated Python checks failed (exit code {run.returncode}).'
            elif no_tests or no_executed_tests:
                status = 'NO_TESTS'
                summary = 'Python compilation passed, but no unittest tests were discovered or no non-skipped cases executed; behavior is not verified.'
            else:
                # Project-owned unittest modules execute during discovery and can terminate
                # this process (or print forged summary markers). A successful exit and
                # self-reported output are useful diagnostics, but are not independent
                # host evidence and must never qualify a candidate as verified.
                status = 'UNTRUSTED_TESTS'
                summary = ('Python compilation passed and project-owned unittest code exited '
                           'successfully in the isolated container. Its own test output is '
                           'untrusted and is not proof of correctness or candidate eligibility.')
            return {'status': status, 'summary': summary, 'output': output, 'exit_code': run.returncode}
    except (OSError, ValueError, subprocess.SubprocessError) as exc:
        return {'status': 'SKIPPED', 'summary': f'Isolated testing could not start safely: {exc}', 'output': ''}



def _last_node_tap_summary_value(test_output: str, label: str) -> int | None:
    """Read the final Node TAP summary line, never an earlier test-console comment.

    Node prefixes test stdout with `# `, so a project test can print text that looks
    exactly like a TAP summary. The runner's real summary is emitted after test output;
    selecting the final exact summary line prevents an earlier console line from winning.
    """
    if label not in {"tests", "pass", "fail", "skipped"}:
        return None
    pattern = re.compile(rf"(?m)^(?:# |ℹ ){re.escape(label)} (\d+)\s*$")
    matches = list(pattern.finditer(test_output))
    return int(matches[-1].group(1)) if matches else None


def _node_tap_has_real_test_records(test_output: str, test_files: list[str]) -> bool:
    """Exclude Node's synthetic per-file success record when a test file is empty.

    `node --test empty.test.js` emits a passing record for the file itself even when
    it registers zero test cases. A real node:test case gets its own TAP record whose
    name differs from the discovered file path. User console output is TAP-commented
    by Node's runner and therefore does not match these anchored records.
    """
    known_paths = {Path(name).as_posix() for name in test_files}
    known_names = {Path(name).name for name in test_files}
    for raw_name in re.findall(r"(?m)^ok\s+\d+\s+-\s+(.+?)\s*$", test_output):
        name = raw_name.strip().strip('"')
        normalized = name.replace("\\", "/")
        if normalized in known_paths or Path(normalized).name in known_names:
            continue
        return True
    return False

def _validated_node_script_args(paths: list[str]) -> list[str]:
    """Validate discovered Node script paths and add an option terminator.

    A workspace can contain a file literally named ``--eval``. Reject flag-shaped
    filenames and always terminate Node option parsing before script paths.
    """
    safe: list[str] = []
    for raw in paths:
        if (not isinstance(raw, str) or not raw or raw.startswith("-")
                or "\x00" in raw or raw.startswith("/") or "\\" in raw
                or any(part in {"", ".", ".."} for part in raw.split("/"))):
            raise ValueError(f"Unsafe Node script path refused: {raw!r}")
        safe.append(raw)
    return ["--", *safe]


def run_isolated_node_checks(workspace: Path, proposed_files: Mapping[str, str], timeout: int = 45) -> dict[str, Any]:
    """Run JavaScript syntax checks and built-in node:test suites in a preinstalled offline image."""
    relevant = {name: content for name, content in proposed_files.items()
                if Path(name).suffix.lower() in {'.js', '.mjs', '.cjs'} or Path(name).name.lower() == 'package.json'}
    if not relevant:
        return {'status': 'NOT_APPLICABLE', 'summary': 'No JavaScript/Node files were proposed.', 'output': ''}
    docker = shutil.which('docker')
    if not docker:
        return {'status': 'SKIPPED', 'summary': 'Docker is not installed; JavaScript was not executed.', 'output': ''}
    image = 'node:22-alpine'
    try:
        inspect = subprocess.run([docker, 'image', 'inspect', image], capture_output=True, text=True, timeout=8)
    except (OSError, subprocess.SubprocessError) as exc:
        return {'status': 'SKIPPED', 'summary': f'Could not inspect the preinstalled Node image: {exc}', 'output': ''}
    if inspect.returncode != 0:
        return {'status': 'SKIPPED', 'summary': f'Docker image {image} is not already installed; no image was downloaded and no code was executed.', 'output': ''}

    root = Path(workspace).expanduser().resolve()
    try:
        with tempfile.TemporaryDirectory(prefix='coding-council-node-') as td:
            snapshot = Path(td) / 'workspace'
            snapshot.mkdir()
            _copy_workspace(root, snapshot)
            overlay_error = _overlay_proposed_files(snapshot, proposed_files, "Node test runner")
            if overlay_error:
                return {'status': 'FAILED', 'summary': overlay_error, 'output': ''}
            source_files = []
            test_files = []
            for base, dirs, files in os.walk(snapshot, followlinks=False):
                dirs[:] = sorted(d for d in dirs if d not in IGNORED and not (Path(base) / d).is_symlink())
                for filename in sorted(files):
                    path = Path(base) / filename
                    rel = path.relative_to(snapshot).as_posix()
                    if path.suffix.lower() not in {'.js', '.mjs', '.cjs'}:
                        continue
                    source_files.append(rel)
                    lower = rel.lower()
                    if ('.test.' in lower or '.spec.' in lower or lower.startswith('test/') or '/test/' in lower or lower.startswith('tests/') or '/tests/' in lower):
                        test_files.append(rel)
            if not source_files:
                return {'status': 'NO_TESTS', 'summary': 'Node project files were changed, but no JavaScript files were available for syntax/runtime verification.', 'output': ''}
            # Paths are relative to the disposable snapshot. Reject option-shaped paths
            # and end Node's option parsing before supplying any workspace-controlled name.
            try:
                source_args = _validated_node_script_args(source_files)
                test_args = _validated_node_script_args(test_files) if test_files else ["--"]
            except ValueError as exc:
                return {'status': 'FAILED', 'summary': str(exc), 'output': ''}
            syntax = subprocess.run([docker, 'run', '--rm', '--network', 'none', '--read-only', '--cap-drop', 'ALL',
                                     '--security-opt', 'no-new-privileges', '--memory', '512m', '--cpus', '1', '--pids-limit', '128',
                                     '--tmpfs', '/tmp:rw,noexec,nosuid,size=64m', '-v', f'{snapshot}:/workspace:ro', '-w', '/workspace',
                                     '--user', '65534:65534', image, 'node', '--check', *source_args],
                                    capture_output=True, text=True, timeout=timeout)
            output = ((syntax.stdout or '') + '\n' + (syntax.stderr or '')).strip()[-12000:]
            if syntax.returncode != 0:
                return {'status': 'FAILED', 'summary': 'Isolated Node.js syntax check failed.', 'output': output, 'exit_code': syntax.returncode}
            if not test_files:
                return {'status': 'NO_TESTS', 'summary': 'JavaScript syntax checks passed, but no Node test files were discovered; behavior is not verified.', 'output': output}
            tests = subprocess.run([docker, 'run', '--rm', '--network', 'none', '--read-only', '--cap-drop', 'ALL',
                                    '--security-opt', 'no-new-privileges', '--memory', '512m', '--cpus', '1', '--pids-limit', '128',
                                    '--tmpfs', '/tmp:rw,noexec,nosuid,size=64m', '-v', f'{snapshot}:/workspace:ro', '-w', '/workspace',
                                    '--user', '65534:65534', image, 'node', '--test', *test_args],
                                   capture_output=True, text=True, timeout=timeout)
            test_output = ((tests.stdout or '') + '\n' + (tests.stderr or '')).strip()[-12000:]
            combined = (output + '\n' + test_output).strip()[-12000:]
            if tests.returncode != 0:
                return {'status': 'FAILED', 'summary': f'Isolated Node.js tests failed (exit code {tests.returncode}).', 'output': combined, 'exit_code': tests.returncode}
            total = _last_node_tap_summary_value(test_output, "tests")
            passed = _last_node_tap_summary_value(test_output, "pass")
            failed = _last_node_tap_summary_value(test_output, "fail")
            skipped = _last_node_tap_summary_value(test_output, "skipped")
            # A zero exit code is not enough: malformed/missing summaries and test logs
            # that imitate summary lines must not be promoted to PASSED.
            if any(value is None for value in (total, passed, failed, skipped)):
                return {'status': 'FAILED', 'summary': 'Node test runner exited successfully but did not emit a complete, parseable final TAP summary; results are unverified.', 'output': combined, 'exit_code': tests.returncode}
            if total == 0:
                return {'status': 'NO_TESTS', 'summary': 'Node test command found no tests; behavior is not verified.', 'output': combined, 'exit_code': tests.returncode}
            if failed > 0:
                return {'status': 'FAILED', 'summary': f'Node test summary reports {failed} failed test(s).', 'output': combined, 'exit_code': tests.returncode}
            if passed == 0 or skipped >= total or passed + skipped > total:
                return {'status': 'NO_TESTS', 'summary': 'Node test discovery did not demonstrate at least one passing, non-skipped test; behavior is not verified.', 'output': combined, 'exit_code': tests.returncode}
            if not _node_tap_has_real_test_records(test_output, test_files):
                return {'status': 'NO_TESTS', 'summary': 'Node reported a passing test-file process but no actual registered test cases; behavior is not verified.', 'output': combined, 'exit_code': tests.returncode}
            # The tested project controls its own test modules and can manufacture
            # plausible TAP output or choose a zero exit code. Until an independent
            # host-owned acceptance runner exists, Node tests remain diagnostic only.
            return {'status': 'UNTRUSTED_TESTS', 'summary': 'JavaScript syntax checks passed and Node tests exited successfully in a disposable no-network Docker container, but project-controlled TAP output is not host-verified evidence.', 'output': combined, 'exit_code': tests.returncode, 'host_evidence_verified': False}
    except subprocess.TimeoutExpired as exc:
        out = ((exc.stdout or '') + '\n' + (exc.stderr or '')) if isinstance(exc.stdout, str) else 'Node test output was unavailable.'
        return {'status': 'FAILED', 'summary': f'Isolated Node.js checks exceeded {timeout} seconds and were stopped.', 'output': out[-12000:]}
    except (OSError, ValueError, subprocess.SubprocessError) as exc:
        return {'status': 'SKIPPED', 'summary': f'Isolated Node.js testing could not start safely: {exc}', 'output': ''}



def run_project_simulations(workspace: Path, proposed_files: Mapping[str, str], timeout: int = 20) -> dict[str, Any]:
    """Run explicitly configured Python/Node smoke or end-to-end scenarios in offline Docker.

    Manifest: council.simulations.json at the workspace root. Example:
    {"scenarios":[{"name":"CLI help", "runtime":"python", "script":"main.py", "args":["--help"], "expect_exit_code":0, "expect_output_contains":"usage"}]}
    Scenarios execute only inside disposable, no-network containers. Commands are argv arrays,
    never shell strings; only Python or Node entry scripts inside the copied workspace are allowed.
    """
    manifest_name = 'council.simulations.json'
    root = Path(workspace).expanduser().resolve()
    proposed_manifest = proposed_files.get(manifest_name)
    manifest_path = root / manifest_name
    if proposed_manifest is None:
        # Treat manifests as project-controlled input, but never follow a symlink or
        # read an unbounded file outside the managed workspace.
        if manifest_path.is_symlink():
            return {'status': 'FAILED', 'summary': 'Simulation manifest must be a regular file, not a symlink.', 'output': '', 'scenarios': []}
        if not manifest_path.exists():
            return {'status': 'NOT_APPLICABLE', 'summary': 'No council.simulations.json manifest configured; explicit runtime simulations were not requested.', 'output': '', 'scenarios': []}
        if not manifest_path.is_file():
            return {'status': 'FAILED', 'summary': 'Simulation manifest must be a regular file.', 'output': '', 'scenarios': []}
        try:
            if manifest_path.stat().st_size > MAX_SIMULATION_MANIFEST_BYTES:
                return {'status': 'FAILED', 'summary': 'Simulation manifest exceeds the 1 MB limit.', 'output': '', 'scenarios': []}
            manifest_text = manifest_path.read_text(encoding='utf-8')
        except (OSError, UnicodeError) as exc:
            return {'status': 'FAILED', 'summary': f'Simulation manifest is unreadable: {exc}', 'output': '', 'scenarios': []}
    else:
        if not isinstance(proposed_manifest, str) or len(proposed_manifest.encode('utf-8')) > MAX_SIMULATION_MANIFEST_BYTES:
            return {'status': 'FAILED', 'summary': 'Proposed simulation manifest exceeds the 1 MB limit or is not text.', 'output': '', 'scenarios': []}
        manifest_text = proposed_manifest
    try:
        manifest = json.loads(manifest_text)
    except (OSError, UnicodeError, json.JSONDecodeError) as exc:
        return {'status': 'FAILED', 'summary': f'Simulation manifest is unreadable or invalid JSON: {exc}', 'output': '', 'scenarios': []}
    scenarios = manifest.get('scenarios') if isinstance(manifest, dict) else None
    if not isinstance(scenarios, list) or not scenarios:
        return {'status': 'NO_TESTS', 'summary': 'Simulation manifest must contain a non-empty scenarios list.', 'output': '', 'scenarios': []}
    if len(scenarios) > 10:
        return {'status': 'FAILED', 'summary': 'At most 10 simulation scenarios are allowed per run.', 'output': '', 'scenarios': []}
    validated: list[dict[str, Any]] = []
    images: set[str] = set()
    for index, raw in enumerate(scenarios):
        if not isinstance(raw, dict):
            return {'status': 'FAILED', 'summary': f'Simulation scenario {index + 1} must be an object.', 'output': '', 'scenarios': []}
        runtime = str(raw.get('runtime', '')).lower()
        script = str(raw.get('script', '')).replace('\\', '/')
        rel = Path(script)
        args = raw.get('args', [])
        if runtime not in {'python', 'node'} or not script or rel.is_absolute() or '..' in rel.parts or not rel.parts or not isinstance(args, list) or len(args) > 20 or any(not isinstance(a, (str, int, float)) for a in args):
            return {'status': 'FAILED', 'summary': f'Simulation scenario {index + 1} has an unsafe runtime, script path, or arguments.', 'output': '', 'scenarios': []}
        if (runtime == 'python' and rel.suffix.lower() != '.py') or (runtime == 'node' and rel.suffix.lower() not in {'.js', '.mjs', '.cjs'}):
            return {'status': 'FAILED', 'summary': f'Simulation scenario {index + 1} script extension does not match runtime.', 'output': '', 'scenarios': []}
        expected_exit = raw.get('expect_exit_code', 0)
        if not isinstance(expected_exit, int) or expected_exit < 0 or expected_exit > 255:
            return {'status': 'FAILED', 'summary': f'Simulation scenario {index + 1} has an invalid expected exit code.', 'output': '', 'scenarios': []}
        expected_text = raw.get('expect_output_contains', '')
        if not isinstance(expected_text, str) or len(expected_text) > 500:
            return {'status': 'FAILED', 'summary': f'Simulation scenario {index + 1} has invalid output assertion.', 'output': '', 'scenarios': []}
        timeout_s = raw.get('timeout_seconds', timeout)
        if not isinstance(timeout_s, int) or timeout_s < 1 or timeout_s > 30:
            return {'status': 'FAILED', 'summary': f'Simulation scenario {index + 1} timeout must be 1–30 seconds.', 'output': '', 'scenarios': []}
        image = 'python:3.12-slim' if runtime == 'python' else 'node:22-alpine'
        images.add(image)
        validated.append({'name': str(raw.get('name', f'Scenario {index + 1}'))[:120], 'runtime': runtime, 'script': rel.as_posix(), 'args': [str(a)[:500] for a in args], 'expect_exit_code': expected_exit, 'expect_output_contains': expected_text, 'timeout_seconds': timeout_s, 'image': image})

    docker = shutil.which('docker')
    if not docker:
        return {'status': 'SKIPPED', 'summary': 'Docker is not installed; configured simulations were not executed.', 'output': '', 'scenarios': []}

    for image in sorted(images):
        try:
            inspect = subprocess.run([docker, 'image', 'inspect', image], capture_output=True, text=True, timeout=8)
        except (OSError, subprocess.SubprocessError) as exc:
            return {'status': 'SKIPPED', 'summary': f'Could not inspect local simulation image {image}: {exc}', 'output': '', 'scenarios': []}
        if inspect.returncode != 0:
            return {'status': 'SKIPPED', 'summary': f'Docker image {image} is not already installed; no image was downloaded and no simulations ran.', 'output': '', 'scenarios': []}

    try:
        with tempfile.TemporaryDirectory(prefix='coding-council-sim-') as td:
            snapshot = Path(td) / 'workspace'; snapshot.mkdir()
            _copy_workspace(root, snapshot)
            overlay_error = _overlay_proposed_files(snapshot, proposed_files, "simulation runner")
            if overlay_error:
                return {'status': 'FAILED', 'summary': overlay_error, 'output': '', 'scenarios': []}
            # Let the unprivileged container user write only inside this disposable snapshot.
            for directory, _subdirs, files in os.walk(snapshot):
                try:
                    Path(directory).chmod(0o777)
                except OSError:
                    pass
                for filename in files:
                    try:
                        (Path(directory) / filename).chmod(0o666)
                    except OSError:
                        pass
            reports = []
            for scenario in validated:
                script_path = snapshot / scenario['script']
                if not script_path.is_file() or script_path.is_symlink():
                    reports.append({'name': scenario['name'], 'status': 'FAILED', 'summary': f"Scenario script not found in isolated workspace: {scenario['script']}", 'output': ''})
                    continue
                runtime_cmd = 'python' if scenario['runtime'] == 'python' else 'node'
                cmd = [docker, 'run', '--rm', '--network', 'none', '--read-only', '--cap-drop', 'ALL', '--security-opt', 'no-new-privileges', '--memory', '512m', '--cpus', '1', '--pids-limit', '128', '--tmpfs', '/tmp:rw,noexec,nosuid,size=64m', '-v', f'{snapshot}:/workspace:rw', '-w', '/workspace', '--user', '65534:65534', scenario['image'], runtime_cmd, '/workspace/' + scenario['script'], *scenario['args']]
                try:
                    run = subprocess.run(cmd, capture_output=True, text=True, timeout=scenario['timeout_seconds'])
                    output = ((run.stdout or '') + '\n' + (run.stderr or '')).strip()[-6000:]
                    ok = run.returncode == scenario['expect_exit_code'] and (scenario['expect_output_contains'] in output if scenario['expect_output_contains'] else True)
                    reports.append({'name': scenario['name'], 'status': 'PASSED' if ok else 'FAILED', 'summary': 'Scenario assertions passed.' if ok else f"Expected exit {scenario['expect_exit_code']}, got {run.returncode}, or expected output assertion was absent.", 'exit_code': run.returncode, 'output': output})
                except subprocess.TimeoutExpired as exc:
                    out = exc.stdout if isinstance(exc.stdout, str) else 'No output captured before timeout.'
                    reports.append({'name': scenario['name'], 'status': 'FAILED', 'summary': f"Scenario exceeded {scenario['timeout_seconds']} seconds and was stopped.", 'output': out[-6000:]})
            statuses = [item['status'] for item in reports]
            status = 'FAILED' if 'FAILED' in statuses else 'PASSED'
            output = '\n\n'.join(f"[{item['name']}] {item['status']}\n{item.get('output', '')}" for item in reports)[-16000:]
            return {'status': status, 'summary': f"{sum(x == 'PASSED' for x in statuses)}/{len(statuses)} configured simulation scenarios passed in offline containers.", 'output': output, 'scenarios': reports}
    except (OSError, ValueError, subprocess.SubprocessError) as exc:
        return {'status': 'SKIPPED', 'summary': f'Simulations could not start safely: {exc}', 'output': '', 'scenarios': []}

def run_project_checks(workspace: Path, proposed_files: Mapping[str, str], timeout: int = 45) -> dict[str, Any]:
    """Run isolated language checks plus optional user-defined end-to-end simulations."""
    reports: dict[str, dict[str, Any]] = {}
    if any(Path(name).suffix.lower() == '.py' for name in proposed_files):
        reports['python'] = run_isolated_python_checks(workspace, proposed_files, timeout=timeout)
    if any(Path(name).suffix.lower() in {'.js', '.mjs', '.cjs'} or Path(name).name.lower() == 'package.json' for name in proposed_files):
        reports['node'] = run_isolated_node_checks(workspace, proposed_files, timeout=timeout)
    simulation = run_project_simulations(workspace, proposed_files, timeout=min(timeout, 30))
    if simulation.get('status') != 'NOT_APPLICABLE':
        reports['simulation'] = simulation
    # Real-browser rendering and interaction checks for web-facing changes.
    web_change = any(Path(name).suffix.lower() in {'.html', '.htm', '.css'} or Path(name).name == 'council.visual.json' for name in proposed_files)
    workspace_root = Path(workspace).expanduser().resolve()
    existing_visual_manifest = (workspace_root / 'council.visual.json').is_file()
    existing_web_entry = any((workspace_root / name).is_file() for name in ('index.html', 'main.html', 'app.html'))
    js_change = any(Path(name).suffix.lower() in {'.js', '.mjs', '.cjs'} for name in proposed_files)
    if web_change or (existing_visual_manifest and (bool(proposed_files) or not reports)) or (js_change and existing_web_entry):
        from .visual_simulation import run_visual_browser_checks
        visual = run_visual_browser_checks(workspace, proposed_files, timeout=min(timeout, 30))
        if visual.get('status') != 'NOT_APPLICABLE':
            reports['visual'] = visual
    if not reports:
        return {'status': 'NOT_APPLICABLE', 'summary': 'No supported runtime checks or configured simulations apply to this proposal.', 'output': '', 'checks': reports}
    statuses = [report.get('status') for report in reports.values()]
    if all(status == 'PASSED' for status in statuses):
        status = 'PASSED'
    elif 'FAILED' in statuses:
        status = 'FAILED'
    elif 'NO_TESTS' in statuses:
        status = 'NO_TESTS'
    elif 'SKIPPED' in statuses:
        status = 'SKIPPED'
    elif 'UNTRUSTED_TESTS' in statuses:
        status = 'UNTRUSTED_TESTS'
    else:
        status = 'NOT_RUN'
    summary = ' | '.join(f'{name}: {report.get("summary", report.get("status", "unknown"))}' for name, report in reports.items())
    output = '\n\n'.join(f'[{name.upper()}]\n{report.get("output", "")}' for name, report in reports.items())[-16000:]
    return {
        'status': status,
        'summary': summary,
        'output': output,
        'checks': reports,
        # Every current runtime check is initiated from project-controlled files or
        # manifests. None is an independently signed host acceptance-test attestation.
        'evidence_source': 'project-controlled-sandbox',
        'host_evidence_verified': False,
    }
