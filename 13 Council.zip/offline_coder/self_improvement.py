"""Evidence-gated self-improvement experiment ledger.

This module records benchmark experiments and candidate outcomes. It never edits the Council,
changes permissions, deploys a candidate, or promotes itself automatically.
"""
from __future__ import annotations

import hashlib
import json
import re
import sqlite3
from contextlib import contextmanager
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from .config import APP_DIR

DB_PATH = APP_DIR / "improvement_lab.sqlite3"
_HASH_RE = re.compile(r"^[0-9a-f]{64}$")
_ALLOWED_TEST_STATES = {"PASSED", "FAILED", "SKIPPED", "UNAVAILABLE", "NO_TESTS", "UNTRUSTED_TESTS", "NOT_APPLICABLE", "NOT_RUN"}


class ImprovementLab:
    """Stores immutable experiment evidence and requires explicit approval to mark a candidate."""

    def __init__(self, db_path: Path = DB_PATH):
        self.db_path = Path(db_path)
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        with self._connect() as db:
            db.execute("""CREATE TABLE IF NOT EXISTS experiments (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                title TEXT NOT NULL,
                hypothesis TEXT NOT NULL,
                baseline_score REAL NOT NULL,
                candidate_score REAL NOT NULL,
                benchmark_suite TEXT NOT NULL,
                baseline_hash TEXT NOT NULL,
                candidate_hash TEXT NOT NULL,
                test_status TEXT NOT NULL,
                evidence_json TEXT NOT NULL,
                status TEXT NOT NULL,
                created_at TEXT NOT NULL,
                approved_at TEXT NOT NULL DEFAULT ''
            )""")

    @contextmanager
    def _connect(self):
        db = sqlite3.connect(self.db_path, timeout=5.0)
        db.row_factory = sqlite3.Row
        try:
            yield db
            db.commit()
        except Exception:
            db.rollback()
            raise
        finally:
            db.close()

    @staticmethod
    def _score(value: Any, label: str) -> float:
        if isinstance(value, bool) or not isinstance(value, (int, float)) or not 0 <= float(value) <= 1:
            raise ValueError(f"{label} must be a measured number between 0 and 1.")
        return float(value)

    def record_experiment(self, *, title: str, hypothesis: str,
                          baseline_score: float, candidate_score: float,
                          benchmark_suite: str, baseline_hash: str,
                          candidate_hash: str, test_status: str,
                          evidence: dict[str, Any] | None = None) -> int:
        title = str(title or "").strip()[:200]
        hypothesis = str(hypothesis or "").strip()[:2000]
        suite = str(benchmark_suite or "").strip()[:200]
        if not title or not hypothesis or not suite:
            raise ValueError("Title, hypothesis, and benchmark suite are required.")
        base = self._score(baseline_score, "Baseline score")
        candidate = self._score(candidate_score, "Candidate score")
        if not isinstance(baseline_hash, str) or not _HASH_RE.fullmatch(baseline_hash):
            raise ValueError("Baseline fingerprint must be a 64-character SHA-256 hex digest.")
        if not isinstance(candidate_hash, str) or not _HASH_RE.fullmatch(candidate_hash):
            raise ValueError("Candidate fingerprint must be a 64-character SHA-256 hex digest.")
        status = str(test_status or "").upper()
        if status not in _ALLOWED_TEST_STATES:
            raise ValueError("Unknown test status.")
        evidence = evidence if isinstance(evidence, dict) else {}
        evidence_json = json.dumps(evidence, ensure_ascii=False, sort_keys=True)[:20_000]
        # A score improvement with no passing tests is retained as a rejected/needs-evidence
        # experiment, never represented as a successful self-upgrade.
        qualified = candidate > base and status == "PASSED" and bool(evidence_json and evidence)
        result_status = "eligible_for_human_review" if qualified else "not_qualified"
        with self._connect() as db:
            cursor = db.execute(
                """INSERT INTO experiments(title,hypothesis,baseline_score,candidate_score,benchmark_suite,
                   baseline_hash,candidate_hash,test_status,evidence_json,status,created_at)
                   VALUES(?,?,?,?,?,?,?,?,?,?,?)""",
                (title, hypothesis, base, candidate, suite, baseline_hash, candidate_hash,
                 status, evidence_json, result_status, datetime.now(timezone.utc).isoformat()),
            )
            return int(cursor.lastrowid)

    def approve_for_future_evaluation(self, experiment_id: int, *, user_confirmed: bool = False) -> dict[str, Any]:
        if user_confirmed is not True:
            raise PermissionError("Explicit user confirmation is required. No self-deployment or automatic promotion is supported.")
        with self._connect() as db:
            row = db.execute("SELECT * FROM experiments WHERE id=?", (int(experiment_id),)).fetchone()
            if row is None:
                raise ValueError("Experiment was not found.")
            if row["status"] != "eligible_for_human_review":
                raise ValueError("Only benchmark-improved candidates with PASSED tests and evidence can be approved for future evaluation.")
            timestamp = datetime.now(timezone.utc).isoformat()
            db.execute("UPDATE experiments SET status='approved_for_future_evaluation', approved_at=? WHERE id=?", (timestamp, int(experiment_id)))
            updated = db.execute("SELECT * FROM experiments WHERE id=?", (int(experiment_id),)).fetchone()
            return dict(updated)

    def list_experiments(self, limit: int = 100) -> list[dict[str, Any]]:
        with self._connect() as db:
            rows = db.execute("SELECT * FROM experiments ORDER BY id DESC LIMIT ?", (max(1, min(int(limit), 500)),)).fetchall()
        results = []
        for row in rows:
            item = dict(row)
            try:
                item["evidence"] = json.loads(item.pop("evidence_json"))
            except (json.JSONDecodeError, TypeError):
                item["evidence"] = {}
            results.append(item)
        return results


def sha256_text(text: str) -> str:
    return hashlib.sha256(str(text).encode("utf-8", errors="replace")).hexdigest()
