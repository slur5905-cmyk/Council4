# Offline Coding Council

**Version 1.7.0 — local-first coding assistant with role-based peer review.**

The desktop app runs a configured local model through four role prompts: Architect, Correctness, Security, and Red Team. Unless distinct model assignments are configured, these are **one model and four prompts**, not four independently trained models.

The Council supports peer questions, investigations, code challenges, component contributions, ongoing discussions, and reviewable lessons from prior disagreements. Model-generated votes are advisory. Host-side checks determine whether a proposal is eligible for a manual Apply action. Automatic Apply is disabled.

## Start here

Read [START_HERE.md](START_HERE.md) for setup and [STATUS.md](STATUS.md) for what has and has not been verified. Security limits are in [SECURITY.md](SECURITY.md).

## Product boundaries

- No paid AI API is required. The desktop app uses local models or a local-only model server.
- Public web research is off by default and requires an explicit, per-query confirmation.\n- Council Browser is an optional Playwright-based browser for page inspection and ordinary interactions. Local models can review the same observation through four role-specific prompts; consequential actions require approval.
- The browser companion is a smaller, separate interface. Its first model load needs internet access to obtain the runtime and model weights; it is not equivalent to the desktop app or four independent models.
- Advanced host telemetry, SQLite memory, and resumable checkpoints are optional and disabled by default.
- This is an experimental private-use tool. It is not security-certified or ready for shared-LAN exposure. Once pushed to the default GitHub branch with Actions enabled, CI runs the verification suite weekly without user intervention. That scheduled run is deterministic CI, not autonomous model-driven repair. The desktop Council can analyze, collaborate, build candidates, and test within its configured workspace; changes to its own authority/security controls and final host writes remain manually gated.

## Project layout

- `offline_coder/` — desktop app, CLI, peer orchestration, model routing, host safety, and optional Council Browser (`council_browser.py`).
- `offline_coder/base_knowledge/` — desktop searchable reference modules.
- `iphone-app/` and `CodingCouncil_Universal.html` — browser/phone companion.
- `docs/guides/` — focused guides; `docs/archive/` — historical reports.
- `.github/workflows/ci.yml` — weekly and push/PR test runs, model-runtime import, Docker fixture, and gated Pages deployment.
