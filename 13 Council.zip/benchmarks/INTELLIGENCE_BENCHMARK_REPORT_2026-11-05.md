# Council Intelligence Benchmark Report

## Conclusion

The audit does **not** establish that the Council's model reasoning became more intelligent. No local model was available, so all six model-quality cases are recorded as `NOT_RUN`, with correctness and completion left null. Benchmark v1.2 establishes an improvement in deterministic host behavior: the original revision passed 4 of 10 checks; the current tree passed 10 of 10 on matching benchmark case-set and runner hashes.

The most valuable fix directly demonstrated by the benchmark was cross-project memory leakage. Newly imported knowledge can now be scoped to a workspace, and retrieval filters by that scope. Existing databases migrate without deleting records. Legacy unscoped notes remain shared for compatibility and are displayed as such.

## Method

- Original baseline: commit `aa81383`, extracted with `git archive`.
- Candidate: current source tree, recorded with a SHA-256 digest in the JSON report.
- Fixed case set: six model cases in `cases.json`, identified by the case-set digest in each report.
- Host lane: ten deterministic checks for role configuration, resource assessment/model ranking/adaptive scheduling, checkpoint recovery, approval gate behavior, 1,200-file retrieval, knowledge/learning integrity, persistence, project scoping, and unsafe write paths.
- Model lane: six fixed tasks for debugging/tests, cross-file architecture, false-premise recognition, contradiction/self-correction, verified-memory retrieval, and malicious instructions.
- Model correctness: requires independent review against each saved criterion or an executable oracle. Council votes and model confidence are not ground truth.
- Confidence: recorded separately, never counted as correctness.
- Verbosity: character counts are diagnostic only; there are no points for long answers or staged reasoning.
- Efficiency: records host wall time and peak-RSS delta. A configured model run additionally records model-call time/count, prompt/output characters, calls by role, and requested token budget. Actual token counts are null unless available from a backend.

## Results

| Source | Host checks | Host elapsed | Process peak-RSS delta | Model cases |
| --- | ---: | ---: | ---: | --- |
| Original `aa81383` (v1.2) | 4/10 (40%) | 0.3130 s | 7,041,024 bytes | 0/6 run |
| Candidate after scope fix (v1.2) | 10/10 (100%) | 0.4625 s | 8,491,008 bytes | 0/6 run |

The baseline and final candidate used the same case-set SHA-256, runner SHA-256, and 10-case denominator. Host elapsed time includes temp fixture creation and local resource/checkpoint checks; it is not inference latency. The candidate was slower and used more process memory in this host-only run; task-aware ranking and additional implemented checks account for work absent in the original. This is not an end-to-end speedup claim. Host RSS does not include accelerator or remote server memory. Historical v1.0 reports are retained and have a smaller denominator; do not compare their percentages directly with v1.2.

Original failures: the baseline did not implement adaptive resource/model selection or phase checkpoints; it also missed a relevant late file under the 90-file cap, did not reject tampered knowledge or learning records, and did not support project-scoped memory. The post-scope candidate passed all ten v1.2 host checks. Historical v1.0 pre-scope results remain available to isolate the memory-scope change.

The final candidate also passed `python -m pytest -q` with 180 tests and 27 subtests, Python compilation, browser logic (9 checks), browser-app validation, phone-companion validation, and iPhone JavaScript syntax. These checks exercise implementation contracts, not live model capability.

## Five Remaining Weaknesses

1. **Reasoning quality is unmeasured.** There are no local weights in the audit environment; expected causes are hardware/model availability and absence of independent outcome labels. Run the fixed model suite with a known local model, blind human scoring, and repeat trials before claiming a reasoning gain.
2. **Peer independence is weak by default.** Four responsibilities are prompts, and all commonly share one model's training data and blind spots. Distinct local role models are supported, but there is no evidence they improve correctness. Compare same-model and role-specialized runs on identical tasks.
3. **Repository understanding is still lexical and bounded.** Task terms rank paths and initial file samples, but no language-aware symbol graph, dependency resolution, or complete context is built. This can miss indirect effects and files beyond scan/context caps.
4. **Memory can still be stale or contradictory.** Retrieval ranks by keyword overlap and does not establish freshness or resolve conflicting claims. New knowledge can be scoped, but old unscoped records remain shared until the user re-imports them with a workspace scope.
5. **Runtime evidence is incomplete.** This environment did not run generated projects in Docker or a real browser. Supported test execution is language-limited, and test output is not host-attested for unattended Apply. Passing peer votes or static checks cannot establish correctness.

## Ranked Next Improvements

1. **Run and independently score the model lane** on the user's actual local model/hardware, with repeat trials and an exact model hash. Highest impact because reasoning quality is the central unmeasured claim; not feasible here without model weights.
2. **Measure whether distinct role models help.** Use the benchmark's per-member outputs and role overrides; retain specialization only when independently scored outcomes improve enough to justify added memory and latency.
3. **Add language-aware repository retrieval.** Start with dependency and symbol indexes for the most common project languages, retain file/context caps, and validate on indirect-change tasks.
4. **Add memory lifecycle and conflict handling.** Make legacy sharing explicit, allow re-scoping without re-import, and surface age/conflicting provenance instead of presenting keyword rank as truth.
5. **Improve independent runtime verification.** Add a host-controlled evidence channel and target-runtime acceptance runners before considering unattended writes. Keep missing runtimes as `NOT_RUN`/`SKIPPED`.

## Preserved Artifacts

- `results/aa81383-v1.2.json`: original host baseline and six unrun model cases.
- `results/working-tree-v1.2.json`: final candidate, 10/10 host checks and six unrun model cases.
- `results/aa81383-final.json` and `results/working-tree-post-scope.json`: preserved v1.0 comparison.
- `results/working-tree-host-pre-scope.json`: candidate before the memory-scope fix; 7/8 host checks.
- `results/working-tree-post-scope.json`: final candidate; 8/8 host checks and six unrun model cases.

The model cases require a configured local model and independent scoring; the reports intentionally do not fabricate those results.