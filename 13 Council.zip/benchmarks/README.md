# Council Intelligence Benchmark

This benchmark separates deterministic host behavior from model reasoning. It is not a leaderboard and it does not infer intelligence from confidence, response length, number of agents, or staged reasoning.

## Run

From the project directory, create a baseline source tree from the original commit and run both revisions with the same Python/runtime/model setup:

```bash
mkdir -p /tmp/council-baseline
git archive aa81383 council_fix/offline_coder | tar -x --strip-components=1 -C /tmp/council-baseline
python tools/run_intelligence_benchmark.py --source-root /tmp/council-baseline --source-revision aa81383 --label baseline --output benchmarks/results/aa81383-v1.3.json
python tools/run_intelligence_benchmark.py --source-root . --source-revision working-tree --label candidate --output benchmarks/results/working-tree-v1.3.json
```

The host suite uses only temporary workspaces and temporary home data. Model selection additionally verifies that narrow benchmark coverage is penalized and that a candidate without the requested task-specific measurement cannot be selected. It covers the four configured role contracts, resource assessment, evidence-coverage-aware model ranking, adaptive scheduling, checkpoint recovery, deterministic collective approval gating, retrieval from a 1,200-file repository, knowledge/learning persistence and tamper handling, project memory scope, and workspace path protections. If an original revision lacks a capability, that check is recorded as a failure instead of reducing the denominator.
For model evaluation, use the same local model file, inference runtime, settings, and cases for both source trees:

```bash
python tools/run_intelligence_benchmark.py --source-root /tmp/council-baseline --source-revision aa81383 --label baseline --model /models/coder.gguf --model-sha256 MODEL_SHA256 --context 8192 --threads 2 --max-tokens 2048 --suite all --output benchmarks/results/aa81383-model.json
python tools/run_intelligence_benchmark.py --source-root . --source-revision working-tree --label candidate --model /models/coder.gguf --model-sha256 MODEL_SHA256 --role-model correctness=/models/coder-specialist.gguf --context 8192 --threads 2 --max-tokens 2048 --suite all --output benchmarks/results/working-tree-model.json
```

No model is downloaded or selected automatically. Replace `MODEL_SHA256` with an externally computed 64-character digest; the runner records but does not verify it. Council phases use fixed, report-recorded temperatures; `--temperature` only sets the backend fallback. `--backend local-server` is also supported, including role-specific served model IDs via `--role-model ROLE=MODEL_ID`, but the existing backend rejects non-loopback hosts. The benchmark disables web research and uses isolated temporary workspaces. A local model run is still stochastic and needs repeat runs for meaningful comparisons. Use `--repeat 3` (up to 10) to retain independent trials for every model case. Each trial gets its own temporary workspace. Reports include per-case timing medians, but do not convert those into a correctness score. Before comparing, manually enter independent `correct` labels for each saved trial in both reports, keeping `repeat_index` intact; `tools/compare_benchmark_reports.py` pairs each case/repeat and rejects mismatched trial sets, model settings, case hashes, runner hashes, or repeat counts.

## Cases And Scoring

`cases.json` fixes 12 task inputs spanning debugging, architecture, fact checking, contradiction handling, memory, security, algorithms, APIs/idempotency, performance, invariants, supply-chain, and multi-language tracing, plus fixture files, verification criteria, and member-specific review dimensions. The model lane retains each member's independent analysis, cross-review, candidate review, and final vote. Model-case correctness is `null` until a reviewer independently verifies the saved proposal against the case criteria or an executable oracle. The Council's own vote is not its own ground truth.

Correctness and task completion are scored only from independent criteria or tests. Confidence is recorded separately and can be calibrated only after a correctness label exists. Answer and analysis character counts are diagnostic only. Efficiency is recorded as elapsed time, process peak RSS, model-call count, prompt/output characters, and requested token budget. Actual token counts and GPU memory remain unmeasured when the backend does not expose them. No composite score hides these separate dimensions.

The deterministic host score measures implemented contracts, not reasoning. It is expected to expose regressions between source revisions. The member-count/lens check verifies configuration distinctness only; it does not establish that members reason independently or improve outcomes.

## Results

Each JSON report is an immutable run artifact containing benchmark version, source-tree digest, revision label, environment, case outcomes, and measurement limitations. Never overwrite an earlier result when comparing progress; use a new filename. Record failed, skipped, and unavailable cases. Do not replace missing evidence with a confidence score or a model-generated assessment.

The current benchmark format is v1.4. Its model-case suite has 12 cases. The repeat-capable model lane and paired-trial comparison require the exact same benchmark runner and case file for both revisions.

## Current Limits

The current environment has no configured local inference model, so model-quality cases cannot be scored here. Host tests use synthetic fixtures. A real benchmark still needs blind human scoring or independently executable task-specific tests, repeated runs, and the exact model/runtime hardware recorded. Host RSS does not include remote GPU-server memory.

## Benchmark v1.5 source fingerprinting

Benchmark v1.5 fingerprints every regular file under `offline_coder/`, including nested modules and the Markdown base-knowledge package. This prevents a code/knowledge revision from being mistaken for the same source tree simply because Python files did not change. Prior benchmark reports retain their original version and digest semantics; compare only reports with matching version, case-set hash, runner hash, model configuration, and repeat count.


## v1.5.1 audit host lane (2026-11-07)

`results/council-v1.5.1-host-2026-11-07.json` records the current audited source tree passing 10/10 deterministic host checks. Its model-quality lane is `NOT_RUN`; no model file or local inference server was configured. This result does not measure model reasoning ability.
