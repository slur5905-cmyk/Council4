#!/usr/bin/env python3
"""Keep the browser payload small; the full knowledge corpus remains desktop-only."""
from __future__ import annotations

import json
import re
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
HTML_PATH = ROOT / "CodingCouncil_Universal.html"
OPEN_TAG = '<script type="application/json" id="offlineKnowledgeData">'
CLOSE_TAG = "</script>"


def sync() -> tuple[int, int]:
    html = HTML_PATH.read_text(encoding="utf-8")
    pattern = re.escape(OPEN_TAG) + r".*?" + re.escape(CLOSE_TAG)
    html, count = re.subn(pattern, OPEN_TAG + "[]" + CLOSE_TAG, html, count=1, flags=re.S)
    if count != 1:
        raise RuntimeError("Expected exactly one browser knowledge data block.")
    HTML_PATH.write_text(html, encoding="utf-8")
    return 0, 0


if __name__ == "__main__":
    sync()
    print("Browser knowledge payload is empty by design; the searchable full knowledge corpus remains in the desktop package.")
