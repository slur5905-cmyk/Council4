"""Extract and syntax-check the inline module script in iphone-app/index.html."""
from pathlib import Path
import re
import subprocess
import tempfile

html = Path("iphone-app/index.html").read_text(encoding="utf-8")
matches = re.findall(r'<script\s+type="module"\s*>(.*?)</script>', html, re.S | re.I)
if len(matches) != 1:
    raise SystemExit(f"Expected exactly one inline module script, found {len(matches)}")
with tempfile.NamedTemporaryFile("w", suffix=".mjs", encoding="utf-8") as f:
    f.write(matches[0])
    f.flush()
    subprocess.run(["node", "--check", f.name], check=True)
print("iPhone app module JavaScript syntax: OK")
required_download_features = {
    "iOS native file-share support": "navigator.canShare({files:[file]})",
    "Save to Files guidance": "Choose Save to Files in the iPhone share sheet.",
    "Safari download fallback": "URL.createObjectURL(blob)",
    "delayed download URL cleanup": "setTimeout(()=>URL.revokeObjectURL(url),60000);",
}
missing = [name for name, marker in required_download_features.items() if marker not in matches[0]]
if missing:
    raise SystemExit("iPhone export compatibility check failed: " + ", ".join(missing))
print("iPhone export compatibility: native file share and Safari fallback present")
