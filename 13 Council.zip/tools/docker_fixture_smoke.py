#!/usr/bin/env python3
"""Fail-closed smoke test for the actual isolated Python and Node Docker runners.

CI must have Docker and pre-pulled fixture images. A missing daemon/image is a failure,
not a skipped success. Project-owned test output remains UNTRUSTED_TESTS by design.
"""
from __future__ import annotations

import shutil
import subprocess
import tempfile
from pathlib import Path

from offline_coder.isolated_tests import run_isolated_node_checks, run_isolated_python_checks


def main() -> int:
    docker = shutil.which("docker")
    if not docker:
        raise SystemExit("FAIL CLOSED: Docker executable is required for this CI job.")
    info = subprocess.run([docker, "info"], capture_output=True, text=True, timeout=20)
    if info.returncode:
        raise SystemExit("FAIL CLOSED: Docker daemon is unavailable: " + (info.stderr or info.stdout)[-1000:])
    for image in ("python:3.12-slim", "node:22-alpine"):
        check = subprocess.run([docker, "image", "inspect", image], capture_output=True, text=True, timeout=10)
        if check.returncode:
            raise SystemExit(f"FAIL CLOSED: required image {image} is not pre-pulled.")

    with tempfile.TemporaryDirectory(prefix="council-docker-ci-") as tmp:
        workspace = Path(tmp)
        python_files = {
            "main.py": "def answer():\n    return 42\n",
            "tests/test_fixture.py": (
                "import unittest\nfrom main import answer\n\n"
                "class FixtureTest(unittest.TestCase):\n"
                "    def test_answer(self):\n        self.assertEqual(answer(), 42)\n"
            ),
        }
        node_files = {
            "main.js": "export function answer() { return 42; }\n",
            "tests/answer.test.js": (
                "import test from 'node:test';\n"
                "import assert from 'node:assert/strict';\n"
                "import { answer } from '../main.js';\n"
                "test('answer is 42', () => assert.equal(answer(), 42));\n"
            ),
        }
        python_result = run_isolated_python_checks(workspace, python_files, timeout=45)
        if python_result.get("status") != "UNTRUSTED_TESTS":
            raise SystemExit("Python isolated runner did not execute fixture as expected: " + str(python_result))
        if "UNITTEST_RESULTS: run=1" not in python_result.get("output", ""):
            raise SystemExit("Python fixture test did not report the expected test execution.")
        node_result = run_isolated_node_checks(workspace, node_files, timeout=45)
        if node_result.get("status") != "UNTRUSTED_TESTS" or node_result.get("host_evidence_verified") is not False:
            raise SystemExit("Node isolated runner did not execute fixture as expected: " + str(node_result))
        if "tests 1" not in node_result.get("output", "") or "pass 1" not in node_result.get("output", ""):
            raise SystemExit("Node fixture test did not report the expected test execution.")
        print("Docker fixture smoke passed: isolated Python and Node runners executed real fixture projects.")
        print("Both results remain UNTRUSTED_TESTS; project-controlled test output is not host attestation.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
