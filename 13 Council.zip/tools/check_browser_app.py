"""Static checks for the standalone responsive browser app (standard library + Node.js)."""
from __future__ import annotations
from html.parser import HTMLParser
from pathlib import Path
import re
import subprocess
import tempfile

ROOT = Path(__file__).resolve().parents[1]
HTML_PATH = ROOT / "CodingCouncil_Universal.html"


class DocumentChecks(HTMLParser):
    def __init__(self) -> None:
        super().__init__(convert_charrefs=True)
        self.ids: list[str] = []
        self.label_targets: list[str] = []
        self.iframes: list[dict[str, str | None]] = []
        self.script_count = 0
        self.script_types: list[str] = []
        self.script_ids: list[str] = []

    def handle_starttag(self, tag: str, attrs) -> None:
        values = dict(attrs)
        if values.get("id") is not None:
            self.ids.append(str(values["id"]))
        if tag == "label" and values.get("for"):
            self.label_targets.append(str(values["for"]))
        if tag == "iframe":
            self.iframes.append(values)
        if tag == "script":
            self.script_count += 1
            self.script_types.append(str(values.get("type", "")).strip().casefold())
            if values.get("id") is not None:
                self.script_ids.append(str(values["id"]))


def main() -> int:
    if not HTML_PATH.is_file():
        raise SystemExit(f"Missing browser app: {HTML_PATH}")
    html = HTML_PATH.read_text(encoding="utf-8")
    check = DocumentChecks()
    check.feed(html)
    duplicates = sorted({value for value in check.ids if check.ids.count(value) > 1})
    missing_labels = sorted(set(check.label_targets) - set(check.ids))
    if duplicates:
        raise SystemExit("Duplicate HTML id(s): " + ", ".join(duplicates))
    if missing_labels:
        raise SystemExit("Label target(s) missing from HTML: " + ", ".join(missing_labels))
    # The offline knowledge JSON is a data block, not executable JavaScript.
    # Count and syntax-check only application scripts (module/classic JS).
    script_matches = list(re.finditer(r"<script\b([^>]*)>(.*?)</script\s*>", html, re.I | re.S))
    executable_scripts = []
    for match in script_matches:
        attrs = match.group(1)
        script_type = re.search(r"\btype\s*=\s*['\"]([^'\"]+)['\"]", attrs, re.I)
        kind = script_type.group(1).strip().casefold() if script_type else ""
        if kind not in {"application/json", "application/ld+json", "text/plain"}:
            executable_scripts.append(match.group(2))
    if len(executable_scripts) != 1:
        raise SystemExit(f"Expected one inline application script plus non-executable data blocks, found {len(executable_scripts)} executable scripts")
    if check.script_ids.count("offlineKnowledgeData") != 1:
        raise SystemExit("Expected exactly one offlineKnowledgeData block.")
    knowledge_match = re.search(r"<script type=\"application/json\" id=\"offlineKnowledgeData\">(.*?)</script>", html, re.S)
    if not knowledge_match or knowledge_match.group(1).strip() != "[]":
        raise SystemExit("Browser build must not embed the full desktop knowledge pack.")
    if len(html.encode("utf-8")) >= 200_000:
        raise SystemExit("Browser app exceeded the 200 KB source budget.")
    scripts = executable_scripts
    dom_refs = set(re.findall(r"\$\(['\"]([^'\"]+)['\"]\)", scripts[0]))
    missing_dom_refs = sorted(dom_refs - set(check.ids))
    if missing_dom_refs:
        raise SystemExit("JavaScript references missing DOM id(s): " + ", ".join(missing_dom_refs))
    if len(check.iframes) != 1 or check.iframes[0].get("sandbox") != "allow-scripts":
        raise SystemExit("Expected exactly one preview iframe sandboxed with allow-scripts only.")

    with tempfile.NamedTemporaryFile("w", suffix=".js", encoding="utf-8") as stream:
        stream.write(scripts[0])
        stream.flush()
        try:
            subprocess.run(["node", "--check", stream.name], check=True, capture_output=True, text=True)
        except FileNotFoundError:
            raise SystemExit("Node.js is required for the universal browser-app syntax check.")
        except subprocess.CalledProcessError as exc:
            raise SystemExit(exc.stderr or exc.stdout or "Universal app JavaScript syntax check failed.")

    # Guard against regression of the URL-only workflow and the resource-size limit.
    required_fragments = {
        "URL-only import can reach the digest routine": "!selected.length&&!pendingUrlSources.length",
        "URL fetch hands resources to digestion": "await digestWebsiteBundle();",
        "URL resources use the streaming byte cap": "readWebsiteResponseLimited(response,1024*1024)",
        "URL import omits credentials": "credentials:'omit'",
        "URL import refuses redirects": "redirect:'error'",
        "URL import has per-resource timeout": "setTimeout(()=>controller.abort(),12000)",
        "URL import has overall crawl deadline": "Date.now()+90000",
        "ZIP parser is at reviewed patch version": "fflate@0.8.3",
        "Result renderer exists (previously this was a missing runtime function)": "function renderResult(result)",
        "Answer-only mode is available": 'option value="answer"',
        "Manual search shows exact query consent": "This exact query will be sent to Wikipedia’s public search service",
        "Automatic research is disclosed as off": "Automatic research is off. No task text is sent out",
        "Role prompts are not misrepresented as separate models": "One local model + role prompts unless distinct models are configured",
        "Browser first-load network dependency is disclosed": "first model load downloads Transformers.js and model weights",
        "Generated project manifests require acceptance criteria": '"acceptance_criteria"',
        "Browser search query sanitizer is present": "function safeResearchQuery(task)",
        "iOS native file sharing is present": "navigator.canShare({files:[file]})",
        "iOS Save to Files guidance is present": "Choose Save to Files in the iPhone share sheet.",
        "Safari download fallback keeps the object URL alive": "setTimeout(()=>URL.revokeObjectURL(url),60000);",
    }
    if "shouldAutoResearchTask" in html or "autonomousWikipediaResearch" in html or "gatherBrowserFollowupResearch" in html:
        raise SystemExit("Browser app must not retain automatic or follow-up web-search routines.")
    missing = [label for label, needle in required_fragments.items() if needle not in html]
    if missing:
        raise SystemExit("Browser import regression guard failed: " + "; ".join(missing))

    try:
        logic = subprocess.run(["node", str(ROOT / "tools" / "check_browser_logic.mjs")], check=True, capture_output=True, text=True, timeout=20)
    except subprocess.TimeoutExpired:
        raise SystemExit("Universal browser logic harness timed out.")
    except subprocess.CalledProcessError as exc:
        raise SystemExit(exc.stderr or exc.stdout or "Universal browser logic checks failed.")

    print(f"Universal browser app: JavaScript syntax OK; compact knowledge payload; {len(check.ids)} IDs unique; labels resolve; preview sandbox OK; manual-search and runtime-reference guards OK.")
    print(logic.stdout.strip())
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
