#!/usr/bin/env python3
"""Reproducible host and optional local-model Council benchmark runner."""
from __future__ import annotations

import argparse
import hashlib
import inspect
import json
import os
import platform
import shutil
import sqlite3
import sys
import tempfile
import threading
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

BENCHMARK_VERSION = "1.5"
PROJECT_ROOT = Path(__file__).resolve().parents[1]
CASES_PATH = PROJECT_ROOT / "benchmarks" / "cases.json"
RUNNER_PATH = Path(__file__).resolve()


def _rss_bytes() -> int | None:
    try:
        for line in Path("/proc/self/status").read_text(encoding="utf-8").splitlines():
            if line.startswith("VmHWM:"):
                return int(line.split()[1]) * 1024
    except (OSError, ValueError, IndexError):
        pass
    try:
        import resource
        peak = int(resource.getrusage(resource.RUSAGE_SELF).ru_maxrss)
        return peak if sys.platform == "darwin" else peak * 1024
    except (ImportError, OSError, ValueError):
        return None


def _tree_digest(source_root: Path) -> str:
    """Fingerprint the complete packaged Council source, including offline knowledge.

    A Python-only hash misses Markdown reference changes, package data, and nested modules.
    Relative paths and length-delimited file bytes make the digest deterministic.
    """
    package_root = source_root / "offline_coder"
    digest = hashlib.sha256()
    if not package_root.is_dir():
        return digest.hexdigest()
    for path in sorted(package_root.rglob("*")):
        if path.is_symlink() or not path.is_file() or "__pycache__" in path.parts or path.suffix == ".pyc":
            continue
        relative = path.relative_to(package_root).as_posix().encode("utf-8")
        content = path.read_bytes()
        digest.update(len(relative).to_bytes(4, "big"))
        digest.update(relative)
        digest.update(len(content).to_bytes(8, "big"))
        digest.update(content)
    return digest.hexdigest()


def _run_host_checks(source_root: Path) -> list[dict[str, Any]]:
    sys.path.insert(0, str(source_root))
    from offline_coder.council import AGENTS, _review_gate_errors, _vote_gate_errors
    from offline_coder.knowledge import KnowledgeStore
    from offline_coder.learning import LearningStore
    from offline_coder.safety import validate_proposed_files
    from offline_coder.workspace import collect_workspace_context
    expansion_path = source_root / "offline_coder" / "expansion.py"
    if expansion_path.is_file():
        from offline_coder.expansion import (
            ExpansionStore,
            adaptive_worker_limit,
            inspect_resources,
            rank_model_candidates,
        )
    else:
        ExpansionStore = adaptive_worker_limit = inspect_resources = rank_model_candidates = None

    results: list[dict[str, Any]] = []

    def record(case_id: str, category: str, ok: bool, detail: str) -> None:
        results.append({"id": case_id, "category": category, "status": "PASS" if ok else "FAIL", "correct": bool(ok), "detail": detail})

    roles = [agent.name for agent in AGENTS]
    lenses = [agent.lens for agent in AGENTS]
    record("HOST-MEMBERS", "role-contract", len(AGENTS) == 4 and len(set(roles)) == 4 and len(set(lenses)) == 4,
           f"{len(AGENTS)} named roles; {len(set(lenses))} distinct lens descriptions. This checks role configuration, not reasoning quality.")

    if ExpansionStore is not None:
        with tempfile.TemporaryDirectory(prefix="council-bench-resources-") as temp:
            resources = inspect_resources({"max_peer_workers": 4}, app_dir=Path(temp))
            observed = (
                isinstance(resources["cpu"]["architecture"], str)
                and "available_bytes" in resources["memory"]
                and "devices" in resources["gpu"]
                and resources["network"]["external_connectivity_tested"] is False
                and resources["storage"]["total_bytes"] is not None
            )
        measured_candidates = rank_model_candidates(
            [
                {"id": "small-measured", "estimated_memory_bytes": 1,
                 "benchmarks": {"coding": 0.8, "tool_use": 0.8, "reliability": 0.9}},
                {"id": "large-unmeasured", "estimated_memory_bytes": 1000, "parameter_count": 1_000_000_000},
            ],
            available_memory_bytes=100,
        )
        ranked_correctly = measured_candidates["selected"]["id"] == "small-measured"
        coverage_result = rank_model_candidates(
            [
                {"id": "narrow-perfect", "benchmarks": {"coding": 0.95}},
                {"id": "broad-strong", "benchmarks": {
                    "coding": 0.85, "tool_use": 0.85, "reliability": 0.85,
                    "context": 0.85, "speed": 0.85,
                }},
            ], available_memory_bytes=8 * 1024**3, task_type="coding",
        )
        coverage_ranked_correctly = coverage_result["selected"]["id"] == "broad-strong"
        adaptive_correctly = (
            adaptive_worker_limit(4, 2 * 1024**3) == 1
            and adaptive_worker_limit(4, 16 * 1024**3) == 4
        )
        resources_ok = observed and ranked_correctly and coverage_ranked_correctly and adaptive_correctly
        with tempfile.TemporaryDirectory(prefix="council-bench-checkpoint-") as temp:
            database = Path(temp) / "expansion.sqlite3"
            store = ExpansionStore(database)
            task_id = store.start_checkpoint("Resume a local Council task", "benchmark-checkpoint")
            store.update_checkpoint(
                task_id, "analyses_complete",
                subtasks=["Analyze", "Review"], completed=["Analyze"],
                state={"phase": "analyses_complete", "outputs": {"peer-a": "saved"}},
            )
            recovered = ExpansionStore(database).get_checkpoint(task_id)
            checkpoint_ok = recovered is not None and recovered["state"].get("outputs", {}).get("peer-a") == "saved"
        record("HOST-ADAPTIVE-RESOURCES", "hardware-and-selection", resources_ok,
               "Resource fields are observed without external network probes; scheduling responds to RAM; candidate ranking penalizes incomplete benchmark coverage and respects measured task quality and hardware fit.")
        record("HOST-CHECKPOINT-RECOVERY", "persistent-execution", checkpoint_ok,
               "A completed phase and its state survive SQLite reopen and are integrity-checked before recovery.")
    else:
        record("HOST-ADAPTIVE-RESOURCES", "hardware-and-selection", False,
               "This source revision does not implement resource assessment, adaptive scheduling, or measured model ranking.")
        record("HOST-CHECKPOINT-RECOVERY", "persistent-execution", False,
               "This source revision does not implement persistent phase checkpoints.")

    valid_reviews = [{
        "agent": agent.name, "vote": "APPROVE", "findings": [],
        "checks_performed": ["Traced the relevant input and error paths."],
        "strengths": ["The candidate satisfies the stated contract."], "confidence": 0.5,
    } for agent in AGENTS]
    valid_votes = [{
        "agent": agent.name, "vote": "APPROVE", "remaining_blockers": [],
        "reason": "The independent review found no unresolved blocker.",
    } for agent in AGENTS]
    passes = not _review_gate_errors(valid_reviews) and not _vote_gate_errors(valid_votes)
    dissent = [dict(vote, vote="REQUEST_CHANGES") if vote["agent"] == roles[-1] else vote for vote in valid_votes]
    blocks_dissent = bool(_vote_gate_errors(dissent))
    record("HOST-COLLECTIVE", "approval-gate", passes and blocks_dissent,
           "Valid unanimous records pass; one dissenting final vote blocks. This checks deterministic gating, not debate quality.")

    with tempfile.TemporaryDirectory(prefix="council-bench-context-") as temp:
        root = Path(temp)
        (root / "README.md").write_text("General project overview.", encoding="utf-8")
        source = root / "src"
        source.mkdir()
        for index in range(1200):
            body = "def routine():\n    return 'ordinary project code'\n"
            if index == 1100:
                body += "# special_retry_policy marker for the requested behavior\n"
            (source / f"module_{index:04}.py").write_text(body, encoding="utf-8")
        try:
            context = collect_workspace_context(root, max_chars=12000, max_files=90, query="special retry policy")
            query_supported = True
        except TypeError:
            context = collect_workspace_context(root, max_chars=12000, max_files=90)
            query_supported = False
        found = "module_1100.py" in context
        record("HOST-CONTEXT", "large-repository-retrieval", found,
               f"Task-relevant late file selected={found}; query parameter supported={query_supported}; 1,200 files, 90-file budget.")

    with tempfile.TemporaryDirectory(prefix="council-bench-knowledge-") as temp:
        root = Path(temp)
        db_path = root / "knowledge.sqlite3"
        source_file = root / "notes.md"
        source_file.write_text("Original verified guidance about Python dictionaries.", encoding="utf-8")
        store = KnowledgeStore(db_path)
        source_id = store.add_file(source_file, "Python dictionary guidance", verified=True)
        with sqlite3.connect(db_path) as db:
            db.execute("UPDATE sources SET body=? WHERE id=?", ("Altered instruction about Python dictionaries.", source_id))
        omitted = not store.relevant_sources("Python dictionaries")
        unverified_id = store.add_file(source_file, "Unverified guidance", verified=False)
        with sqlite3.connect(db_path) as db:
            db.execute("UPDATE sources SET body=? WHERE id=?", ("Tampered unverified content.", unverified_id))
        rejected = False
        try:
            store.verify_source(unverified_id)
        except ValueError:
            rejected = True
        record("HOST-KNOWLEDGE-INTEGRITY", "memory-integrity", omitted and rejected,
               f"Altered verified record omitted={omitted}; altered unverified record rejected at verification={rejected}.")

    with tempfile.TemporaryDirectory(prefix="council-bench-learning-") as temp:
        root = Path(temp)
        db_path = root / "learning.sqlite3"
        store = LearningStore(db_path)
        example_id = store.add_confirmed("Fix Python dictionary lookup", "Use mapping.get(key).")
        with sqlite3.connect(db_path) as db:
            db.execute("UPDATE examples SET answer=? WHERE id=?", ("Tampered answer.", example_id))
        omitted = not store.relevant_examples("Python dictionary lookup")
        export_path = root / "training.jsonl"
        exported = store.export_jsonl(export_path)
        record("HOST-LEARNING-INTEGRITY", "memory-integrity", omitted and exported == 0,
               f"Altered example omitted from retrieval={omitted}; exported rows={exported}.")

    with tempfile.TemporaryDirectory(prefix="council-bench-persistence-") as temp:
        root = Path(temp)
        db_path = root / "knowledge.sqlite3"
        source_file = root / "notes.md"
        source_file.write_text("Verified notes: retry policy uses bounded exponential backoff.", encoding="utf-8")
        first = KnowledgeStore(db_path)
        first.add_file(source_file, "Retry policy", verified=True)
        second = KnowledgeStore(db_path)
        found = bool(second.relevant_sources("retry policy exponential backoff"))
        record("HOST-MEMORY-PERSISTENCE", "memory-persistence", found,
               "A verified knowledge record survives closing and reopening the local SQLite store.")

    with tempfile.TemporaryDirectory(prefix="council-bench-memory-scope-") as temp:
        root = Path(temp)
        db_path = root / "knowledge.sqlite3"
        source_file = root / "project-a-notes.md"
        source_file.write_text("Project A only: use a custom red delivery protocol.", encoding="utf-8")
        store = KnowledgeStore(db_path)
        supports_scope = "project_scope" in inspect.signature(KnowledgeStore.add_file).parameters and \
            "project_scope" in inspect.signature(KnowledgeStore.relevant_sources).parameters
        isolated = False
        if supports_scope:
            store.add_file(source_file, "Project A protocol", verified=True, project_scope="/project-a")
            isolated = not store.relevant_sources("red delivery protocol", project_scope="/project-b")
        record("HOST-MEMORY-SCOPE", "project-memory-isolation", isolated,
               f"Project-specific knowledge is isolated from other workspaces={isolated}; scope API available={supports_scope}.")

    with tempfile.TemporaryDirectory(prefix="council-bench-safety-") as temp:
        root = Path(temp)
        sensitive = validate_proposed_files(root, {".env": "API_TOKEN=example"})
        traversal = validate_proposed_files(root, {"../outside.py": "value = 1"})
        record("HOST-SECURITY", "untrusted-output", not sensitive.ok and not traversal.ok,
               f"Sensitive path rejected={not sensitive.ok}; traversal rejected={not traversal.ok}.")

    return results


class _CountingModel:
    def __init__(self, model: object):
        self.model = model
        self.primary = getattr(model, "primary", model)
        self.role_models = getattr(model, "role_models", {})
        self.lock = threading.Lock()
        self.calls = 0
        self.elapsed_seconds = 0.0
        self.prompt_chars = 0
        self.output_chars = 0
        self.requested_max_tokens = 0
        self.calls_by_role: dict[str, int] = {}

    def snapshot(self) -> dict[str, Any]:
        with self.lock:
            return {"calls": self.calls, "elapsed_seconds": self.elapsed_seconds,
                    "prompt_chars": self.prompt_chars, "output_chars": self.output_chars,
                    "requested_max_tokens": self.requested_max_tokens,
                    "calls_by_role": dict(self.calls_by_role)}

    def generate(self, system: str, user: str, max_tokens: int | None = None,
                 temperature: float | None = None, role: str | None = None) -> str:
        started = time.perf_counter()
        try:
            if hasattr(self.model, "role_models"):
                output = self.model.generate(system, user, max_tokens=max_tokens, temperature=temperature, role=role)
            else:
                output = self.model.generate(system, user, max_tokens=max_tokens, temperature=temperature)
            return output
        finally:
            elapsed = time.perf_counter() - started
            with self.lock:
                self.calls += 1
                self.elapsed_seconds += elapsed
                self.prompt_chars += len(system) + len(user)
                self.requested_max_tokens += int(max_tokens or 0)
                self.calls_by_role[str(role or "unassigned")] = self.calls_by_role.get(str(role or "unassigned"), 0) + 1
                if "output" in locals() and isinstance(output, str):
                    self.output_chars += len(output)


def _run_model_cases(args: argparse.Namespace, source_root: Path, cases: dict[str, Any]) -> list[dict[str, Any]]:
    if not args.model and args.backend == "gguf":
        return [{"id": case["id"], "category": case["category"], "status": "NOT_RUN",
                 "correct": None, "reason": "No local model was supplied; model quality cannot be inferred from host tests."}
                for case in cases["model_cases"]]

    sys.path.insert(0, str(source_root))
    from offline_coder.config import APP_DIR
    from offline_coder.council import AGENTS, CouncilRunner
    from offline_coder.knowledge import KnowledgeStore
    from offline_coder.model_backend import build_model_router

    settings = {
        "model_backend": args.backend,
        "model_path": args.model,
        "local_server_url": args.endpoint,
        "local_server_model": args.served_model,
        "n_ctx": args.context,
        "n_threads": args.threads,
        "n_gpu_layers": args.gpu_layers,
        "max_tokens": args.max_tokens,
        "temperature": args.temperature,
    }
    role_models: dict[str, str] = {}
    for assignment in args.role_model:
        role, separator, value = assignment.partition("=")
        if not separator or role not in {"architect", "correctness", "security", "redteam"} or not value.strip():
            raise ValueError(f"Invalid --role-model assignment: {assignment!r}; use ROLE=PATH_OR_MODEL_ID.")
        role_models[role] = value.strip()
    if args.backend == "gguf":
        settings["role_model_paths"] = role_models
    else:
        settings["local_server_role_models"] = role_models
    raw_model = build_model_router(settings)
    model = _CountingModel(raw_model)
    results = []
    for repeat_index in range(max(1, min(10, int(getattr(args, "repeat", 1))))):
        for case in cases["model_cases"]:
            with tempfile.TemporaryDirectory(prefix=f"council-bench-{case['id'].lower()}-") as temp:
                root = Path(temp)
                for relative, content in case.get("fixture_files", {}).items():
                    target = root / relative
                    target.parent.mkdir(parents=True, exist_ok=True)
                    target.write_text(content, encoding="utf-8")
                knowledge = KnowledgeStore(root / "benchmark-knowledge.sqlite3")
                if case["id"] == "MEM-001":
                    note = root / "verified-reference.md"
                    note.write_text("Retry guidance: use a bounded exponential backoff and honor Retry-After.", encoding="utf-8")
                    knowledge.add_file(note, "Verified retry reference", "Benchmark fixture", verified=True)
                metrics_before = model.snapshot()
                started = time.perf_counter()
                runner = CouncilRunner(model, root, review_rounds=0, knowledge=knowledge,
                                       max_context_chars=args.context_chars, max_tokens=args.max_tokens,
                                       web_research_enabled=False, max_peer_workers=args.peer_workers,
                                       logger=lambda _message: None)
                result = runner.run_task(case["task"])
                elapsed = time.perf_counter() - started
                metrics_after = model.snapshot()
                member_records = {}
                for agent in AGENTS:
                    member_records[agent.name] = {
                        "independent_analysis": result.analyses.get(agent.name, "")[:12000],
                        "cross_review": result.cross_reviews.get(agent.name, "")[:12000],
                        "candidate_review": next((review for review in result.reviews if review.get("agent") == agent.name), None),
                        "final_vote": next((vote for vote in result.votes if vote.get("agent") == agent.name), None),
                        "analysis_chars": len(result.analyses.get(agent.name, "")),
                        "cross_review_chars": len(result.cross_reviews.get(agent.name, "")),
                    }
                results.append({
                    "id": case["id"], "category": case["category"], "repeat_index": repeat_index + 1,
                    "status": "REVIEW_REQUIRED",
                    "correct": None, "task_completion": None,
                    "confidence": [review.get("confidence") for review in result.reviews if isinstance(review.get("confidence"), (int, float))],
                    "confidence_scored": False,
                    "verbosity_chars": {"answer": len(result.answer), "analyses": sum(item["analysis_chars"] for item in member_records.values())},
                    "wall_seconds": elapsed, "model_calls": metrics_after["calls"] - metrics_before["calls"],
                    "run_metrics": {
                        "model_call_seconds": metrics_after["elapsed_seconds"] - metrics_before["elapsed_seconds"],
                        "prompt_chars": metrics_after["prompt_chars"] - metrics_before["prompt_chars"],
                        "output_chars": metrics_after["output_chars"] - metrics_before["output_chars"],
                        "requested_max_tokens": metrics_after["requested_max_tokens"] - metrics_before["requested_max_tokens"],
                        "actual_tokens": None,
                        "calls_by_role": {role: count - metrics_before["calls_by_role"].get(role, 0)
                                           for role, count in metrics_after["calls_by_role"].items()},
                    },
                    "test_report": result.test_report, "final_status": result.final_status,
                    "task_plan": result.task_plan, "member_records": member_records,
                    "proposed_files": result.proposed_files, "independent_verification": case["independent_verification"],
                    "member_dimensions": case["member_dimensions"],
                })
    return results


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--source-root", type=Path, default=PROJECT_ROOT,
                        help="Directory containing offline_coder/; run baseline and candidate in separate invocations.")
    parser.add_argument("--source-revision", default="working-tree", help="Git revision or descriptive source label for the report.")
    parser.add_argument("--label", choices=("baseline", "candidate", "custom"), default="custom",
                        help="Comparison role for this source tree.")
    parser.add_argument("--suite", choices=("all", "host", "model"), default="all")
    parser.add_argument("--backend", choices=("gguf", "local-server"), default="gguf")
    parser.add_argument("--model", default="", help="Optional local GGUF model path. No model is downloaded.")
    parser.add_argument("--model-sha256", default="", help="Optional externally computed SHA-256 for the exact model file; the runner records but does not verify it.")
    parser.add_argument("--role-model", action="append", default=[], metavar="ROLE=MODEL",
                        help="Optional local model path or served model ID for architect/correctness/security/redteam; repeatable.")
    parser.add_argument("--endpoint", default="http://127.0.0.1:8080/v1", help="Loopback-only local model server endpoint.")
    parser.add_argument("--served-model", default="")
    parser.add_argument("--context", type=int, default=8192)
    parser.add_argument("--context-chars", type=int, default=24000)
    parser.add_argument("--threads", type=int, default=2)
    parser.add_argument("--gpu-layers", type=int, default=0)
    parser.add_argument("--max-tokens", type=int, default=2048)
    parser.add_argument("--temperature", type=float, default=0.2,
                        help="Backend fallback only; Council phases use the fixed temperatures recorded in the report.")
    parser.add_argument("--peer-workers", type=int, choices=(1, 2, 3, 4), default=1)
    parser.add_argument("--repeat", type=int, choices=range(1, 11), default=1,
                        help="Repeat every model case independently (1–10) to expose run-to-run variability.")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()

    source_root = args.source_root.expanduser().resolve()
    if not (source_root / "offline_coder").is_dir():
        parser.error("--source-root must contain an offline_coder/ directory.")
    if args.model_sha256 and (len(args.model_sha256) != 64 or any(ch not in "0123456789abcdefABCDEF" for ch in args.model_sha256)):
        parser.error("--model-sha256 must be a 64-character hexadecimal SHA-256 digest.")
    cases = json.loads(CASES_PATH.read_text(encoding="utf-8"))
    # Keep Council settings, peer rotation, and learning databases out of the user's home.
    sandbox_home = tempfile.mkdtemp(prefix="council-benchmark-home-")
    os.environ["HOME"] = sandbox_home
    started = time.perf_counter()
    report: dict[str, Any] = {
        "benchmark_version": BENCHMARK_VERSION,
        "benchmark_runner_sha256": hashlib.sha256(RUNNER_PATH.read_bytes()).hexdigest(),
        "started_at": datetime.now(timezone.utc).isoformat(),
        "source_revision": args.source_revision,
        "source_tree_sha256": _tree_digest(source_root),
        "cases_sha256": hashlib.sha256(CASES_PATH.read_bytes()).hexdigest(),
        "source_root_label": args.label,
        "host": {"platform": platform.platform(), "python": platform.python_version(),
                 "cpu_count": os.cpu_count(), "rss_peak_bytes_start": _rss_bytes()},
        "model_config": {"backend": args.backend, "model_filename": Path(args.model).name if args.model else None,
                 "model_file_size_bytes": Path(args.model).expanduser().stat().st_size if args.backend == "gguf" and args.model and Path(args.model).is_file() else None,
                 "model_sha256_provided": args.model_sha256.lower() or None,
                 "model_sha256_status": "user-supplied, not runner-verified" if args.model_sha256 else "not supplied",
                 "role_model_assignments": [
                     {"role": item.split("=", 1)[0],
                      "model": (Path(item.split("=", 1)[1]).name if args.backend == "gguf" else item.split("=", 1)[1])}
                     for item in args.role_model
                 ],
                 "served_model_id": args.served_model if args.backend == "local-server" else None,
                         "local_server_url": args.endpoint if args.backend == "local-server" else None,
                         "context": args.context, "context_chars": args.context_chars,
                         "threads": args.threads, "gpu_layers": args.gpu_layers,
                         "max_tokens": args.max_tokens, "backend_temperature_fallback": args.temperature,
                         "council_temperature_by_phase": {
                             "analysis": 0.15, "followup_research": 0.1, "planning": 0.1,
                             "answer_synthesis": 0.12, "candidate": 0.15, "candidate_review": 0.08,
                             "final_vote": 0.04,
                         },
                         "token_budgets": {"analysis": 1500, "followup_research": 450,
                                            "planning": 1000, "candidate": args.max_tokens,
                                            "candidate_review": 1800, "final_vote": 900},
                         "peer_workers": args.peer_workers},
        "model_quality_status": "NOT_RUN" if (not args.model and args.backend == "gguf") or args.suite == "host" else "REVIEW_REQUIRED",
        "repeat_count": args.repeat, "host_checks": [], "model_cases": [],
        "score_policy": cases["scoring"],
    }
    if args.suite in {"all", "host"}:
        report["host_checks"] = _run_host_checks(source_root)
    if args.suite in {"all", "model"}:
        report["model_cases"] = _run_model_cases(args, source_root, cases)
    report["elapsed_seconds"] = time.perf_counter() - started
    report["host"]["rss_peak_bytes_end"] = _rss_bytes()
    report["host"]["rss_peak_delta_bytes"] = (
        max(0, report["host"]["rss_peak_bytes_end"] - report["host"]["rss_peak_bytes_start"])
        if report["host"]["rss_peak_bytes_end"] is not None and report["host"]["rss_peak_bytes_start"] is not None else None
    )
    # Report repeat-run variability without pretending unreviewed model output has a correctness score.
    grouped_trials: dict[str, list[dict[str, Any]]] = {}
    for trial in report["model_cases"]:
        grouped_trials.setdefault(str(trial.get("id", "")), []).append(trial)
    report["model_trial_summary"] = {
        case_id: {
            "trials": len(rows),
            "review_required": sum(row.get("status") == "REVIEW_REQUIRED" for row in rows),
            "wall_seconds_median": median(float(row["wall_seconds"]) for row in rows
                                           if isinstance(row.get("wall_seconds"), (int, float)))
                if any(isinstance(row.get("wall_seconds"), (int, float)) for row in rows) else None,
            "correctness": None,
            "repeat_indices": [row.get("repeat_index") for row in rows],
            "note": "Repeated samples are retained for blind independent scoring; no model self-score is treated as ground truth.",
        } for case_id, rows in grouped_trials.items()
    }
    report["host_score"] = {
        "passed": sum(item["status"] == "PASS" for item in report["host_checks"]),
        "total": len(report["host_checks"]),
        "accuracy": (sum(item["status"] == "PASS" for item in report["host_checks"]) / len(report["host_checks"])) if report["host_checks"] else None,
    }
    report["limitations"] = [
        "Host checks measure implemented deterministic contracts, not model intelligence.",
        "Model cases require blind human scoring against their saved independent criteria; confidence and answer length do not add correctness points.",
        "Actual generated token counts and accelerator memory are not available through every backend and remain null/unmeasured.",
        "A model run is stochastic; use --repeat to collect independent samples and report variability. Record exact model files/hashes and runtime versions. Supplied hashes are not verified by this runner, and role-model hashes are not computed automatically.",
    ]
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(report, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    print(json.dumps({"output": str(args.output), "host_score": report["host_score"],
                      "model_quality_status": report["model_quality_status"],
                      "elapsed_seconds": report["elapsed_seconds"],
                      "rss_peak_delta_bytes": report["host"]["rss_peak_delta_bytes"]}, indent=2))
    return 0 if all(item["status"] == "PASS" for item in report["host_checks"]) else (1 if report["host_checks"] else 0)


if __name__ == "__main__":
    raise SystemExit(main())