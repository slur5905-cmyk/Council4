"""Static checks for the embedded LAN companion page and its authentication shape."""
from __future__ import annotations
import ast
from html.parser import HTMLParser
from pathlib import Path
import re
import subprocess
import tempfile

ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / "offline_coder" / "mobile.py"


class PageChecks(HTMLParser):
    def __init__(self) -> None:
        super().__init__(convert_charrefs=True)
        self.ids: list[str] = []
        self.labels: list[str] = []
        self.scripts: list[str] = []
        self._in_script = False
        self._script_parts: list[str] = []

    def handle_starttag(self, tag, attrs):
        values = dict(attrs)
        if values.get("id") is not None:
            self.ids.append(str(values["id"]))
        if tag == "label" and values.get("for"):
            self.labels.append(str(values["for"]))
        if tag == "script":
            self._in_script = True
            self._script_parts = []

    def handle_data(self, data):
        if self._in_script:
            self._script_parts.append(data)

    def handle_endtag(self, tag):
        if tag == "script" and self._in_script:
            self.scripts.append("".join(self._script_parts))
            self._in_script = False


def main() -> int:
    module = ast.parse(SOURCE.read_text(encoding="utf-8"))
    page_value = None
    for node in module.body:
        if isinstance(node, ast.Assign) and any(isinstance(t, ast.Name) and t.id == "PAGE" for t in node.targets):
            page_value = ast.literal_eval(node.value)
            break
    if not isinstance(page_value, str):
        raise SystemExit("Could not extract the mobile companion PAGE constant.")
    check = PageChecks()
    check.feed(page_value)
    duplicates = sorted({value for value in check.ids if check.ids.count(value) > 1})
    missing = sorted(set(check.labels) - set(check.ids))
    if duplicates:
        raise SystemExit("Mobile page duplicate IDs: " + ", ".join(duplicates))
    if missing:
        raise SystemExit("Mobile page labels have no matching IDs: " + ", ".join(missing))
    if len(check.scripts) != 1:
        raise SystemExit(f"Expected one inline mobile-page script; found {len(check.scripts)}")
    with tempfile.NamedTemporaryFile("w", suffix=".js", encoding="utf-8") as stream:
        stream.write(check.scripts[0])
        stream.flush()
        subprocess.run(["node", "--check", stream.name], check=True, capture_output=True, text=True)
    guards = {
        "token comes from URL fragment": "new URLSearchParams(location.hash.slice(1))",
        "token removed from history": "history.replaceState(null,'',location.pathname+location.search)",
        "API uses Authorization header": "headers={'Authorization':'Bearer '+token}",
        "token is not appended to API query strings": "fetch(path+'?token=" not in page_value,
        "localhost is the default bind": bool(re.search(r'def serve\(host="127\.0\.0\.1",\s*port=8765', SOURCE.read_text(encoding="utf-8"))),
        "LAN use requires explicit bind": 'p.add_argument("--host",default="127.0.0.1")' in SOURCE.read_text(encoding="utf-8"),
        "restrictive content security policy is present": "Content-Security-Policy" in SOURCE.read_text(encoding="utf-8"),
        "mobile uses shared desktop model router": "build_model_router(settings)" in SOURCE.read_text(encoding="utf-8"),
        "mobile does not hard-code GGUF-only loading": "LocalModel(model_path" not in SOURCE.read_text(encoding="utf-8"),
        "handler concurrency is bounded": "class BoundedThreadingHTTPServer" in SOURCE.read_text(encoding="utf-8"),
        "plaintext LAN binding requires an explicit opt-in": "--allow-insecure-lan" in SOURCE.read_text(encoding="utf-8"),
        "HTTPS certificate support exists": "tls_context.load_cert_chain" in SOURCE.read_text(encoding="utf-8"),
        "request and failed-authentication rate limits exist": "auth_failure_limiter.allow" in SOURCE.read_text(encoding="utf-8") and "request_limiter.allow" in SOURCE.read_text(encoding="utf-8"),
        "POST action limits run after authorization": SOURCE.read_text(encoding="utf-8").index("if not self.authorized():return") < SOURCE.read_text(encoding="utf-8").index("if not self.endpoint_allowed(path): return"),
    }
    failed = [name for name, ok in guards.items() if not ok]
    if failed:
        raise SystemExit("Mobile safety guard failed: " + "; ".join(failed))
    print(f"Mobile companion: JavaScript syntax OK; {len(check.ids)} unique IDs; labels resolve; auth and localhost-default guards OK.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
