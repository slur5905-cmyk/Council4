#!/usr/bin/env python3
"""Compare two manually scored Council intelligence benchmark reports.

This is deliberately strict: benchmark cases must be scored by a human (the runner saves
correct=None), the case suite/model configuration must match, the candidate source tree must
be different, and every candidate host check must PASS before the result is eligible for
human-approved future evaluation. It does not deploy or edit a Council version.
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parents[1]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from offline_coder.self_improvement import ImprovementLab


def load(path: Path) -> dict:
    value = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        raise ValueError(f"Benchmark report must contain a JSON object: {path}")
    return value


def _scored_accuracy(report: dict) -> tuple[float, int, dict[tuple[str, int], bool]]:
    cases = report.get("model_cases")
    if not isinstance(cases, list) or not cases:
        raise ValueError("Both reports must contain model_cases from the same model benchmark suite.")
    values: list[float] = []
    keyed: dict[tuple[str, int], bool] = {}
    for index, case in enumerate(cases):
        if not isinstance(case, dict) or not isinstance(case.get("correct"), bool):
            raise ValueError("Every compared model trial must have a human-entered boolean 'correct' score.")
        case_id = str(case.get("id", ""))
        repeat_index = case.get("repeat_index", 1)
        if not case_id or type(repeat_index) is not int or repeat_index < 1:
            raise ValueError("Every scored model trial needs a case ID and positive repeat_index.")
        key = (case_id, repeat_index)
        if key in keyed:
            raise ValueError(f"Duplicate scored model trial: {key}.")
        keyed[key] = bool(case["correct"])
        values.append(1.0 if case["correct"] else 0.0)
    return sum(values) / len(values), len(values), keyed


def compare(baseline: dict, candidate: dict) -> dict:
    for key in ("benchmark_version", "cases_sha256", "benchmark_runner_sha256"):
        if baseline.get(key) != candidate.get(key):
            raise ValueError(f"Reports do not use the same {key}.")
    if baseline.get("model_config") != candidate.get("model_config"):
        raise ValueError("Model/runtime configuration differs; this comparison cannot isolate a Council code change.")
    if baseline.get("repeat_count", 1) != candidate.get("repeat_count", 1):
        raise ValueError("Reports use different repeat counts.")
    base_hash = baseline.get("source_tree_sha256")
    candidate_hash = candidate.get("source_tree_sha256")
    if not isinstance(base_hash, str) or len(base_hash) != 64 or not isinstance(candidate_hash, str) or len(candidate_hash) != 64:
        raise ValueError("Both reports need source_tree_sha256 values.")
    if base_hash == candidate_hash:
        raise ValueError("Baseline and candidate source trees are identical.")
    baseline_accuracy, baseline_count, base_trials = _scored_accuracy(baseline)
    candidate_accuracy, candidate_count, candidate_trials = _scored_accuracy(candidate)
    if base_trials.keys() != candidate_trials.keys():
        raise ValueError("Baseline and candidate trial IDs/repeat indices do not match.")
    host_checks = candidate.get("host_checks")
    if not isinstance(host_checks, list) or not host_checks:
        host_status = "NOT_RUN"
    elif all(isinstance(item, dict) and item.get("status") == "PASS" for item in host_checks):
        host_status = "PASSED"
    elif any(isinstance(item, dict) and item.get("status") == "FAIL" for item in host_checks):
        host_status = "FAILED"
    else:
        host_status = "UNAVAILABLE"
    paired = [{"id": case_id, "repeat_index": repeat, "baseline_correct": base_trials[(case_id, repeat)],
               "candidate_correct": candidate_trials[(case_id, repeat)]}
              for case_id, repeat in sorted(base_trials)]
    return {
        "baseline_accuracy": baseline_accuracy,
        "candidate_accuracy": candidate_accuracy,
        "baseline_trials": baseline_count,
        "candidate_trials": candidate_count,
        "paired_trials": len(paired),
        "delta": candidate_accuracy - baseline_accuracy,
        "host_status": host_status,
        "baseline_source_sha256": base_hash,
        "candidate_source_sha256": candidate_hash,
        "same_model_config": True,
        "same_benchmark_suite": True,
        "same_benchmark_runner": True,
        "same_repeat_count": True,
        "human_scored_trials": True,
        "evidence": {
            "baseline_revision": baseline.get("source_revision"),
            "candidate_revision": candidate.get("source_revision"),
            "baseline_started_at": baseline.get("started_at"),
            "candidate_started_at": candidate.get("started_at"),
            "candidate_host_checks": host_checks,
            "paired_trial_scores": paired,
        },
    }


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--baseline", type=Path, required=True)
    parser.add_argument("--candidate", type=Path, required=True)
    parser.add_argument("--title", default="Council self-improvement comparison")
    parser.add_argument("--hypothesis", default="Candidate Council source performs better on the same human-scored benchmark.")
    parser.add_argument("--output", type=Path, default=None)
    parser.add_argument("--no-record", action="store_true", help="Compare and report without recording an experiment in local Council memory.")
    args = parser.parse_args()
    try:
        baseline = load(args.baseline.expanduser())
        candidate = load(args.candidate.expanduser())
        result = compare(baseline, candidate)
        eligible = result["delta"] > 0 and result["host_status"] == "PASSED"
        result["status"] = "eligible_for_human_review" if eligible else "not_qualified"
        result["policy"] = "Paired human-scored task accuracy across repeated trials must improve and every candidate host check must pass. This experiment is not a proof of general intelligence and cannot auto-deploy a self-modification."
        if not args.no_record:
            lab = ImprovementLab()
            experiment_id = lab.record_experiment(
                title=args.title, hypothesis=args.hypothesis,
                baseline_score=result["baseline_accuracy"], candidate_score=result["candidate_accuracy"],
                benchmark_suite=str(baseline.get("benchmark_version", "unknown")) + ":" + str(baseline.get("cases_sha256", "")),
                baseline_hash=result["baseline_source_sha256"], candidate_hash=result["candidate_source_sha256"],
                test_status=result["host_status"], evidence=result["evidence"],
            )
            result["experiment_id"] = experiment_id
            result["recorded_in_local_lab"] = True
        else:
            result["recorded_in_local_lab"] = False
        output = json.dumps(result, indent=2, ensure_ascii=False) + "\n"
        if args.output:
            args.output.expanduser().write_text(output, encoding="utf-8")
        print(output)
        return 0 if eligible else 2
    except (OSError, ValueError, json.JSONDecodeError) as exc:
        parser.error(str(exc))
    return 2


if __name__ == "__main__":
    raise SystemExit(main())
