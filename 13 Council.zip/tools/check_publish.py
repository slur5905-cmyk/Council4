#!/usr/bin/env python3
"""Fail a static-site build if likely secrets or machine-local paths are published."""
from __future__ import annotations

import re
import sys
from pathlib import Path

PATTERNS = [
    ("GitHub token", re.compile(r"\bgh[pousr]_[A-Za-z0-9]{20,}\b")),
    ("OpenAI-style API key", re.compile(r"\bsk-(?:ant-)?[A-Za-z0-9_-]{24,}\b")),
    ("AWS access key ID", re.compile(r"\bAKIA[0-9A-Z]{16}\b")),
    ("private-key block", re.compile(r"-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----")),
    ("Linux home path", re.compile(r"/home/[A-Za-z0-9_.-]+/")),
    ("macOS home path", re.compile(r"/Users/[A-Za-z0-9_.-]+/")),
    ("Windows user profile", re.compile(r"[A-Za-z]:\\Users\\[^\\\s]+", re.I)),
]


def main() -> int:
    if len(sys.argv) != 2:
        raise SystemExit("Usage: python tools/check_publish.py SITE_DIRECTORY")
    root = Path(sys.argv[1]).resolve()
    if not root.is_dir():
        raise SystemExit(f"Site directory does not exist: {root}")
    problems: list[str] = []
    entries = list(root.rglob("*"))
    symlinks = [p for p in entries if p.is_symlink()]
    problems.extend(f"{p.relative_to(root)}: symlink is not allowed in the publish tree" for p in symlinks)
    files = [p for p in entries if p.is_file() and not p.is_symlink()]
    for path in files:
        try:
            if path.stat().st_size > 10 * 1024 * 1024:
                problems.append(f"{path.relative_to(root)}: unexpectedly large static asset")
                continue
            data = path.read_bytes()
            try:
                content = data.decode("utf-8")
            except UnicodeDecodeError:
                continue
            for label, pattern in PATTERNS:
                match = pattern.search(content)
                if match:
                    problems.append(f"{path.relative_to(root)}: possible {label} (match redacted)")
        except OSError as exc:
            problems.append(f"{path.relative_to(root)}: could not inspect ({type(exc).__name__})")
    if problems:
        raise SystemExit("Static publish scan failed:\n- " + "\n- ".join(problems))
    print(f"Static publish scan passed: {len(files)} files checked; no configured secret/path patterns found.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
