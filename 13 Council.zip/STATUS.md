# Project Status

**Product:** Offline Coding Council  
**Version:** 1.7.0  
**Status date:** 2026-11-07  
**Release class:** Experimental, private-use, manual-apply only

## Council Browser additions (1.7.0)

- Added an optional Playwright Chromium browser and a desktop control panel.
- Added public-HTTP(S)-only navigation, DNS/private-address blocking, bounded page text/control inspection, click/fill/select actions, and an explicit approval callback for form entry and button/form actions.
- Disabled downloads and persistence of browser cookies/storage; no file-upload or arbitrary JavaScript API is exposed.
- Added a shared-observation handoff to the next four-peer Council run and role-specific observation prompt helper.
- Added policy tests for URL restrictions, consequential-action gating, and declarative workflow storage.
- Install the optional browser dependency with `pip install -e ".[browser]"`, then `playwright install chromium`.

## Verified in this build environment

- Original Python 3.13.5 suite result from v1.6.3: **253 passed; 76 subtests passed**.\n- New Council Browser policy suite: **7 passed; 11 subtests passed**.
- Python source compilation: passed (`compileall`).
- iPhone app JavaScript syntax/export checks: passed.
- Universal browser app: JavaScript syntax, compact knowledge payload, 66 unique IDs, labels, preview sandbox, and manual-search checks passed.
- Browser logic: **8 checks passed**.
- Phone companion: JavaScript syntax, 12 unique IDs, labels, authentication, and localhost-default checks passed.
- Static publish scan: passed on the 5-file local Pages output tree.
- Node 22 CLI behavior checked locally: `--` safely terminates option parsing before script paths.
- Desktop communication, self-edit, host-policy, model-routing, lazy model-manager, and scheduled-CI behavior are covered by the Python tests.

## Implemented controls

- Four peer roles can ask questions, request investigations, challenge code, contribute components, preserve unresolved discussions, and record provisional lessons for human review.
- Default model truth is **one underlying model plus four role prompts**. Separate local model assignments are supported; GGUF models load on demand with a configurable resident-model limit.
- Peer votes and model reviews are advisory. Host-side path, secret, hash, and candidate checks determine manual Apply eligibility. Unattended Apply is forced off, including legacy saved settings.
- Self-edit is default-deny and allowlisted to documentation and curated knowledge. Application, networking, process, test-runner, model, and permission-control files remain protected.
- Project-controlled Python and Node test output is marked untrusted and cannot authorize Apply.
- Web research is off by default. A user must enter and confirm the exact query before any external search request.
- Mobile Apply requires typing `APPLY` and entering a single-use code printed in the server terminal.
- Optional telemetry, SQLite memory, and checkpoints are off by default. The default database cap when enabled is 128 MiB.
- GitHub Actions runs the deterministic CI suite weekly (Sunday 18:00 UTC) as well as on pushes and pull requests. The scheduled run includes the Python matrix, model-runtime import, and Docker fixture job. GitHub Pages deployment remains limited to qualifying main-branch pushes and waits for all required jobs and the static publish scan. Workflow actions are pinned to full commit SHAs.

## Not verified in this environment

- No real GGUF model weights were configured or loaded; the 12 model-quality benchmark cases remain `NOT_RUN`.
- The optional `llama-cpp-python` installation/import job is configured in CI but was not run locally.
- Docker is unavailable locally. Actual Docker-backed Python/Node fixtures and container isolation therefore remain unverified here; CI is configured to fail closed if Docker is unavailable.
- Python 3.10, 3.11, and 3.12 are in the CI matrix but were not run locally. This local run used Python 3.13.5.
- The new weekly GitHub Actions schedule has not yet executed against the user's repository; it becomes active after this workflow is pushed to the default branch and Actions is enabled. GitHub Actions and Pages deployment have not otherwise been run against the user's repository in this environment.
- Real Playwright browser navigation and interaction were not executed in this build environment; only browser-policy tests were run.\n- The browser is currently integrated into the desktop Tk app; the iPhone/browser companion does not yet include Council Browser.\n- Windows, macOS, physical iPhone/iPad behavior, and real device inference performance were not verified.

## Security and operating limits

- Not ready for shared-LAN use, public hosting of the desktop/mobile server, or unattended model-driven writes to host/security/authority files. Scheduled CI is unattended test execution only; it does not load private local model weights, repair source, grant the Council repository write access, or deploy from a schedule event.
- Mobile's one-time Apply code is an extra confirmation, not a guarantee against hostile local processes, XSS, or unsafe networks. Keep the mobile service bound to localhost unless you separately secure the network.
- Disposable project tests are useful diagnostics, not host-owned test attestations. Their text cannot prove they passed.
- The browser companion is a separate small-model experience; its first model load requires internet access for runtime and model downloads. It is not equivalent to the desktop Council.
- A public release still needs an intentional license and a real vulnerability-reporting contact.

**Bottom line:** This is a local-first experimental coding assistant with useful role-based review and manual write controls. It is not four independent AIs by default, is not security-certified, and is not verified for unattended or shared-network use.
